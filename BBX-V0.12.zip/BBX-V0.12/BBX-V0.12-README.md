# BBX-V0.12 — 主辦索引陣列格式修復

本版只更新 Firebase Hosting 靜態前端，保持 Firebase 專案 `ljt-beyblade-x` 既有 9 支 V0.11 Cloud Functions、Realtime Database Rules 及資料 **完全不變**。

## 故障原因

`userEvents/{uid}` 由數字索引 `0`、`1`、`2` 組成。Realtime Database SDK / REST 可將其轉成 JSON Array；V0.11 新增的 `indexedOwnerSlots` 卻把 Array 視為不合法，使已存在三場賽事的主辦清單陷入 `read_failed`。

## 修正

- 接受有效的 RTDB 數字槽 Array 與 Object，仍拒絕純量或其他錯誤型態。
- 為完整 Array、稀疏 Array、錯誤資料加入單元回歸測試。
- 更新前端與觀眾端靜態資源名為 `v012`，重新計算 SHA-256 短雜湊，避免舊瀏覽器資源快取混淆。
- 雲端 Functions API 名 `bbxV011*`、賽事 `releaseTag` 與 `authorityBBXV011` **刻意保留**，是既有 V0.11 賽事協定，不可為顯示版本升級而改名或重新部署。
- 全部原有賽程、裁判、抽籤、SSE、Rules 程式由既有測試與後端 byte-for-byte 雜湊驗證保護。

## 部署

將完整 `BBX-V0.12.zip` 上傳到 `rkomrz/Beyblade-X` main 根目錄。使用附在 ChatGPT 回覆中的單段 Cloud Shell 指令；內含 SHA-256 完整檔案驗證。`bash 00_start.sh` 自動執行本機程式測試，僅部署 Hosting，不改動 Functions / Rules / 資料庫。

重要：前端修正不等於已經完成 Safari 與 Chrome 的實機驗收；需部署後確認同一 Firebase UID 下顯示三場賽事。
