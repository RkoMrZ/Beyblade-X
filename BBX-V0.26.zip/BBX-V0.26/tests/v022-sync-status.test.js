const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ui=fs.readFileSync(path.join(__dirname,'../assets/index-v026.js'),'utf8');
const css=fs.readFileSync(path.join(__dirname,'../assets/index-v026.css'),'utf8');
const part=ui.slice(ui.indexOf('function listenCloudEvent(id){'),ui.indexOf('async function waitForAuthRestore('));
test('compact hidden status and click-only detailed explanation',()=>{
 assert.match(part,/wrapper.classList.toggle\('hidden',!message\)/);
 assert.match(part,/button.addEventListener\('click'/);
 assert.match(part,/button.setAttribute\('aria-expanded','false'\)/);
 assert.match(css,/\.bbxSyncStatusButton\{/);
 assert.doesNotMatch(part,/style.cssText='margin:10px 16px/);
});
test('command sequence does not cause a false missing-delta alarm',()=>{
 assert.match(part,/commandSeq=Math\.max\(commandSeq,Number\(s\.val\(\)\)\|\|0\)/);
 assert.doesNotMatch(part,/missing-match-delta/);
});
test('healthy projection and connection automatically release the write gate',()=>{
 assert.match(part,/if\(!active\(\)\|\|!connected\|\|!streamReady\|\|streamFault\|\|!publicationReady\)return/);
 assert.match(part,/cloudResyncBlocked=false;status\(''\)/);
 assert.match(part,/setHealthy\(\)/);
});
test('genuine stale-state write prevention remains',()=>{
 assert.match(ui,/if\(cloudResyncBlocked\)throw new Error/);
 assert.match(part,/cloudResyncBlocked=true/);
});
