'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const ui=fs.readFileSync(path.join(__dirname,'../assets/index-v026.js'),'utf8');
function section(start){const pos=ui.indexOf(start);assert.ok(pos!==-1,start);let at=pos+start.length,depth=1;for(;at<ui.length&&depth;at++){if(ui[at]==='{')depth++;if(ui[at]==='}')depth--;}return ui.slice(pos,at)}
const code=section('function normalizeRefereeClaimsData(raw){')+'\n'+section('function normalizeRefereeClaims(){')+'\n'+section('function refereeClaimKey(index){')+'\n'+section('function getRefereeClaim(index){');
function run(raw){const context=vm.createContext({ev:{refereeClaims:raw}});vm.runInContext(code,context);return vm.runInContext('({one:getRefereeClaim(0),two:getRefereeClaim(1),all:normalizeRefereeClaims()})',context)}
test('dense Firebase index array retains first referee identity',()=>{let a=run([{uid:'judge-a',name:'裁判 1',claimedAt:100}]);assert.equal(a.one.uid,'judge-a');assert.equal(Object.keys(a.all).length,1)});
test('sparse Firebase index array retains original slot indices',()=>{let a=run([null,{uid:'judge-b',name:'裁判 2',claimedAt:200}]);assert.equal(a.one,null);assert.equal(a.two.uid,'judge-b');assert.equal(Object.keys(a.all).join(','),'1')});
test('Firebase keyed object retains claims unchanged',()=>{let raw={'0':{uid:'judge-a',name:'裁判 1',claimedAt:100}};let a=run(raw);assert.equal(a.one.uid,'judge-a')});
test('missing claims yield empty state without fabricated slot',()=>{let a=run(null);assert.equal(a.one,null);assert.equal(Object.keys(a.all).length,0)});
test('entry normalization does not clear arrays, live listener updates referee view',()=>{assert.match(ui,/ev\.refereeClaims=normalizeRefereeClaimsData\(ev\.refereeClaims\);/);assert.match(ui,/onValue\(`refereeClaims\/\$\{id\}`,[\s\S]*?renderReferee\(\{skipCloudRefresh:true\}\)/);assert.match(ui,/refereeClaimsStreamRevision\+\+/)});
test('organizer distinguishes global claims from its own local selection',()=>{assert.match(ui,/全場裁判領取狀態/);assert.match(ui,/與其他裁判領取狀態分開/);assert.match(ui,/這支主辦手機尚未選擇裁判身分；不代表其他裁判尚未領取/)});
test('server claim permission is unchanged; no direct claim without UID and ETag guard',()=>{assert.match(ui,/headers:\{'X-Firebase-ETag':'true'\}/);assert.match(ui,/'if-match':etag/);assert.match(ui,/if\(res.status===412\)return false/)});
