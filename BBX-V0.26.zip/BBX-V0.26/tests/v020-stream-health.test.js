const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ui=fs.readFileSync(path.join(__dirname,'../assets/index-v026.js'),'utf8');
const viewer=fs.readFileSync(path.join(__dirname,'../assets/viewer-v026.js'),'utf8');
const section=ui.slice(ui.indexOf('function listenCloudEvent(id){'),ui.indexOf('async function waitForAuthRestore('));
test('referee and organizer subscribe to the same private event authority',()=>{
 assert.match(section,/onValue\(`refereeClaims\/\$\{id\}`/);
 assert.match(section,/onValue\(`events\/\$\{id\}\/authoritySeq`/);
 assert.match(section,/onChildren\(`events\/\$\{id\}\/rounds\/\$\{ri\}\/matches`/);
});
test('match deltas redraw the entire bracket without forcing a tab switch',()=>{
 assert.match(section,/if\(changed\)lastMatchDelivery=Date\.now\(\)|onValue\(`events\/\$\{id\}\/publishedMatchHints`/);
 assert.match(section,/renderAdmin\(\{bracketOnly:true\}\)/);
 assert.match(ui,/bracketViewAfterRender\(bracketView\)/);
});
test('cancelled listeners retry with bounded backoff and no deletions',()=>{
 assert.match(section,/retryListeners\(path\)/);
 assert.match(section,/Math\.min\(14000/);
 assert.doesNotMatch(section,/purgeLocalEvent\(/);
});
test('only projected watermark detects missed scoreboard changes',()=>{
 assert.match(section,/events\/\$\{id\}\/publishedSeq/);
 assert.match(section,/onValue\(`events\/\$\{id\}\/authoritySeq`/);
 assert.doesNotMatch(section,/rtdbRestGet\(`events\/\$\{id\}\/authoritySeq`/);
 assert.match(section,/watchdogTimer=setInterval\(watchdog,30000\)/);
});
test('claims remain a separate subscribed channel',()=>{
 assert.match(section,/onValue\(`refereeClaims\/\$\{id\}`/);
 assert.match(section,/renderReferee\(\{skipCloudRefresh:true\}\)/);
});
test('unsubscribing cancels coalescing and connection repair',()=>{
 assert.match(section,/clearTimeout\(reconcileTimer\)/);
 assert.match(section,/clearInterval\(watchdogTimer\)/);
 assert.match(section,/if\(epoch===cloudListenerEpoch\)cloudListenerEpoch\+\+/);
});
test('viewer retains SSE and watches only small public sequence for missed events',()=>{
 assert.match(viewer,/new EventSource\(streamUrl\(kind,id\)\)/);
 assert.match(viewer,/meta\/authoritySeq\.json/);
 assert.match(viewer,/scheduleReconnectResync\(kind,id,'viewer-missed-sequence'\)/);
});
