'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v026.js'),'utf8');
const code=src.slice(src.indexOf('function listenCloudEvent(id){'),src.indexOf('async function waitForAuthRestore('));
function make(){
 const paths=new Map(),renders=[];let fullReads=0,matchReads=0;
 const first={a:'A',b:'B',sa:0,sb:0,winner:null,refereeActive:false,referee:'',matchVersion:1};
 const ev={id:'E0',rounds:[{matches:[first]}],roster:['A','B'],refereeClaims:{},publishedSeq:0};
 const node=()=>({classList:{contains:()=>false,add(){},remove(){},toggle(){}},getAttribute:()=>null,setAttribute(){},addEventListener(){},append(){},prepend(){},after(){},querySelector:()=>node(),textContent:''});
 const obj={console,Date,JSON,Number,Map,setTimeout,clearTimeout,setInterval,clearInterval,
   cloudReady:true,ev,isAdmin:true,isReferee:false,cloudUnsub:null,cloudListenerEpoch:0,
   currentAdminTab:'bracket',cloudEventsCache:{},cloudResyncBlocked:false,liveRetryAttempts:new Map(),refereeClaimsStreamRevision:0,
   document:{visibilityState:'visible',createElement:()=>node()}, fbDb:{ref(p){const x=paths.get(p)||{};paths.set(p,x);return {on(t,f){x[t]=f},off(t,f){if(x[t]===f)delete x[t]}}}},
   $:()=>node(),
   renderAdmin:x=>renders.push(x),renderReferee:()=>{},listenPublicProjectionEvent:()=>{},
   isV1Authority:()=>false,v05ScorePending:()=>false,
   normalizeRefereeClaimsData:v=>v||{},
   rtdbRestGet:async p=>{if(p==='events/E0'){fullReads++;return {...ev,rounds:[{matches:[{...first}]}],publishedSeq:2};}if(p.includes('/matches/'))matchReads++;return null;}
 };
 vm.createContext(obj);vm.runInContext(code,obj);
 const emit=(p,t,v)=>{const f=paths.get(p)?.[t];assert.equal(typeof f,'function',p);f({key:String(v?.key??0),val:()=>v?.payload??v,exists:()=>v!==null});};
 obj.listenCloudEvent('E0');emit('.info/connected','value',true);emit('events/E0/publishedSeq','value',0);
 return {obj,emit,renders,first,close:()=>obj.cloudUnsub(),counts:()=>({fullReads,matchReads})};
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
test('unchanged initial child_added snapshots never repaint an already current match',async()=>{
 const h=make();h.emit('events/E0/rounds/0/matches','child_added',{key:0,payload:{...h.first}});
 await sleep(190);assert.equal(h.renders.length,0);h.close();
});
test('one live match score results in one coalesced render without a REST GET',async()=>{
 const h=make();const score={...h.first,sa:3,matchVersion:2};
 h.emit('events/E0/rounds/0/matches','child_changed',{key:0,payload:score});
 h.emit('events/E0/rounds/0/matches','child_changed',{key:0,payload:score});
 await sleep(220);assert.equal(h.renders.length,1);assert.deepEqual(h.counts(),{fullReads:0,matchReads:0});h.close();
});
test('watermark and matching hint do NOT trigger a redundant full GET',async()=>{
 const h=make();h.emit('events/E0/publishedSeq','value',2);
 h.emit('events/E0/publishedMatchHints','value',{seq:2,matches:{r0_0:{version:1,refereeActive:false,referee:'',winner:null,sa:0,sb:0}}});
 await sleep(1000);assert.deepEqual(h.counts(),{fullReads:0,matchReads:0});h.close();
});
test('watermark without hint issues a single coalesced full snapshot repair',async()=>{
 const h=make();h.emit('events/E0/publishedSeq','value',2);h.emit('events/E0/publishedSeq','value',2);
 await sleep(1250);assert.equal(h.counts().fullReads,1);h.close();
});
