'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v028.js'),'utf8');
const listen=src.slice(src.indexOf('function listenCloudEvent(id){'),src.indexOf('async function waitForAuthRestore('));
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const event=()=>({id:'EV123456',rounds:[{matches:[
 {a:'A',b:'B',sa:0,sb:0,matchVersion:1,refereeActive:false,referee:''},
 {a:'C',b:'D',sa:0,sb:0,matchVersion:1,refereeActive:false,referee:''}
 ]}],roster:['A','B','C','D'],refereeClaims:{},publishedSeq:0,refereeNames:['裁判 1','裁判 2']});
function harness(role){
 const paths=new Map(),draws=[], reads=[];
 const n=()=>({classList:{contains:()=>false,toggle(){},add(){},remove(){}},append(){},prepend(){},after(){},querySelector:()=>n(),getAttribute:()=>null,setAttribute(){},addEventListener(){},textContent:''});
 const admin=n();
 const context={console,Date,JSON,Number,Map,Set,setTimeout,clearTimeout,setInterval,clearInterval,
  ev:event(),cloudReady:true,isAdmin:role==='organizer',isReferee:role==='referee',cloudUnsub:null,cloudListenerEpoch:0,
  cloudResyncBlocked:false,cloudEventsCache:{},liveRetryAttempts:new Map(),liveTransportRecoveryAt:new Map(),refereeClaimsStreamRevision:0,currentAdminTab:'bracket',
  document:{visibilityState:'visible',createElement:n},
  $:id=>id==='admin'?admin:null,
  fbDb:{ref(p){let x=paths.get(p);if(!x){x=new Map();paths.set(p,x)}return {
   on(type,cb){x.set(type,cb)},off(type,cb){if(x.get(type)===cb)x.delete(type)}
  }}},
  normalizeRefereeClaimsData:data=>Array.isArray(data)?Object.fromEntries(data.map((x,i)=>[i,x]).filter(([,x])=>!!x)):(data||{}),
  v05ScorePending:()=>false,rtdbRestGet:async p=>{reads.push(p);return p.endsWith('publishedSeq')?0:null},
  renderAdmin:o=>draws.push(o),renderReferee:()=>draws.push({referee:true}),listenPublicProjectionEvent(){}
 };
 vm.createContext(context);vm.runInContext(listen,context);context.listenCloudEvent('EV123456');
 const emit=(p,type,payload,key='0')=>{
  const cb=paths.get(p)?.get(type);assert.equal(typeof cb,'function',p+':'+type);
  cb({key,val:()=>payload,exists:()=>payload!==null});
 };
 emit('.info/connected','value',true);emit('events/EV123456/publishedSeq','value',0);
 return {context,emit,draws,reads,close:()=>context.cloudUnsub()};
}
test('judge-to-owner and owner-to-judge live changes are symmetric and do not need page reload',async()=>{
 const owner=harness('organizer'),judge=harness('referee');
 try{
  const path='events/EV123456/rounds/0/matches';
  const fromJudge={a:'A',b:'B',sa:2,sb:0,matchVersion:2,refereeActive:true,referee:'裁判 1'};
  for(const h of [owner,judge])h.emit(path,'child_changed',fromJudge,'0');
  await delay(140);
  assert.equal(owner.context.ev.rounds[0].matches[0].sa,2);assert.equal(judge.context.ev.rounds[0].matches[0].sa,2);
  const fromOwner={a:'C',b:'D',sa:0,sb:3,matchVersion:2,refereeActive:true,referee:'裁判 2'};
  for(const h of [owner,judge])h.emit(path,'child_changed',fromOwner,'1');
  await delay(140);
  assert.equal(owner.context.ev.rounds[0].matches[1].sb,3);assert.equal(judge.context.ev.rounds[0].matches[1].sb,3);
  assert.equal(owner.reads.filter(p=>p==='events/EV123456').length,0);
  assert.equal(judge.reads.filter(p=>p==='events/EV123456').length,0);
 }finally{owner.close();judge.close()}
});
test('one referee switching matches clears old highlight on both clients even at equal version',async()=>{
 const owner=harness('organizer'),judge=harness('referee');
 try{
  const p='events/EV123456/rounds/0/matches';
  const active={a:'A',b:'B',sa:0,sb:0,matchVersion:1,refereeActive:true,referee:'裁判 1'};
  for(const h of [owner,judge])h.emit(p,'child_changed',active,'0');
  const released={...active,refereeActive:false,referee:'',matchVersion:2};
  for(const h of [owner,judge])h.emit(p,'child_changed',released,'0');
  await delay(140);
  assert.equal(owner.context.ev.rounds[0].matches[0].refereeActive,false);
  assert.equal(judge.context.ev.rounds[0].matches[0].refereeActive,false);
 }finally{owner.close();judge.close()}
});
test('live claim array is visible in owner/referee without opening tab again',()=>{
 const owner=harness('organizer'),judge=harness('referee');
 try{
  owner.context.currentAdminTab='referee';
  const claims=[{uid:'A',name:'裁判 1',claimedAt:1}];
  owner.emit('refereeClaims/EV123456','value',claims);
  judge.emit('refereeClaims/EV123456','value',claims);
  assert.equal(owner.context.ev.refereeClaims[0].uid,'A');
  assert.equal(judge.context.ev.refereeClaims[0].uid,'A');
  assert.ok(owner.draws.some(x=>x.referee));
 }finally{owner.close();judge.close()}
});
test('a cancelled subscription cannot modify another event or write a stale card',async()=>{
 const owner=harness('organizer');
 const old=owner.context.ev.rounds[0].matches[0];
 const cb=owner.context.fbDb.ref('events/EV123456/rounds/0/matches');
 owner.close();
 // the RTDB handler was removed by the single session cleanup; no polling can revive it.
 assert.equal(owner.context.cloudResyncBlocked,false);
 assert.equal(owner.context.ev.rounds[0].matches[0],old);
});
