const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ui=fs.readFileSync(path.join(__dirname,'../assets/index-v028.js'),'utf8');
const css=fs.readFileSync(path.join(__dirname,'../assets/index-v028.css'),'utf8');
const part=ui.slice(ui.indexOf('function listenCloudEvent(id){'),ui.indexOf('async function waitForAuthRestore('));
test('compact hidden status and click-only detailed explanation',()=>{
 assert.match(part,/el.classList.toggle\('hidden',!msg\)/);
 assert.match(part,/btn.addEventListener\('click'/);
 assert.match(part,/btn.setAttribute\('aria-expanded','false'\)/);
 assert.match(css,/\.bbxSyncStatusButton\{/);
 assert.doesNotMatch(part,/style.cssText='margin:10px 16px/);
});
test('command sequence does not cause a false missing-delta alarm',()=>{
 assert.match(part,/ev.authoritySeq=Math.max\(Number\(ev.authoritySeq\)\|\|0,Number\(s.val\(\)\)\|\|0\)/);
 assert.doesNotMatch(part,/missing-match-delta/);
});
test('healthy projection and connection automatically release the write gate',()=>{
 assert.match(part,/if\(!active\(\)\|\|!connected\|\|!ready\|\|failed\)return/);
 assert.match(part,/cloudResyncBlocked=false;status\(''\)/);
 assert.match(part,/healthy\(\)/);
});
test('genuine stale-state write prevention remains',()=>{
 assert.match(ui,/if\(cloudResyncBlocked\)throw new Error/);
 assert.match(part,/cloudResyncBlocked=true/);
});
