#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.28 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.28 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.28 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v028.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v028-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
# This release changes only the browser synchronization recovery layer.
# Never redeploy a backend or RTDB Rules for a client-only change.
gcloud auth print-access-token >/dev/null
echo "PASS: Cloud Functions and RTDB Rules unchanged"
bash deploy/hosting-v028.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.28 Hosting ONLY deployed and verified; Functions, Rules and saved events untouched.\n'
# Only remove recoverable local old build folders once the new release succeeded.
cd "$HOME"
for old in BBX-V0.5 BBX-V0.6 BBX-V0.7 BBX-V0.8 BBX-V0.9 BBX-V0.10 BBX-V0.11 BBX-V0.12 BBX-V0.13 BBX-V0.14 BBX-V0.15 BBX-V0.16 BBX-V0.17 BBX-V0.18 BBX-V0.19 BBX-V0.20 BBX-V0.21 BBX-V0.22 BBX-V0.23 BBX-V0.24 BBX-V0.25; do
 [[ -d "$old" && -f "$old/MANIFEST.json" ]] || continue
 rm -rf -- "$old"
done
