#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.16 deployment is already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.16 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.16 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/BBX-V0.16-檢查.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v016-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
gcloud auth print-access-token >/dev/null
# New auto-format requires server-owned bracket allocation. Deploy dependencies
# BEFORE Hosting so an old browser can continue while new HTML is prepared.
echo '=== Updating ONLY CreateAuthority and OrganizerAuthority functions ==='
npm install --prefix functions --no-audit --no-fund --package-lock=false
[[ -d functions/node_modules/firebase-functions ]] || { echo 'STOP: firebase-functions not installed';exit 3; }
firebase deploy --only functions:bbxV011CreateAuthority,functions:bbxV011OrganizerAuthority --config firebase.json --project ljt-beyblade-x --non-interactive
# All other Cloud Functions, Rules and RTDB event records remain untouched.
echo '=== Updating bbxs-tamsui Hosting ==='
bash deploy/BBX-V0.16-Hosting.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.16 deployed and verified: Create+Organizer Functions and Hosting ONLY; RTDB Rules and saved events untouched.\n'
