#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re,zipfile,shutil
r=Path(__file__).resolve().parents[1];output=r.parent/'BBX-V0.16.zip'
# Fingerprint every served asset using its exact content; stale Safari cannot
# use a previous URL after changes to script or style.
for f in (r/'assets').iterdir():
 if re.fullmatch(r'(?:index|viewer)-v016-[0-9a-f]{12}\.(?:js|css)',f.name):f.unlink()
for name in ('index','viewer'):
 for ext in ('js','css'):
  src=r/'assets'/f'{name}-v016.{ext}'
  fingerprint=hashlib.sha256(src.read_bytes()).hexdigest()[:12]
  target=src.with_name(f'{name}-v016-{fingerprint}.{ext}')
  shutil.copy2(src,target)
  page=r/f'{name}.html'
  html=page.read_text()
  pattern=rf'assets/{name}-v0(?:15|16)-[0-9a-f]{{12}}\.{ext}'
  assert len(re.findall(pattern,html))==1,(name,ext)
  html=re.sub(pattern,'assets/'+target.name,html)
  page.write_text(html)
# The original HTML/JS and new QA scripts are audited as one release.
manifest_file=r/'MANIFEST.json'
old=json.loads(manifest_file.read_text())
untouched=['functions/bbx-v011-publication.js','functions/bbx-v011-cleanup.js','functions/bbx-v011-lifecycle.js', 'functions/package.json','database.rules.json']
manifest={
 'project_id':'BBX-V0.16','previous_release':'BBX-V0.15',
 'firebase_project':'ljt-beyblade-x','database_instance':'ljt-beyblade-x-default-rtdb',
 'hosting_site':'bbxs-tamsui','release_status':'PREDEPLOY_TEST_REQUIRED (auto BYE and viewport fixes)',
 'functions_exports':old['functions_exports'],
 'functions_deploy_only':['bbxV011CreateAuthority','bbxV011OrganizerAuthority'],
 'untouched_backend_hashes':{f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in untouched},
 'files':[]}
for f in sorted(r.rglob('*')):
 if not f.is_file() or f==manifest_file or any(x in f.parts for x in ['node_modules','hosting-public','__pycache__']) or f.name in ['release.log','start.log','.release-completed','.release.lock'] or f.name.endswith('.pyc'):
  continue
 # Only hashed assets are delivered to clients. Source files kept in ZIP for audit.
 data=f.read_bytes()
 manifest['files'].append({'path':str(f.relative_to(r)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest_file.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(r.rglob('*')):
  if not f.is_file() or any(x in f.parts for x in ['node_modules','hosting-public','__pycache__']) or f.name in ['release.log','start.log','.release-completed','.release.lock'] or f.name.endswith('.pyc'):
   continue
  z.write(f,arcname=f'{r.name}/{f.relative_to(r)}')
print('BUNDLE',output,'BYTES',output.stat().st_size,'SHA256',hashlib.sha256(output.read_bytes()).hexdigest())
