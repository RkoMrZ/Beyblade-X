戰鬥陀螺線上報名 / V8.4 正備選順位伺服器修正版
適用 Firebase 專案：ljtreg-39954
更新依據：已部署之 V8.1 後端 + V8.2 signup.html + V8.3 主辦後台

這次處理的問題
1. 選手報名後 signup.html 不再 GET /publicRowsV8/<event>.json，也不再下載其他選手資料。
2. reg8Submit 於已完成報名後，直接回傳 {signupNo, rankLabel, rank, position, status}；報名成功視窗當場顯示。
3. 新增 reg8MyRank：只憑本人不可猜測的 48 位十六進位收據 rid 查詢此人的最新順位；沒有收據者無法查表。沒有在報名成功後額外呼叫此端點。
4. 新活動在 rankActiveV8/<event>/<p號> 記錄簡短 true 旗標。報名、拒絕、恢復、刪除選手都透過同一次原子多節點更新，維持一致。
5. 伺服器計算本人順位時只需讀取之前的有效順位布林旗標（不讀姓名或 LINE）。當活動為舊 V8 結構、缺少 rankIndexed 時，伺服器內部相容性讀取之前的公開選手資料，瀏覽器仍不下載整份資料。
6. 公開查詢 status.html 原有的首次取回單場名單、後續即時分流同步方式不變。主辦 index.html 保留 V8.3，不覆蓋。

注意：
- 已提交並取得原始報名序號的選手，可能因更早取得序號的人稍晚完成提交，或主辦修改審核狀態，而變更有效正備選順位。以公開查詢表最新狀態為準。
- 函式部署前，舊 reg8Submit 不會回傳 rankLabel。請先部署新版 Functions，再覆蓋 GitHub /reg/signup.html。
- Firebase Rules 不需要變動：rankActiveV8 節點仍由根節點拒絕所有客戶端讀寫，僅 Admin SDK 可以操作。
- reg8MyRank 是新的 Cloud Function，必須部署。
- 本次沒有改動 V6 資料、V8.3 主辦頁、status.html 或另一個賽程表 Firebase 專案。

ZIP 內檔案：
 reg_v8_preflight/functions/index.js                  改良的 Functions
 reg_v8_preflight/functions/tests/smoke.test.js       記憶體 64 人及順位測試
 reg_v8_preflight/functions/tests/emulator.integration.js  實際 RTDB 模擬器測試（需要 Cloud Shell 跑）
 reg_v8_preflight/functions/tests/rules.static.test.js  靜態 Rules 檢查
 reg_v8_preflight/reg/signup.html                    選手報名網頁（唯一需要替換的 HTML）

手機操作：
 A. 將本 ZIP 原樣上傳 GitHub Repo Beyblade-X 的根目錄，檔名固定 reg-v8-rankfix.zip。
 B. Cloud Shell 終端機每次從 ~ 開始，執行下方「測試」完整指令。
 C. 必須出現 PASS RANK INDEX、PASS RTDB EMULATOR、TEST_EXIT_CODE=0 後，才執行「正式部署」指令。
 D. 將 ZIP 裡的 reg/signup.html 覆蓋 GitHub /Beyblade-X/reg/signup.html。不要覆蓋根目錄 index.html。

測試（請整行貼上）：
cd ~ && if [ ! -f ~/reg_v8_preflight/functions/index.js.before-rankfix ]; then cp ~/reg_v8_preflight/functions/index.js ~/reg_v8_preflight/functions/index.js.before-rankfix; fi && curl -fLsS -o reg-v8-rankfix.zip https://raw.githubusercontent.com/rkomrz/Beyblade-X/main/reg-v8-rankfix.zip && unzip -oq reg-v8-rankfix.zip -d ~ && cd ~/reg_v8_preflight && nvm install 22 && nvm use 22 && node --check functions/index.js && node functions/tests/smoke.test.js && node functions/tests/rules.static.test.js && timeout -k 10s 360s firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'; echo TEST_EXIT_CODE=$?

正式部署（測試成功後才執行；只部署指定 6 個 V8 API）：
cd ~/reg_v8_preflight && nvm install 22 && nvm use 22 && firebase deploy --only functions:registration:reg8CreateEvent,functions:registration:reg8Submit,functions:registration:reg8Review,functions:registration:reg8DeleteEntry,functions:registration:reg8DeleteEvent,functions:registration:reg8MyRank --project ljtreg-39954

上線驗收：
1. 建立一場全新正選 2 人活動。
2. 使用至少兩個瀏覽器／裝置，讓 3 人依序成功報名（同一瀏覽器仍限制 2 次）：應顯示正選#1、正選#2、備選#1；瀏覽器不會讀取 publicRowsV8 整場資料。
3. 主辦將第一位標記不通過：第三位應成為正選#2。
4. 主辦恢復第一位通過：第三位應恢復備選#1。
5. 主辦刪除第二位：第三位應成為正選#2。
6. 公開查詢頁仍應隨審核操作即時更新。
7. 既有 V8 活動資料仍可使用，新活動使用更精簡的布林順位索引。

測試結果：
 本地 JavaScript 語法 PASS、64 筆記憶體模擬 PASS、順位拒絕/恢復/刪除 PASS、舊 V8 相容 PASS、Rules 靜態 PASS。
 Chromium 320/390/768/1440px 測試 PASS，確認報名後只呼叫後端報名 API，不下載 publicRowsV8。
 本次修正版「真正 RTDB Emulator」仍須 Cloud Shell 執行確認；不應在未確認前直接正式部署。
