'use strict';
// In-memory deterministic simulation, NOT real Firebase Emulator or pressure testing.
const assert=require('node:assert/strict'),Module=require('node:module'),path=require('node:path');
const state={},clone=x=>x===undefined?undefined:structuredClone(x);let q=Promise.resolve(),pushNo=0,failRootUpdate=null,nullOnlyTransactions=0;const activeListeners=new Map();
const keys=p=>String(p).split('/').filter(Boolean);
const get=p=>clone(keys(p).reduce((c,k)=>c?.[k],state));
function set(p,v){const a=keys(p);if(!a.length)throw Error('root');let cur=state;for(const k of a.slice(0,-1))cur=cur[k]??={};if(v===null||v===undefined)delete cur[a.at(-1)];else cur[a.at(-1)]=clone(v)}
function snap(v){return {val:()=>clone(v),exists:()=>v!==null&&v!==undefined,hasChild:k=>v!=null&&Object.hasOwn(v,k),numChildren:()=>Object.keys(v||{}).length}}
function ref(p=''){return {
 orderByKey(){const rows=()=>Object.entries(get(p)||{}).sort(([a],[b])=>a.localeCompare(b));return {
  limitToFirst:n=>({get:async()=>snap(Object.fromEntries(rows().slice(0,n)))}),
  limitToLast:n=>({get:async()=>snap(Object.fromEntries(rows().slice(-n)))}),
  endAt:k=>({get:async()=>snap(Object.fromEntries(rows().filter(([key])=>key<=k)))})
 }},
 child:k=>ref(p+'/'+k),push(){return {key:'-chg'+String(++pushNo).padStart(16,'0')}},async get(){return snap(get(p))},
 on(type,callback){assert.equal(type,'value');const listeners=activeListeners.get(p)||new Set();listeners.add(callback);activeListeners.set(p,listeners);queueMicrotask(()=>callback(snap(get(p))));return callback},
 off(type,callback){const listeners=activeListeners.get(p);if(listeners){listeners.delete(callback);if(!listeners.size)activeListeners.delete(p)}},
 async update(up){
 const failure=p===''?failRootUpdate:null;
 if(failure){failRootUpdate=null;if(failure==='before')throw Error('injected: server rejected before commit')}
 // RTDB multi-location update is atomic; the fake must preserve that property.
 const backup=clone(state);
 try{for(const [k,v] of Object.entries(up))set(p?(p+'/'+k):k,v)}catch(e){for(const k of Object.keys(state))delete state[k];Object.assign(state,backup);throw e}
 if(failure==='after')throw Error('injected: response lost after server commit');
 },transaction(fn){const job=q.then(()=>{const cur=get(p)??null;
 if(cur!==null&&!activeListeners.has(p)){
  // Model RTDB cold cache: aborting the speculative null means no server retry.
  const guess=fn(null);if(guess===undefined)return {committed:false,snapshot:snap(cur)};
 }
 const output=fn(clone(cur));if(output===undefined)return {committed:false,snapshot:snap(cur)};set(p,output);return {committed:true,snapshot:snap(output)}});q=job.catch(()=>{});return job}}}

class HttpsError extends Error{constructor(code,message){super(message);this.code=code}}
const load=Module._load;
Module._load=function(id,parent,main){if(id==='firebase-functions/v2/https')return {onCall:(_,f)=>f,HttpsError};if(id==='firebase-admin/app')return {initializeApp:()=>{},getApps:()=>[{}]};if(id==='firebase-admin/database')return {getDatabase:()=>({ref})};return load.apply(this,arguments)};
const api=require(path.join(__dirname,'../index.js'));Module._load=load;
const owner={auth:{uid:'owner',token:{firebase:{sign_in_provider:'google.com'}}}},other={auth:{uid:'other',token:{firebase:{sign_in_provider:'google.com'}}}},guest={auth:null};
let cid=0;const call=(n,data,as=owner)=>api[n]({...as,data:n==='reg8CreateEvent'&&!data.createId?{...data,createId:(++cid).toString(16).padStart(48,'0')}:data});
(async()=>{
 const event={title:'金魚盃',eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'體育館',fee:0,capacity:32};
 const idFirst='f'.repeat(48);const {eid}=await call('reg8CreateEvent',{...event,createId:idFirst});
 const replayCreate=await call('reg8CreateEvent',{...event,createId:idFirst});assert.equal(replayCreate.eid,eid);assert.equal(replayCreate.replayed,true);
 await assert.rejects(call('reg8CreateEvent',{...event,createId:idFirst,title:'錯誤重送名稱'}),/已使用不同的活動資料/);
 assert.equal(get(`allocV8/${eid}/rankIndexed`),true);assert.equal(get(`allocV8/${eid}/next`),0);assert.equal(get(`ownerEventsV8/owner/${eid}/title`),'金魚盃');
 await assert.rejects(call('reg8UpdateEvent',{eid,...event,expectedVersion:1},other),/權限/);
 const rid=i=>i.toString(16).padStart(48,'0');
 const form=i=>({eid,rid:rid(i),playerName:'選手 '+i,phone3:'093',lineName:'同一 LINE'});
 const results=await Promise.all(Array.from({length:64},(_,i)=>call('reg8Submit',form(i+1),guest)));
 assert.deepEqual(results.map(x=>x.signupNo).sort((a,b)=>a-b),Array.from({length:64},(_,i)=>i+1));
 assert.equal(Object.keys(get(`publicRowsV8/${eid}`)).length,64);
 assert.equal(Object.keys(get(`rankActiveV8/${eid}`)).length,64);
 const receiptForNo=n=>Object.entries(get(`receiptsV8/${eid}`)).find(([,r])=>r.signupNo===n)[0];
 const selfRank=n=>call('reg8MyRank',{eid,rid:receiptForNo(n)},guest);
 assert.equal((await selfRank(33)).rankLabel,'備選#1');
 await assert.rejects(call('reg8MyRank',{eid,rid:'e'.repeat(48)},guest),/找不到這筆報名/);
 await call('reg8CreateEvent',{...event,createId:idFirst});assert.equal(get(`allocV8/${eid}/next`),64,'retrying event creation must NOT reset the allocator');assert.equal(Object.keys(get(`nameClaimsV8/${eid}`)).length,64);
 assert.equal(get(`publicRowsV8/${eid}/p00000001/lineName`),undefined);
 assert.equal(get(`privateRowsV8/${eid}/p00000001/lineName`),'同一 LINE');
 assert.equal((await call('reg8Submit',form(1),guest)).signupNo,1);
 await assert.rejects(call('reg8Submit',{...form(65),playerName:'選手 1',phone3:'777',lineName:'其他 LINE'},guest),/比賽名稱/);
 // Normalized Unicode and case variants must not bypass the name uniqueness index.
 await assert.rejects(call('reg8Submit',{...form(65),playerName:'選手　1',phone3:'777'},guest),/比賽名稱/);
 const raceEvent=await call('reg8CreateEvent',{...event,title:'並發同名測試'});
 const contest=await Promise.allSettled([
   call('reg8Submit',{eid:raceEvent.eid,rid:rid(301),playerName:'只有一位',phone3:'093',lineName:'甲'},guest),
   call('reg8Submit',{eid:raceEvent.eid,rid:rid(302),playerName:'只有一位',phone3:'222',lineName:'乙'},guest)
 ]);
 assert.equal(contest.filter(x=>x.status==='fulfilled').length,1,'concurrent identical playerName cannot both commit');
 assert.equal(Object.keys(get(`publicRowsV8/${raceEvent.eid}`)).length,1);
 // Fault injection: atomic write fails before commit, retry can recover safely.
 const faultEvent=(await call('reg8CreateEvent',{...event,title:'斷線測試'})).eid;
 const faultReq={eid:faultEvent,rid:rid(555),playerName:'離線仍能重試',phone3:'093',lineName:'LINE'};
 failRootUpdate='before';await assert.rejects(call('reg8Submit',faultReq,guest),/injected/);
 assert.equal(get(`publicRowsV8/${faultEvent}`),undefined,'no partial roster after failed atomic patch');
 const afterFail=await call('reg8Submit',faultReq,guest);assert.equal(afterFail.confirmed,true);
 assert.equal(Object.keys(get(`publicRowsV8/${faultEvent}`)).length,1);
 // Fault injection: write COMMITTED but HTTP response lost. Retry returns the one receipt.
 const afterCommitReq={eid:faultEvent,rid:rid(556),playerName:'回應遺失仍不重複',phone3:'093',lineName:'LINE'};
 failRootUpdate='after';await assert.rejects(call('reg8Submit',afterCommitReq,guest),/injected/);
 const afterCommit=await call('reg8Submit',afterCommitReq,guest);assert.equal(afterCommit.confirmed,true);
 assert.equal(Object.keys(get(`publicRowsV8/${faultEvent}`)).length,2);
 // A cold RTDB cache would initially return null without a listener;
 // transactionOnExisting temporarily attaches a listener to prime the value.
 const nullRetry=await call('reg8Submit',{eid:faultEvent,rid:rid(557),playerName:'第一次空值也應成功',phone3:'093',lineName:'LINE'},guest);
 assert.equal(nullRetry.confirmed,true);
 const newNo=await call('reg8Submit',{...form(65),playerName:'新選手',phone3:'093',lineName:'同一 LINE'},guest);
 assert.equal(newNo.signupNo,65);
 const rank=n=>Object.values(get(`publicRowsV8/${eid}`)).filter(x=>x.signupNo<=n&&x.status!=='rejected').length;
 await call('reg8Review',{eid,key:'p00000010',status:'rejected',expectedVersion:1});assert.equal(rank(33),32);
 assert.equal((await selfRank(33)).rankLabel,'正選#32');
 assert.equal((await selfRank(10)).rankLabel,null);
 assert.equal(get(`rankActiveV8/${eid}/p00000010`),undefined);
 await assert.rejects(call('reg8Review',{eid,key:'p00000010',status:'approved',expectedVersion:1}),/其他裝置修改/);
 await call('reg8Review',{eid,key:'p00000010',status:'approved',expectedVersion:2});assert.equal(rank(33),33);
 assert.equal((await selfRank(33)).rankLabel,'備選#1');
 assert.equal((await selfRank(10)).rankLabel,'正選#10');
 const oldName=get(`privateRowsV8/${eid}/p00000001/nameKey`);
 const edit=await call('reg8EditEntry',{eid,key:'p00000001',expectedVersion:1,playerName:'更名選手',phone3:'093',lineName:'更名 LINE'});
 assert.equal(edit.row.playerName,'更名選手');assert.equal(get(`privateRowsV8/${eid}/p00000001/lineName`),'更名 LINE');
 assert.equal(get(`nameClaimsV8/${eid}/${oldName}`),undefined);
 await assert.rejects(call('reg8EditEntry',{eid,key:'p00000002',expectedVersion:1,playerName:'更名選手',phone3:'123',lineName:'不同 LINE'}),/已被使用/);
 await call('reg8DeleteEntry',{eid,key:'p00000002',expectedVersion:1});
 assert.equal(get(`publicRowsV8/${eid}/p00000002`),undefined);
 assert.equal(get(`rankActiveV8/${eid}/p00000002`),undefined);
 assert.equal((await selfRank(33)).rankLabel,'正選#32');
 await assert.rejects(call('reg8Submit',form(2),guest),/已被移除/);
 await assert.rejects(call('reg8UpdateEvent',{eid,...event,capacity:24,expectedVersion:1}),/不可更改正選/);
 const updated=await call('reg8SetOpen',{eid,open:false,expectedVersion:1});assert.equal(updated.meta.open,false);
 await assert.rejects(call('reg8Submit',{...form(66),playerName:'關閉後報名'},guest),/未開放/);
 assert.ok(Object.keys(get(`changesV8/${eid}`)).length>=69);
 // Exercise opportunistic journal retention with many edits to existing single-row data.
 let rversion=get(`publicRowsV8/${eid}/p00000003/recordVersion`);
 for(let j=0;j<700;j++){
  const next=j%2?'pending':'approved';
  await call('reg8Review',{eid,key:'p00000003',status:next,expectedVersion:rversion++});
 }
 assert.ok(Object.keys(get(`changesV8/${eid}`)).length<500,'journal should compact older entries');
 assert.ok(get(`syncV8/${eid}`).token);
 const legacy='b'.repeat(24),lrid='c'.repeat(48);set(`eventStates/${legacy}`,{ownerUid:'owner',revision:1,nextNo:1,public:{...event,open:false,createdAt:111},registrations:{[lrid]:{rid:lrid,signupNo:1,playerName:'舊版玩家',phone3:'093',lineName:'測試名稱',status:'approved',recordVersion:1,createdAt:111}}});
 await assert.rejects(call('reg8MigrateV6',{eid:legacy},other),/權限/);
 const migration=await call('reg8MigrateV6',{eid:legacy});assert.equal(migration.migrated,1);assert.equal(get(`publicRowsV8/${legacy}/p00000001/playerName`),'舊版玩家');assert.ok(get(`eventStates/${legacy}`));
 // Deleting an active event first closes the gate; retry cleans up after leases end.
 set(`allocV8/${eid}/active`,{testActive:Date.now()+60000});
 await assert.rejects(call('reg8DeleteEvent',{eid}),/仍有操作處理中/);
 assert.equal(get(`allocV8/${eid}/deleted`),true);
 set(`allocV8/${eid}/active`,{});
 await call('reg8DeleteEvent',{eid});assert.equal(get(`publicRowsV8/${eid}`),undefined);assert.equal(get(`privateRowsV8/${eid}`),undefined);assert.equal(get(`ownerEventsV8/owner/${eid}`),undefined);
 assert.equal(get(`rankActiveV8/${eid}`),undefined);
 console.log('PASS RANK OPTIMIZATION: own-receipt rank, 64 concurrent submissions, reject/promote/restore, delete, compact index; PASS: V8 hardened / partial-failure-before-commit / response-lost-after-commit / repeatable create / change-journal-maintenance / delete-while-busy / V8 node split, 64 parallel simulated submissions, unique NAME only, shared phone/LINE allowed, receipt dedupe, version rejection, review/recover, edit claim, delete, owner isolation, V6 COPY migration');
})().catch(e=>{console.error(e);process.exitCode=1});
