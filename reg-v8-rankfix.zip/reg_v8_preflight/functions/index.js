'use strict';
// V8: node-scoped Firebase RTDB reads/writes. Separate public and private collections.
// Do NOT deploy to production before RTDB Emulator + concurrency and recovery tests.
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {initializeApp,getApps}=require('firebase-admin/app');
const {getDatabase}=require('firebase-admin/database');
const crypto=require('node:crypto');
// Runtime FIREBASE_CONFIG determines the database for the selected Firebase project.
if(!getApps().length)initializeApp();
const db=getDatabase(),REGION='asia-southeast1';
const settings={region:REGION,memory:'256MiB',timeoutSeconds:90,concurrency:16,maxInstances:8,minInstances:0,cors:['https://rkomrz.github.io',/^https?:\/\/localhost(?::\d+)?$/]};
const api=handler=>onCall(settings,handler);
const error=(code,msg)=>{throw new HttpsError(code,msg)};
const text=v=>typeof v==='string'?v.trim():'';
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
const hex=v=>crypto.randomBytes(v).toString('hex');
const checkEid=e=>{if(typeof e!=='string'||!/^[a-f0-9]{24}$/.test(e))error('invalid-argument','比賽代碼無效');return e};
const checkRid=r=>{if(typeof r!=='string'||!/^[a-f0-9]{48}$/.test(r))error('invalid-argument','提交代碼無效');return r};
const checkKey=k=>{if(typeof k!=='string'||!/^p\d{8}$/.test(k))error('invalid-argument','選手編號無效');return k};
const rowKey=n=>'p'+String(n).padStart(8,'0');
const path={event:e=>`eventsV8/${e}`,meta:e=>`eventsV8/${e}/meta`,owner:e=>`eventsV8/${e}/ownerUid`,allocator:e=>`allocV8/${e}`,claim:(e,h)=>`nameClaimsV8/${e}/${h}`,row:(e,k)=>`publicRowsV8/${e}/${k}`,priv:(e,k)=>`privateRowsV8/${e}/${k}`,receipt:(e,r)=>`receiptsV8/${e}/${r}`,change:e=>`changesV8/${e}`,sync:e=>`syncV8/${e}`,index:(u,e)=>`ownerEventsV8/${u}/${e}`,lock:(e,k)=>`rowLocksV8/${e}/${k}`,rank:e=>`rankActiveV8/${e}`,rankRow:(e,k)=>`rankActiveV8/${e}/${k}`};
const ref=p=>db.ref(p);
function google(req){if(!req.auth?.uid||req.auth?.token?.firebase?.sign_in_provider!=='google.com')error('unauthenticated','主辦需要 Google 登入');return req.auth.uid}
async function isOwner(e,uid){const val=(await ref(path.owner(e)).get()).val();if(!val)error('not-found','找不到新版活動');if(val!==uid)error('permission-denied','沒有這場比賽的管理權限')}
function inputMeta(v){const title=text(v?.title),eventDate=text(v?.eventDate),checkinTime=text(v?.checkinTime),startTime=text(v?.startTime),venue=text(v?.venue),fee=Number(v?.fee),capacity=Number(v?.capacity);
 if(!title||title.length>70||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(eventDate)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(checkinTime)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)||checkinTime>startTime||!venue||venue.length>150||!Number.isSafeInteger(fee)||fee<0||fee>1000000||!Number.isSafeInteger(capacity)||capacity<1||capacity>10000)error('invalid-argument','請填完整且正確的比賽設定');
 const d=new Date(eventDate+'T12:00:00+08:00');if(!Number.isFinite(d.getTime())||new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(d)!==eventDate)error('invalid-argument','比賽日期無效');return {title,eventDate,checkinTime,startTime,venue,fee,capacity}}
function inputPerson(v){const playerName=text(v?.playerName),phone3=text(v?.phone3),lineName=text(v?.lineName);if(!playerName||playerName.length>50||!/^[0-9]{3}$/.test(phone3)||!lineName||lineName.length>40)error('invalid-argument','比賽名稱、手機後三碼與 LINE 名稱均需填寫');return {playerName,phone3,lineName}}
// Unique PER EVENT PLAYER NAME. Phone last 3 digits and LINE display names MAY repeat.
function normalizedName(name){return text(name).normalize('NFKC').replace(/\s+/gu,' ').toLocaleLowerCase('zh-TW')}
function nameHash(name){return sha(normalizedName(name))}
function fingerprint(person){return sha(JSON.stringify([person.playerName,person.phone3,person.lineName]))}
// Prime the local SDK cache with a temporary server-side value listener.
// Otherwise an Admin RTDB transaction may optimistically receive null and
// abort before the server can return the existing value. Keep the listener
// only for the lifetime of this one transaction; browsers never subscribe.
async function transaction(r,fn,{mustExist=false}={}){
 let resolveReady,rejectReady;
 const ready=new Promise((resolve,reject)=>{resolveReady=resolve;rejectReady=reject});
 const listener=snapshot=>resolveReady(snapshot);
 let attached=false;
 try{
  r.on('value',listener,rejectReady);attached=true;
  const initial=await ready;
  if(mustExist&&!initial.exists())error('not-found','比賽不存在或已刪除');
  return await r.transaction(v=>{
   // Never recreate a removed allocator after a concurrent event deletion.
   if(mustExist&&(v===null||v===undefined))return;
   return fn(v);
  },undefined,false);
 }finally{if(attached)r.off('value',listener)}
}
async function transactionOnExisting(r,fn){return transaction(r,fn,{mustExist:true})}

const rev=()=>hex(8);
function changeFields(e,type,key=''){const id=ref(path.change(e)).push().key;return {[path.change(e)+'/'+id]:{type,key,at:Date.now()},[path.sync(e)]:{token:rev(),lastChange:id}}}
// Opportunistically compact the append-only public change journal. This runs
// only once per ~128 successful write operations per warm instance; the client
// falls back to a full snapshot if its cursor is older than the retained range.
let journalWrites=0;
async function maybeCompactChanges(e){
 if(++journalWrites%128!==0)return;
 try{
  const base=ref(path.change(e));
  const [old,newest]=await Promise.all([base.orderByKey().limitToFirst(200).get(),base.orderByKey().limitToLast(200).get()]);
  const oldestKeys=Object.keys(old.val()||{}),latestKeys=Object.keys(newest.val()||{});
  if(oldestKeys.length!==200||latestKeys.length!==200||oldestKeys.at(-1)>=latestKeys[0])return;
  const batch={};for(const key of oldestKeys)batch[path.change(e)+'/'+key]=null;
  await patch(batch);
 }catch(err){console.warn('change-journal-compaction-skipped',e,err?.message||err)}
}
function pruneActive(v){const now=Date.now(),active={};for(const [k,u]of Object.entries(v?.active||{}))if(Number(u)>now)active[k]=u;return active}
// The allocator holds only counters, switches and short-lived in-flight operation leases.
// It NEVER contains the participant roster or individual names.
async function leaseStart(e,token,{allowClosed=false}={}){const r=ref(path.allocator(e));let reason='';const result=await transactionOnExisting(r,v=>{if(!v){reason='比賽不存在';return}if(v.deleted){reason='比賽已刪除';return}if(v.configLock?.until>Date.now()){reason='正在更新活動設定，請稍後重試';return}if(!allowClosed&&!v.open){reason='目前未開放報名';return}const active=pruneActive(v);if(Object.keys(active).length>=128){reason='目前報名人數眾多，請稍後重新送出';return}active[token]=Date.now()+120000;return {...v,active}});
 if(!result.committed)error('failed-precondition',reason||'活動正在處理其他操作，請稍後重試');return result.snapshot.val()}
async function leaseEnd(e,token){const r=ref(path.allocator(e));try{await transaction(r,v=>{if(!v||!v.active?.[token])return;const active={...v.active};delete active[token];return {...v,active}})}catch(e){console.error('lease-release',e)}}
// Reserve a number AND an in-flight lease in the SAME small allocator transaction.
async function allocateWithLease(e,token){const r=ref(path.allocator(e));let reason='';const t=await transactionOnExisting(r,v=>{
 if(!v){reason='比賽不存在';return}if(v.deleted||!v.open){reason='目前未開放報名或活動已刪除';return}if(v.configLock?.until>Date.now()){reason='活動正在更新設定，請稍後再試';return}
 const active=pruneActive(v);if(Object.keys(active).length>=128){reason='目前報名較踴躍，請稍後再送出';return}if(v.next>=100000){reason='已達系統上限';return}
 // Event-wide soft throttle: allow at least 64 simultaneous legitimate requests,
 // but bound successful allocations during automated floods. Not a substitute for App Check.
 const now=Date.now(),minute=Math.floor(now/60000),rate=v.rate?.minute===minute?v.rate:{minute,count:0};
 if(rate.count>=240){reason='報名請求太集中，請稍後約一分鐘再試';return}
 active[token]=now+120000;return {...v,active,next:v.next+1,rate:{minute,count:rate.count+1}}
 });if(!t.committed)error('failed-precondition',reason||'取號失敗，請稍後重試');return t.snapshot.val().next}
// Configuration lock is separate from individual roster updates; prevent mixed open/capacity revisions.
async function configStart(e,expected){const r=ref(path.allocator(e)),token=hex(12);let reason='';const t=await transactionOnExisting(r,v=>{if(!v){reason='活動不存在';return}if(v.deleted){reason='活動已刪除';return}if(v.configLock?.until>Date.now()){reason='已有其他設定操作，請稍後重試';return}if(Object.keys(pruneActive(v)).length){reason='有人正在報名或審核，請稍後重試';return}if(v.version!==expected){reason='活動設定已被其他裝置更新';return}return {...v,active:{},configLock:{token,until:Date.now()+120000}}});if(!t.committed)error('failed-precondition',reason||'活動設定有變動');return {token,current:t.snapshot.val()}}
async function configStop(e,token){try{await transaction(ref(path.allocator(e)),v=>!v||v.configLock?.token!==token?undefined:{...v,configLock:null})}catch(ex){console.error('config-release',ex)}}
async function rowLock(e,k){const token=hex(12),r=ref(path.lock(e,k)),now=Date.now();const t=await transaction(r,v=>v&&v.until>now?undefined:{token,until:now+120000});if(!t.committed)error('aborted','這筆選手資料正在更新，請稍後再試');return token}
async function rowUnlock(e,k,token){try{await transaction(ref(path.lock(e,k)),v=>v?.token===token?null:undefined)}catch(ex){console.error('row-unlock',ex)}}
function summary(meta){return {title:meta.title,eventDate:meta.eventDate,venue:meta.venue,capacity:meta.capacity,open:meta.open,createdAt:meta.createdAt,updatedAt:meta.updatedAt}}
async function patch(updates){return db.ref().update(updates)}
// Lightweight server-only active-rank index. Values are booleans, never names,
// LINE handles, phone numbers, or receipt IDs. Only Functions write this index.
// A submission/review/delete atomically updates the row and rank flag together.
// Old V8 events without allocator.rankIndexed use server-only legacy fallback.
async function currentRank(e,signupNo){
 const key=rowKey(signupNo);
 const [allocatorSnap,rowSnap]=await Promise.all([
  ref(path.allocator(e)).get(),ref(path.row(e,key)).get()
 ]);
 const allocator=allocatorSnap.val(),row=rowSnap.val();
 if(!allocator||allocator.deleted||!row||row.signupNo!==signupNo)
  error('not-found','報名不存在或活動已刪除');
 if(row.status==='rejected')return {signupNo,status:'rejected',rank:null,rankLabel:null};
 let rank;
 if(allocator.rankIndexed===true){
  // Read only compact flags preceding this ticket; never download public/private roster.
  const flags=await ref(path.rank(e)).orderByKey().endAt(key).get();
  if(flags.hasChild(key))rank=flags.numChildren();
 }
 if(rank===undefined){
  // Pre-upgrade V8 activities may have existing registrations but no rank index.
  // The fallback happens INSIDE the server, never in the participant's browser.
  const prior=await ref(`publicRowsV8/${e}`).orderByKey().endAt(key).get();
  const v=prior.val()||{};
  const last=v[key];
  if(!last)error('not-found','報名不存在');
  if(last.status==='rejected')return {signupNo,status:'rejected',rank:null,rankLabel:null};
  rank=Object.values(v).filter(r=>r&&r.status!=='rejected'&&r.status!=='deleted').length;
 }
 const primary=rank<=allocator.capacity;
 return {signupNo,status:row.status,rank,position:primary?'primary':'waitlist',
  rankLabel:(primary?'正選#'+rank:'備選#'+(rank-allocator.capacity))};
}
// A successful registration must never be treated as failed because a later
// *read-only* rank lookup timed out; use the receipt on a retry if needed.
async function rankOrPending(e,no){
 try{return await currentRank(e,no)}catch(err){console.warn('rank-read-deferred',e,no,err?.message||err);
  return {signupNo:no,rank:null,rankLabel:null,rankPending:true}}
}
// Secret receipt (192-bit) is a bearer proof. This endpoint returns ONLY
// this person's compact status/rank; arbitrary callers cannot enumerate rows.
exports.reg8MyRank=api(async req=>{
 const eid=checkEid(req.data?.eid),rid=checkRid(req.data?.rid);
 const receipt=(await ref(path.receipt(eid,rid)).get()).val();
 if(!receipt)error('not-found','找不到這筆報名');
 return currentRank(eid,receipt.signupNo);
});

exports.reg8CreateEvent=api(async req=>{
 const uid=google(req),v=inputMeta(req.data),createId=checkRid(req.data?.createId);
 // Deterministic event ID + create-only transaction. A timed-out response can be retried
 // with the same createId without resetting a real event or creating a second event.
 const eid=sha(uid+':'+createId).slice(0,24),eRef=ref(path.event(eid)),now=Date.now();
 const meta={...v,open:true,version:1,createdAt:now,updatedAt:now};
 const t=await transaction(eRef,old=>old?undefined:{ownerUid:uid,meta});
 let actual=t.committed?{ownerUid:uid,meta}:t.snapshot.val();
 if(!actual)actual=(await eRef.get()).val();
 if(!actual||actual.ownerUid!==uid)error('permission-denied','活動建立識別衝突');
 for(const [k,value] of Object.entries(v))if(actual.meta?.[k]!==value)error('failed-precondition','這次建立請求已使用不同的活動資料，請重新建立');
 // The multi-location completion is retryable if interrupted after the create-only write.
 // Never overwrite an existing allocator (which may already contain real signups).
 const allocRef=ref(path.allocator(eid)),existing=(await allocRef.get()).val();
 if(!existing){
  const init=await transaction(allocRef,old=>old?undefined:{next:0,open:true,deleted:false,capacity:v.capacity,version:1,active:{},rankIndexed:true});
  if(!init.committed&&!init.snapshot.val())error('unavailable','活動初始化尚未完成，請重試同一次建立請求');
 }
 await patch({[path.index(uid,eid)]:summary(actual.meta)});
 // Only create a marker when missing; retries must not invalidate readers unnecessarily.
 const syncRef=ref(path.sync(eid));await transaction(syncRef,old=>old?undefined:{token:rev(),lastChange:''});
 return {eid,replayed:!t.committed};
});
exports.reg8UpdateEvent=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),v=inputMeta(req.data);await isOwner(eid,uid);const {token,current}=await configStart(eid,req.data?.expectedVersion);try{if(current.next>0&&v.capacity!==current.capacity)error('failed-precondition','已有選手報名，不可更改正選人數');const old=(await ref(path.meta(eid)).get()).val();if(!old)error('not-found','活動不存在');const meta={...old,...v,open:current.open,updatedAt:Date.now(),version:current.version+1};await patch({[path.meta(eid)]:meta,[path.index(uid,eid)]:summary(meta),[path.allocator(eid)+'/capacity']:v.capacity,[path.allocator(eid)+'/version']:meta.version,[path.allocator(eid)+'/configLock']:null,...changeFields(eid,'meta')});await maybeCompactChanges(eid);return {meta}}
 finally{await configStop(eid,token)}});
exports.reg8SetOpen=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),open=req.data?.open;if(typeof open!=='boolean')error('invalid-argument','請選擇開放或關閉報名');await isOwner(eid,uid);const {token,current}=await configStart(eid,req.data?.expectedVersion);try{const meta=(await ref(path.meta(eid)).get()).val();if(!meta)error('not-found','活動不存在');const next={...meta,open,version:current.version+1,updatedAt:Date.now()};await patch({[path.meta(eid)]:next,[path.index(uid,eid)]:summary(next),[path.allocator(eid)+'/open']:open,[path.allocator(eid)+'/version']:next.version,[path.allocator(eid)+'/configLock']:null,...changeFields(eid,'meta')});await maybeCompactChanges(eid);return {meta:next}}finally{await configStop(eid,token)}});
// Claim one name with an atomic transaction, THEN allocate a position, THEN commit
// public row + private row + receipt + claim + public revision with ONE multipath update.
exports.reg8Submit=api(async req=>{const eid=checkEid(req.data?.eid),rid=checkRid(req.data?.rid),person=inputPerson(req.data),fp=fingerprint(person),claimKey=nameHash(person.playerName),token=hex(12);
 const prior=(await ref(path.receipt(eid,rid)).get()).val();if(prior){const live=(await ref(path.allocator(eid)).get()).val();if(!live||live.deleted||!(await ref(path.row(eid,rowKey(prior.signupNo))).get()).exists())error('failed-precondition','這筆報名已被移除或活動已刪除');if(prior.fp!==fp)error('failed-precondition','相同提交代碼的報名內容不一致');return {...await rankOrPending(eid,prior.signupNo),confirmed:true,replayed:true}}
 const nameRef=ref(path.claim(eid,claimKey)),leaseMark=hex(12);let reserved=false,finished=false,gateLeased=false;try{
  const now=Date.now();const t=await transaction(nameRef,v=>{if(!v||(v.state==='processing'&&v.until<now))return {rid,fp,state:'processing',mark:leaseMark,until:now+120000};return});
  if(!t.committed){const old=(await nameRef.get()).val();if(old?.rid===rid&&old?.fp===fp&&old?.state==='done'){const receipt=(await ref(path.receipt(eid,rid)).get()).val();if(receipt&&(await ref(path.row(eid,rowKey(receipt.signupNo))).get()).exists())return {...await rankOrPending(eid,receipt.signupNo),confirmed:true,replayed:true}}
   if(old?.rid!==rid)error('already-exists','這場比賽已有相同的比賽名稱，請改用其他名稱');error('unavailable','相同報名請求仍在處理中，請稍後再試')}
  reserved=true;
  const signupNo=await allocateWithLease(eid,token),k=rowKey(signupNo),now2=Date.now();gateLeased=true;
  const c=(await nameRef.get()).val();if(c?.mark!==leaseMark||c?.rid!==rid)error('aborted','報名名稱占位已變動，請重新報名');
  const row={signupNo,playerName:person.playerName,phone3:person.phone3,status:'pending',recordVersion:1};
  // Never expose LINE contact or unpredictable receipt IDs in the public roster.
  const updates={[path.row(eid,k)]:row,[path.priv(eid,k)]:{...person,rid,createdAt:now2,nameKey:claimKey},[path.receipt(eid,rid)]:{signupNo,fp},[path.rankRow(eid,k)]:true,[path.claim(eid,claimKey)]:{rid,fp,state:'done',signupNo},...changeFields(eid,'row',k)};await patch(updates);finished=true;await maybeCompactChanges(eid);return {...await rankOrPending(eid,signupNo),confirmed:true};
 }catch(ex){if(reserved&&!finished){try{await transaction(nameRef,v=>v?.mark===leaseMark&&v?.state==='processing'?null:undefined)}catch{}}throw ex}finally{if(gateLeased)await leaseEnd(eid,token)}});
async function withRecord(e,uid,k,expected,action,{withPrivate=true}={}){await isOwner(e,uid);const token=hex(12);await leaseStart(e,token,{allowClosed:true});let rowToken;try{rowToken=await rowLock(e,k);const row=(await ref(path.row(e,k)).get()).val(),priv=withPrivate?(await ref(path.priv(e,k)).get()).val():null;if(!row||(withPrivate&&!priv))error('not-found','這位選手的報名資料已不存在');if(row.recordVersion!==expected)error('failed-precondition','選手已被其他裝置修改，請確認最新資料');return await action(row,priv)}finally{if(rowToken)await rowUnlock(e,k,rowToken);await leaseEnd(e,token)}}
exports.reg8Review=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),key=checkKey(req.data?.key),status=req.data?.status;if(!['pending','approved','rejected'].includes(status))error('invalid-argument','審核狀態無效');return withRecord(eid,uid,key,req.data?.expectedVersion,async (row)=>{if(row.status===status)return {row};const updated={...row,status,recordVersion:row.recordVersion+1};const updates={[path.row(eid,key)]:updated,...changeFields(eid,'review',key)};
 if((row.status==='rejected')!==(status==='rejected'))updates[path.rankRow(eid,key)]=status==='rejected'?null:true;
 await patch(updates);await maybeCompactChanges(eid);return {row:updated}},{withPrivate:false})});
exports.reg8EditEntry=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),key=checkKey(req.data?.key),person=inputPerson(req.data);return withRecord(eid,uid,key,req.data?.expectedVersion,async (row,priv)=>{
 const nextKey=nameHash(person.playerName),oldKey=priv.nameKey||nameHash(row.playerName),fp=fingerprint(person);let mark=null;
 if(nextKey!==oldKey){mark=hex(12);const now=Date.now();const t=await transaction(ref(path.claim(eid,nextKey)),v=>!v||(v.state==='processing'&&v.until<now)?{rid:priv.rid,fp,state:'processing',mark,until:now+120000}:undefined);if(!t.committed)error('already-exists','比賽名稱已被使用，請改用其他名稱')}
 let changed=false;try{const updated={...row,playerName:person.playerName,phone3:person.phone3,recordVersion:row.recordVersion+1};const changes={[path.row(eid,key)]:updated,[path.priv(eid,key)]:{...priv,...person,nameKey:nextKey},...changeFields(eid,'row',key)};if(nextKey!==oldKey){changes[path.claim(eid,nextKey)]={rid:priv.rid,fp,state:'done',signupNo:row.signupNo};changes[path.claim(eid,oldKey)]=null}
 await patch(changes);changed=true;await maybeCompactChanges(eid);return {row:updated,private:{...priv,...person,nameKey:nextKey}}}finally{if(mark&&!changed)try{await transaction(ref(path.claim(eid,nextKey)),v=>v?.mark===mark?null:undefined)}catch{}}})});
exports.reg8DeleteEntry=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),key=checkKey(req.data?.key);return withRecord(eid,uid,key,req.data?.expectedVersion,async (row,priv)=>{await patch({[path.row(eid,key)]:null,[path.rankRow(eid,key)]:null,[path.priv(eid,key)]:null,[path.claim(eid,priv.nameKey||nameHash(row.playerName))]:null,...changeFields(eid,'delete',key)});await maybeCompactChanges(eid);return {ok:true,key}})});
exports.reg8DeleteEvent=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid);await isOwner(eid,uid);const g=ref(path.allocator(eid));let busy=false;const t=await transactionOnExisting(g,v=>{if(!v)return;if(Object.keys(pruneActive(v)).length||v.configLock?.until>Date.now()){busy=true;return {...v,deleted:true,open:false,active:pruneActive(v)}}return {...v,deleted:true,open:false,active:{}}});if(!t.committed)error('failed-precondition','刪除前無法確認目前報名狀態');const meta=(await ref(path.meta(eid)).get()).val();if(meta)await patch({[path.meta(eid)+'/deleted']:true,[path.meta(eid)+'/open']:false});if(busy||Object.keys(pruneActive(t.snapshot.val())).length)error('failed-precondition','已暫停新的報名；仍有操作處理中，請稍後再按一次刪除');await patch({[path.event(eid)]:null,[path.allocator(eid)]:null,[`publicRowsV8/${eid}`]:null,[path.rank(eid)]:null,[`privateRowsV8/${eid}`]:null,[`nameClaimsV8/${eid}`]:null,[`receiptsV8/${eid}`]:null,[`rowLocksV8/${eid}`]:null,[path.sync(eid)]:null,[path.change(eid)]:null,[path.index(uid,eid)]:null});return {ok:true}});
// V6 conversion is opt-in and COPYING ONLY: original source stays untouched.
// Require V6 signups to be CLOSED before converting; different unique-name policy
// will reject any old rows that share normalized playerName.
exports.reg8MigrateV6=api(async req=>{
 const uid=google(req),eid=checkEid(req.data?.eid),old=(await ref('eventStates/'+eid).get()).val();
 if(!old)error('not-found','舊版比賽不存在');if(old.ownerUid!==uid)error('permission-denied','沒有舊活動權限');
 if(old.public?.open)error('failed-precondition','請先在 V6 主辦頁關閉報名，再執行轉換');
 const source=old.public||{},base=inputMeta(source),list=Object.values(old.registrations||{});
 if(list.length>500)error('failed-precondition','舊名單過大，需另外進行分批遷移');
 const lease=ref('migrationLocksV8/'+eid),migrationMark=hex(12),lock=await transaction(lease,v=>v&&v.until>Date.now()?undefined:{uid,mark:migrationMark,until:Date.now()+120000});
 if(!lock.committed)error('aborted','這場比賽正在轉換中');
 try{
  if((await ref(path.owner(eid)).get()).exists())error('already-exists','已經轉換過，請開啟 V8 活動');
  const names=new Set(),at=Date.now(),meta={...base,open:false,version:1,createdAt:source.createdAt||at,updatedAt:at};
  const next=Math.max(Number(old.nextNo)||0,...list.map(r=>Number(r.signupNo)||0),0);
  const updates={[path.event(eid)]:{ownerUid:uid,meta},[path.allocator(eid)]:{next,open:false,deleted:false,capacity:meta.capacity,version:1,rankIndexed:true},[path.index(uid,eid)]:summary(meta),[path.sync(eid)]:{token:rev(),lastChange:''}};
  for(const r of list){const person=inputPerson(r),rid=checkRid(r.rid),no=r.signupNo;
   if(!Number.isSafeInteger(no)||no<1||no>100000)error('failed-precondition','舊名單有無效報名順位');
   const nameKey=nameHash(person.playerName);
   if(names.has(nameKey))error('failed-precondition','舊名單有重複的參賽名稱；必須先人工確認，不能自動合併');names.add(nameKey);
   const key=rowKey(no),fp=fingerprint(person),status=['pending','approved','rejected'].includes(r.status)?r.status:'pending';
   updates[path.row(eid,key)]={signupNo:no,playerName:person.playerName,phone3:person.phone3,status,recordVersion:Number(r.recordVersion)||1};
   if(status!=='rejected')updates[path.rankRow(eid,key)]=true;
   updates[path.priv(eid,key)]={...person,rid,createdAt:r.createdAt||at,nameKey};
   updates[path.claim(eid,nameKey)]={rid,fp,state:'done',signupNo:no};updates[path.receipt(eid,rid)]={signupNo:no,fp};
  }
  // Compare legacy revision again; V6 must be closed and no concurrent modifications.
  if((await ref('eventStates/'+eid+'/revision').get()).val()!==old.revision)error('aborted','舊版名單在轉換期間被修改，請重試');
  await patch(updates);return {eid,migrated:list.length,originalRetained:true};
 }finally{await transaction(lease,v=>v?.mark===migrationMark?null:undefined).catch(()=>{})}
});

// V6 API kept unchanged while old sites/tabs transition. V7 was a candidate and never deployed.
Object.assign(exports,require('./legacy'));
