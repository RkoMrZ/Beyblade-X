#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == BBX-V0.6 ]] || { echo 'STOP: wrong release folder'; exit 2; }
python3 - <<'PYINNER'
import json
m=json.load(open('MANIFEST.json'))
assert m['project_id']=='BBX-V0.6' and m['firebase_project']=='ljt-beyblade-x'
assert len(m['functions_exports'])==9
assert all(name.startswith('bbxV06') for name in m['functions_exports'])
PYINNER
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v06-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: tests and Firebase Emulator not passed for this exact ZIP'; exit 3; }
for c in gcloud firebase node npm python3; do command -v "$c" >/dev/null || { echo "STOP: missing $c"; exit 3; }; done
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required'; exit 3; }
if ! gcloud auth print-access-token >/dev/null 2>&1; then
 mapfile -t A < <(gcloud auth list --format='value(account)' | sed '/^$/d')
 [[ ${#A[@]} == 1 ]] || { echo 'STOP: gcloud auth login required'; exit 3; }
 gcloud config set account "${A[0]}" --quiet
fi
gcloud auth print-access-token >/dev/null
P=ljt-beyblade-x
DB=ljt-beyblade-x-default-rtdb
gcloud config set project "$P" --quiet
[[ "$(python3 -c 'import json;print(json.load(open(".firebaserc"))["projects"]["default"])')" == "$P" ]] || { echo 'STOP: wrong Firebase project'; exit 3; }
echo '=== Deploy BBX-V0.6 new Functions ==='
npm --prefix functions install --no-audit --no-fund
FN='functions:bbxV06CreateAuthority,functions:bbxV06CommandAuthority,functions:bbxV06GetOperation,functions:bbxV06RepairPublication,functions:bbxV06PublishAuthority,functions:bbxV06OrganizerAuthority,functions:bbxV06DeleteAuthority,functions:bbxV06RepairQueue,functions:bbxV06AssignPublicCode'
firebase deploy --only "$FN" --project "$P" --non-interactive --force
gcloud functions list --regions=asia-southeast1 --project "$P" --format=json > /tmp/bbx-v06-functions.json
python3 - <<'PYINNER'
import json
m=json.load(open('MANIFEST.json'))
a=json.load(open('/tmp/bbx-v06-functions.json'))
names={str(f['name']).split('/')[-1] for f in a}
assert set(m['functions_exports']).issubset(names),f'Missing V0.6: {set(m["functions_exports"])-names}'
print('PASS: all 9 V0.6 Functions deployed')
PYINNER
echo '=== Deploy V0.6 Rules directly (fresh project; no old Rules merge) ==='
# firebase.json has the original direct database.rules.json mapping;
# preserve local project config; do not add temporary aliases.
firebase deploy --only database --project "$P" --non-interactive
TOKEN="$(gcloud auth print-access-token)"
RULES_URL="https://${DB}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
curl -fLsS --retry 3 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v06-online-rules.json
python3 - <<'PYINNER'
import json
from pathlib import Path
def read(p):
 x=json.loads(Path(p).read_text());return json.loads(x) if isinstance(x,str) else x
assert read('database.rules.json')==read('/tmp/bbx-v06-online-rules.json'),'online Rules differ'
print('PASS: online V0.6 Rules verified')
PYINNER
# Retire ONLY known V0.5 functions, after V0.6 and Rules are confirmed working.
python3 - <<'PYINNER'
import json,subprocess
m=json.load(open('MANIFEST.json'))
old=m['previous_function_exports']
assert all(n.startswith('bbxV05') for n in old)
actual=json.loads(subprocess.check_output(['gcloud','functions','list','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=json'],text=True))
found={x['name'].split('/')[-1] for x in actual}
for fn in old:
 if fn in found:
  print('Retiring old function:',fn,flush=True)
  subprocess.run(['gcloud','functions','delete',fn,'--region=asia-southeast1','--project=ljt-beyblade-x','--quiet'],check=True)
actual=json.loads(subprocess.check_output(['gcloud','functions','list','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=json'],text=True))
found={x['name'].split('/')[-1] for x in actual}
want=set(m['functions_exports'])
assert found==want,f'Unexpected functions: {sorted(found ^ want)}'
print('PASS: only the 9 V0.6 Functions remain')
PYINNER
printf '
PASS: BBX-V0.6 Functions (9) + Rules deployed and verified. Update GitHub Pages index.html and viewer.html from this SAME ZIP.
'
