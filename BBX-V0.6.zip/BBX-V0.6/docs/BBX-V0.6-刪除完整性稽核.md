# BBX-V0.6｜跨版本賽事完整刪除與 Rules 保留稽核

日期：2026-10-17。程式版本仍為 BBX-V0.6。此修訂只更動刪除 Callable、刪除清單／稽核測試、歷史 Rules 與修復部署腳本；不修改比賽前端或其他 7 支 Functions 的外部行為。

## 1. 舊版程式原始碼的事件資料根節點盤點

從 V0.1、V0.2、V0.3、V0.4、V0.6 的後端建立、主辦管理、裁判接手、觀看及刪除程式交叉對照：

| 路徑（`{eventId}`） | 用途 | 永久刪除 |
|---|---|---|
| `events/{eventId}` | 主辦、裁判、賽程管理投影 | 是 |
| `publicEvents/{eventId}` | 觀眾資料、QR/分享公開投影、觀看期限 | 是 |
| `authorityBBX/{eventId}` | V0.1～V0.3 權威賽程、發布序號、outbox | 是 |
| `authorityBBXV04/{eventId}` | V0.4 權威賽程、兩把舊租約、outbox | 是 |
| `authorityBBXV06/{eventId}` | V0.6 權威賽程、租約、outbox | 是 |
| `bbxV06PublicationPending/{eventId}` | V0.6 背景發布重試索引 | 是（無條件，不論賽事版本） |
| `refereeClaims/{eventId}` | 已接手裁判帳號 | 是 |
| `refereeUsers/{eventId}` | 授權裁判 UID | 是 |
| `refereeSecrets/{eventId}` | 裁判驗證資訊 | 是 |
| `secrets/{eventId}` | 主辦驗證資訊 | 是 |
| `admins/{eventId}` | 管理員 UID、權限碼 | 是 |
| `userEvents/{ownerUid}/{slot}` | 建立者三個賽事名額 | **值等於該 eventId 才刪** |

必須保留的**共用資源**：`bbxV04CreateLocks/{uid}` 和 `bbxV06CreateLocks/{uid}` 是帳號層級新建賽事的臨時鎖，不能因單場刪除而取消。同理，Firebase Auth 帳號、Cloud Functions 日誌、整庫 Rules、其他賽事皆不可刪除。以上盤點僅承諾原始程式碼已知的 Realtime Database 事件專屬節點，不承諾刪除其他 Firebase 服務的記錄。

## 2. 安全刪除協定

1. `bbxV06DeleteAuthority` 必須由 Google Firebase Auth 帳號呼叫；用線上 `events/{eventId}` 的 `ownerUid` 與 `releaseTag` 核對，白名單僅含 V0.1～V0.6，絕不允許正式 V1.0。
2. V0.4 使用原有 `authorityBBXV04/{eventId}/operationLock` 與 `publishing` 兩把鎖；V0.6 使用現有 `authorityBBXV06` 兩把鎖；不新增鎖。V0.1～V0.3 舊函數必須已全部退役，才能使用目前已部署的修復腳本。
3. 鎖內重新核對建立者與版本；有權威 board 時先標示 `deleted:true`，阻擋新權威操作。
4. 產生精確刪除清單，**一次** `db.ref().update({path:null,...})` 提交。任何單一刪除不會影響其他賽事的資料。
5. 多路徑更新完成後，**逐項 GET 回讀**全部 11 條事件節點，以及這位建立者指向該賽事的名額位置。若仍有殘留，紀錄 `BBX_V06_DELETE_RESIDUAL`，不回傳刪除成功；全部為空才回傳 `{ok:true, deleted:true, verified:true}` 並紀錄 `BBX_V06_DELETE_VERIFIED`。
6. 客戶端網路斷線時，伺服器成功原子刪除仍可能導致使用者看不到成功訊息；請先重新載入再確認，不應用繞過驗證的補刪方法。

**無法自動恢復的例外：** 若過去版本已先刪 `events/{eventId}`、但其他舊節點殘留，建立者身分已無法從賽事主檔驗證；拒絕自動清理。管理員應先做唯讀清點、確認擁有者及殘留索引，再進行單一賽事的手動定向修復。不要將「找不到事件主檔」視為任意使用者可以清除節點的授權。

## 3. RTDB Rules 的版本保留（不同於刪除資料）

Rules 是整個資料庫的權限規則，不是各事件生成的資料。Cloud Functions 的 Admin SDK 會略過用戶端 Rules，因此缺少 Rules 不直接阻止有授權的後端清理；但可能影響舊版網頁讀取／權限一致性。

V0.6 完整 Rules 包現在明確含：

```
"authorityBBX":    {".read": false, ".write": false}
"authorityBBXV04": {".read": false, ".write": false}
"authorityBBXV06": {".read": false, ".write": false}
```

部署修復腳本先讀取**線上現存** Rules，再跑 `deploy/merge-rules.py`：只准 BBX 相關的已知改動，外部或客製分支完整保留。即使線上舊 V0.4 私有分支被漏掉，亦能加回上述拒讀寫節點。來源異常或未知權限修改直接停止。合併後進行線上讀回比對，不會用本地完整 Rules 直接覆蓋線上檔案。

## 4. 測試範圍與剩餘驗證

- 已納入 `tests/create-integration.test.js`：五代版本、同一場的跨版本殘留、舊權限憑證、索引、無權限刪除、正式 V1.0 保護及帳號建賽鎖隔離。
- 已納入 `tests/cleanup.test.js`：精確清單、非法路徑拒絕、刪除後讀回發現殘留。
- `tests/check_cleanup_rules.py`：模擬線上漏掉 V0.4 歷史私有分支、混有外部 Rules 時，安全合併後全部正確保留。
- `tests/rules-emulator.test.cjs`：增加禁止前端直接讀寫 V0.4 私有權威資料的實際 RTDB Rules 模擬器測試。
- **本地 Node 整合測試及離線 Rules 合併通過不等於已通過 Firebase Emulator。** 修復部署腳本在 Cloud Shell 必須先跑 RTDB Emulator，通過後才准部署。
- 修復部署只更新一支 `bbxV06DeleteAuthority`，Rules 僅在比對出必要差異時經白名單合併部署；**部署本身不執行任何賽事刪除**。實際資料由原建立者在網頁按刪除時才移除。
