# BBX-V0.6

基於使用者提供的 `BBX-V0.5(4).zip` 原檔修正，不以舊版 ZIP 取代。

## 建立賽事 `functions/internal` 程式原因

V0.5 的 `bbx-v05-lifecycle.js` 使用 `releases:{[originVersion]:true}`，令 `BBX-V0.5` 成為 **Firebase Realtime Database 子鍵名稱**。Realtime Database 不允許鍵名包含 `.`，所以建賽的 `db.ref().update(updates)` 會失敗。舊有整合測試使用寬鬆的假資料庫，沒有測出非法鍵名。這是可由原始碼確定的缺陷；真正線上錯誤仍可用建賽函數日誌佐證。

V0.6 將 `releases` 改為文字陣列（例如 `["BBX-V0.6"]`），並相容舊格式合併。模擬 RTDB 的 `update` 和 `set` 也加入遞迴非法鍵名驗證，避免之後又漏測；亦保留 Google 建立者、獨立長 eventId 與五碼別名、原子建立、操作代碼冪等、跨版本安全刪除。

## 後端版本隔離

Functions 名稱 `bbxV06*`（9 支）、私有權威節點 `authorityBBXV06`、發布待處理 `bbxV06PublicationPending`、建立鎖 `bbxV06CreateLocks`、版本字串 `BBX-V0.6`、前端 `bbx-v0.6-authority-1`、五碼仍與不可變 eventId 分離。

## 發布

保持原版 V1.0 的 HTML/CSS；只替換前端 JS 的 V0.6 端點。`deploy/BBX-V0.6-檢查.sh` 必須先完成本地測試及 Firebase Emulator 權限檢查；`deploy/BBX-V0.6-Cloud-Functions.sh` 在該包驗證通過才部署 V0.6 9 支 Functions 和 **乾淨的 V0.6 Rules**。待新 Functions/Rules 通過線上清單檢查，才精確刪除舊 V0.5 9 支 Functions，不清除資料庫，不碰 `ljtreg-39954`。

驗收優先：建賽 → 可看到單場賽程與五碼 → 開始執裁 → 連續加分 → 完成 → 晉級及觀眾增量同步；六裁判並行測試仍需真實雲端驗收。Firebase Emulator 未在本機執行，不得以本地測試取代。
