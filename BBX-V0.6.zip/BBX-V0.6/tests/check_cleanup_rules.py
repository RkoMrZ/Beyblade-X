#!/usr/bin/env python3
"""Unit audit for Rules migrations: missing V0.4 historical deny branch is recovered."""
import json,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
old=json.loads((root/'docs/previous-v04-rules.json').read_text())
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'old.json';q=Path(d)/'merged.json'
 old['rules'].pop('authorityBBXV04',None)
 old['rules']['EXTERNAL_UNTOUCHED_BBX_TEST']={'.read':False,'.write':False}
 p.write_text(json.dumps(old))
 subprocess.run(['python3',str(root/'deploy/merge-rules.py'),str(p),str(q)],check=True)
 out=json.loads(q.read_text())
 assert out['rules']['authorityBBXV04']=={'.read':False,'.write':False}
 assert out['rules']['EXTERNAL_UNTOUCHED_BBX_TEST']=={'.read':False,'.write':False}
 assert out['rules']['authorityBBXV05']=={'.read':False,'.write':False}
 assert out['rules']['authorityBBXV06']=={'.read':False,'.write':False}
 assert out['rules']['authorityBBX']=={'.read':False,'.write':False}
 assert out['rules']['bbxV06PublicationPending']=={'.read':False,'.write':False,'.indexOn':['updatedAt']}
 print('PASS historical V0.4 security rule restored without dropping current / external Rules')
 # The five-character public alias is read-only; private lifecycle registration is never client-accessible.
 assert out['rules']['bbxEventCleanupRegistry']=={'.read':False,'.write':False}
 assert out['rules']['bbxPublicCodeReservations']=={'.read':False,'.write':False}
 assert out['rules']['bbxPublicCodeLookup']['$code']['.write'] is False
 print('PASS five-character lookup and lifecycle ledger are server-owned')
