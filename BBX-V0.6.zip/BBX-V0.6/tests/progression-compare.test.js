'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const C=require('../functions/bbx-v06-core');
const O=require('../functions/bbx-v06-organizer');
const src=fs.readFileSync(__dirname+'/../baseline/index.v1.html','utf8');
const code=src.slice(src.indexOf('function nextPow2('),src.indexOf('function pick(ri,mi,side)'));
let i=0;const NOW=Date.now();const id=()=>NOW.toString(16).padStart(12,'0')+(++i).toString(16).padStart(36,'0');
function canonical(ev){return JSON.parse(JSON.stringify({rounds:ev.rounds,finalRR:ev.finalRR},(k,v)=>['matchVersion','referee','refereeActive','claimUid','_previousWinner','reviewPublished'].includes(k)?undefined:v));}
for(const [mode,freeFinal,nums] of [['single','champ',[3,4,6,8,12,24,32,64]],['free','champ',[3,4,6,8,12,24]],['free','rr3',[3,6,12,24,48]]]){
 test(`server propagates winners same as V1.0 (${mode}/${freeFinal})`,()=>{
  for(const n of nums){
   const roster=Array.from({length:n},(_,j)=>`P${j+1}`);
   const ctx=vm.createContext({ev:{roster,mode,freeFinal,rounds:[],finalRR:null}});vm.runInContext(code,ctx);ctx.buildFirst();
   let b=C.bootstrap({...JSON.parse(JSON.stringify(ctx.ev)),ownerUid:'owner',publicOpen:true,publicUntil:NOW+3600000,id:'event-test'});
   for(let ri=0;ri<ctx.ev.rounds.length;ri++){
    const r=ctx.ev.rounds[ri];if(r.placementFinal)continue;
    for(let mi=0;mi<r.matches.length;mi++){
     let m=ctx.ev.rounds[ri].matches[mi];
     if(m.winner||m.a==='待定'||m.b==='待定'||m.a==='BYE'||m.b==='BYE')continue;
     const reqBase={target:{kind:'round',ri,mi},referee:'主辦'};
     let o=C.apply(b,'owner',{...reqBase,opId:id(),action:'claim',expectedStructureVersion:0,expectedMatchVersion:b.rounds[ri].matches[mi].matchVersion||0},NOW,{});b=o.board;b.outbox={};
     o=C.apply(b,'owner',{...reqBase,opId:id(),action:'score',sa:4,sb:0,expectedStructureVersion:0,expectedMatchVersion:b.rounds[ri].matches[mi].matchVersion},NOW,{});b=o.board;b.outbox={};
     o=C.apply(b,'owner',{...reqBase,opId:id(),action:'complete',sa:4,sb:0,expectedStructureVersion:0,expectedMatchVersion:b.rounds[ri].matches[mi].matchVersion},NOW,{});b=o.board;b.outbox={};
     m=ctx.ev.rounds[ri].matches[mi];m.sa=4;m.sb=0;m.winner=m.a;
     ctx.ensureNext();
     assert.deepEqual(canonical(b),canonical(ctx.ev),`n=${n} round=${ri} match=${mi}`);
    }
   }
  }
 });
}
