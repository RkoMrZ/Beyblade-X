#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
INSTANCE=ljtreg-39954-default-rtdb
bash 06_source_guard.sh >/dev/null
VERSION="$(node -p "JSON.parse(require('fs').readFileSync('RELEASE_VERSION.json')).release")"
API="$(node -p "JSON.parse(require('fs').readFileSync('RELEASE_VERSION.json')).apiPrefix")"
FUNCTIONS="$(firebase functions:list --project "$PROJECT")" || { echo 'ERROR: cannot inspect Functions'; exit 2; }
for suffix in CreateEvent UpdateEvent SetOpen Submit Review EditEntry DeleteEntry DeleteEvent MyRank; do
 printf '%s\n' "$FUNCTIONS" | grep -Fq "${API}${suffix}" || { echo "ERROR: ${API}${suffix} missing; refusing reset"; exit 3; }
done
if printf '%s\n' "$FUNCTIONS" | grep -Eo 'reg(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|MyRank)|reg8(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|MyRank)|regV[0-9]+(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|MyRank)' | grep -v "^${API}"; then
 echo 'ERROR: old registration Functions remain deployed; reset refused'; exit 3
fi
printf '\nDANGER: COMPLETE RESET %s / %s before %s\n' "$PROJECT" "$INSTANCE" "$VERSION"
printf 'Existing events, receipts and URLs WILL NOT be recoverable through the live website.\n'
printf 'NO AUTOMATIC BACKUP: all prior event / signup / private records will be permanently lost.\n'
read -r -p "To permanently erase the entire registration database, type ERASE-$VERSION-ljtreg-39954: " answer
[ "$answer" = "ERASE-$VERSION-ljtreg-39954" ] || { echo 'CANCELLED'; exit 2; }
firebase database:remove / --project "$PROJECT" --instance "$INSTANCE" --force
STATE="$(firebase database:get / --project "$PROJECT" --instance "$INSTANCE")"
[ "$STATE" = null ] || { echo 'ERROR: Database is not empty. Do not repeat deletion blindly'; exit 5; }
echo 'RESET_VERIFIED: Firebase RTDB is empty. Publish the new versioned pages next.'
