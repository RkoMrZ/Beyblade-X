
import {initializeApp} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import {getAuth,GoogleAuthProvider,onAuthStateChanged,signInWithPopup,signOut} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
const app=initializeApp({apiKey:'AIzaSyDc0wD_Rfo4Ldf86stPbMHN9Q8Ng0PJsvo',authDomain:'ljtreg-39954.firebaseapp.com',projectId:'ljtreg-39954',appId:'1:898101322849:web:a0c568372940da7901f620'});
const auth=getAuth(app),DB='https://ljtreg-39954-default-rtdb.asia-southeast1.firebasedatabase.app',FN='https://asia-southeast1-ljtreg-39954.cloudfunctions.net/';
const $=s=>document.getElementById(s),safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let managerEpoch=0;const managerQueue=BBX.createQueue();
let syncToken=null,syncBusy=false,lastChangeCursor="";let user=null,mode='home',eid='',eventMeta=null,rows={},extras={},tab='all',loading=false,lastFetch=0;
const msg=(s,kind='ok')=>{$('banner').className='status '+kind;$('banner').textContent=s};
const statusName={pending:'待審核',approved:'通過',rejected:'不通過'};
function openModal(html){$('modalContent').innerHTML=html;$('modal').classList.remove('hide')}
function closeModal(){$('modal').classList.add('hide');$('modalContent').innerHTML=''}
$('modal').onclick=e=>{if(e.target===$('modal'))closeModal()};
function go(next,id=''){const target=next==='manage'?'#manage='+id:next==='create'?'#create':'#home';if(location.hash===target)return;location.hash=target}
function fromHash(){managerEpoch++;managerReadPool.abort();managerWatchStop();stopManagerLive();managerDenied=false;eventMeta=null;rows={};extras={};syncToken=null;lastChangeCursor="";const h=location.hash.replace(/^#/,'');if(h.startsWith('manage=')&&/^[A-Z0-9]{5}$/.test(h.slice(7))){mode='manage';eid=h.slice(7)}else{mode=h==='create'?'create':'home';eid=''}render()}
function toggleTheme(){const t=document.documentElement.dataset.theme==='light'?'dark':'light';document.documentElement.dataset.theme=t;try{localStorage.setItem('reg-v04-theme',t)}catch{}}
$('theme').onclick=toggleTheme;$('home').onclick=()=>go('home');
$('authBtn').onclick=async()=>{try{if(user)await signOut(auth);else await signInWithPopup(auth,new GoogleAuthProvider())}catch(e){msg('Google 登入失敗：'+(e.message||e.code),'err')}};
const managerReadPool=BBX.createReadPool(()=>managerVisible());
async function get(path,privateRead=false,query=null){
 const epoch=managerEpoch,who=user;
 if(!managerVisible())throw BBX.aborted();
 const url=new URL(DB+'/'+path+'.json');if(query)for(const [k,v] of Object.entries(query))url.searchParams.set(k,v);
 if(privateRead){if(!who)throw Error('尚未登入');url.searchParams.set('auth',await who.getIdToken())}
 if(epoch!==managerEpoch||who!==user||!managerVisible())throw BBX.aborted();
 return managerReadPool.get(url.toString());
}
async function call(name,data){if(!user)throw Error('尚未登入主辦帳號');const token=await user.getIdToken(),ctl=new AbortController(),tm=setTimeout(()=>ctl.abort(),20000);try{const r=await fetch(FN+name,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify({data}),signal:ctl.signal});const p=await r.json();if(p.error||!r.ok)throw Error(p.error?.message||'雲端操作失敗');return p.result}finally{clearTimeout(tm)}}
function statRank(items,capacity){const ordered=Object.values(items||{}).filter(v=>v&&v.status!=='deleted').sort((a,b)=>a.signupNo-b.signupNo);const map=new Map();let i=0;for(const r of ordered)if(r.status!=='rejected'){i++;map.set(r.signupNo,i<=capacity?'正選#'+i:'備選#'+(i-capacity))}return {ordered:ordered.sort((a,b)=>(a.status==='rejected')-(b.status==='rejected')||a.signupNo-b.signupNo),map,active:i}}
function formFields(m={}){return `<div class="formGrid"><div class="full"><label>比賽名稱 *</label><input name="title" maxlength="70" required value="${safe(m.title)}" placeholder="例如：金魚盃"></div><div><label>比賽日期 *</label><input name="eventDate" type="date" required value="${safe(m.eventDate)}"></div><div><label>報到時間 *</label><input name="checkinTime" type="time" required value="${safe(m.checkinTime)}"></div><div><label>開賽時間 *</label><input name="startTime" type="time" required value="${safe(m.startTime)}"></div><div><label>比賽地點 *</label><input name="venue" required maxlength="150" value="${safe(m.venue)}"></div><div><label>報名費（免費填 0）*</label><input name="fee" type="number" min="0" step="1" required value="${m.fee??0}"></div><div><label>正選人數 *</label><input name="capacity" type="number" min="1" max="10000" step="1" required value="${m.capacity??32}"></div></div><p class="dim">正選名額以報名順序排列；備選不限人數。有人不通過時往前遞補，恢復後按原始順序重新排列。</p>`}
function collect(f){const d=Object.fromEntries(new FormData(f));d.fee=Number(d.fee);d.capacity=Number(d.capacity);return d}
function createRequestId(m){
 const content=JSON.stringify(m),storageKey='reg-v04-create-request';
 try{const saved=JSON.parse(sessionStorage.getItem(storageKey)||'null');if(saved?.content===content&&/^[0-9a-f]{48}$/.test(saved.createId))return saved.createId}catch{}
 const createId=Array.from(crypto.getRandomValues(new Uint8Array(24)),v=>v.toString(16).padStart(2,'0')).join('');
 try{sessionStorage.setItem(storageKey,JSON.stringify({content,createId}))}catch{}
 return createId;
}
async function submitCreate(e){e.preventDefault();if(loading)return;loading=true;try{
 const m=collect(e.target),createId=createRequestId(m);msg('正在向雲端建立比賽…','warn');
 const r=await call('regV04CreateEvent',{...m,createId});
 try{sessionStorage.removeItem('reg-v04-event-draft');sessionStorage.removeItem('reg-v04-create-request')}catch{}
 msg('已由雲端建立比賽');go('manage',r.eid)
 }catch(x){msg('建立結果尚未確認：'+x.message+'。請保持表單並以相同資料重試；不會產生重複活動。','err')}finally{loading=false}}

function render(){if(!user){$('app').innerHTML='<section class="card"><h1>主辦管理後台</h1><p class="muted">請使用 Google 帳號登入；選手不必登入。</p><button id="startLogin">使用 Google 登入</button></section>';$('startLogin').onclick=()=>$('authBtn').click();return}if(mode==='create'){let draft={};try{draft=JSON.parse(sessionStorage.getItem('reg-v04-event-draft')||'{}')}catch{}$('app').innerHTML='<h1>建立新比賽</h1><section class="card" style="max-width:800px"><form id="createForm">'+formFields(draft)+'<div class="formBtns"><button type="submit">建立並開放報名</button><button type="button" class="alt" id="cancel">取消</button></div></form></section>';$('createForm').onsubmit=submitCreate;$('createForm').oninput=e=>{try{sessionStorage.setItem('reg-v04-event-draft',JSON.stringify(Object.fromEntries(new FormData(e.currentTarget))))}catch{}};$('cancel').onclick=()=>go('home');return}if(mode==='home'){renderHome();return}renderManage()}
function renderHome(){
 const epoch=managerEpoch,who=user;
 if(!who||mode!=='home'||!managerVisible())return Promise.resolve();
 return managerQueue.run('home:'+epoch,async()=>{
  if(epoch!==managerEpoch||user!==who||mode!=='home'||!managerVisible())return;
  homeRefreshPending=false;
  $('app').innerHTML='<h1>我的比賽</h1><section class="card"><button id="newEvent">＋ 建立新比賽</button></section><div id="events">正在讀取雲端活動索引…</div>';$('newEvent').onclick=()=>go('create');
  try{
   const index=await get('ownerEventsV04/'+who.uid,true);
   if(epoch!==managerEpoch||user!==who||mode!=='home'||!managerVisible())return;
   const cards=Object.entries(index||{}).map(([id,m])=>`<article class="card"><span class="badge">精簡節點活動</span><h2>${safe(m.title)}</h2><p class="dim">📅 ${safe(m.eventDate)} · 正選 ${m.capacity} 人</p><button class="alt" data-manage="${id}">進入報名管理 →</button></article>`);
   $('events').innerHTML=cards.length?'<div class="grid">'+cards.join('')+'</div>':'<div class="msg">尚無活動。</div>';
   document.querySelectorAll('[data-manage]').forEach(b=>b.onclick=()=>go('manage',b.dataset.manage));lastFetch=Date.now();msg('主辦索引已從雲端取得');
  }catch(e){
   if(epoch!==managerEpoch||user!==who||mode!=='home')return;
   homeRefreshPending=true;
   if(managerVisible()&&e.name!=='AbortError'){$('events').innerHTML='<button class="alt" id="retryHome">重新讀取索引</button>';$('retryHome').onclick=renderHome;msg(e.message,'err')}
  }
 });
}
// Organizer listens to the same tiny public sync marker; private records are still fetched via authenticated HTTPS.
let managerStream=null,managerOnline=false,managerRetry=null,managerDebounce=null,managerHint=null,managerDenied=false,managerRetryAttempt=0;
// V0.4 organizer lifecycle: no live connection or scheduled GET while backgrounded.
let managerSleeping=document.visibilityState!=='visible',managerWatch=null,managerStable=null;
let managerFallbackAfter=0,managerFallbackFailures=0;
let managerLoading=false,managerResumePending=false,homeRefreshPending=false,managerForcedCatchup=false;
function managerVisible(){return !managerSleeping&&document.visibilityState==='visible'}
function managerWatchStop(){clearTimeout(managerWatch);managerWatch=null}
function managerWatchStart(){
 managerWatchStop();if(!managerVisible()||!user||mode!=='manage')return;
 managerWatch=setTimeout(()=>{
  if(!managerVisible()||!user||mode!=='manage')return;
  if($('modal').classList.contains('hide')&&!syncBusy&&eventMeta){
   const now=Date.now();
   if(managerOnline){if(now-lastFetch>=120000)pollChanges()}
   else if(now>=managerFallbackAfter){
    managerFallbackAfter=now+Math.min(120000,30000*2**Math.min(managerFallbackFailures,2))+Math.floor(Math.random()*2500);
    pollChanges();
   }
  }
  managerWatchStart();
 },20000)
}
function managerSleep(){
 managerSleeping=true;managerWatchStop();stopManagerLive();
 managerReadPool.abort();
}
function managerWake(){
 if(document.visibilityState!=='visible')return;
 managerSleeping=false;managerFallbackAfter=0;
 if(!user)return;
 if(mode==='manage'){
  if(!eventMeta){renderManage();return}
  startManagerLive();scheduleManagerCheck();managerWatchStart();
 }else if(mode==='home'&&(homeRefreshPending||Date.now()-lastFetch>20000))renderHome();
}
function stopManagerLive(){clearTimeout(managerRetry);clearTimeout(managerDebounce);clearTimeout(managerStable);managerRetry=managerDebounce=managerStable=null;managerHint=null;if(managerStream){managerStream.close();managerStream=null}managerOnline=false}
function scheduleManagerCheck(hint=null){if(mode!=='manage'||!managerVisible())return;if(hint)managerHint=hint;clearTimeout(managerDebounce);managerDebounce=setTimeout(()=>{managerDebounce=null;pollChanges()},300)}
function startManagerLive(){
 if(managerStream||managerDenied||!user||mode!=='manage'||!eid||!managerVisible()||typeof EventSource==='undefined')return;
 const id=eid,s=new EventSource(DB+'/syncV04/'+id+'.json');managerStream=s;
 s.onopen=()=>{if(s!==managerStream||!managerVisible())return;managerOnline=true;managerFallbackFailures=0;clearTimeout(managerStable);managerStable=setTimeout(()=>{if(s===managerStream&&managerOnline)managerRetryAttempt=0},30000)};
 const onChange=ev=>{if(eid!==id||s!==managerStream||!managerVisible())return;try{const v=JSON.parse(ev.data);if(v.path==='/'){if(v.data?.token===syncToken)return;scheduleManagerCheck(v.data)}else if(v.path==='/token')scheduleManagerCheck({token:v.data});else if(v.path==='/lastChange')scheduleManagerCheck()}catch{scheduleManagerCheck()}};
 s.addEventListener('put',onChange);s.addEventListener('patch',onChange);
 const denied=()=>{stopManagerLive();managerDenied=true;msg('即時通知暫不可用，已切換低頻檢查','warn')};
 s.addEventListener('cancel',denied);s.addEventListener('auth_revoked',denied);
 s.onerror=()=>{
  if(s!==managerStream)return;
  stopManagerLive();if(!managerVisible()||mode!=='manage'||eid!==id||managerDenied)return;
  const delay=Math.min(120000,2500*2**Math.min(managerRetryAttempt++,6))+Math.floor(Math.random()*3500);
  managerRetry=setTimeout(()=>{managerRetry=null;startManagerLive()},delay);
 };
}
function managerContext(){return {epoch:managerEpoch,id:eid,uid:user?.uid}}
function managerCurrent(c){return c.epoch===managerEpoch&&c.id===eid&&c.uid===user?.uid&&mode==='manage'&&managerVisible()}
function applyRow(key,row){if(!row)delete rows[key];else if(!rows[key]||Number(row.recordVersion)>=Number(rows[key].recordVersion||0))rows[key]=row}
function applyExtra(key,value){if(!value)delete extras[key];else if(!extras[key]||Number(value.recordVersion||0)>=Number(extras[key].recordVersion||0))extras[key]=value}
async function fetchManagerRaw(c){
 if(!managerCurrent(c))return false;
 const id=c.id,started=await get('syncV04/'+id);
 if(!managerCurrent(c))return false;
 const [m,ro,pr]=await Promise.all([get('eventsV04/'+id+'/meta'),get('publicRowsV04/'+id),get('managerRowsV04/'+id,true)]);
 if(!managerCurrent(c))return false;
 if(!m||m.deleted)throw Error('找不到活動');
 // Keep newer confirmed versions if an operation completed during this snapshot.
 const oldRows=rows,oldExtras=extras;rows=ro||{};extras=pr||{};
 for(const [k,v] of Object.entries(oldRows))if(rows[k]&&v.recordVersion>rows[k].recordVersion)rows[k]=v;
 for(const [k,v] of Object.entries(oldExtras))if(extras[k]&&v.recordVersion>extras[k].recordVersion)extras[k]=v;
 if(!eventMeta||m.version>=eventMeta.version)eventMeta=m;
 syncToken=started?.token||null;lastChangeCursor=started?.lastChange||'';lastFetch=Date.now();return true;
}
function fetchManager(){const c=managerContext();return managerQueue.run('snapshot:'+c.epoch,()=>fetchManagerRaw(c))}
async function renderManage(){
 if(!eid||!managerVisible())return;
 if(managerLoading){managerResumePending=true;return}
 managerLoading=true;const id=eid;
 $('app').innerHTML='<h1>報名審核管理</h1><div class="msg">正在讀取單場節點…</div>';
 try{if(await fetchManager()){drawManager();startManagerLive();managerWatchStart()}}
 catch(e){if(mode!=='manage'||eid!==id||!managerVisible()||e.name==='AbortError')return;msg(e.message,'err');$('app').innerHTML='<h1>讀取失敗</h1><button class="alt" id="retry">重新讀取</button>';$('retry').onclick=renderManage}
 finally{
  managerLoading=false;
  if(managerResumePending&&managerVisible()&&mode==='manage'){
   managerResumePending=false;setTimeout(()=>{if(!managerVisible())return;if(!eventMeta)renderManage();else scheduleManagerCheck()},0)
  }
 }
}
function drawManager(){if(mode!=='manage'||!eventMeta)return;const preservedQuery=$('search')?.value||'',searchFocused=document.activeElement?.id==='search',caret=searchFocused?$('search').selectionStart:0;const s=statRank(rows,eventMeta.capacity),a=s.ordered,approved=a.filter(r=>r.status==='approved').length,pend=a.filter(r=>r.status==='pending').length,rejected=a.filter(r=>r.status==='rejected').length;const u='https://bbxr-tamsui.web.app/s/'+encodeURIComponent(eid),v='https://bbxr-tamsui.web.app/q/'+encodeURIComponent(eid);
$('app').innerHTML=`<div class="manageHeading"><h1>報名審核管理</h1><button class="alt" id="back">← 返回我的比賽</button></div><div class="grid"><section class="card"><div class="row between"><h2>${safe(eventMeta.title)}</h2><span class="pill ${eventMeta.open?'approved':'rejected'}">${eventMeta.open?'報名開放':'報名關閉'}</span></div><p class="dim">📅 ${safe(eventMeta.eventDate)} · 報到 ${safe(eventMeta.checkinTime)} · 開賽 ${safe(eventMeta.startTime)}<br>📍 ${safe(eventMeta.venue)}<br>報名費 ${eventMeta.fee} 元 · 正選 ${eventMeta.capacity} 人／備選不限</p><div class="eventActionsLabel">分享連結</div><div class="eventControlGrid"><button class="alt" id="copyLink" type="button">複製報名網址</button><button class="alt" id="copyStatus" type="button">複製查詢表網址</button><button class="alt" id="openSignup" type="button">另開報名頁 ↗</button><button class="alt" id="openStatus" type="button">另開查詢表 ↗</button></div><div class="eventActionsLabel">比賽設定</div><div class="eventControlGrid"><button class="alt" id="editEvent" type="button">編輯比賽</button><button class="alt" id="toggleOpen" type="button">${eventMeta.open?'關閉報名':'重新開放'}</button></div><div class="eventDangerRow"><button class="bad" id="deleteEvent" type="button">刪除活動</button></div></section><section class="card"><h2>報名統計</h2><p class="dim">總報名 ${a.length} 人 · 有效順位 ${s.active} 人 · 待審核 ${pend} · 通過 ${approved} · 不通過 ${rejected}</p><div class="statsMainButtons"><button class="good" id="copyPass">複製通過正選</button><button class="alt" id="csv">下載 CSV</button></div><div class="statsSyncRow"><button class="alt" id="refresh" title="只重新讀取本場活動及其名單，不修改雲端資料">手動重新同步</button><p class="dim">顯示不同步時才需要；平時會自動更新。</p></div></section></div><section class="card"><h2>報名紀錄</h2><div class="tabbar" id="tabs">${[['all','全部',a.length],['pending','待審核',pend],['approved','通過',approved],['rejected','不通過',rejected]].map(([k,n,c])=>`<button type="button" data-tab="${k}" aria-selected="${tab===k}">${n} ${c}</button>`).join('')}</div><label for="search">搜尋比賽名稱、LINE 名稱或手機後三碼</label><input id="search" type="search" placeholder="搜尋…"><div id="roster"></div></section>`;
$('back').onclick=()=>go('home');$('copyLink').onclick=()=>copy(new URL(u,location.href).href);$('copyStatus').onclick=()=>copy(new URL(v,location.href).href);$('openSignup').onclick=()=>window.open(u,'_blank','noopener');$('openStatus').onclick=()=>window.open(v,'_blank','noopener');$('editEvent').onclick=editEvent;$('toggleOpen').onclick=toggleOpen;$('deleteEvent').onclick=deleteEvent;$('copyPass').onclick=()=>copy(s.ordered.filter(r=>r.status==='approved'&&s.map.get(r.signupNo)?.startsWith('正選')).map(r=>r.playerName).join('\n'));
$('csv').onclick=()=>{const content=[['比賽名稱','LINE名稱','手機後三碼','正備選編號','審核狀態'],...s.ordered.map(r=>[r.playerName,extras['p'+String(r.signupNo).padStart(8,'0')]?.lineName||'',r.phone3,s.map.get(r.signupNo)||'',statusName[r.status]||''])].map(v=>v.map(x=>'"'+String(x).replaceAll('"','""')+'"').join(',')).join('\r\n');const a=document.createElement('a'),url=URL.createObjectURL(new Blob(['\ufeff'+content],{type:'text/csv;charset=utf-8'}));a.href=url;a.download='報名名單.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
$('refresh').onclick=refresh;$('search').value=preservedQuery;document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;document.querySelectorAll('[data-tab]').forEach(t=>t.setAttribute('aria-selected',String(t.dataset.tab===tab)));drawRoster()});$('search').oninput=drawRoster;drawRoster();if(searchFocused){$('search').focus({preventScroll:true});try{$('search').setSelectionRange(caret,caret)}catch{}}msg('已取得最新雲端資料');}
function drawRoster(){if(mode!=='manage'||!$('roster'))return;const s=statRank(rows,eventMeta.capacity),q=$('search').value.trim().toLowerCase();const items=s.ordered.filter(r=>(tab==='all'||r.status===tab)&&(r.playerName.toLowerCase().includes(q)||r.phone3.includes(q)||(extras['p'+String(r.signupNo).padStart(8,'0')]?.lineName||'').toLowerCase().includes(q)));
$('roster').innerHTML='<div class="tableWrap"><table><thead><tr><th>比賽名稱</th><th>LINE／手機後三碼</th><th>審核狀態</th><th>正備選編號</th><th>編輯</th></tr></thead><tbody>'+ (items.length?items.map(r=>{const key='p'+String(r.signupNo).padStart(8,'0');return `<tr><td><strong>${safe(r.playerName)}</strong></td><td class="contact">${safe(extras[key]?.lineName||'—')}<small>${safe(r.phone3)}</small></td><td><button class="alt sm reviewbtn ${safe(r.status)}" data-review="${key}">${safe(statusName[r.status])}⌄</button></td><td><span class="rank">${safe(s.map.get(r.signupNo)||'—')}</span></td><td><button class="alt sm" data-edit="${key}">編輯</button></td></tr>`}).join(''):'<tr><td colspan="5" class="muted" style="text-align:center">沒有符合條件的選手</td></tr>')+'</tbody></table></div>';
$('roster').querySelectorAll('[data-review]').forEach(b=>b.onclick=()=>review(b.dataset.review));$('roster').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>editEntry(b.dataset.edit));}
async function refresh(){if(mode!=='manage')return;try{if(await fetchManager())drawManager()}catch(e){msg('重新讀取失敗，保留畫面資料：'+e.message,'err')}}
// Check one tiny sync node first; when unchanged, NO roster GET takes place.
// After a change only retrieve the affected row(s). Large change bursts fall back to one snapshot.
function pollChanges(){const c=managerContext();if(syncBusy)managerForcedCatchup=true;return managerQueue.run('delta:'+c.epoch,()=>managerCurrent(c)?runPollChanges(c):undefined)}
async function runPollChanges(c){
 if(mode!=='manage'||!eid||!user||!managerVisible())return;
 if(syncBusy){managerForcedCatchup=true;return}
 syncBusy=true;const id=eid,uid=user.uid;
 try{
  const hinted=managerHint;managerHint=null;
  const stamp=hinted?.token&&typeof hinted.lastChange==='string'?hinted:await get('syncV04/'+id);
  if(!stamp)return;
  if(!managerVisible())return;
  if(stamp.token===syncToken){lastFetch=Date.now();managerFallbackFailures=0;return}
  // A concurrent writer can commit an older push key AFTER our current cursor.
  // Correctness wins: on non-forward progress, re-fetch one event snapshot.
  if(lastChangeCursor&&stamp.lastChange&&stamp.lastChange<=lastChangeCursor){if(await fetchManagerRaw(c))drawManager();return}
  const query=lastChangeCursor?{'orderBy':'"$key"','startAt':JSON.stringify(lastChangeCursor),'limitToFirst':'101'}:{'orderBy':'"$key"','limitToFirst':'101'};
  const history=await get('changesV04/'+id,false,query);
  if(!managerCurrent(c))return;
  const entries=Object.entries(history||{}).sort((a,b)=>a[0].localeCompare(b[0]));
  const continuous=lastChangeCursor?entries[0]?.[0]===lastChangeCursor:true;
  if(!continuous||entries.length>=101){if(await fetchManagerRaw(c))drawManager();return}
  const unseen=entries.filter(([key])=>key!==lastChangeCursor);
  const affected=new Map();let metaChanged=false;
  for(const [key,c] of unseen){if(c.type==='meta')metaChanged=true;
   else if(/^p\d{8}$/.test(c.key||'')){const prior=affected.get(c.key)||{private:false,version:0,privateVersion:0,unknown:false};prior.private ||= c.type!=='review';prior.version=Math.max(prior.version,c.recordVersion||0);if(c.type!=='review')prior.privateVersion=Math.max(prior.privateVersion,c.recordVersion||0);prior.unknown ||= !c.recordVersion||c.type==='delete';affected.set(c.key,prior)}}
  let nextMeta=null;if(metaChanged)nextMeta=await get('eventsV04/'+id+'/meta');
  const updates=[];
  const targets=[...affected.entries()];for(let i=0;i<targets.length;i+=6){
   await Promise.all(targets.slice(i,i+6).map(async ([key,need])=>{
    if(!managerCurrent(c))return;
    const item={key};
    if(need.unknown||!rows[key]||Number(rows[key].recordVersion||0)<need.version)item.row=await get('publicRowsV04/'+id+'/'+key);
    if(need.private&&(need.unknown||!extras[key]||Number(extras[key].recordVersion||0)<need.privateVersion))item.extra=await get('managerRowsV04/'+id+'/'+key,true);
    updates.push(item);
   }))
  }
  if(!managerCurrent(c))return;
  if(nextMeta&&(!eventMeta||nextMeta.version>=eventMeta.version))eventMeta=nextMeta;
  for(const item of updates){if('row' in item)applyRow(item.key,item.row);if('extra' in item)applyExtra(item.key,item.extra)}
  if(!managerCurrent(c))return;
  
  if(!managerVisible())return;lastChangeCursor=entries.at(-1)?.[0]||lastChangeCursor;syncToken=stamp.token;lastFetch=Date.now();managerFallbackFailures=0;drawManager();
 }catch(e){if(mode==='manage'&&managerVisible()){managerFallbackFailures=Math.min(managerFallbackFailures+1,2);msg('增量更新暫時失敗，可按「手動重新同步」：'+e.message,'warn')}}
 finally{syncBusy=false;if(managerVisible()&&(managerForcedCatchup||(managerHint&&managerHint.token!==syncToken))){managerForcedCatchup=false;scheduleManagerCheck()}}
}

function copy(t){navigator.clipboard?.writeText(t).then(()=>msg('已複製')).catch(()=>window.prompt('請長按複製',t))}
async function reloadAffected(data,name,c){return managerQueue.run('recover:'+c.epoch,async()=>{
 if(!managerCurrent(c))return;
 if(name==='regV04Review'||name==='regV04EditEntry'||name==='regV04DeleteEntry'){
  const rr=await get('publicRowsV04/'+c.id+'/'+data.key);
  const priv=name==='regV04Review'?undefined:await get('managerRowsV04/'+c.id+'/'+data.key,true);
  if(!managerCurrent(c))return;applyRow(data.key,rr);if(priv!==undefined)applyExtra(data.key,priv);
 }else if(name==='regV04UpdateEvent'||name==='regV04SetOpen'){
  const m=await get('eventsV04/'+c.id+'/meta');if(managerCurrent(c)&&m&&(!eventMeta||m.version>=eventMeta.version))eventMeta=m;
 }
})}
async function attempt(name,data){if(loading)return null;const context=managerContext();loading=true;
 try{msg('等待伺服器確認…','warn');const out=await managerQueue.run('write:'+context.epoch+':'+name+':'+(data.key||''),()=>{if(context.epoch!==managerEpoch||context.id!==eid||context.uid!==user?.uid)throw BBX.aborted();return call(name,data)});if(context.epoch!==managerEpoch||context.id!==eid||context.uid!==user?.uid)return null;
  if(name==='regV04Review'||name==='regV04EditEntry'){applyRow(data.key,out.row);if(out.private)applyExtra(data.key,out.private)}
  else if(name==='regV04DeleteEntry'){delete rows[data.key];delete extras[data.key]}
  else if(name==='regV04UpdateEvent'||name==='regV04SetOpen'){if(!eventMeta||out.meta.version>=eventMeta.version)eventMeta=out.meta}
  closeModal();if(mode==='manage')drawManager();msg('雲端確認操作成功');return out;
 }catch(e){if(context.epoch!==managerEpoch||context.id!==eid||context.uid!==user?.uid)return null;msg('當次操作未完成：'+e.message+'；正在確認相關節點。未自動重送','err');try{await reloadAffected(data,name,context);if(mode==='manage')drawRoster()}catch{}
  if(context.epoch!==managerEpoch||context.id!==eid||context.uid!==user?.uid)return null;
  if(!$('modal').classList.contains('hide')){const b=document.createElement('div');b.className='status err';b.textContent='伺服器拒絕這次修改，已嘗試更新相關紀錄。未送出的表單仍保留；請關閉視窗後重新開啟，再確認最新資料。';$('modalContent').prepend(b)}
  if(mode==='manage')drawManager();return null
 }finally{loading=false}}
function review(key){const r=rows[key];if(!r)return;openModal(`<h2>${safe(r.playerName)}</h2><p class="muted">目前：${safe(statusName[r.status])} · 原始順位 #${r.signupNo}</p><div class="stack">${[['pending','待審核'],['approved','通過'],['rejected','不通過']].map(([s,n])=>`<button data-to="${s}" class="${s==='approved'?'good':s==='rejected'?'bad':'alt'}">${n}</button>`).join('')}</div><button class="alt close" id="close">取消</button>`);$('close').onclick=closeModal;$('modalContent').querySelectorAll('[data-to]').forEach(b=>b.onclick=()=>{if(b.dataset.to===r.status){closeModal();msg('審核狀態沒有改變，不需要發送雲端請求');return}attempt('regV04Review',{eid,key,status:b.dataset.to,expectedVersion:r.recordVersion})});}
function editEntry(key){const r=rows[key],p=extras[key];if(!r)return;openModal(`<h2>編輯選手資料</h2><form id="entryForm"><label>比賽名稱</label><input name="playerName" required maxlength="50" value="${safe(r.playerName)}"><label>手機後三碼</label><input name="phone3" inputmode="numeric" pattern="[0-9]{3}" required value="${safe(r.phone3)}"><label>LINE 名稱</label><input name="lineName" maxlength="40" required value="${safe(p?.lineName||'')}"><div class="formBtns"><button type="submit">儲存</button><button type="button" class="alt" id="cancel">取消</button></div></form><button type="button" class="bad close" id="deleteRow">刪除選手</button>`);$('cancel').onclick=closeModal;$('entryForm').onsubmit=e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));if(data.playerName.trim()===r.playerName&&data.phone3.trim()===r.phone3&&data.lineName.trim()===(p?.lineName||'')){closeModal();msg('選手資料未變更，不需要發送雲端請求');return}attempt('regV04EditEntry',{eid,key,expectedVersion:r.recordVersion,...data})};$('deleteRow').onclick=()=>{if(confirm('確定刪除這筆報名？'))attempt('regV04DeleteEntry',{eid,key,expectedVersion:r.recordVersion})};}
function editEvent(){openModal(`<h2>編輯比賽</h2><form id="editForm">${formFields(eventMeta)}<div class="formBtns"><button type="submit">儲存</button><button class="alt" type="button" id="cancel">取消</button></div></form>`);$('cancel').onclick=closeModal;$('editForm').onsubmit=e=>{e.preventDefault();const data=collect(e.target);if(Object.entries(data).every(([k,v])=>v===eventMeta[k])){closeModal();msg('活動設定未變更，不需要發送雲端請求');return}attempt('regV04UpdateEvent',{eid,expectedVersion:eventMeta.version,...data})}}
function toggleOpen(){attempt('regV04SetOpen',{eid,open:!eventMeta.open,expectedVersion:eventMeta.version})}
function deleteEvent(){if(!confirm('確定刪除此比賽及全部報名紀錄？無法復原！'))return;attempt('regV04DeleteEvent',{eid}).then(v=>{if(v)go('home')})}
window.addEventListener('hashchange',fromHash);window.addEventListener('pageshow',e=>{if(e.persisted)managerWake()});window.addEventListener('pagehide',managerSleep);
document.addEventListener('visibilitychange',()=>document.visibilityState==='visible'?managerWake():managerSleep());
// No background interval: a foreground-only watchdog handles HTTPS fallback and safety checks.
onAuthStateChanged(auth,u=>{user=u;$('authBtn').textContent=u?'登出':'主辦登入';msg(u?'已登入｜HTTPS 雲端資料模式':'登入後可建立和審核比賽');fromHash()});
