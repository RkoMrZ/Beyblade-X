
'use strict';
const DB='https://ljtreg-39954-default-rtdb.asia-southeast1.firebasedatabase.app',eid=(new URLSearchParams(location.search).get('e')||new URLSearchParams(location.search).get('event')||location.pathname.match(/^\/q\/([A-Z0-9]{5})\/?$/)?.[1]||''), $=s=>document.getElementById(s),safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const names={pending:'待審核',approved:'通過',rejected:'不通過'};
let meta=null,rows=null,requesting=false,lastUpdate=0,syncToken=null,lastChangeCursor="";
// SSE listens only to the tiny, public syncV05/<event> marker, NOT the roster.
// All registration/review data remain HTTPS-only; this public page cannot write.
let liveStream=null,liveOnline=false,scheduled=null,missedUpdate=false,reconnect=null,pendingHint=null,liveDenied=false,retryAttempt=0;
// V0.5 idle lifecycle: foreground users retain realtime; hidden pages retain NO network activity.
let statusSleeping=document.visibilityState!=='visible',statusResumePending=false,statusWatch=null,statusStable=null;
let fallbackAfter=0,fallbackFailures=0;
function statusVisible(){return !statusSleeping&&document.visibilityState==='visible'}
function stopStatusWatch(){clearTimeout(statusWatch);statusWatch=null}
function startStatusWatch(){
 stopStatusWatch();if(!statusVisible()||rows===null)return;
 statusWatch=setTimeout(()=>{
  if(!statusVisible()||rows===null)return;
  const now=Date.now();
  if(liveOnline){if(now-lastUpdate>=120000)checkUpdate()}
  else if(now>=fallbackAfter){
   // HTTPS fallback is paced independently of SSE retries; at most one marker GET.
   fallbackAfter=now+Math.min(120000,30000*2**Math.min(fallbackFailures,2))+Math.floor(Math.random()*2500);
   checkUpdate();
  }
  startStatusWatch();
 },20000)
}
function sleepStatus(){
 statusSleeping=true;stopStatusWatch();stopLive();pendingHint=null;
 statusReadPool.abort();
}
function resumeStatus(){
 if(document.visibilityState!=='visible')return;
 statusSleeping=false;fallbackAfter=0;
 if(requesting){statusResumePending=true;return}
 if(rows===null){initial();return}
 startLive();scheduleCheck();startStatusWatch(); // always verify marker after resume
}
function finishStatusResume(){
 if(statusResumePending&&statusVisible()){
  statusResumePending=false;setTimeout(()=>{if(!statusVisible())return;resumeStatus()},0)
 }
}
function stopLive(){clearTimeout(reconnect);clearTimeout(scheduled);clearTimeout(statusStable);reconnect=scheduled=statusStable=null;if(liveStream){liveStream.close();liveStream=null}liveOnline=false}
function scheduleCheck(hint=null){if(!statusVisible()||rows===null)return;if(hint)pendingHint=hint;clearTimeout(scheduled);scheduled=setTimeout(()=>checkUpdate(),300)}
function startLive(){
 if(!statusVisible()||rows===null||liveStream||liveDenied||!eid||typeof EventSource==='undefined')return;
 const s=new EventSource(DB+'/syncV05/'+eid+'.json');liveStream=s;
 s.onopen=()=>{if(s!==liveStream||!statusVisible())return;liveOnline=true;fallbackFailures=0;notice('即時同步已連線，名單變動會自動顯示');clearTimeout(statusStable);statusStable=setTimeout(()=>{if(s===liveStream&&liveOnline)retryAttempt=0},30000)};
 const notify=ev=>{if(s!==liveStream||!statusVisible())return;try{const v=JSON.parse(ev.data);if(v.path==='/'){if(v.data?.token===syncToken)return;scheduleCheck(v.data)}else if(v.path==='/token')scheduleCheck({token:v.data});else if(v.path==='/lastChange')scheduleCheck()}catch{scheduleCheck()}};
 s.addEventListener('put',notify);s.addEventListener('patch',notify);
 s.addEventListener('cancel',()=>{if(s!==liveStream)return;stopLive();liveDenied=true;notice('即時訂閱被拒絕，改用定期更新',true)});
 s.addEventListener('auth_revoked',()=>{if(s!==liveStream)return;stopLive();liveDenied=true;notice('即時授權中斷，改用定期更新',true)});
 s.onerror=()=>{
  if(s!==liveStream)return;
  stopLive();if(!statusVisible()||liveDenied)return;
  // Own the retry schedule: prevent EventSource's uncontrolled native reconnect loop.
  const delay=Math.min(120000,2500*2**Math.min(retryAttempt++,6))+Math.floor(Math.random()*3500);
  notice('即時連線中斷；正以低頻檢查保持資料更新',true);
  reconnect=setTimeout(()=>{reconnect=null;startLive()},delay);
 };
}

function notice(t,bad=false){$('notice').className='status '+(bad?'warn':'ok');$('notice').textContent=t}
const statusReadPool=BBX.createReadPool(()=>statusVisible());
async function get(path,query=null){
 const u=new URL(DB+'/'+path+'.json');if(query)for(const [k,v] of Object.entries(query))u.searchParams.set(k,v);
 return statusReadPool.get(u.toString());
}
function render(){if(!meta||rows===null)return;let a=Object.values(rows).filter(x=>x&&x.status!=='deleted').sort((x,y)=>x.signupNo-y.signupNo),n=0,m=new Map();for(const r of a){if(r.status==='rejected')continue;n++;m.set(r.signupNo,n<=meta.capacity?'正選#'+n:'備選#'+(n-meta.capacity))}a.sort((x,y)=>(x.status==='rejected')-(y.status==='rejected')||x.signupNo-y.signupNo);const q=$('search').value.trim().toLowerCase(),matched=a.filter(r=>r.playerName.toLowerCase().includes(q)||r.phone3.includes(q));$('count').textContent='總報名 '+a.length+' 人 · 有效順位 '+n+' 人';$('rows').innerHTML=matched.length?matched.map(r=>`<tr><td class="rank">${safe(m.get(r.signupNo)||'—')}</td><td>${safe(r.playerName)}</td><td>${safe(r.phone3)}</td><td><span class="pill ${safe(r.status)}">${safe(names[r.status]||'未知')}</span></td></tr>`).join(''):'<tr><td colspan="4">目前沒有符合條件的報名</td></tr>';$('last').textContent='最新確認：'+new Date(lastUpdate).toLocaleTimeString('zh-TW',{hour12:false})}
async function initial(){
 if(!/^[A-Z0-9]{5}$/.test(eid)){notice('報名連結無效',true);return}
 if(requesting){missedUpdate=true;return}
 requesting=true;
 try{
  const marker=await get('syncV05/'+eid);
  const [m,r]=await Promise.all([get('eventsV05/'+eid+'/meta'),get('publicRowsV05/'+eid)]);
  if(!m||m.deleted)throw Error('活動不存在或已刪除');
  if(!statusVisible())return;meta=m;rows=r||{};syncToken=marker?.token||null;lastChangeCursor=marker?.lastChange||'';lastUpdate=Date.now();
  $('title').textContent=m.title;document.title=m.title+'｜公開查詢';render();notice('已取得正式雲端公開名單');startLive();startStatusWatch();
 }catch(e){if(!(e.name==='AbortError'&&!statusVisible()))notice('讀取失敗：'+e.message,true)}
 finally{requesting=false;if(missedUpdate){missedUpdate=false;scheduleCheck()}finishStatusResume()}
 // The EventSource initial 'put' event replays the current marker. Any write between
 // our initial marker and the roster snapshot is replayed from lastChangeCursor.
 // No extra startup GET: if SSE is unavailable, the 20-second fallback checks it.
}
async function checkUpdate(){
 if(!rows)return;
 if(requesting){missedUpdate=true;return}
 requesting=true;
 try{
  const hinted=pendingHint;pendingHint=null;
  // An SSE root event includes both token and lastChange; token-only events
  // deliberately use one marker GET, preserving out-of-order write detection.
  const stamp=hinted?.token&&typeof hinted.lastChange==='string'?hinted:await get('syncV05/'+eid);
  if(!stamp){rows=null;stopLive();$('rows').innerHTML='<tr><td colspan="4">活動已刪除</td></tr>';throw Error('活動已刪除')}
  if(!statusVisible())return;
  if(stamp.token===syncToken){lastUpdate=Date.now();fallbackFailures=0;return}
  // Push-key creation order and transaction commit order can differ. If a later
  // completed write points behind our cursor, a cursor-only query would miss it.
  if(lastChangeCursor&&stamp.lastChange&&stamp.lastChange<=lastChangeCursor){requesting=false;await initial();return}
  // Fetch only journal entries after the last processed push-key. Firebase startAt is inclusive.
  const query=lastChangeCursor?{'orderBy':'"$key"','startAt':JSON.stringify(lastChangeCursor),'limitToFirst':'101'}:{'orderBy':'"$key"','limitToFirst':'101'};
  const history=await get('changesV05/'+eid,query);
  const list=Object.entries(history||{}).sort((a,b)=>a[0].localeCompare(b[0]));
  const continuous=lastChangeCursor?list[0]?.[0]===lastChangeCursor:true;
  // Journal compaction, missing cursor, or excessive burst => one safe full-roster refresh.
  if(!continuous||list.length>=101||(stamp.lastChange&&!list.some(([key])=>key===stamp.lastChange))){requesting=false;await initial();return}
  const fresh=list.filter(([key])=>key!==lastChangeCursor),affected=new Set();let metaChanged=false;
  for(const [key,item] of fresh){if(item.type==='meta')metaChanged=true;
   else if(/^p\d{8}$/.test(item.key||''))affected.add(item.key)}
  let nextMeta=meta;const nextRows={...rows};
  if(metaChanged){const m=await get('eventsV05/'+eid+'/meta');if(!m||m.deleted)throw Error('活動已刪除');nextMeta=m}
  // Several edits of one player in a burst become one GET. Bounded parallelism avoids floods.
  const keys=[...affected];for(let i=0;i<keys.length;i+=6){await Promise.all(keys.slice(i,i+6).map(async key=>{const r=await get('publicRowsV05/'+eid+'/'+key);if(r)nextRows[key]=r;else delete nextRows[key]}))}
  
  if(!statusVisible())return;meta=nextMeta;rows=nextRows;$('title').textContent=meta.title;document.title=meta.title+'｜公開查詢';lastChangeCursor=list.at(-1)?.[0]||lastChangeCursor;syncToken=stamp.token;lastUpdate=Date.now();fallbackFailures=0;render();notice('已套用最新雲端變更');
 }catch(e){if(!(e.name==='AbortError'&&!statusVisible())){fallbackFailures=Math.min(fallbackFailures+1,2);notice('目前無法確認最新名單：'+e.message+'；不會寫回手機舊資料',true)}}
 finally{requesting=false;if(missedUpdate||(pendingHint&&pendingHint.token!==syncToken)){missedUpdate=false;scheduleCheck()}finishStatusResume()}
}
$('search').oninput=render;
$('refresh').onclick=()=>rows?checkUpdate():initial();
// When SSE is healthy: lightweight safety check every ~2 minutes.
// When SSE is disconnected: only one small marker read every 20 seconds.
document.addEventListener('visibilitychange',()=>document.visibilityState==='visible'?resumeStatus():sleepStatus());
window.addEventListener('pageshow',e=>{if(e.persisted)resumeStatus()});
window.addEventListener('pagehide',sleepStatus);
initial();
