'use strict';
// Shared infrastructure only; business data is never persisted or cached here.
try{document.documentElement.dataset.theme=localStorage.getItem('reg-v05-theme')==='light'?'light':'dark'}catch{}
window.BBX=Object.freeze({
 aborted:()=>new DOMException('頁面已休眠或已切換','AbortError'),
 createQueue(){
  let tail=Promise.resolve();const pending=new Map();
  return {run(key,fn){
   if(pending.has(key))return pending.get(key);
   const task=tail.then(fn);
   const result=task.finally(()=>{if(pending.get(key)===result)pending.delete(key)});
   pending.set(key,result);tail=result.catch(()=>{});return result;
  }};
 },
 createReadPool(enabled){
  const pending=new Map();
  return {
   get(url){
    if(!enabled())return Promise.reject(BBX.aborted());
    if(pending.has(url))return pending.get(url).promise;
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),12000);
    const entry={ctl,promise:null};
    entry.promise=(async()=>{
     try{
      const response=await fetch(url,{cache:'no-store',signal:ctl.signal});
      if(!response.ok)throw Error('雲端讀取失敗（HTTP '+response.status+'）');
      const data=await response.json();
      if(ctl.signal.aborted||!enabled())throw BBX.aborted();
      return data;
     }finally{clearTimeout(timer);if(pending.get(url)===entry)pending.delete(url)}
    })();
    pending.set(url,entry);return entry.promise;
   },
   abort(){for(const entry of pending.values())entry.ctl.abort();pending.clear()}
  };
 }
});
