'use strict';
// In-memory deterministic simulation, NOT real Firebase Emulator or pressure testing.
const assert=require('node:assert/strict'),Module=require('node:module'),path=require('node:path');
const state={},clone=x=>x===undefined?undefined:structuredClone(x);let q=Promise.resolve(),pushNo=0,failRootUpdate=null,nullOnlyTransactions=0;const activeListeners=new Map();
const keys=p=>String(p).split('/').filter(Boolean);
const get=p=>clone(keys(p).reduce((c,k)=>c?.[k],state));
function set(p,v){const a=keys(p);if(!a.length)throw Error('root');let cur=state;for(const k of a.slice(0,-1))cur=cur[k]??={};if(v===null||v===undefined)delete cur[a.at(-1)];else cur[a.at(-1)]=clone(v)}
function snap(v){return {val:()=>clone(v),exists:()=>v!==null&&v!==undefined,hasChild:k=>v!=null&&Object.hasOwn(v,k),numChildren:()=>Object.keys(v||{}).length}}
function ref(p=''){return {
 orderByKey(){const rows=()=>Object.entries(get(p)||{}).sort(([a],[b])=>a.localeCompare(b));return {
  limitToFirst:n=>({get:async()=>snap(Object.fromEntries(rows().slice(0,n)))}),
  limitToLast:n=>({get:async()=>snap(Object.fromEntries(rows().slice(-n)))}),
  endAt:k=>({get:async()=>snap(Object.fromEntries(rows().filter(([key])=>key<=k)))})
 }},
 child:k=>ref(p+'/'+k),push(){return {key:'-chg'+String(++pushNo).padStart(16,'0')}},async get(){return snap(get(p))},
 on(type,callback){assert.equal(type,'value');const listeners=activeListeners.get(p)||new Set();listeners.add(callback);activeListeners.set(p,listeners);queueMicrotask(()=>callback(snap(get(p))));return callback},
 off(type,callback){const listeners=activeListeners.get(p);if(listeners){listeners.delete(callback);if(!listeners.size)activeListeners.delete(p)}},
 async update(up){
 const failure=p===''?failRootUpdate:null;
 if(failure){failRootUpdate=null;if(failure==='before')throw Error('injected: server rejected before commit')}
 // RTDB multi-location update is atomic; the fake must preserve that property.
 const backup=clone(state);
 try{for(const [k,v] of Object.entries(up))set(p?(p+'/'+k):k,v)}catch(e){for(const k of Object.keys(state))delete state[k];Object.assign(state,backup);throw e}
 if(failure==='after')throw Error('injected: response lost after server commit');
 },transaction(fn){const job=q.then(()=>{const cur=get(p)??null;
 if(cur!==null&&!activeListeners.has(p)){
  // Model RTDB cold cache: aborting the speculative null means no server retry.
  const guess=fn(null);if(guess===undefined)return {committed:false,snapshot:snap(cur)};
 }
 const output=fn(clone(cur));if(output===undefined)return {committed:false,snapshot:snap(cur)};set(p,output);return {committed:true,snapshot:snap(output)}});q=job.catch(()=>{});return job}}}

class HttpsError extends Error{constructor(code,message){super(message);this.code=code}}
const load=Module._load;
Module._load=function(id,parent,main){if(id==='firebase-functions/v2/https')return {onCall:(_,f)=>f,HttpsError};if(id==='firebase-admin/app')return {initializeApp:()=>{},getApps:()=>[{}]};if(id==='firebase-admin/database')return {getDatabase:()=>({ref})};return load.apply(this,arguments)};
const api=require(path.join(__dirname,'../index.js'));Module._load=load;
const owner={auth:{uid:'owner',token:{firebase:{sign_in_provider:'google.com'}}}},other={auth:{uid:'other',token:{firebase:{sign_in_provider:'google.com'}}}},guest={auth:null};
let cid=0;const call=(n,data,as=owner)=>api[n]({...as,data:n==='regV05CreateEvent'&&!data.createId?{...data,createId:(++cid).toString(16).padStart(48,'0')}:data});
(async()=>{
 const event={title:'金魚盃',eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'體育館',fee:0,capacity:32};
 const idFirst='f'.repeat(48);const {eid}=await call('regV05CreateEvent',{...event,createId:idFirst});
 assert.match(eid,/^[A-Z0-9]{5}$/,'event IDs must be 5 readable characters');
 const replayCreate=await call('regV05CreateEvent',{...event,createId:idFirst});assert.equal(replayCreate.eid,eid);assert.equal(replayCreate.replayed,true);
 await assert.rejects(call('regV05CreateEvent',{...event,createId:idFirst,title:'錯誤重送名稱'}),/已使用不同的活動資料/);
 assert.equal(get(`allocV05/${eid}/rankIndexed`),true);assert.equal(get(`allocV05/${eid}/next`),0);assert.equal(get(`ownerEventsV05/owner/${eid}/title`),'金魚盃');
 await assert.rejects(call('regV05UpdateEvent',{eid,...event,expectedVersion:1},other),/權限/);
 const rid=i=>i.toString(16).padStart(48,'0');
 const form=i=>({eid,rid:rid(i),playerName:'選手 '+i,phone3:'093',lineName:'同一 LINE'});
 const results=await Promise.all(Array.from({length:64},(_,i)=>call('regV05Submit',form(i+1),guest)));
 assert.deepEqual(results.map(x=>x.signupNo).sort((a,b)=>a-b),Array.from({length:64},(_,i)=>i+1));
 assert.equal(Object.keys(get(`publicRowsV05/${eid}`)).length,64);
 assert.equal(Object.keys(get(`rankActiveV05/${eid}`)).length,64);
 const receiptForNo=n=>Object.entries(get(`receiptsV05/${eid}`)).find(([,r])=>r.signupNo===n)[0];
 const selfRank=n=>call('regV05MyRank',{eid,rid:receiptForNo(n)},guest);
 assert.equal((await selfRank(33)).rankLabel,'備選#1');
 await assert.rejects(call('regV05MyRank',{eid,rid:'e'.repeat(48)},guest),/找不到這筆報名/);
 await call('regV05CreateEvent',{...event,createId:idFirst});assert.equal(get(`allocV05/${eid}/next`),64,'retrying event creation must NOT reset the allocator');assert.equal(Object.keys(get(`nameClaimsV05/${eid}`)).length,64);
 assert.equal(get(`publicRowsV05/${eid}/p00000001/lineName`),undefined);
 assert.equal(get(`privateRowsV05/${eid}/p00000001/lineName`),'同一 LINE');
 assert.equal((await call('regV05Submit',form(1),guest)).signupNo,1);
 await assert.rejects(call('regV05Submit',{...form(65),playerName:'選手 1',phone3:'777',lineName:'其他 LINE'},guest),/比賽名稱/);
 // Normalized Unicode and case variants must not bypass the name uniqueness index.
 await assert.rejects(call('regV05Submit',{...form(65),playerName:'選手　1',phone3:'777'},guest),/比賽名稱/);
 const raceEvent=await call('regV05CreateEvent',{...event,title:'並發同名測試'});
 const contest=await Promise.allSettled([
   call('regV05Submit',{eid:raceEvent.eid,rid:rid(301),playerName:'只有一位',phone3:'093',lineName:'甲'},guest),
   call('regV05Submit',{eid:raceEvent.eid,rid:rid(302),playerName:'只有一位',phone3:'222',lineName:'乙'},guest)
 ]);
 assert.equal(contest.filter(x=>x.status==='fulfilled').length,1,'concurrent identical playerName cannot both commit');
 assert.equal(Object.keys(get(`publicRowsV05/${raceEvent.eid}`)).length,1);
 // Fault injection: atomic write fails before commit, retry can recover safely.
 const faultEvent=(await call('regV05CreateEvent',{...event,title:'斷線測試'})).eid;
 const faultReq={eid:faultEvent,rid:rid(555),playerName:'離線仍能重試',phone3:'093',lineName:'LINE'};
 failRootUpdate='before';await assert.rejects(call('regV05Submit',faultReq,guest),/injected/);
 assert.equal(get(`publicRowsV05/${faultEvent}`),undefined,'no partial roster after failed atomic patch');
 const afterFail=await call('regV05Submit',faultReq,guest);assert.equal(afterFail.confirmed,true);
 assert.equal(Object.keys(get(`publicRowsV05/${faultEvent}`)).length,1);
 // Fault injection: write COMMITTED but HTTP response lost. Retry returns the one receipt.
 const afterCommitReq={eid:faultEvent,rid:rid(556),playerName:'回應遺失仍不重複',phone3:'093',lineName:'LINE'};
 failRootUpdate='after';await assert.rejects(call('regV05Submit',afterCommitReq,guest),/injected/);
 const afterCommit=await call('regV05Submit',afterCommitReq,guest);assert.equal(afterCommit.confirmed,true);
 assert.equal(Object.keys(get(`publicRowsV05/${faultEvent}`)).length,2);
 // A cold RTDB cache would initially return null without a listener;
 // transactionOnExisting temporarily attaches a listener to prime the value.
 const nullRetry=await call('regV05Submit',{eid:faultEvent,rid:rid(557),playerName:'第一次空值也應成功',phone3:'093',lineName:'LINE'},guest);
 assert.equal(nullRetry.confirmed,true);
 const newNo=await call('regV05Submit',{...form(65),playerName:'新選手',phone3:'093',lineName:'同一 LINE'},guest);
 assert.equal(newNo.signupNo,65);
 const rank=n=>Object.values(get(`publicRowsV05/${eid}`)).filter(x=>x.signupNo<=n&&x.status!=='rejected').length;
 await call('regV05Review',{eid,key:'p00000010',status:'rejected',expectedVersion:1});assert.equal(rank(33),32);
 assert.equal((await selfRank(33)).rankLabel,'正選#32');
 assert.equal((await selfRank(10)).rankLabel,null);
 assert.equal(get(`rankActiveV05/${eid}/p00000010`),undefined);
 await assert.rejects(call('regV05Review',{eid,key:'p00000010',status:'approved',expectedVersion:1}),/其他裝置修改/);
 await call('regV05Review',{eid,key:'p00000010',status:'approved',expectedVersion:2});assert.equal(rank(33),33);
 assert.equal((await selfRank(33)).rankLabel,'備選#1');
 assert.equal((await selfRank(10)).rankLabel,'正選#10');
 const oldName=get(`privateRowsV05/${eid}/p00000001/nameKey`);
 const edit=await call('regV05EditEntry',{eid,key:'p00000001',expectedVersion:1,playerName:'更名選手',phone3:'093',lineName:'更名 LINE'});
 assert.equal(edit.row.playerName,'更名選手');assert.equal(get(`privateRowsV05/${eid}/p00000001/lineName`),'更名 LINE');
 assert.equal(get(`nameClaimsV05/${eid}/${oldName}`),undefined);
 await assert.rejects(call('regV05EditEntry',{eid,key:'p00000002',expectedVersion:1,playerName:'更名選手',phone3:'123',lineName:'不同 LINE'}),/已被使用/);
 await call('regV05DeleteEntry',{eid,key:'p00000002',expectedVersion:1});
 assert.equal(get(`publicRowsV05/${eid}/p00000002`),undefined);
 assert.equal(get(`rankActiveV05/${eid}/p00000002`),undefined);
 assert.equal((await selfRank(33)).rankLabel,'正選#32');
 await assert.rejects(call('regV05Submit',form(2),guest),/已被移除/);
 await assert.rejects(call('regV05UpdateEvent',{eid,...event,capacity:24,expectedVersion:1}),/不可更改正選/);
 const updated=await call('regV05SetOpen',{eid,open:false,expectedVersion:1});assert.equal(updated.meta.open,false);
 await assert.rejects(call('regV05Submit',{...form(66),playerName:'關閉後報名'},guest),/未開放/);
 assert.ok(Object.keys(get(`changesV05/${eid}`)).length>=69);
 // Exercise opportunistic journal retention with many edits to existing single-row data.
 let rversion=get(`publicRowsV05/${eid}/p00000003/recordVersion`);
 for(let j=0;j<700;j++){
  const next=j%2?'pending':'approved';
  await call('regV05Review',{eid,key:'p00000003',status:next,expectedVersion:rversion++});
 }
 assert.ok(Object.keys(get(`changesV05/${eid}`)).length<500,'journal should compact older entries');
 assert.ok(get(`syncV05/${eid}`).token);
 assert.deepEqual(Object.keys(api).filter(k=>k.startsWith('reg')).sort(),['regV05CreateEvent','regV05DeleteEntry','regV05DeleteEvent','regV05DeleteLegacyEvent','regV05EditEntry','regV05MyRank','regV05Review','regV05SetOpen','regV05Submit','regV05UpdateEvent'].sort());
 // Deleting an active event first closes the gate; retry cleans up after leases end.
 set(`allocV05/${eid}/active`,{testActive:Date.now()+60000});
 await assert.rejects(call('regV05DeleteEvent',{eid}),/仍有操作處理中/);
 assert.equal(get(`allocV05/${eid}/deleted`),true);
 set(`allocV05/${eid}/active`,{});
 await call('regV05DeleteEvent',{eid});assert.equal(get(`publicRowsV05/${eid}`),undefined);assert.equal(get(`privateRowsV05/${eid}`),undefined);assert.equal(get(`ownerEventsV05/owner/${eid}`),undefined);
 assert.equal(get(`rankActiveV05/${eid}`),undefined);
 assert.deepEqual(Object.keys(get(`eventsV05/${eid}`)).sort(),['createProof','deleted','deletedAt','ownerUid'].sort());
 assert.deepEqual(get(`allocV05/${eid}`),{deleted:true,open:false},'allocator tombstone contains no roster/counters');
 await assert.rejects(call('regV05CreateEvent',{...event,createId:idFirst}),/已刪除/);
 assert.equal((await call('regV05DeleteEvent',{eid})).ok,true,'lost delete response can be retried');
 // Deterministic Base36 collision fixture: two distinct create requests begin with HRECR.
 // The second MUST probe a different code instead of corrupting the first event.
 const ca='000000000000000000000000000000000000000000000212';
 const cb='000000000000000000000000000000000000000000000761';
 const one=await call('regV05CreateEvent',{...event,title:'短碼碰撞甲',createId:ca});
 const two=await call('regV05CreateEvent',{...event,title:'短碼碰撞乙',createId:cb});
 assert.equal(one.eid,'5IJRP');assert.equal(two.eid,'FSYV8');
 assert.notEqual(one.eid,two.eid,'collision must allocate another code');
 assert.equal((await call('regV05CreateEvent',{...event,title:'短碼碰撞甲',createId:ca})).eid,one.eid);
 assert.equal((await call('regV05CreateEvent',{...event,title:'短碼碰撞乙',createId:cb})).eid,two.eid);
 assert.equal(get(`eventsV05/${one.eid}/meta/title`),'短碼碰撞甲');
 assert.equal(get(`eventsV05/${two.eid}/meta/title`),'短碼碰撞乙');
 await call('regV05DeleteEvent',{eid:one.eid});await call('regV05DeleteEvent',{eid:two.eid});
 // Legacy deletion: verified V03/V04 schema roots only. No cross-version spillover.
 const legacyId='LM123',legacyOther='UV987';
 for(const version of ['V03','V04']){
  set(`events${version}/${legacyId}`,{ownerUid:'owner',meta:{title:'舊活動'}});
  set(`ownerEvents${version}/owner/${legacyId}`,{title:'歷史活動'});
  for(const root of ['alloc','publicRows','privateRows','nameClaims','receipts','rowLocks','rankActive','changes','sync',...(version==='V04'?['managerRows']:[])])set(`${root}${version}/${legacyId}`,{sample:'must-be-removed'});
 }
 set(`eventsV03/${legacyOther}`,{ownerUid:'other'});set(`publicRowsV03/${legacyOther}`,{secret:'other'});
 await assert.rejects(call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:legacyOther,confirm:legacyOther}),{code:'permission-denied'});
 await assert.rejects(call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:legacyId,confirm:'NOTIT'}),/輸入完整活動代碼/);
 await assert.rejects(call('regV05DeleteLegacyEvent',{sourceVersion:'V02',eid:legacyId,confirm:legacyId}),/只支援/);
 await call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:legacyId,confirm:legacyId});
 for(const root of ['events','alloc','publicRows','privateRows','nameClaims','receipts','rowLocks','rankActive','changes','sync'])assert.equal(get(`${root}V03/${legacyId}`),undefined,'legacy path remains '+root);
 assert.equal(get(`ownerEventsV03/owner/${legacyId}`),undefined);
 assert.equal(get(`eventsV04/${legacyId}/ownerUid`),'owner','same code in another version must survive');
 assert.equal(get(`publicRowsV03/${legacyOther}/secret`),'other','different owner survives');
 await call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:legacyId,confirm:legacyId}); // idempotent receipt
 // Orphaned canonical owner: a leftover index by itself is NOT enough.
 set(`eventsV04/${legacyId}`,null);
 await assert.rejects(call('regV05DeleteLegacyEvent',{sourceVersion:'V04',eid:legacyId,confirm:legacyId}),{code:'permission-denied'});
 assert.ok(get(`privateRowsV04/${legacyId}`),'uncertain owner cannot be swept');
 // A receipt created by THIS version after verifying original owner allows safe resume.
 set(`legacyCleanupV05/V04/${legacyId}`,{ownerUid:'owner',startedAt:Date.now()});
 await call('regV05DeleteLegacyEvent',{sourceVersion:'V04',eid:legacyId,confirm:legacyId});
 for(const root of ['events','alloc','publicRows','privateRows','managerRows','nameClaims','receipts','rowLocks','rankActive','changes','sync'])assert.equal(get(`${root}V04/${legacyId}`),undefined);
 assert.equal(get(`ownerEventsV04/owner/${legacyId}`),undefined);
 assert.equal(get(`legacyCleanupV05/V03/${legacyId}/ownerUid`),'owner');
 await assert.rejects(call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:legacyId,confirm:legacyId},other),{code:'permission-denied'});
 // Historical cleanup with response lost after committed multipath patch.
 const lostLegacy='LR321';
 set(`eventsV03/${lostLegacy}`,{ownerUid:'owner'});set(`ownerEventsV03/owner/${lostLegacy}`,{title:'retry'});
 set(`privateRowsV03/${lostLegacy}`,{p00000001:{lineName:'private'}});
 failRootUpdate='after';
 await assert.rejects(call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:lostLegacy,confirm:lostLegacy}),/injected/);
 assert.equal(get(`privateRowsV03/${lostLegacy}`),undefined);
 await call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:lostLegacy,confirm:lostLegacy});
 assert.equal(get(`legacyCleanupV05/V03/${lostLegacy}/ownerUid`),'owner');
 const orphan='NO123';set(`publicRowsV03/${orphan}`,{p00000001:{name:'orphan'}});
 await assert.rejects(call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:orphan,confirm:orphan}),{code:'permission-denied'});
 assert.ok(get(`publicRowsV03/${orphan}`),'unverified orphan must not be silently removed');
 // A crashed CreateEvent may leave only an event owner record, no allocator.
 const partialCid=rid(998);const partial=(await call('regV05CreateEvent',{...event,title:'半初始化活動',createId:partialCid})).eid;
 set(`allocV05/${partial}`,null);
 await call('regV05DeleteEvent',{eid:partial});
 assert.deepEqual(get(`allocV05/${partial}`),{deleted:true,open:false});
 await assert.rejects(call('regV05CreateEvent',{...event,title:'半初始化活動',createId:partialCid}),/已刪除/);
 assert.equal(get(`ownerEventsV05/owner/${partial}`),undefined);
 // Permanent ledger recovers current orphan data without canonical/index.
 const recovery=(await call('regV05CreateEvent',{...event,title:'清理登記測試'})).eid;
 const ledgerPath=`eventLifecycleV05/V05/${recovery}`;
 assert.equal(get(ledgerPath+'/ownerUid'),'owner');
 assert(get(ledgerPath+'/paths').includes(`privateRowsV05/${recovery}`));
 set(`eventsV05/${recovery}`,null);set(`ownerEventsV05/owner/${recovery}`,null);
 set(`privateRowsV05/${recovery}`,{sample:'orphan'});
 await assert.rejects(call('regV05DeleteEvent',{eid:recovery},other),{code:'permission-denied'});
 assert(get(`privateRowsV05/${recovery}`));
 const validPaths=get(ledgerPath+'/paths');
 set(ledgerPath+'/paths',[...validPaths,'privateRowsV05/OTHER']);
 await assert.rejects(call('regV05DeleteEvent',{eid:recovery}),{code:'failed-precondition'});
 assert(get(`privateRowsV05/${recovery}`),'invalid path cannot clear anything');
 set(ledgerPath+'/paths',validPaths);
 await call('regV05DeleteEvent',{eid:recovery});
 assert.equal(get(`privateRowsV05/${recovery}`),undefined);
 assert.equal(get(ledgerPath+'/state'),'deleted');
 assert((await call('regV05DeleteEvent',{eid:recovery})).ok);
 // Legacy retry remains possible using only permanent lifecycle evidence.
 set(`legacyCleanupV05/V03/${legacyId}`,null);
 set(`privateRowsV03/${legacyId}`,{sample:'residual'});
 await call('regV05DeleteLegacyEvent',{sourceVersion:'V03',eid:legacyId,confirm:legacyId});
 assert.equal(get(`privateRowsV03/${legacyId}`),undefined);
 console.log('PASS PERMANENT LIFECYCLE: missing main/index recovery, foreign owner denied, path injection denied, retry, legacy proof retained');
 console.log('PASS PARTIAL CREATE: no allocator, deleted marker, no resurrected index after retry');
 console.log('PASS LEGACY CLEANUP: V03/V04 exact manifest, partial deletion recovery, ownership isolation, collision isolation, response-lost retry');
 console.log('PASS 5-CHAR COLLISION: two colliding requests allocate separate events; both retries preserve original codes');
 console.log('PASS RANK OPTIMIZATION: own-receipt rank, 64 concurrent submissions, reject/promote/restore, delete, compact index; PASS: V0.5 hardened / partial-failure-before-commit / response-lost-after-commit / repeatable create / change-journal-maintenance / delete-while-busy / V0.5 node split, 64 parallel simulated submissions, unique NAME only, shared phone/LINE allowed, receipt dedupe, version rejection, review/recover, edit claim, delete, owner isolation, V0.5-only exports');
})().catch(e=>{console.error(e);process.exitCode=1});
