'use strict';
const assert=require('node:assert/strict');
const {roots,cleanupPaths,LEGACY_VERSIONS}=require('../cleanup_manifest');
const expected={V03:['events','alloc','publicRows','privateRows','nameClaims','receipts','rowLocks','rankActive','sync','changes'],V04:['events','alloc','publicRows','privateRows','managerRows','nameClaims','receipts','rowLocks','rankActive','sync','changes'],V05:['events','alloc','publicRows','privateRows','managerRows','nameClaims','receipts','rowLocks','rankActive','sync','changes']};
assert.deepEqual(roots,expected);
for(const version of ['V03','V04','V05']){
 const updates=cleanupPaths(version,'ABCDE','good-uid');
 assert.equal(Object.keys(updates).length,roots[version].length+1);
 for(const root of roots[version])assert.equal(updates[`${root}${version}/ABCDE`],null);
 assert.equal(updates[`ownerEvents${version}/good-uid/ABCDE`],null);
 for(const path of Object.keys(updates))assert(!path.includes('other-id'));
}
assert.deepEqual(LEGACY_VERSIONS,['V03','V04']);
const retained=cleanupPaths('V05','ABCDE','good-uid',{retainEventTombstone:true,retainAllocatorTombstone:true});
assert(!Object.hasOwn(retained,'eventsV05/ABCDE'));
assert(!Object.hasOwn(retained,'allocV05/ABCDE'));
// Automatically fail if future backend writes add a new V05 event collection
// without listing it in the cleanup manifest. ownerEvents is the owner index,
// legacyCleanup is the small cross-version retry receipt.
const fs=require('node:fs'),path=require('node:path');
const backend=fs.readFileSync(path.join(__dirname,'../index.js'),'utf8');
const used=[...new Set([...backend.matchAll(/\b([A-Za-z][A-Za-z0-9]*)V05\//g)].map(x=>x[1]))].filter(x=>!['ownerEvents','legacyCleanup','eventLifecycle'].includes(x)).sort();
assert.deepEqual(used,[...roots.V05].sort(),'new V05 data node MUST be in cleanup manifest');
for(const version of ['V01','V02','V99'])assert.throws(()=>cleanupPaths(version,'ABCDE','uid'));
for(const id of ['BAD/1','hello','../../..'])assert.throws(()=>cleanupPaths('V05',id,'uid'));
console.log('PASS cleanup manifest: all verified event nodes, single-event scope, V05 tombstone, no unsafe versions');

const registry=require('../cleanup_registry.json');
const history=require('./cleanup_history.json');
for(const [v,schema] of Object.entries(history))assert.deepEqual(registry.schemas[v],schema,'historical schema must be preserved: '+v);
assert.equal(registry.currentVersion,JSON.parse(fs.readFileSync(path.join(__dirname,'../../RELEASE_VERSION.json'))).dataSuffix);
const rules=JSON.parse(fs.readFileSync(path.join(__dirname,'../../database.rules.json'))).rules;
for(const v of LEGACY_VERSIONS)assert(rules[registry.schemas[v].ownerIndex+v],'missing legacy owner-index rule: '+v);
const ui=fs.readFileSync(path.join(__dirname,'../../web/js/common.js'),'utf8');
assert.deepEqual(JSON.parse(ui.match(/CLEANUP_VERSIONS \*\/ (\[[^\]]*\])/)[1]),LEGACY_VERSIONS);
console.log('PASS permanent cleanup contract: history preserved, release namespace and UI/Rules coverage');

// Simulate a future release: the same engine discovers the formerly-current
// version automatically; no per-version deletion function is introduced.
const nextRegistry=JSON.parse(JSON.stringify(registry));
nextRegistry.schemas.V06=JSON.parse(JSON.stringify(nextRegistry.schemas.V05));
nextRegistry.currentVersion='V06';
const sandbox={module:{exports:{}},require:id=>{assert.equal(id,'./cleanup_registry.json');return nextRegistry}};
require('node:vm').runInNewContext(fs.readFileSync(path.join(__dirname,'../cleanup_manifest.js'),'utf8'),sandbox);
assert(sandbox.module.exports.LEGACY_VERSIONS.includes('V05'));
assert.equal(Object.keys(sandbox.module.exports.cleanupPaths('V05','ABCDE','uid')).length,roots.V05.length+1);
console.log('PASS future-version simulation: existing deletion engine handles V05 as historical');
