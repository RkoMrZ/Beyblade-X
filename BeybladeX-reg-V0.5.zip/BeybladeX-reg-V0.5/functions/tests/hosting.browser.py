"""Local Firebase Hosting Emulator only. Actual built HTML/assets; mocked Auth/RTDB."""
import os,json,urllib.request,urllib.error,importlib.util
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_support import browser_options
root=Path(__file__).resolve().parents[2];host=os.environ.get('HOSTING_EMULATOR_URL','http://127.0.0.1:5000')
assert host in ['http://127.0.0.1:5000','http://localhost:5000'], 'Only local emulator allowed'
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('request_audit_browser.py'));a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))
manifest=json.loads((root/'asset-manifest.json').read_text())
for route in ['/','/index','/index.html','/s/ABCDE','/q/ABCDE','/signup','/status']:
 with urllib.request.urlopen(host+route) as r:assert r.status==200;assert 'no-cache' in r.headers.get('Cache-Control',''),(route,dict(r.headers))
conditional=[]
for route in manifest.values():
 with urllib.request.urlopen(host+route) as r:
  assert 'immutable' in r.headers.get('Cache-Control','') and 'no-cache' not in r.headers.get('Cache-Control',''),(route,dict(r.headers));etag=r.headers.get('ETag')
 if etag:
  try:
   with urllib.request.urlopen(urllib.request.Request(host+route,headers={'If-None-Match':etag})) as r:
    assert r.read()==(root/'reg'/route.lstrip('/')).read_bytes()
    conditional.append({'path':route,'status':r.status,'etag':etag})
  except urllib.error.HTTPError as e:
   assert e.code==304;conditional.append({'path':route,'status':304,'etag':etag})
with sync_playwright() as pw:
 b=pw.chromium.launch(**browser_options())
 for width in [320,390,1280]:
  c=b.new_context(viewport={'width':width,'height':900});c.add_init_script(a.JS_SEED)
  def route(req):
   url=req.request.url
   if url.startswith(host+'/'):return req.continue_()
   if 'www.gstatic.com/firebasejs/' in url:
    if url.endswith('/firebase-app.js'):body='export const initializeApp=window.initializeApp;'
    else:body='export const getAuth=window.getAuth,GoogleAuthProvider=window.GoogleAuthProvider,onAuthStateChanged=window.onAuthStateChanged,signInWithPopup=window.signInWithPopup,signOut=window.signOut;'
    return req.fulfill(status=200,content_type='application/javascript',body=body,headers={'Access-Control-Allow-Origin':'*'})
   return req.abort()
  c.route('**/*',route);p=c.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.goto(host+'/s/ABCDE');p.wait_for_function('meta!==null');assert p.evaluate('document.documentElement.scrollWidth<=innerWidth')
  p.goto(host+'/q/ABCDE');p.wait_for_function('rows!==null');assert p.evaluate('document.documentElement.scrollWidth<=innerWidth')
  p.goto(host+'/');p.wait_for_selector('[data-manage]');p.locator('[data-manage]').click();p.wait_for_selector('#roster tbody tr');assert p.evaluate('document.documentElement.scrollWidth<=innerWidth')
  assert not errors,errors;c.close()
 b.close()
(root/'HOSTING_TEST_RESULTS.json').write_text(json.dumps({'conditionalRequests':conditional,'productionCDNVerified':False},indent=2)+'\n')
print('PASS HOSTING: actual built HTML + hashed JS/CSS loaded on 3 routes, 320/390/1280px; no page errors/overflow; HTML revalidation and immutable asset headers; conditional status recorded (production CDN requires post-deploy check)')
