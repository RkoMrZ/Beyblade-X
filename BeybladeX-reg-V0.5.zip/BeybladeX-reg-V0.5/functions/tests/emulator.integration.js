'use strict';
// Runs ONLY against a local Firebase RTDB Emulator (never against production).
// Invoke from BeybladeX-reg-V0.5 root:
// firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const Module=require('node:module');
const host=process.env.FIREBASE_DATABASE_EMULATOR_HOST||'';
if(!/^(localhost|127\.0\.0\.1):\d+$/.test(host)){
 console.error('REFUSING TO RUN: FIREBASE_DATABASE_EMULATOR_HOST must point to local RTDB emulator');process.exit(2);
}
// Local emulator traffic must bypass HTTP/WebSocket proxies.
for(const key of ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','WS_PROXY','WSS_PROXY','ws_proxy','wss_proxy'])delete process.env[key];
process.env.NODE_USE_ENV_PROXY='0';
// Use an isolated database namespace, never the real ljtreg-39954 namespace.
process.env.FIREBASE_CONFIG=JSON.stringify({projectId:'demo-ljtreg',databaseURL:'https://demo-ljtreg-default-rtdb.firebaseio.com'});
// We only replace the callable HTTP wrapper; all Firebase Admin SDK/database
// transactions are REAL and are routed to the emulator by the env variable.
const old=Module._load;
Module._load=function(id,parent,isMain){
 if(id==='firebase-functions/v2/https'){
  const real=old.apply(this,arguments);return {...real,onCall:(_cfg,fn)=>fn};
 }
 return old.apply(this,arguments);
};
const api=require('../index.js');Module._load=old;
const {getDatabase}=require('firebase-admin/database');
const db=getDatabase();
const owner={auth:{uid:'preflight-owner',token:{firebase:{sign_in_provider:'google.com'}}}};
const intruder={auth:{uid:'preflight-intruder',token:{firebase:{sign_in_provider:'google.com'}}}};
const guest={auth:null};
const createId=()=>crypto.randomBytes(24).toString('hex');
const invoke=(name,data,who=owner)=>api[name]({...who,data});
const prefix='emulator_'+Date.now().toString(36);
const mkForm=i=>({playerName:prefix+'_player_'+i,phone3:'093',lineName:'sameLINE',rid:createId()});
let eid=null;
(async()=>{
 const base={title:'模擬器 '+prefix,eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'測試體育館',fee:0,capacity:32};
 const cid=createId(),created=await invoke('regV05CreateEvent',{...base,createId:cid});eid=created.eid;
 assert.match(eid,/^[A-Z0-9]{5}$/,'event IDs must be 5 readable characters');
 const again=await invoke('regV05CreateEvent',{...base,createId:cid});assert.equal(again.eid,eid);
 await assert.rejects(invoke('regV05SetOpen',{eid,open:false,expectedVersion:1},intruder));
 const forms=Array.from({length:64},(_,i)=>({...mkForm(i),eid}));
 const results=await Promise.all(forms.map(f=>invoke('regV05Submit',f,guest)));
 const nums=results.map(x=>x.signupNo).sort((a,b)=>a-b);
 assert.deepEqual(nums,Array.from({length:64},(_,i)=>i+1));
 assert.equal((await db.ref(`publicRowsV05/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`rankActiveV05/${eid}`).get()).numChildren(),64);
 const ownNo=n=>results.findIndex(x=>x.signupNo===n);
 const myRank=n=>invoke('regV05MyRank',{eid,rid:forms[ownNo(n)].rid},guest);
 assert.equal((await myRank(33)).rankLabel,'備選#1');
 await invoke('regV05Review',{eid,key:'p00000001',status:'rejected',expectedVersion:1});
 assert.equal((await myRank(33)).rankLabel,'正選#32');
 await invoke('regV05Review',{eid,key:'p00000001',status:'approved',expectedVersion:2});
 assert.equal((await myRank(33)).rankLabel,'備選#1');
 assert.equal((await db.ref(`privateRowsV05/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`managerRowsV05/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`nameClaimsV05/${eid}`).get()).numChildren(),64);
 const replay=await invoke('regV05Submit',forms[0],guest);assert.equal(replay.signupNo,results[0].signupNo);
 await assert.rejects(invoke('regV05Submit',{...forms[0],rid:createId(),phone3:'777'},guest));
 const both=await Promise.allSettled([invoke('regV05Review',{eid,key:'p00000010',status:'rejected',expectedVersion:1}),invoke('regV05Review',{eid,key:'p00000010',status:'approved',expectedVersion:1})]);
 assert.equal(both.filter(x=>x.status==='fulfilled').length,1,'only one review may commit for a record version');
 const rv=(await db.ref(`publicRowsV05/${eid}/p00000010`).get()).val();assert.equal(rv.recordVersion,2);
 // Verify that external unauthenticated visitors cannot download LINE/private information.
 const namespace='demo-ljtreg-default-rtdb';
 const res=await fetch(`http://${host}/privateRowsV05/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.notEqual(res.status,200,'anonymous REST read of privateRows must be denied by Rules');
 const idx=await fetch(`http://${host}/rankActiveV05/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.notEqual(idx.status,200,'anonymous REST read of rankActive must be denied by Rules');
 const pub=await fetch(`http://${host}/publicRowsV05/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.equal(pub.status,200,'public simplified roster should be readable');
 const data=await pub.json();assert.equal(Object.values(data)[0].lineName,undefined);
 // V0.5 lean projection is atomically updated and owner-only; internal data is server-only.
 const {initializeApp}=require('firebase-admin/app');
 const ownerApp=initializeApp({projectId:'demo-ljtreg',databaseURL:'https://demo-ljtreg-default-rtdb.firebaseio.com',databaseAuthVariableOverride:{uid:'preflight-owner',token:{firebase:{sign_in_provider:'google.com'}}}},'rules-owner');
 const otherApp=initializeApp({projectId:'demo-ljtreg',databaseURL:'https://demo-ljtreg-default-rtdb.firebaseio.com',databaseAuthVariableOverride:{uid:'other',token:{firebase:{sign_in_provider:'google.com'}}}},'rules-other');
 const ownerDb=getDatabase(ownerApp),otherDb=getDatabase(otherApp);
 const projected=(await ownerDb.ref(`managerRowsV05/${eid}/p00000002`).get()).val();
 assert.deepEqual(Object.keys(projected).sort(),['lineName','recordVersion']);
 await assert.rejects(otherDb.ref(`managerRowsV05/${eid}`).get());
 await assert.rejects(ownerDb.ref(`privateRowsV05/${eid}`).get());
 await assert.rejects(ownerDb.ref(`managerRowsV05/${eid}/p00000002/lineName`).set('forbidden'));
 const orig=(await db.ref(`publicRowsV05/${eid}/p00000002`).get()).val();
 const edited=await invoke('regV05EditEntry',{eid,key:'p00000002',expectedVersion:orig.recordVersion,playerName:orig.playerName,phone3:orig.phone3,lineName:'Updated LINE'});
 assert.deepEqual(Object.keys(edited.private).sort(),['lineName','recordVersion']);
 assert.equal((await db.ref(`managerRowsV05/${eid}/p00000002/lineName`).get()).val(),'Updated LINE');
 await invoke('regV05Review',{eid,key:'p00000002',expectedVersion:edited.row.recordVersion,status:'approved'});
 const journal=(await db.ref(`changesV05/${eid}`).orderByKey().limitToLast(2).get()).val();
 assert(Object.values(journal).every(x=>Number.isSafeInteger(x.recordVersion)));
 console.log('PASS V05 PROJECTION: owner-only lean records; foreign owner/internal records/client writes denied; edit/review versions published');
 // Real RTDB Emulator collision regression; the seed pair maps to PYC7C at attempt 0.
 const collisionA='000000000000000000000000000000000000000000000b3b';
 const collisionB='000000000000000000000000000000000000000000004c37';
 const [first,second]=await Promise.all([
  invoke('regV05CreateEvent',{...base,title:'碰撞測試 A',createId:collisionA}),
  invoke('regV05CreateEvent',{...base,title:'碰撞測試 B',createId:collisionB})
 ]);
 assert.notEqual(first.eid,second.eid,'atomic code allocation must survive concurrent creation and a collision');
 assert([first.eid,second.eid].includes('S4WFQ'),'both requests have the same attempt-zero code');
 assert.equal((await db.ref(`eventsV05/${first.eid}/meta/title`).get()).val(),'碰撞測試 A');
 assert.equal((await db.ref(`eventsV05/${second.eid}/meta/title`).get()).val(),'碰撞測試 B');
 assert.equal((await invoke('regV05CreateEvent',{...base,title:'碰撞測試 B',createId:collisionB})).eid,second.eid);
 await invoke('regV05DeleteEvent',{eid:first.eid});
 await invoke('regV05DeleteEvent',{eid:second.eid});
 console.log('PASS 5-CHAR COLLISION EMULATOR: both owners/requests isolated with deterministic retry');
 await invoke('regV05DeleteEvent',{eid});
 assert.equal((await db.ref(`privateRowsV05/${eid}`).get()).exists(),false);
 assert.equal((await db.ref(`managerRowsV05/${eid}`).get()).exists(),false);
 // Legacy per-event cleanup is owner-only and cannot affect a sibling version.
 const legacy='LG123';
 const {roots:cleanupRoots,cleanupPaths}=require('../cleanup_manifest');
 for(const v of ['V03','V04']){
  const fixtures={};
  for(const root of cleanupRoots[v]){fixtures[`${root}${v}/${legacy}`]={sentinel:'cleanup-target'};fixtures[`${root}${v}/OTHER`]={sentinel:'must-remain'};}
  await db.ref().update(fixtures);
  await db.ref().update({[`events${v}/${legacy}`]:{ownerUid:'preflight-owner',meta:{title:'archived'}},[`ownerEvents${v}/preflight-owner/${legacy}`]:{title:'archived'},[`publicRows${v}/${legacy}/p00000001`]:{playerName:'archived'},[`privateRows${v}/${legacy}/p00000001`]:{lineName:'hidden'}});
 }
 await assert.rejects(invoke('regV05DeleteLegacyEvent',{eid:legacy,sourceVersion:'V03',confirm:legacy},intruder));
 await invoke('regV05DeleteLegacyEvent',{eid:legacy,sourceVersion:'V03',confirm:legacy});
 assert.equal((await db.ref(`publicRowsV03/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`privateRowsV03/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`eventsV03/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`eventsV04/${legacy}/ownerUid`).get()).val(),'preflight-owner');
 await db.ref(`eventsV04/${legacy}`).remove(); // simulate stale old index without proof
 await assert.rejects(invoke('regV05DeleteLegacyEvent',{eid:legacy,sourceVersion:'V04',confirm:legacy}));
 await db.ref(`eventsV04/${legacy}/ownerUid`).set('preflight-owner');
 await invoke('regV05DeleteLegacyEvent',{eid:legacy,sourceVersion:'V04',confirm:legacy});
 assert.equal((await db.ref(`privateRowsV04/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`ownerEventsV04/preflight-owner/${legacy}`).get()).exists(),false);
 await invoke('regV05DeleteLegacyEvent',{eid:legacy,sourceVersion:'V03',confirm:legacy});
 for(const v of ['V03','V04']){
  for(const target of Object.keys(cleanupPaths(v,legacy,'preflight-owner')))assert.equal((await db.ref(target).get()).exists(),false,target);
  for(const root of cleanupRoots[v])assert.equal((await db.ref(`${root}${v}/OTHER/sentinel`).get()).val(),'must-remain');
 }
 const recover=(await invoke('regV05CreateEvent',{...base,title:'lifecycle recovery',createId:createId()})).eid;
 await db.ref().update({[`eventsV05/${recover}`]:null,[`ownerEventsV05/preflight-owner/${recover}`]:null,[`privateRowsV05/${recover}`]:{sample:'orphan'}});
 await assert.rejects(invoke('regV05DeleteEvent',{eid:recover},intruder));
 await invoke('regV05DeleteEvent',{eid:recover});
 assert.equal((await db.ref(`privateRowsV05/${recover}`).get()).exists(),false);
 assert.equal((await db.ref(`eventLifecycleV05/V05/${recover}/state`).get()).val(),'deleted');
 console.log('PASS REAL RTDB LIFECYCLE: missing main/index recovered with server ledger');
 console.log('PASS REAL RTDB EMULATOR LEGACY: V03/V04 cleanup, strict owner proof, cross-version isolation, second-owner forbidden');
 console.log('PASS RANK INDEX: direct callable rank, reject/promote/restore, private index denied; PASS RTDB EMULATOR: 64 genuinely concurrent transactions, unique name, idempotency, 2-owner version conflict, public/private Rules, full-event cleanup');
})().catch(async err=>{
 console.error('FAIL RTDB EMULATOR:',err.stack||err);
 if(eid){try{await invoke('regV05DeleteEvent',{eid})}catch{}}
 process.exitCode=1;
}).finally(async()=>{await Promise.all(require('firebase-admin/app').getApps().map(app=>app.delete()))});
