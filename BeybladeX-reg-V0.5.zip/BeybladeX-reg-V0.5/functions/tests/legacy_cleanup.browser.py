#!/usr/bin/env python3
"""Owner-triggered V03/V04 lazy cleanup UX; Chromium with mocked calls, no production access."""
from pathlib import Path
import importlib.util
from playwright.sync_api import sync_playwright
from browser_support import browser_options
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('request_audit_browser.py'))
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
with sync_playwright() as pw:
 browser=pw.chromium.launch(**browser_options())
 ctx=browser.new_context(viewport={'width':390,'height':844});ctx.add_init_script(audit.JS_SEED)
 ctx.route('**/*',lambda route:route.abort())
 p=ctx.new_page();p.set_content(audit.html(root/'reg','index.html'))
 p.wait_for_selector('#checkLegacy')
 assert p.evaluate("__hits.every(s=>!s.includes('V03')&&!s.includes('V04'))"),'legacy indexes must be lazy'
 p.evaluate('''() => {
  window.__legacy={V03:{LM123:{title:'V03 舊報名表'}},V04:{LM123:{title:'V04 同碼活動'}}};
  window.__deletes=[];window.prompt=()=> 'LM123';
  const orig=window.fetch;
  window.fetch=async (input,opt={})=>{
   const url=String(input);
   if(url.includes('ownerEventsV03/')||url.includes('ownerEventsV04/')){
    const v=url.includes('ownerEventsV03/')?'V03':'V04';
    __hits.push('GET ownerEvents'+v+'/tester');
    return new Response(JSON.stringify(__legacy[v]),{status:200});
   }
   if(url.includes('regV05DeleteLegacyEvent')){
    const payload=JSON.parse(opt.body).data;__deletes.push(payload);
    delete __legacy[payload.sourceVersion][payload.eid];
    return new Response(JSON.stringify({result:{ok:true,deletedVersion:payload.sourceVersion,eid:payload.eid}}),{status:200});
   }
   return orig(input,opt);
  };
 }''')
 p.locator('#checkLegacy').click();p.wait_for_function("document.querySelectorAll('[data-legacy]').length===2")
 assert p.evaluate("__hits.filter(s=>s.includes('ownerEventsV03')).length") == 1
 assert p.evaluate("__hits.filter(s=>s.includes('ownerEventsV04')).length") == 1
 p.locator('[data-legacy="V03"]').click()
 p.wait_for_function("__deletes.length===1 && document.querySelectorAll('[data-legacy]').length===1")
 assert p.evaluate('__deletes[0].sourceVersion')=='V03'
 assert p.evaluate('__deletes[0].eid')=='LM123'
 assert p.evaluate('__deletes[0].confirm')=='LM123'
 assert p.locator('[data-legacy="V04"]').count()==1,'same code from other version remains'
 assert p.evaluate("__hits.filter(s=>s.includes('ownerEventsV05')).length") == 1,'no repeat normal index GET'
 p.evaluate("() => {window.__answers=['V04','LM123','LM123'];window.prompt=()=>__answers.shift()}")
 p.locator('#recoverEvent').click();p.wait_for_function('__deletes.length===2')
 assert p.evaluate('__deletes[1].sourceVersion')=='V04'
 assert p.evaluate('__deletes[1].eid')=='LM123'
 p.evaluate("() => {window.__answers=['V02'];window.prompt=()=>__answers.shift()}")
 p.locator('#recoverEvent').click()
 assert p.evaluate('__deletes.length')==2,'unknown versions must not issue cleanup'
 ctx.close();browser.close()
print('PASS legacy cleanup Chromium UX: lazy two-index read, typed confirmation, V03 deletion does not hide same-code V04')
