from pathlib import Path
import os,re

def html_assets(folder,page):
 folder=Path(folder);text=(folder/page).read_text()
 def script(m):
  attrs=m.group(1);file=folder/m.group(2).lstrip('/')
  attrs=re.sub(r'\s*(?:defer|src="[^"]*")','',attrs)
  return '<script'+attrs+'>'+file.read_text()+'</script>'
 text=re.sub(r'<script([^>]*\bsrc="(/assets/[^"]+)"[^>]*)></script>',script,text)
 text=re.sub(r'<link rel="stylesheet" href="(/assets/[^"]+)">',lambda m:'<style>'+(folder/m.group(1).lstrip('/')).read_text()+'</style>',text)
 return text

def browser_options():
 path=os.environ.get('CHROMIUM_PATH')
 if not path and Path('/usr/bin/chromium').exists():path='/usr/bin/chromium'
 return dict(headless=True,args=['--no-sandbox','--disable-dev-shm-usage'],**({'executable_path':path} if path else {}))
