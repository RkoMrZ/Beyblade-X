'use strict';
// V0.5 development release with new isolated data and callable names. API endpoints and RTDB paths are EXCLUSIVE to V0.5 (regV05* and *V05).
// V0.5: node-scoped Firebase RTDB reads/writes. Separate public and private collections.
// Do NOT deploy to production before RTDB Emulator + concurrency and recovery tests.
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {initializeApp,getApps}=require('firebase-admin/app');
const {getDatabase}=require('firebase-admin/database');
const crypto=require('node:crypto');
const {roots:cleanupRoots,LEGACY_VERSIONS,cleanupPaths,registry:cleanupRegistry}=require('./cleanup_manifest');
// Runtime FIREBASE_CONFIG determines the database for the selected Firebase project.
if(!getApps().length)initializeApp();
const db=getDatabase(),REGION='asia-southeast1';
const settings={region:REGION,memory:'256MiB',timeoutSeconds:90,concurrency:16,maxInstances:8,minInstances:0,cors:['https://rkomrz.github.io','https://bbxr-tamsui.web.app',/^https?:\/\/localhost(?::\d+)?$/]};
const api=handler=>onCall(settings,handler);
const error=(code,msg)=>{throw new HttpsError(code,msg)};
const text=v=>typeof v==='string'?v.trim():'';
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
const hex=v=>crypto.randomBytes(v).toString('hex');
// Five-character Base36 event codes: uppercase A-Z and digits 0-9 (36^5 choices).
// No punctuation: RTDB excludes several symbols in keys, and URL-reserved symbols
// would require escaping or break copy/paste. The code is NOT an auth secret.
const EVENT_ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const EVENT_ID_RE=/^[A-Z0-9]{5}$/;
const EVENT_SPACE=36**5;
// Rejection sampling prevents modulo bias and is CPU-only: no extra database
// requests. The random 192-bit createId comes from browser crypto.getRandomValues;
// deterministic hashing keeps retries idempotent after a lost HTTP response.
function eventCode(uid,createId,attempt){
 const seed='BBXREG-V05:'+uid+':'+createId+':'+attempt;
 const max=2**32-(2**32%EVENT_SPACE);
 let value=0;
 for(let round=0;;round++){
  const digest=crypto.createHash('sha256').update(seed+':'+round).digest();
  value=digest.readUInt32BE(0);
  if(value<max)break;
 }
 value%=EVENT_SPACE;
 let code='';
 for(let i=0;i<5;i++){code=EVENT_ALPHABET[value%36]+code;value=Math.floor(value/36)}
 return code;
}
const checkEid=e=>{if(typeof e!=='string'||!EVENT_ID_RE.test(e))error('invalid-argument','比賽代碼無效');return e};
const checkRid=r=>{if(typeof r!=='string'||!/^[a-f0-9]{48}$/.test(r))error('invalid-argument','提交代碼無效');return r};
const checkKey=k=>{if(typeof k!=='string'||!/^p\d{8}$/.test(k))error('invalid-argument','選手編號無效');return k};
const rowKey=n=>'p'+String(n).padStart(8,'0');
const path={event:e=>`eventsV05/${e}`,meta:e=>`eventsV05/${e}/meta`,owner:e=>`eventsV05/${e}/ownerUid`,allocator:e=>`allocV05/${e}`,claim:(e,h)=>`nameClaimsV05/${e}/${h}`,row:(e,k)=>`publicRowsV05/${e}/${k}`,priv:(e,k)=>`privateRowsV05/${e}/${k}`,manager:(e,k)=>`managerRowsV05/${e}/${k}`,receipt:(e,r)=>`receiptsV05/${e}/${r}`,change:e=>`changesV05/${e}`,sync:e=>`syncV05/${e}`,index:(u,e)=>`ownerEventsV05/${u}/${e}`,lock:(e,k)=>`rowLocksV05/${e}/${k}`,rank:e=>`rankActiveV05/${e}`,rankRow:(e,k)=>`rankActiveV05/${e}/${k}`};
const ref=p=>db.ref(p);
function google(req){if(!req.auth?.uid||req.auth?.token?.firebase?.sign_in_provider!=='google.com')error('unauthenticated','主辦需要 Google 登入');return req.auth.uid}
async function isOwner(e,uid){const val=(await ref(path.owner(e)).get()).val();if(!val)error('not-found','找不到新版活動');if(val!==uid)error('permission-denied','沒有這場比賽的管理權限')}
function inputMeta(v){const title=text(v?.title),eventDate=text(v?.eventDate),checkinTime=text(v?.checkinTime),startTime=text(v?.startTime),venue=text(v?.venue),fee=Number(v?.fee),capacity=Number(v?.capacity);
 if(!title||title.length>70||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(eventDate)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(checkinTime)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)||checkinTime>startTime||!venue||venue.length>150||!Number.isSafeInteger(fee)||fee<0||fee>1000000||!Number.isSafeInteger(capacity)||capacity<1||capacity>10000)error('invalid-argument','請填完整且正確的比賽設定');
 const d=new Date(eventDate+'T12:00:00+08:00');if(!Number.isFinite(d.getTime())||new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(d)!==eventDate)error('invalid-argument','比賽日期無效');return {title,eventDate,checkinTime,startTime,venue,fee,capacity}}
function inputPerson(v){const playerName=text(v?.playerName),phone3=text(v?.phone3),lineName=text(v?.lineName);if(!playerName||playerName.length>50||!/^[0-9]{3}$/.test(phone3)||!lineName||lineName.length>40)error('invalid-argument','比賽名稱、手機後三碼與 LINE 名稱均需填寫');return {playerName,phone3,lineName}}
// Unique PER EVENT PLAYER NAME. Phone last 3 digits and LINE display names MAY repeat.
function normalizedName(name){return text(name).normalize('NFKC').replace(/\s+/gu,' ').toLocaleLowerCase('zh-TW')}
function nameHash(name){return sha(normalizedName(name))}
function fingerprint(person){return sha(JSON.stringify([person.playerName,person.phone3,person.lineName]))}
// Prime the local SDK cache with a temporary server-side value listener.
// Otherwise an Admin RTDB transaction may optimistically receive null and
// abort before the server can return the existing value. Keep the listener
// only for the lifetime of this one transaction; browsers never subscribe.
async function transaction(r,fn,{mustExist=false}={}){
 let resolveReady,rejectReady;
 const ready=new Promise((resolve,reject)=>{resolveReady=resolve;rejectReady=reject});
 const listener=snapshot=>resolveReady(snapshot);
 let attached=false;
 try{
  r.on('value',listener,rejectReady);attached=true;
  const initial=await ready;
  if(mustExist&&!initial.exists())error('not-found','比賽不存在或已刪除');
  return await r.transaction(v=>{
   // Never recreate a removed allocator after a concurrent event deletion.
   if(mustExist&&(v===null||v===undefined))return;
   return fn(v);
  },undefined,false);
 }finally{if(attached)r.off('value',listener)}
}
async function transactionOnExisting(r,fn){return transaction(r,fn,{mustExist:true})}

const rev=()=>hex(8);
function changeFields(e,type,key='',recordVersion=null){const id=ref(path.change(e)).push().key;return {[path.change(e)+'/'+id]:{type,key,at:Date.now(),...(Number.isSafeInteger(recordVersion)?{recordVersion}:{})},[path.sync(e)]:{token:rev(),lastChange:id}}}
// Opportunistically compact the append-only public change journal. This runs
// only once per ~128 successful write operations per warm instance; the client
// falls back to a full snapshot if its cursor is older than the retained range.
let journalWrites=0;
async function maybeCompactChanges(e){
 if(++journalWrites%128!==0)return;
 try{
  const base=ref(path.change(e));
  const [old,newest]=await Promise.all([base.orderByKey().limitToFirst(200).get(),base.orderByKey().limitToLast(200).get()]);
  const oldestKeys=Object.keys(old.val()||{}),latestKeys=Object.keys(newest.val()||{});
  if(oldestKeys.length!==200||latestKeys.length!==200||oldestKeys.at(-1)>=latestKeys[0])return;
  const batch={};for(const key of oldestKeys)batch[path.change(e)+'/'+key]=null;
  await patch(batch);
 }catch(err){console.warn('change-journal-compaction-skipped',e,err?.message||err)}
}
function pruneActive(v){const now=Date.now(),active={};for(const [k,u]of Object.entries(v?.active||{}))if(Number(u)>now)active[k]=u;return active}
// The allocator holds only counters, switches and short-lived in-flight operation leases.
// It NEVER contains the participant roster or individual names.
async function leaseStart(e,token,{allowClosed=false}={}){const r=ref(path.allocator(e));let reason='';const result=await transactionOnExisting(r,v=>{if(!v){reason='比賽不存在';return}if(v.deleted){reason='比賽已刪除';return}if(v.configLock?.until>Date.now()){reason='正在更新活動設定，請稍後重試';return}if(!allowClosed&&!v.open){reason='目前未開放報名';return}const active=pruneActive(v);if(Object.keys(active).length>=128){reason='目前報名人數眾多，請稍後重新送出';return}active[token]=Date.now()+120000;return {...v,active}});
 if(!result.committed)error('failed-precondition',reason||'活動正在處理其他操作，請稍後重試');return result.snapshot.val()}
async function leaseEnd(e,token){const r=ref(path.allocator(e));try{await transaction(r,v=>{if(!v||!v.active?.[token])return;const active={...v.active};delete active[token];return {...v,active}})}catch(e){console.error('lease-release',e)}}
// Reserve a number AND an in-flight lease in the SAME small allocator transaction.
async function allocateWithLease(e,token){const r=ref(path.allocator(e));let reason='';const t=await transactionOnExisting(r,v=>{
 if(!v){reason='比賽不存在';return}if(v.deleted||!v.open){reason='目前未開放報名或活動已刪除';return}if(v.configLock?.until>Date.now()){reason='活動正在更新設定，請稍後再試';return}
 const active=pruneActive(v);if(Object.keys(active).length>=128){reason='目前報名較踴躍，請稍後再送出';return}if(v.next>=100000){reason='已達系統上限';return}
 // Event-wide soft throttle: allow at least 64 simultaneous legitimate requests,
 // but bound successful allocations during automated floods. Not a substitute for App Check.
 const now=Date.now(),minute=Math.floor(now/60000),rate=v.rate?.minute===minute?v.rate:{minute,count:0};
 if(rate.count>=240){reason='報名請求太集中，請稍後約一分鐘再試';return}
 active[token]=now+120000;return {...v,active,next:v.next+1,rate:{minute,count:rate.count+1}}
 });if(!t.committed)error('failed-precondition',reason||'取號失敗，請稍後重試');return t.snapshot.val().next}
// Configuration lock is separate from individual roster updates; prevent mixed open/capacity revisions.
async function configStart(e,expected){const r=ref(path.allocator(e)),token=hex(12);let reason='';const t=await transactionOnExisting(r,v=>{if(!v){reason='活動不存在';return}if(v.deleted){reason='活動已刪除';return}if(v.configLock?.until>Date.now()){reason='已有其他設定操作，請稍後重試';return}if(Object.keys(pruneActive(v)).length){reason='有人正在報名或審核，請稍後重試';return}if(v.version!==expected){reason='活動設定已被其他裝置更新';return}return {...v,active:{},configLock:{token,until:Date.now()+120000}}});if(!t.committed)error('failed-precondition',reason||'活動設定有變動');return {token,current:t.snapshot.val()}}
async function configStop(e,token){try{await transaction(ref(path.allocator(e)),v=>!v||v.configLock?.token!==token?undefined:{...v,configLock:null})}catch(ex){console.error('config-release',ex)}}
async function rowLock(e,k){const token=hex(12),r=ref(path.lock(e,k)),now=Date.now();const t=await transaction(r,v=>v&&v.until>now?undefined:{token,until:now+120000});if(!t.committed)error('aborted','這筆選手資料正在更新，請稍後再試');return token}
async function rowUnlock(e,k,token){try{await transaction(ref(path.lock(e,k)),v=>v?.token===token?null:undefined)}catch(ex){console.error('row-unlock',ex)}}
function summary(meta){return {title:meta.title,eventDate:meta.eventDate,venue:meta.venue,capacity:meta.capacity,open:meta.open,createdAt:meta.createdAt,updatedAt:meta.updatedAt}}
async function patch(updates){return db.ref().update(updates)}
// Lightweight server-only active-rank index. Values are booleans, never names,
// LINE handles, phone numbers, or receipt IDs. Only Functions write this index.
// A submission/review/delete atomically updates the row and rank flag together.
// Each new development release starts from an empty namespace. There are NO legacy rank fallbacks.
// The compact server-only index stores just active flags, never player data.
async function currentRank(e,signupNo){
 const key=rowKey(signupNo);
 const [allocatorSnap,rowSnap]=await Promise.all([
  ref(path.allocator(e)).get(),ref(path.row(e,key)).get()
 ]);
 const allocator=allocatorSnap.val(),row=rowSnap.val();
 if(!allocator||allocator.deleted||!row||row.signupNo!==signupNo)
  error('not-found','報名不存在或活動已刪除');
 if(row.status==='rejected')return {signupNo,status:'rejected',rank:null,rankLabel:null};
 if(allocator.rankIndexed!==true)error('failed-precondition','此活動的有效順位索引尚未初始化');
 const flags=await ref(path.rank(e)).orderByKey().endAt(key).get();
 if(!flags.hasChild(key))error('failed-precondition','此報名有效順位索引不完整');
 const rank=flags.numChildren();
 const primary=rank<=allocator.capacity;
 return {signupNo,status:row.status,rank,position:primary?'primary':'waitlist',
  rankLabel:(primary?'正選#'+rank:'備選#'+(rank-allocator.capacity))};
}
// A successful registration must never be treated as failed because a later
// *read-only* rank lookup timed out; use the receipt on a retry if needed.
async function rankOrPending(e,no){
 try{return await currentRank(e,no)}catch(err){console.warn('rank-read-deferred',e,no,err?.message||err);
  return {signupNo:no,rank:null,rankLabel:null,rankPending:true}}
}
// Secret receipt (192-bit) is a bearer proof. This endpoint returns ONLY
// this person's compact status/rank; arbitrary callers cannot enumerate rows.
exports.regV05MyRank=api(async req=>{
 const eid=checkEid(req.data?.eid),rid=checkRid(req.data?.rid);
 const receipt=(await ref(path.receipt(eid,rid)).get()).val();
 if(!receipt)error('not-found','找不到這筆報名');
 return currentRank(eid,receipt.signupNo);
});

// Private lifecycle ledger: version + event code is the identity. Stored paths
// are always revalidated against the server schema; callers cannot supply paths.
const lifecyclePath=(version,eid)=>`eventLifecycleV05/${version}/${eid}`;
async function lifecycleRecord(version,eid,uid,canonical=null){
 const snapshots=await Promise.all(cleanupRegistry.lifecycleRoots.map(root=>ref(`${root}/${version}/${eid}`).get()));
 const records=snapshots.map(s=>s.val()).filter(Boolean);
 for(const record of records){
  if(record.ownerUid!==uid||record.sourceVersion!==version||record.eventId!==eid)
   error('permission-denied','活動清理登記歸屬不符');
  const permitted=cleanupPaths(version,eid,uid);
  if(!Array.isArray(record.paths)||record.paths.some(p=>!Object.hasOwn(permitted,p)))
   error('failed-precondition','清理登記含未核實路徑，必須先人工查核');
 }
 if(canonical?.ownerUid&&canonical.ownerUid!==uid)error('permission-denied','沒有這場比賽的管理權限');
 if(!records.length&&canonical?.ownerUid!==uid)error('permission-denied','缺少可信活動歸屬，需人工查核');
 const proof=records[0]?.createProof||canonical?.createProof||null;
 if(records.some(r=>r.createProof&&proof&&r.createProof!==proof)||canonical?.createProof&&proof&&canonical.createProof!==proof)
  error('failed-precondition','活動身分證據衝突，需人工查核');
 const target=ref(lifecyclePath(version,eid));
 const result=await transaction(target,old=>{
  if(old){
   if(old.ownerUid!==uid)return old;
   return {...old,paths:[...new Set([...(old.paths||[]),...Object.keys(cleanupPaths(version,eid,uid))])]};
  }
  return {ownerUid:uid,sourceVersion:version,eventId:eid,createProof:proof,
   paths:Object.keys(cleanupPaths(version,eid,uid)),state:records.some(r=>r.state==='deleted')?'deleted':'registered',registeredAt:Date.now()};
 });
 const record=result.snapshot.val();
 if(record?.ownerUid!==uid)error('permission-denied','活動清理登記歸屬不符');
 return record;
}
async function lifecycleState(version,eid,state){await ref(lifecyclePath(version,eid)).update({state,updatedAt:Date.now()})}

exports.regV05CreateEvent=api(async req=>{
 const uid=google(req),v=inputMeta(req.data),createId=checkRid(req.data?.createId);
 // Deterministic 5-character code: a retry with the same createId recovers the SAME event.
 // The 25-bit namespace has occasional collisions; compare the private creation proof
 // after a create-only RTDB transaction and deterministically probe the next code.
 // Never replace an event owned by another user or produced by a different request.
 const proof=sha('BBXREG-V05:'+uid+':'+createId),now=Date.now();
 const meta={...v,open:true,version:1,createdAt:now,updatedAt:now};
 let eid=null,actual=null,replayed=false;
 for(let attempt=0;attempt<64;attempt++){
  const candidate=eventCode(uid,createId,attempt),eRef=ref(path.event(candidate));
  const t=await transaction(eRef,old=>old?undefined:{ownerUid:uid,createProof:proof,meta});
  let value=t.snapshot.val();
  if(!value)value=(await eRef.get()).val();
  if(!value){error('unavailable','活動建立狀態尚未確認，請使用原按鈕重試')}
  if(value.ownerUid===uid&&value.createProof===proof){
   if(value.deleted)error('failed-precondition','這次建立請求對應的活動已刪除，不能重新建立');
   eid=candidate;actual=value;replayed=!t.committed;break;
  }
 }
 if(!eid)error('resource-exhausted','比賽短碼暫時無法分配，請稍後重試');
 for(const [k,value] of Object.entries(v))if(actual.meta?.[k]!==value)error('failed-precondition','這次建立請求已使用不同的活動資料，請重新建立');
 // The multi-location completion is retryable if interrupted after the create-only write.
 // Never overwrite an existing allocator (which may already contain real signups).
 const lifecycle=await lifecycleRecord('V05',eid,uid,actual);
 if(lifecycle.state!=='registered')error('failed-precondition','活動已進入刪除程序，不能重新建立');
 const allocRef=ref(path.allocator(eid)),existing=(await allocRef.get()).val();
 if(existing?.deleted)error('failed-precondition','活動已刪除，不能重新建立');
 if(!existing){
  const init=await transaction(allocRef,old=>old?undefined:{next:0,open:true,deleted:false,capacity:v.capacity,version:1,active:{},rankIndexed:true});
  if(init.snapshot.val()?.deleted)error('failed-precondition','這次活動已刪除，不能重建計數器');
  if(!init.committed&&!init.snapshot.val())error('unavailable','活動初始化尚未完成，請重試同一次建立請求');
 }
 // Creation completion is a write operation too. Hold a tiny allocator lease
 // across index/sync initialization so concurrent deletion cannot finish and
 // then have this late create retry resurrect those supposedly removed nodes.
 const createLease=hex(12);
 await leaseStart(eid,createLease,{allowClosed:true});
 try{
  const live=(await ref(path.event(eid)).get()).val();
  if(!live||live.deleted)error('failed-precondition','活動已被刪除，不能補建活動索引');
  await patch({[path.index(uid,eid)]:summary(actual.meta)});
  // Only create a marker when missing; retries must not invalidate readers unnecessarily.
  const syncRef=ref(path.sync(eid));await transaction(syncRef,old=>old?undefined:{token:rev(),lastChange:''});
 }finally{await leaseEnd(eid,createLease)}
 return {eid,replayed};
});
exports.regV05UpdateEvent=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),v=inputMeta(req.data);await isOwner(eid,uid);const {token,current}=await configStart(eid,req.data?.expectedVersion);try{if(current.next>0&&v.capacity!==current.capacity)error('failed-precondition','已有選手報名，不可更改正選人數');const old=(await ref(path.meta(eid)).get()).val();if(!old)error('not-found','活動不存在');const meta={...old,...v,open:current.open,updatedAt:Date.now(),version:current.version+1};await patch({[path.meta(eid)]:meta,[path.index(uid,eid)]:summary(meta),[path.allocator(eid)+'/capacity']:v.capacity,[path.allocator(eid)+'/version']:meta.version,[path.allocator(eid)+'/configLock']:null,...changeFields(eid,'meta')});await maybeCompactChanges(eid);return {meta}}
 finally{await configStop(eid,token)}});
exports.regV05SetOpen=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),open=req.data?.open;if(typeof open!=='boolean')error('invalid-argument','請選擇開放或關閉報名');await isOwner(eid,uid);const {token,current}=await configStart(eid,req.data?.expectedVersion);try{const meta=(await ref(path.meta(eid)).get()).val();if(!meta)error('not-found','活動不存在');const next={...meta,open,version:current.version+1,updatedAt:Date.now()};await patch({[path.meta(eid)]:next,[path.index(uid,eid)]:summary(next),[path.allocator(eid)+'/open']:open,[path.allocator(eid)+'/version']:next.version,[path.allocator(eid)+'/configLock']:null,...changeFields(eid,'meta')});await maybeCompactChanges(eid);return {meta:next}}finally{await configStop(eid,token)}});
// Claim one name with an atomic transaction, THEN allocate a position, THEN commit
// public row + private row + receipt + claim + public revision with ONE multipath update.
exports.regV05Submit=api(async req=>{const eid=checkEid(req.data?.eid),rid=checkRid(req.data?.rid),person=inputPerson(req.data),fp=fingerprint(person),claimKey=nameHash(person.playerName),token=hex(12);
 const prior=(await ref(path.receipt(eid,rid)).get()).val();if(prior){const live=(await ref(path.allocator(eid)).get()).val();if(!live||live.deleted||!(await ref(path.row(eid,rowKey(prior.signupNo))).get()).exists())error('failed-precondition','這筆報名已被移除或活動已刪除');if(prior.fp!==fp)error('failed-precondition','相同提交代碼的報名內容不一致');return {...await rankOrPending(eid,prior.signupNo),confirmed:true,replayed:true}}
 const nameRef=ref(path.claim(eid,claimKey)),leaseMark=hex(12);let reserved=false,finished=false,gateLeased=false;try{
  const now=Date.now();const t=await transaction(nameRef,v=>{if(!v||(v.state==='processing'&&v.until<now))return {rid,fp,state:'processing',mark:leaseMark,until:now+120000};return});
  if(!t.committed){const old=(await nameRef.get()).val();if(old?.rid===rid&&old?.fp===fp&&old?.state==='done'){const receipt=(await ref(path.receipt(eid,rid)).get()).val();if(receipt&&(await ref(path.row(eid,rowKey(receipt.signupNo))).get()).exists())return {...await rankOrPending(eid,receipt.signupNo),confirmed:true,replayed:true}}
   if(old?.rid!==rid)error('already-exists','這場比賽已有相同的比賽名稱，請改用其他名稱');error('unavailable','相同報名請求仍在處理中，請稍後再試')}
  reserved=true;
  const signupNo=await allocateWithLease(eid,token),k=rowKey(signupNo),now2=Date.now();gateLeased=true;
  const c=(await nameRef.get()).val();if(c?.mark!==leaseMark||c?.rid!==rid)error('aborted','報名名稱占位已變動，請重新報名');
  const row={signupNo,playerName:person.playerName,phone3:person.phone3,status:'pending',recordVersion:1};
  // Never expose LINE contact or unpredictable receipt IDs in the public roster.
  const updates={[path.row(eid,k)]:row,[path.manager(eid,k)]:{lineName:person.lineName,recordVersion:1},[path.priv(eid,k)]:{...person,rid,createdAt:now2,nameKey:claimKey},[path.receipt(eid,rid)]:{signupNo,fp},[path.rankRow(eid,k)]:true,[path.claim(eid,claimKey)]:{rid,fp,state:'done',signupNo},...changeFields(eid,'row',k,1)};await patch(updates);finished=true;await maybeCompactChanges(eid);return {...await rankOrPending(eid,signupNo),confirmed:true};
 }catch(ex){if(reserved&&!finished){try{await transaction(nameRef,v=>v?.mark===leaseMark&&v?.state==='processing'?null:undefined)}catch{}}throw ex}finally{if(gateLeased)await leaseEnd(eid,token)}});
async function withRecord(e,uid,k,expected,action,{withPrivate=true}={}){await isOwner(e,uid);const token=hex(12);await leaseStart(e,token,{allowClosed:true});let rowToken;try{rowToken=await rowLock(e,k);const row=(await ref(path.row(e,k)).get()).val(),priv=withPrivate?(await ref(path.priv(e,k)).get()).val():null;if(!row||(withPrivate&&!priv))error('not-found','這位選手的報名資料已不存在');if(row.recordVersion!==expected)error('failed-precondition','選手已被其他裝置修改，請確認最新資料');return await action(row,priv)}finally{if(rowToken)await rowUnlock(e,k,rowToken);await leaseEnd(e,token)}}
exports.regV05Review=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),key=checkKey(req.data?.key),status=req.data?.status;if(!['pending','approved','rejected'].includes(status))error('invalid-argument','審核狀態無效');return withRecord(eid,uid,key,req.data?.expectedVersion,async (row)=>{if(row.status===status)return {row};const updated={...row,status,recordVersion:row.recordVersion+1};const updates={[path.row(eid,key)]:updated,...changeFields(eid,'review',key,updated.recordVersion)};
 if((row.status==='rejected')!==(status==='rejected'))updates[path.rankRow(eid,key)]=status==='rejected'?null:true;
 await patch(updates);await maybeCompactChanges(eid);return {row:updated}},{withPrivate:false})});
exports.regV05EditEntry=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),key=checkKey(req.data?.key),person=inputPerson(req.data);return withRecord(eid,uid,key,req.data?.expectedVersion,async (row,priv)=>{
 const nextKey=nameHash(person.playerName),oldKey=priv.nameKey||nameHash(row.playerName),fp=fingerprint(person);let mark=null;
 if(nextKey!==oldKey){mark=hex(12);const now=Date.now();const t=await transaction(ref(path.claim(eid,nextKey)),v=>!v||(v.state==='processing'&&v.until<now)?{rid:priv.rid,fp,state:'processing',mark,until:now+120000}:undefined);if(!t.committed)error('already-exists','比賽名稱已被使用，請改用其他名稱')}
 let changed=false;try{const updated={...row,playerName:person.playerName,phone3:person.phone3,recordVersion:row.recordVersion+1};const changes={[path.row(eid,key)]:updated,[path.manager(eid,key)]:{lineName:person.lineName,recordVersion:updated.recordVersion},[path.priv(eid,key)]:{...priv,...person,nameKey:nextKey},...changeFields(eid,'row',key,updated.recordVersion)};if(nextKey!==oldKey){changes[path.claim(eid,nextKey)]={rid:priv.rid,fp,state:'done',signupNo:row.signupNo};changes[path.claim(eid,oldKey)]=null}
 await patch(changes);changed=true;await maybeCompactChanges(eid);return {row:updated,private:{lineName:person.lineName,recordVersion:updated.recordVersion}}}finally{if(mark&&!changed)try{await transaction(ref(path.claim(eid,nextKey)),v=>v?.mark===mark?null:undefined)}catch{}}})});
exports.regV05DeleteEntry=api(async req=>{const uid=google(req),eid=checkEid(req.data?.eid),key=checkKey(req.data?.key);return withRecord(eid,uid,key,req.data?.expectedVersion,async (row,priv)=>{await patch({[path.row(eid,key)]:null,[path.manager(eid,key)]:null,[path.rankRow(eid,key)]:null,[path.priv(eid,key)]:null,[path.claim(eid,priv.nameKey||nameHash(row.playerName))]:null,...changeFields(eid,'delete',key)});await maybeCompactChanges(eid);return {ok:true,key}})});
// Current deletion is gated by the allocator, then uses a single atomic multipath
// patch built from the schema inventory. Keep a tiny event tombstone so a late
// retried createId can never resurrect a deleted event or reuse its code.
async function verifyEventCleanup(version,eid,uid,{retained=false}={}){
 const targets=Object.keys(cleanupPaths(version,eid,uid,{retainEventTombstone:retained,retainAllocatorTombstone:retained}));
 // Deletions are infrequent; explicitly verify each small path rather than
 // trusting that an HTTP acknowledgement means no residual event data exists.
 for(let i=0;i<targets.length;i+=6){
  const group=targets.slice(i,i+6),snapshots=await Promise.all(group.map(p=>ref(p).get()));
  const left=group.filter((p,j)=>snapshots[j].exists());
  if(left.length)error('unavailable','資料清理尚未完整；請重試相同刪除操作');
 }
}
exports.regV05DeleteEvent=api(async req=>{
 const uid=google(req),eid=checkEid(req.data?.eid);
 const eventRef=ref(path.event(eid)),allocRef=ref(path.allocator(eid));
 const canonical=(await eventRef.get()).val();
 const ledger=await lifecycleRecord('V05',eid,uid,canonical);
 const before=canonical||{ownerUid:uid,createProof:ledger.createProof};
 await lifecycleState('V05',eid,'deleting');
 // A partially completed create may have no allocator yet. Atomically put a
 // deleted allocator marker there rather than leaving a race that lets the
 // interrupted creator initialize it after the cleanup completes.
 let busy=false;
 const t=await transaction(allocRef,v=>{
  if(v?.deleted)return v;
  const active=pruneActive(v);
  busy=Object.keys(active).length>0||Boolean(v?.configLock?.until>Date.now());
  return {...(v||{}),deleted:true,open:false,active};
 });
 if(!t.committed)error('failed-precondition','刪除前無法鎖定活動，請重試');
 if(!before.deleted&&before.meta)
  await patch({[path.meta(eid)+'/deleted']:true,[path.meta(eid)+'/open']:false});
 if(busy||Object.keys(pruneActive(t.snapshot.val())).length||t.snapshot.val().configLock?.until>Date.now())
  error('failed-precondition','已停止接受新報名；仍有操作處理中，請稍後重試刪除');
 // Two intentionally tiny tombstones prevent both event recreation and a
 // delayed allocator initialization. Every actual registration payload, receipt,
 // lock, index, journal and other event field is removed atomically.
 const tombstone={ownerUid:uid,createProof:before.createProof||null,deleted:true,deletedAt:before.deletedAt||Date.now()};
 await patch({...cleanupPaths('V05',eid,uid,{retainEventTombstone:true,retainAllocatorTombstone:true}),[path.event(eid)]:tombstone,[path.allocator(eid)]:{deleted:true,open:false}});
 await verifyEventCleanup('V05',eid,uid,{retained:true});
 await lifecycleState('V05',eid,'deleted');
 return {ok:true,deletedVersion:'V05',eid};
});
// Historical forms remain separate. Never clear all V03/V04 roots or assume
// equal 5-character codes in different versions refer to the same event.
// This endpoint is deliberately owner-only, opt-in, scoped and repeatable.
exports.regV05DeleteLegacyEvent=api(async req=>{
 const uid=google(req),eid=checkEid(req.data?.eid),version=req.data?.sourceVersion;
 if(!LEGACY_VERSIONS.includes(version))error('invalid-argument','只支援清理規範中已登記並核實的歷史版本');
 if(req.data?.confirm!==eid)error('invalid-argument','請輸入完整活動代碼確認刪除');
 const markerPath=`legacyCleanupV05/${version}/${eid}`;
 const [canonical,prior,...historicalReceipts]=await Promise.all([
  ref(`events${version}/${eid}/ownerUid`).get(),
  ref(markerPath).get(),
  ...cleanupRegistry.cleanupReceiptRoots.filter(root=>root!=='legacyCleanupV05').map(root=>ref(`${root}/${version}/${eid}`).get())
 ]);
 const sourceOwner=canonical.val(),record=prior.val()||historicalReceipts.map(s=>s.val()).find(Boolean);
 const ledger=await lifecycleRecord(version,eid,uid,sourceOwner?{ownerUid:sourceOwner}:record?.ownerUid===uid?{ownerUid:uid}:null);
 if(historicalReceipts.some(s=>s.exists()&&s.val().ownerUid!==uid))error('permission-denied','歷史清理紀錄的所有權不符');
 if(sourceOwner&&sourceOwner!==uid)error('permission-denied','這場舊活動不屬於此主辦');
 if(record&&record.ownerUid!==uid)error('permission-denied','舊活動清理紀錄的所有權不符');
 // An owner index alone is not sufficient if the canonical owner is gone:
 // it might be stale from an earlier reused five-character code. Only an
 // existing ownerUid or THIS release's prior owner-proven deletion receipt
 // authorizes cleanup. Otherwise require a separate human-reviewed audit.
 if(sourceOwner!==uid&&record?.ownerUid!==uid&&ledger.ownerUid!==uid)
  error('permission-denied','舊版活動缺少可核實的原始所有權；需先人工查核，不能只靠舊索引刪除');
 if(!record){
  const r=await transaction(ref(markerPath),v=>v||{ownerUid:uid,startedAt:Date.now()});
  if(r.snapshot.val()?.ownerUid!==uid)error('permission-denied','舊活動清理已由其他帳號鎖定');
 }
 // Historical callable endpoints MUST have been retired on deployment. Old
 // clients had no writable Rules, so no new rows can appear during the sweep.
 await lifecycleState(version,eid,'deleting');
 const patchSet=cleanupPaths(version,eid,uid);
 await patch(patchSet);
 await verifyEventCleanup(version,eid,uid);
 // Retain a compact, private, server-only ownership receipt for response-lost
 // retries. All historical roster, receipts, indexes and event data are gone.
 await ref(markerPath).update({finishedAt:Date.now()});
 await lifecycleState(version,eid,'deleted');
 return {ok:true,deletedVersion:version,eid};
});
// Older schemas must be added to cleanup_manifest ONLY after inspection.
// No release automatically purges other users' or unverified orphan data.
