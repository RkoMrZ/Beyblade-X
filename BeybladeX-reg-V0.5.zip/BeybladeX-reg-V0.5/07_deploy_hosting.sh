#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
python3 build.py
bash 06_source_guard.sh
node -e "const c=require('./firebase.json');if(c.hosting.site!=='bbxr-tamsui'||c.hosting.public!=='reg')process.exit(8)"
echo 'Firebase Hosting site: bbxr-tamsui; project: ljtreg-39954'
echo 'Reminder: add bbxr-tamsui.web.app in Firebase Authentication > Authorized domains before testing Google login.'
echo 'Frontend files (reg/index.html, signup.html, status.html) will be served directly by Firebase Hosting.'
read -r -p 'To deploy only this Hosting site, type HOSTING-V0.5: ' answer
[ "$answer" = 'HOSTING-V0.5' ] || { echo CANCELLED; exit 2; }
firebase deploy --only hosting --project "$PROJECT"
echo 'HOSTING_READY: https://bbxr-tamsui.web.app/'
