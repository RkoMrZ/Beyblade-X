#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.ui-deploy.lock
flock -n 9 || { echo 'UI deployment already running'; exit 1; }
[ ! -e .ui-deploy-completed ] || { echo 'UI deployment already completed'; exit 0; }
exec > >(tee -a ui-deploy.log) 2>&1
if [ -s "$HOME/.nvm/nvm.sh" ]; then source "$HOME/.nvm/nvm.sh"; nvm use 22; fi
bash 06_source_guard.sh
firebase deploy --only hosting:bbxr-tamsui --project ljtreg-39954
touch .ui-deploy-completed
echo 'UI_DEPLOY_COMPLETED: https://bbxr-tamsui.web.app/'
