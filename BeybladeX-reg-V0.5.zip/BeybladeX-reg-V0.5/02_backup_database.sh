#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
INSTANCE=ljtreg-39954-default-rtdb
bash 06_source_guard.sh
umask 077
BACKUP="$HOME/ljtreg-$(date +%Y%m%d-%H%M%S)-before-$(node -p "JSON.parse(require('fs').readFileSync('RELEASE_VERSION.json')).release").json"
# Avoid mixing a broken/half-fetched backup with a successful one.
TMP="${BACKUP}.part"
trap 'rm -f "$TMP"' EXIT
firebase database:get / --project "$PROJECT" --instance "$INSTANCE" > "$TMP"
[ -s "$TMP" ] || { echo 'ERROR: backup returned empty output'; exit 2; }
node - "$TMP" <<'JS'
const fs=require('node:fs');const obj=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
console.log('BACKUP VALID root keys:',obj&&typeof obj==='object'?Object.keys(obj).join(', '):'(empty)');
JS
mv "$TMP" "$BACKUP"
chmod 600 "$BACKUP"
printf '%s\n' "$BACKUP" > .last_backup_path
chmod 600 .last_backup_path
printf 'BACKUP_READY=%s\n' "$BACKUP"
echo 'Keep this private backup outside GitHub. A release reset destroys prior activities and receipts.'
