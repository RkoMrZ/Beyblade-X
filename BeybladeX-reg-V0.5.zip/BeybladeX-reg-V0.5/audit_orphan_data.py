#!/usr/bin/env python3
"""Compatibility entrypoint for the read-only private-export orphan report."""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).resolve().parent/'maintenance/orphan_report.py'),run_name='__main__')
