#!/usr/bin/env python3
"""Post-deploy read-only verification. Static files only; no Firebase data/API calls."""
import json, urllib.request, urllib.error
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base='https://bbxr-tamsui.web.app'
manifest=json.loads((root/'asset-manifest.json').read_text())
def get(path,headers=None):
 return urllib.request.urlopen(urllib.request.Request(base+path,headers=headers or {'Cache-Control':'no-cache'}),timeout=30)
for route,file in [('/', 'index.html'),('/s/ABCDE','signup.html'),('/q/ABCDE','status.html')]:
 with get(route) as r:
  assert r.read()==(root/'reg'/file).read_bytes(), 'Hosted HTML differs: '+route
  assert 'no-cache' in r.headers.get('Cache-Control',''), 'HTML cache policy: '+route
conditional={}
for route in manifest.values():
 with get(route) as r:
  assert r.read()==(root/'reg'/route.lstrip('/')).read_bytes(), 'Asset mismatch: '+route
  cache=r.headers.get('Cache-Control','')
  assert 'immutable' in cache and 'max-age=31536000' in cache and 'no-cache' not in cache, (route,cache)
  etag=r.headers.get('ETag')
 if etag:
  try:
   with get(route,{'If-None-Match':etag}) as r:conditional[route]=r.status
  except urllib.error.HTTPError as e:
   if e.code!=304:raise
   conditional[route]=304
print('PASS LIVE STATIC FILES: 3 HTML routes, 8 hashed assets and cache policies match this release.')
print('Conditional GET statuses:',json.dumps(conditional))
if any(x!=304 for x in conditional.values()):print('CHECK: some conditional requests returned 200; inspect browser cache/network after CDN propagation.')
