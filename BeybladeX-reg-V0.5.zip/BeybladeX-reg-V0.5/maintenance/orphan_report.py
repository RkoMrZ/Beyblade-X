#!/usr/bin/env python3
"""PRIVATE offline export audit. No credentials, network, writes or deletion."""
import json,sys,re
from pathlib import Path

def audit(data,registry):
    report={'candidates':[],'unknownRoots':[]}
    known=set(registry['cleanupReceiptRoots']+registry.get('lifecycleRoots',[]))
    for version,schema in registry['schemas'].items():
        roots=schema['eventRoots'];index=schema['ownerIndex']+version
        known.update(root+version for root in roots);known.add(index)
        ids=set()
        for root in roots:
            value=data.get(root+version,{})
            if isinstance(value,dict):ids.update(value)
        for entries in data.get(index,{}).values():
            if isinstance(entries,dict):ids.update(entries)
        for ledgerRoot in registry.get('lifecycleRoots',[]):
            ids.update(data.get(ledgerRoot,{}).get(version,{}))
        for eid in sorted(ids):
            if not re.fullmatch('[A-Z0-9]{5}',eid):
                report['candidates'].append({'version':version,'id':eid,'status':'REVIEW_INVALID_ID'});continue
            main=data.get('events'+version,{}).get(eid,{}) or {}
            records=[data.get(root,{}).get(version,{}).get(eid) for root in registry.get('lifecycleRoots',[])]
            records=[v for v in records if isinstance(v,dict)]
            owners={v.get('ownerUid') for v in records if v.get('ownerUid')}
            if main.get('ownerUid'):owners.add(main['ownerUid'])
            present=[root+version+'/'+eid for root in roots if eid in data.get(root+version,{})]
            if main.get('meta') and not main.get('deleted') and not main['meta'].get('deleted'):continue
            only_markers=all(p.split('/')[0] in ('events'+version,'alloc'+version) for p in present)
            if only_markers and any(v.get('state')=='deleted' for v in records):continue
            status='OWNER_RECOVERY_CANDIDATE' if len(owners)==1 else 'REVIEW_NO_PROOF' if not owners else 'REVIEW_CONFLICT'
            report['candidates'].append({'version':version,'id':eid,'status':status,'remainingPaths':present})
    report['unknownRoots']=sorted(set(data)-known)
    report['notice']='Read-only candidates, NOT deletion authorization. Revalidate live server ownership and registered paths before any cleanup. Index alone is not proof. Keep export private.'
    return report

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python3 maintenance/orphan_report.py PRIVATE_EXPORT.json')
    root=Path(__file__).resolve().parents[1]
    print(json.dumps(audit(json.loads(Path(sys.argv[1]).read_text()),json.loads((root/'functions/cleanup_registry.json').read_text())),ensure_ascii=False,indent=2))
