#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
trap 'rc=$?; echo "PREFLIGHT_EXIT_CODE=$rc"' EXIT
[ "$(node -p 'process.versions.node.split(".")[0]')" = 22 ] || { echo 'ERROR: use Node.js 22'; exit 1; }
command -v firebase >/dev/null || { echo 'ERROR: Firebase CLI not found'; exit 1; }
echo 'OFFLINE PREFLIGHT — emulator demo-ljtreg only; no production writes'
bash 06_source_guard.sh
node --check functions/index.js
node --check functions/cleanup_manifest.js
node functions/tests/cleanup.manifest.test.js
python3 functions/tests/cleanup.contract.py
python3 functions/tests/orphan_report.test.py
for f in web/js/*.js; do node --check "$f"; done
node functions/tests/code_space.test.js
node functions/tests/smoke.test.js
node functions/tests/rules.static.test.js
npm ci --prefix functions --no-audit --no-fund
if python3 -c 'from playwright.sync_api import sync_playwright' >/dev/null 2>&1 && { [ -n "${CHROMIUM_PATH:-}" ] || command -v chromium >/dev/null 2>&1; }; then
 for test in frontend.offline request_audit_browser lifecycle.offline short_urls.offline optimization.browser legacy_cleanup.browser final_audit.browser; do python3 "functions/tests/$test.py"; done
 firebase emulators:exec --only hosting --project demo-ljtreg 'python3 functions/tests/hosting.browser.py'
else
 echo 'BROWSER_TESTS_NOT_RERUN: this machine lacks Playwright/Chromium. Packaged test evidence is in V0.5_TEST_STATUS.md.'
fi
timeout -k 10s 360s firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'
echo 'PASS source, unit tests, Rules and actual local RTDB integration.'
