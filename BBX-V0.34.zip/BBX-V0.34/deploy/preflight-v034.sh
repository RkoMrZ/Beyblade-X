#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.34 ]] || { echo 'STOP: wrong V0.34 folder';exit 2; }
[[ "$(gcloud config get-value project 2>/dev/null)" == 'ljt-beyblade-x' ]] || { echo 'STOP: wrong Firebase project';exit 2; }
python3 - <<'PY_VERIFY'
import hashlib,json,re
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.34' and m['firebase_project']=='ljt-beyblade-x'
assert m['hosting_site']=='bbxs-tamsui' and len(m['functions_exports'])==9
for f in m['files']:
 raw=Path(f['path']).read_bytes()
 assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256'],f['path']
for file,digest in m['untouched_backend_hashes'].items():
 assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==digest,file
for page in ('index','viewer'):
 s=Path(page+'.html').read_text()
 for ext in ('js','css'):
  refs=re.findall(r'assets/'+page+r'-v034-[a-f0-9]{12}\.'+ext,s)
  assert len(refs)==1,(page,ext,refs)
  for p in refs:
   f=Path(p);fingerprint=re.search(r'-([a-f0-9]{12})\.'+ext+'$',p).group(1)
   assert hashlib.sha256(f.read_bytes()).hexdigest().startswith(fingerprint),p
assert 'repechageOption' not in Path('index.html').read_text()
assert 'id="byePolicy"' in Path('index.html').read_text()
assert 'events/${eventId}/publishedSeq' in Path('functions/bbx-v011-publication.js').read_text()
assert 'watch(`events/${id}/publishedSeq`' in Path('assets/index-v034.js').read_text()
print('PASS: V0.34 immutable assets, server-published watermark, Rules and historical format')
PY_VERIFY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required';exit 3; }
for f in functions/*.js assets/*-v034.js; do node --check "$f";done
node --test tests/*.test.js
python3 tests/check_static.py
python3 tests/check_rules_syntax.py
python3 tests/check_cleanup_rules.py
python3 deploy/merge-rules.py docs/previous-v09-rules.json /tmp/bbx-v034-test-merge.json
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI missing';exit 4; }
# Cloud Shell keeps old npm dependencies between versions. Remove ONLY
# regenerable dependency directories from historical BBX release folders if
# the home partition is low; keep all source, ZIPs and previous V0.26.
free_kb=$(df -Pk "$HOME" | awk 'NR==2{print $4}')
if [[ "$free_kb" -lt 1100000 ]];then
  for release in BBX-V0.5 BBX-V0.6 BBX-V0.7 BBX-V0.8 BBX-V0.9 BBX-V0.10 BBX-V0.11 BBX-V0.12 BBX-V0.13 BBX-V0.14 BBX-V0.15 BBX-V0.16 BBX-V0.17 BBX-V0.18 BBX-V0.19 BBX-V0.20 BBX-V0.21 BBX-V0.22 BBX-V0.23 BBX-V0.24 BBX-V0.25 BBX-V0.26 BBX-V0.27;do
    [[ -d "$HOME/$release" && -f "$HOME/$release/MANIFEST.json" ]] || continue
    rm -rf -- "$HOME/$release/tests/node_modules" "$HOME/$release/functions/node_modules"
  done
  npm cache clean --force >/dev/null 2>&1 || true
  free_kb=$(df -Pk "$HOME" | awk 'NR==2{print $4}')
fi
[[ "$free_kb" -ge 650000 ]] || { echo 'STOP: Cloud Shell has under 650 MB free after safe dependency cleanup. No deployment attempted.';exit 4; }
npm ci --prefix tests --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v011 --config firebase.json 'cd tests && node rules-emulator.test.cjs'
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v034-preflight-ok"
echo 'PASS: BBX-V0.34 browser subscription recovery, RTDB Emulator and Hosting preflight'
