'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync(require('node:path').join(__dirname,'../assets/index-v034.js'),'utf8');
const begin=source.indexOf('function configureBbxRealtimeTransport(');
const finish=source.indexOf('function firebaseConfigured()',begin);
assert.ok(begin>=0&&finish>begin,'transport initializer must exist');
const body=source.slice(begin,finish);
function scenario(ua,search='',available=true){
 let calls=0;
 const context={console,URLSearchParams,bbxRealtimeTransport:'auto',bbxTransportSelectionError:null};
 vm.createContext(context);vm.runInContext(body,context);
 const db={INTERNAL:available?{forceLongPolling(){calls++}}:{}};
 const mode=context.configureBbxRealtimeTransport(db,ua,search);
 return {mode,calls,error:context.bbxTransportSelectionError};
}
test('iPhone Safari, iOS Chrome and iOS in-app WebViews use ONE long-polling transport',()=>{
 for(const agent of [
   'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 Version/18.6 Mobile Safari/604.1',
   'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 CriOS/138.0 Mobile/15E148 Safari/604.1',
   'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 LINE/14.0 Mobile'
 ]){
   const x=scenario(agent);assert.equal(x.mode,'long-polling');assert.equal(x.calls,1);
 }
});
test('desktop remains unchanged; manual transport comparison available',()=>{
 const ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0';
 assert.deepEqual(scenario(ua).calls,0);
 assert.equal(scenario(ua,'?bbxTransport=longpoll').calls,1);
 assert.equal(scenario('iPhone Mobile','?bbxTransport=auto').calls,0);
});
test('compatibility API absence falls back safely without extra database instances',()=>{
 const x=scenario('iPhone Mobile','',false);
 assert.equal(x.mode,'auto');assert.equal(x.calls,0);
 assert.match(x.error,/unavailable/);
});
test('transport is configured before subscription and both channels remain independent',()=>{
 const init=source.slice(source.indexOf('async function initCloud(){'),source.indexOf('function localEventSave(){'));
 assert.ok(init.indexOf('configureBbxRealtimeTransport(fbDb')>=0);
 assert.ok(init.indexOf('configureBbxRealtimeTransport(fbDb')<init.indexOf('fbAuth.onAuthStateChanged('));
 const listen=source.slice(source.indexOf('function listenCloudEvent(id){'),source.indexOf('async function waitForAuthRestore(',source.indexOf('function listenCloudEvent(id){')));
 assert.ok(listen.includes('watch(`refereeClaims/${id}`'));
 assert.ok(listen.includes('watch(`events/${id}/publishedSeq`'));
 assert.ok(listen.includes('metric.restLastOk=Date.now()'));
 assert.ok(!listen.includes('goOffline()'));
});
