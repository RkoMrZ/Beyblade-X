#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.35 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.35 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.35 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v035.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v035-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
# This release changes only the browser synchronization recovery layer.
# Never redeploy a backend or RTDB Rules for a client-only change.
gcloud auth print-access-token >/dev/null
echo "PASS: Cloud Functions and RTDB Rules unchanged"
bash deploy/hosting-v035.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.35 Hosting ONLY deployed and verified; Functions, Rules and saved events untouched.\n'
