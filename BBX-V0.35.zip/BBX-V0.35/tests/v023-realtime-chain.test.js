'use strict';
const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path'), vm=require('node:vm');
const {buildProjectionPatch}=require('../functions/bbx-v011-publication');
const source=fs.readFileSync(path.join(__dirname,'../assets/index-v035.js'),'utf8');
const code=source.slice(source.indexOf('function listenCloudEvent(id){'),source.indexOf('async function waitForAuthRestore('));
function harness(){
 const entries=new Map(),seen=[];
 const elements={};
 const node=()=>({
   classList:{contains:()=>false,add:()=>{},remove:()=>{},toggle:()=>{}},
   setAttribute:()=>{},getAttribute:()=>null,addEventListener:()=>{},
   append:()=>{},prepend:()=>{},after:()=>{},querySelector:()=>node(),
   textContent:''
 });
 elements.admin=node();

 const makeEvent=()=>({id:'EV123456',authorityBBX:'active',releaseTag:'BBX-V0.11',publishedSeq:0,authoritySeq:0,
  rounds:[{matches:[{a:'A',b:'B',sa:0,sb:0,matchVersion:0}]}],refereeClaims:{},roster:['A','B']});
 const ctx={console,Date,Number,JSON,Map,setTimeout,clearTimeout,setInterval,clearInterval,
  ev:makeEvent(),cloudEventsCache:{},cloudReady:true,isReferee:true,isAdmin:true,
  cloudUnsub:null,cloudListenerEpoch:0,cloudResyncBlocked:false,liveRetryAttempts:new Map(),liveTransportRecoveryAt:new Map(),
  document:{visibilityState:'visible',createElement:()=>node()},
  fbDb:{ref(name){let entry=entries.get(name);if(!entry){entry={};entries.set(name,entry)}
   return {on(type,fn){entry[type]=fn},off(type,fn){if(entry[type]===fn)delete entry[type]}}}},
  rtdbRestGet:async name=>name==='events/EV123456'?makeEvent():name==='refereeClaims/EV123456'?{}:null,
  normalizeRefereeClaimsData:data=>Array.isArray(data)?Object.fromEntries(data.map((v,i)=>[i,v])):(data||{}),
  isV1Authority:()=>false,v05ScorePending:()=>false,$:id=>elements[id]||null,
  renderAdmin:args=>seen.push(args),renderReferee:()=>seen.push({referee:true}),currentAdminTab:'bracket',
  refereeClaimsStreamRevision:0,refereeClaimsConfirmed:()=>false,confirmRefereeClaims:()=>false,listenPublicProjectionEvent:()=>{}
 };
 vm.createContext(ctx);vm.runInContext(code,ctx);
 const send=(p,type,value)=>{const fn=entries.get(p)?.[type];assert.equal(typeof fn,'function',p+':'+type);fn({key:String(value?.key??0),val:()=>value?.data??value,exists:()=>value!==null})};
 return {ctx,entries,seen,makeEvent,send,close:()=>ctx.cloudUnsub?.()};
}
test('atomic publication watermark accompanies private score and public score',()=>{
 const patch=buildProjectionPatch('EV123456',{seq:7,changes:[{path:'rounds/0/matches/0',value:{sa:4},publicValue:{sa:4}}]});
 assert.equal(patch['events/EV123456/publishedSeq'],7);
 assert.equal(patch['publicEvents/EV123456/meta/authoritySeq'],7);
 assert.deepEqual(patch['events/EV123456/rounds/0/matches/0'],{sa:4});
});
test('another judge changing command sequence alone must never pause scoring',()=>{
 const h=harness();h.ctx.listenCloudEvent('EV123456');
 h.send('.info/connected','value',true);
 h.send('events/EV123456/publishedSeq','value',0);
 h.send('events/EV123456/authoritySeq','value',5);
 assert.equal(h.ctx.cloudResyncBlocked,false);
 assert.equal(h.ctx.ev.rounds[0].matches[0].sa,0);
 h.close();
});
test('score push updates same open page, with no need to navigate or reload',async()=>{
 const h=harness();h.ctx.listenCloudEvent('EV123456');
 h.send('.info/connected','value',true);
 h.send('events/EV123456/publishedSeq','value',0);
 h.send('events/EV123456/rounds/0/matches','child_changed',{key:0,data:{a:'A',b:'B',sa:4,sb:1,matchVersion:1}});
 await new Promise(r=>setTimeout(r,200));
 assert.equal(h.ctx.ev.rounds[0].matches[0].sa,4);
 assert.ok(h.seen.some(x=>x.bracketOnly===true));
 assert.equal(h.ctx.cloudResyncBlocked,false);
 h.close();
});
test('claim snapshot updates organizer claim state without re-entering tab',()=>{
 const h=harness();h.ctx.currentAdminTab='referee';h.ctx.listenCloudEvent('EV123456');
 h.send('refereeClaims/EV123456','value',[{uid:'J1',name:'裁判 1'}]);
 assert.equal(h.ctx.ev.refereeClaims[0].uid,'J1');
 assert.ok(h.seen.some(x=>x.referee===true));h.close();
});
test('publication watermark without child push triggers a coalesced authoritative repair',async()=>{
 const h=harness();let reads=0;
 h.ctx.rtdbRestGet=async name=>{
  if(name==='events/EV123456'){
   reads++;const fresh=h.makeEvent();fresh.publishedSeq=2;fresh.rounds[0].matches[0].sa=5;return fresh;
  }
  return {};
 };
 h.ctx.listenCloudEvent('EV123456');h.send('.info/connected','value',true);
 h.send('events/EV123456/publishedSeq','value',0);
 h.send('events/EV123456/publishedSeq','value',2);
 await new Promise(r=>setTimeout(r,1100));
 assert.equal(reads,1,'one coalesced verified GET, rather than endlessly polling all matches');
 assert.equal(h.ctx.ev.rounds[0].matches[0].sa,5);
 assert.equal(h.ctx.cloudResyncBlocked,false);
 h.close();
});
test('missing owner metadata cannot delete event or return the organizer home',async()=>{
 const h=harness();let reads=0;
 h.ctx.rtdbRestGet=async name=>{
   if(name==='events/EV123456'){reads++;return null;}
   return {};
 };
 h.ctx.listenCloudEvent('EV123456');h.send('.info/connected','value',true);
 h.send('events/EV123456/publishedSeq','value',0);
 h.send('events/EV123456/ownerUid','value',null);
 await new Promise(r=>setTimeout(r,850));
 assert.ok(reads>=1);
 assert.equal(h.ctx.ev.id,'EV123456');
 assert.equal(h.ctx.ev.rounds[0].matches.length,1);
 h.close();
});
test('removing numeric match key does not shift its neighbor and overwrite another fixture',()=>{
 const h=harness();h.ctx.ev.rounds[0].matches.push({a:'C',b:'D',sa:0,sb:0});
 h.ctx.listenCloudEvent('EV123456');
 h.send('events/EV123456/rounds/0/matches','child_removed',{key:0,data:null});
 assert.equal(h.ctx.ev.rounds[0].matches[1].a,'C');
 h.close();
});
test('SSE receiver preserves last valid scoreboard on transient null root',()=>{
 const viewer=fs.readFileSync(path.join(__dirname,'../assets/viewer-v035.js'),'utf8');
 assert.match(viewer,/if\(payload\.path==='\/'&&payload\.data===null&&data\)/);
 assert.match(viewer,/scheduleReconnectResync\(streamKind,streamId,'null-sse-root'\)/);
});
