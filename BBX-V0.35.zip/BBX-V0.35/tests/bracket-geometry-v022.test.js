const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
for(const name of ['index','viewer']){
 const js=fs.readFileSync(path.join(__dirname,`../assets/${name}-v035.js`),'utf8');
 const css=fs.readFileSync(path.join(__dirname,`../assets/${name}-v035.css`),'utf8');
 test(`${name} bracket aligns destination centers to feeder pairs`,()=>{
  assert.match(js,/function alignBracketRounds\(canvas\)/);
  assert.match(js,/alignBracketRounds\(canvas\);/);
  assert.match(js,/centerY\(previous\[j\*2\]\)\+centerY\(previous\[j\*2\+1\]\)/);
  assert.match(js,/container\.style\.paddingTop=/);
  assert.match(js,/container\.style\.gap=/);
  assert.doesNotMatch(js,/function (?:roundLayout|layout)\(ri\)/);
  assert.doesNotMatch(js,/--top:\$\{l\.top\}/);
  assert.doesNotMatch(css,/gap:var\(--gap,16px\);padding-top:var\(--top,0px\)/);
 });
}
