from pathlib import Path
from playwright.sync_api import sync_playwright
src=(Path(__file__).resolve().parents[1]/'assets/index-v035.js').read_text()
code=src[src.index('function listenCloudEvent(id){'):src.index('async function waitForAuthRestore(')]
fixture='''
window.bbxRunIsolatedConnectionProbe=async()=>{window.bbxProbeResult='獨立連線成功'};window.bbxManuallyRestartOfflineTransport=async()=>{window.bbxManualRestartResult='手動恢復已測試'};window.bbxProbeResult='尚未執行';window.bbxManualRestartResult='尚未執行';window.switchBbxTransportAfterConfirmation=()=>false;window.bbxRealtimeTransport='long-polling';window.bbxLifecycleEvents=[];window.bbxEnteringPrivateEvent=0;window.cloudInitPromise=null;window.ownerIndexUnsub=null;window.fbAuth={currentUser:null};
window.cloudReady=true;window.ev={id:'EVTEST',rounds:[{matches:[{a:'A',b:'B',sa:0,sb:0,refereeActive:false,matchVersion:1}]}],refereeClaims:{},publishedSeq:0,refereeNames:['裁判1']};
window.isAdmin=true;window.isReferee=false;window.cloudListenerEpoch=0;window.cloudUnsub=null;window.cloudResyncBlocked=false;
window.cloudEventsCache={};window.liveRetryAttempts=new Map();window.liveTransportRecoveryAt=new Map();window.refereeClaimsStreamRevision=0;window.currentAdminTab='bracket';
window.$=id=>document.getElementById(id);window.v05ScorePending=()=>false;
window.normalizeRefereeClaimsData=raw=>raw||{};
window.renderAdmin=()=>{};window.renderReferee=()=>{};window.listenPublicProjectionEvent=()=>{};
window.rtdbRestGet=async()=>null;
window.paths=new Map();
window.fbDb={ref(p){if(!paths.has(p))paths.set(p,new Map());return {on(t,fn){paths.get(p).set(t,fn)},off(t,fn){if(paths.get(p).get(t)===fn)paths.get(p).delete(t)}}}};
'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in (375,390,768,1366):
  page=browser.new_page(viewport={'width':width,'height':800})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content('<div id="admin"><div class="adminTabs"><button id="tab">對戰表</button></div><div id="bracketTab"></div></div>')
  page.add_script_tag(content=fixture+'\n'+code+'\nlistenCloudEvent("EVTEST");')
  assert page.locator('#bbxLiveDiag summary').count()==1,(width,'diag missing')
  page.locator('#bbxLiveDiag summary').click()
  page.locator('#bbxLiveDiag button').first.click()
  assert '版本 BBX-V0.35' in page.locator('#bbxLiveDiag pre').inner_text()
  page.locator('#bbxLiveDiag button').nth(2).click()
  assert '獨立連線成功' in page.locator('#bbxLiveDiag pre').inner_text()
  page.locator('#bbxLiveDiag button').nth(3).click()
  assert '手動恢復已測試' in page.locator('#bbxLiveDiag pre').inner_text()
  page.evaluate('''()=>{paths.get('.info/connected').get('value')({val:()=>true});paths.get('events/EVTEST/publishedSeq').get('value')({val:()=>0});paths.get('events/EVTEST/rounds/0/matches').get('child_changed')({key:'0',val:()=>({a:'A',b:'B',sa:1,sb:0,refereeActive:true,matchVersion:2})});}''')
  page.wait_for_timeout(150)
  page.locator('#bbxLiveDiag button').first.click()
  text=page.locator('#bbxLiveDiag pre').inner_text()
  assert 'sdk child_changed rounds/matches' in text and 'accepted rounds/0/matches/0' in text and 'paint bracket' in text,(width,text)
  assert page.evaluate('ev.rounds[0].matches[0].sa')==1
  assert not errors,(width,errors)
  print('PASS',width,'diagnostics, real DOM disclosure, SDK event -> accepted -> paint')
  page.close()
 browser.close()
