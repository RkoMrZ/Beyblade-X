'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync(require('node:path').join(__dirname,'../assets/index-v035.js'),'utf8');
const start=source.indexOf('// V0.35: Manually requested read-only transport isolation probe.');
const end=source.indexOf('function firebaseConfigured(){',start);
assert.ok(start>=0&&end>start);
const body=source.slice(start,end);
function ctx(opts={}){
  let listeners=0,removed=0,deleted=0,privateRefs=0,offline=0,online=0,apps=0,queries=0;
  const ref={on(type,cb){listeners++;assert.equal(type,'value');queueMicrotask(()=>{
    if(opts.probeOnline!==false)cb({val:()=>true});
  })},off(type,cb){removed++}};
  const db={INTERNAL:{forceLongPolling(){}},ref(path){queries++;assert.equal(path,'.info/connected');return ref},goOffline(){offline++},goOnline(){online++}};
  const fb={initializeApp(config,name){apps++;assert.equal(typeof name,'string');return {database(){return db},async delete(){deleted++}}}};
  const c={console,Date,Promise,Map,Set,JSON,Number,Error,String,setTimeout,clearTimeout,window:{confirm:()=>true,__bbxSyncMetrics:{connected:false}},
    bbxRealtimeTransport:'long-polling',firebase:fb,FIREBASE_CONFIG:{databaseURL:'https://example.invalid'},
    fbDb:db,v05ScoreQueues:new Map()};
  vm.createContext(c);vm.runInContext(body,c);
  return {c,counts:()=>({listeners,removed,deleted,apps,queries,privateRefs,offline,online})};
}
test('standalone probe reads ONLY local connection health and destroys temporary Firebase app',async()=>{
 const p=ctx(); const result=await p.c.bbxRunIsolatedConnectionProbe();
 assert.equal(result,'獨立連線成功');
 assert.deepEqual(p.counts(),{listeners:1,removed:1,deleted:1,apps:1,queries:1,privateRefs:0,offline:0,online:0});
 assert.equal(await p.c.bbxRunIsolatedConnectionProbe(),result,'20-second cooldown must not add probes');
 assert.equal(p.counts().apps,1);
});
test('manual transport reset is denied if scores are pending and never silently deletes listener or data',async()=>{
 const p=ctx();p.c.v05ScoreQueues.set('M1',{run:true});
 assert.equal(await p.c.bbxManuallyRestartOfflineTransport(),'仍有未完成記分，未執行');
 assert.equal(p.counts().offline,0);
 p.c.v05ScoreQueues.clear();
 assert.match(await p.c.bbxManuallyRestartOfflineTransport(),/已要求重建/);
 assert.equal(p.counts().offline,1);assert.equal(p.counts().online,1);
 await p.c.bbxManuallyRestartOfflineTransport();
 assert.equal(p.counts().offline,1,'one restart per page at most');
});
test('manual transport reset is denied when main Firebase SDK is already connected',async()=>{
 const p=ctx();p.c.window.__bbxSyncMetrics.connected=true;
 assert.match(await p.c.bbxManuallyRestartOfflineTransport(),/目前非離線/);
 assert.equal(p.counts().offline,0);assert.equal(p.counts().online,0);
});
test('the isolation probe does not copy Firebase auth, Google account, tokens or referee rights',()=>{
 assert.doesNotMatch(body,/signInWith|updateCurrentUser|\.getIdToken\(|\.set\(|\.update\(|\/events\/|refereeClaims\//);
 assert.match(body,/firebase\.initializeApp\(FIREBASE_CONFIG,name\)/);
 assert.match(body,/db\.ref\('\.info\/connected'\)/);
 assert.match(body,/await app\.delete\(\)/);
});
