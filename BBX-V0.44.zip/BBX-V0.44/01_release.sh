#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.44 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: V0.44 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.44 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v044.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v044-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight mismatch';exit 3; }
# Every entry point that uses the repaired projection builder must ship
# the same code before the new frontend expects a published structure epoch.
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: wrong Firebase project'; exit 2; }
firebase deploy --only functions:bbxV011OrganizerAuthority,functions:bbxV011CommandAuthority,functions:bbxV011PublishAuthority,functions:bbxV011RepairPublication,functions:bbxV011RepairQueue --config firebase.json --project ljt-beyblade-x --non-interactive
bash deploy/hosting-v044.sh
date -u > .release-completed
printf '\nPASS: V0.44 selected Functions and Hosting deployed; no Rules deployment or data migration.\n'
