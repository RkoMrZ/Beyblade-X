"""Real DOM, fake clock and Firebase responses only, no live traffic."""
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil
root=Path(__file__).resolve().parents[1]
s=(root/'assets/index-v044.js').read_text()
css=(root/'assets/index-v044.css').read_text()
def pick(a,b): return s[s.index(a):s.index(b,s.index(a))]
code='\n'.join((pick('function projectedStructureOf','const makeV1OpId'),
 pick('async function v1CloudOrganizerCommand','function publicMatchCloudPath'),
 pick('const pendingPublications','function queueSingleMatchCloud'),
 pick('function renderRoster(){','function closeRaffleWinnerModal'),
 pick('let refereeInviteRotation','async function refreshRefereeState'),
 pick('function showTab(t)','// V0.37: Claim/claim-release'),
 pick('function backToBracketFromMatch','function openMatchEditor')))
html='''<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><main id=admin>
<div class=adminTabs><button data-tab-btn=bracket onclick="showTab('bracket')">對戰表</button><button data-tab-btn=roster onclick="showTab('roster')">參賽名單</button></div>
<div id=bbxPublicationNotice class="notice hidden"></div><div id=rosterTab></div><div id=bracketTab></div><div id=refereeTab class=hidden><div id=refereeInviteCode></div><div id=refereeCodeCountdown></div><div id=refereeInviteQr>QR stays</div></div></main><div id=matchModal class=hidden><div id=matchSheet><b>existing match</b></div></div>'''
fixture=r'''
window.$=id=>document.getElementById(id);window.esc=s=>String(s);
window.ev={id:'TEST',releaseTag:'BBX-V0.11',authorityBBX:'active',roster:['甲','乙','丙'],rounds:[],finalRR:{matches:[]},authoritySeq:5,publishedSeq:5,structureVersion:0};
window.hasOrganizerAccess=()=>true;window.isV1Authority=()=>true;window.isReferee=false;window.currentAdminTab='roster';
window.cloudResyncBlocked=false;window.cloudEventsCache={};window.fbAuth={currentUser:{uid:'owner'}};window.V1_AUTH_CLIENT='test';
window.authorityFnName=()=> 'bbxV011OrganizerAuthority';window.authorityClientVersion=()=>V1_AUTH_CLIENT;window.initCloud=async()=>true;
window.opCount=0;window.makeV1OpId=()=>String(++opCount);window.sent=[];window.alerts=[];window.alert=m=>alerts.push(m);
window.persistActiveView=()=>{};window.syncTabButtons=()=>{};window.bracketScale=1;window.setBracketScale=()=>{};window.drawBracketLinks=()=>{};
window.stopAdminCodeRotation=()=>{};window.closeScorePicker=()=>{};window.closeResetChoice=()=>{};window.closeMatchEditor=()=>$('matchModal').classList.add('hidden');
window.renderReferee=()=>startRefereeCodeRotation();window.remoteSeq=5;window.updatedRoster=null;
window.rtdbRestGet=async path=>remoteSeq;
window.backgroundRefreshCurrentEvent=async()=>{if(updatedRoster&&remoteSeq>ev.publishedSeq){
 ev={...ev,roster:[...updatedRoster],publishedSeq:remoteSeq,authoritySeq:remoteSeq,structureVersion:remoteSeq-5,publishedStructureVersion:remoteSeq-5};
 if(currentAdminTab==='roster')renderRoster();updatePendingPublicationStatus();}};
window.codeCalls=0;window.failInvite=false;window.uncertainAdd=false;window.receiptQueries=[];
window.v05ReadOperationReceipt=async(id,op)=>{receiptQueries.push([id,op]);return {found:true,ok:true,seq:6};};
window.firebase={app:()=>({functions:()=>({httpsCallable:()=>async req=>{
 if(req.action==='getRefereeInviteCode'){
  if(failInvite){failInvite=false;codeCalls++;throw Object.assign(new Error('network'),{code:'unavailable'});}
  return {data:{ok:true,code:String(111111+codeCalls++),serverNow:1000,expiresAt:3000}};
 }
 sent.push(req);
 if(req.action==='addPlayer'){
  if(ev.roster.includes(req.value))throw Object.assign(new Error('真實重複'),{code:'functions/already-exists'});
  updatedRoster=[...ev.roster,req.value];
  if(uncertainAdd)throw Object.assign(new Error('response interrupted'),{code:'functions/unavailable'});
  return {data:{ok:true,seq:6,publicationPending:true}};
 }
 if(req.action==='randomRebuild'){updatedRoster=[...ev.roster].reverse();remoteSeq=7;return {data:{ok:true,seq:7,published:true}};}
}})})};
'''
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path=os.environ.get('BBX_CHROMIUM_EXECUTABLE') or shutil.which('chromium'),args=['--no-sandbox','--no-zygote'])
 for width in (375,390,412,1366):
  page=browser.new_page(viewport={'width':width,'height':740},has_touch=width<500,is_mobile=width<500)
  page.clock.install()
  page.set_content(html);page.add_style_tag(content=css)
  page.add_script_tag(content=fixture+'\n'+code+'\nrenderRoster();')
  page.get_by_role('button',name='依目前名單重新抽籤比賽順序',exact=True).wait_for()
  assert page.get_by_role('button',name='抽籤重建',exact=True).count()==0
  add=page.get_by_role('button',name='＋新增')
  page.locator('#newPlayer').fill('001')
  if width==390: page.evaluate('uncertainAdd=true')
  if width<500: add.tap()
  else: add.click()
  assert page.evaluate('sent.length')==1
  assert page.evaluate('sent[0].value')=='001'
  assert page.evaluate('receiptQueries.length')==(1 if width==390 else 0)
  assert add.is_disabled()
  assert page.locator('#bbxPublicationNotice').is_visible()
  page.evaluate("$('matchModal').classList.remove('hidden');showTab('roster');")
  assert page.locator('#matchModal').is_hidden()
  page.get_by_role('button',name='對戰表',exact=True).click()
  assert page.locator('#bbxPublicationNotice').is_visible() and page.evaluate('alerts.length')==0
  page.evaluate('remoteSeq=6');page.clock.run_for(900)
  assert page.locator('#bbxPublicationNotice').is_hidden()
  page.get_by_role('button',name='參賽名單',exact=True).click()
  assert page.locator('#editRoster input').count()==4 and page.locator('#editRoster input').last.input_value()=='001'
  assert page.locator('#newPlayer').input_value()==''
  page.get_by_role('button',name='依目前名單重新抽籤比賽順序',exact=True).click()
  assert page.locator('#editRoster input').first.input_value()=='001'
  assert page.evaluate('sent[1].expectedStructureVersion')==1
  page.evaluate("showTab('referee')")
  assert page.locator('#refereeInviteCode').inner_text()=='111111'
  page.evaluate("failInvite=true")
  page.clock.run_for(2350)
  assert page.locator('#refereeInviteCode').inner_text()=='------'
  assert '自動重試' in page.locator('#refereeCodeCountdown').inner_text()
  page.clock.run_for(1500)
  assert page.locator('#refereeInviteCode').inner_text()=='111113'
  assert page.locator('#refereeInviteQr').inner_text()=='QR stays'
  page.evaluate("showTab('bracket')")
  page.clock.run_for(5000)
  assert page.evaluate('codeCalls')==3
  page.evaluate("showTab('referee')")
  assert page.locator('#refereeInviteCode').inner_text()=='111114'
  page.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,value:'hidden'});stopRefereeCodeRotation()")
  page.clock.run_for(7000)
  assert page.evaluate('codeCalls')==4
  page.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,value:'visible'});startRefereeCodeRotation()")
  assert page.locator('#refereeInviteCode').inner_text()=='111115'
  print('PASS',width,'roster, 001, no modal popup, real button taps, QR expiry/retry/tab/background/resume')
  page.close()
 browser.close()
