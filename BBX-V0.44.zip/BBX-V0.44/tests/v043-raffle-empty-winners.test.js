'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const O=require('../functions/bbx-v011-organizer.js');
const source=fs.readFileSync(path.join(__dirname,'../assets/index-v044.js'),'utf8');
const a=source.indexOf('function defaultRaffleState(){');
const b=source.indexOf('// V0.43:',a);
assert(a>=0 && b>a);
const clientCode=source.slice(a,b);
function view(raw){
 const ctx={ev:{id:'ABC123',roster:['甲','乙','丙'],raffleState:raw},cloneJson:structuredClone,
   localStorage:{getItem(){return null}},Map};
 vm.createContext(ctx);
 vm.runInContext('let v1RaffleChecksEventId=null;let v1RaffleChecksInflightEventId=null;let v1RaffleChecksInflight=new Map();let v1RaffleChecksPending=new Map();',ctx);
 vm.runInContext(clientCode,ctx);
 return JSON.parse(JSON.stringify(vm.runInContext('getRaffleState()',ctx)));
}
let id=0;const stamp=Date.now();
function board(){return {ownerUid:'OWNER',seq:12,roster:['甲','乙','丙'],rounds:[{matches:[{a:'甲',b:'乙',sa:3,sb:2,refereeActive:true,claimUid:'JUDGE',matchVersion:8}]}],refereeCount:1,refereeNames:['裁判 1'],raffleState:{checked:{甲:true,乙:true,丙:true}},receipts:{},outbox:{}}}
function patch(raw,name,checked){
 return O.apply(raw,'OWNER',{action:'setRaffleChecks',opId:stamp.toString(16).padStart(12,'0')+(++id).toString(16).padStart(36,'0'),expectedSeq:1,checks:[{name,checked}]},stamp,{admin:false});
}
// Mimics RTDB omission of a zero-length array under a nonempty object.
function roundtripNoEmptyWinners(state){const x=structuredClone(state);if(Array.isArray(x.winners)&&!x.winners.length)delete x.winners;return x;}
test('empty winners child absent in RTDB must not reset confirmed unchecked players',()=>{
 const result=view({checked:{甲:true,乙:false,丙:true}});
 assert.deepEqual(result.winners,[]);assert.equal(result.checked.乙,false);
 assert.equal(Object.values(result.checked).filter(Boolean).length,2);
});
test('null winners is equivalent to no winners, preserving exclusions',()=>{
 const result=view({winners:null,checked:{甲:false,乙:true,丙:true}});
 assert.deepEqual(result.winners,[]);assert.equal(result.checked.甲,false);
});
test('authoritative consecutive checkbox patches preserve earlier exclusions if RTDB omits empty winners',()=>{
 const original=board(),match=JSON.stringify(original.rounds);
 const first=patch(original,'甲',false);
 assert.equal(first.board.raffleState.checked.甲,false);
 const resumed=structuredClone(first.board);resumed.raffleState=roundtripNoEmptyWinners(resumed.raffleState);
 const second=patch(resumed,'乙',false);
 assert.equal(second.board.raffleState.checked.甲,false);
 assert.equal(second.board.raffleState.checked.乙,false);
 assert.equal(JSON.stringify(second.board.rounds),match);
 const afterRefresh=view(roundtripNoEmptyWinners(second.board.raffleState));
 assert.equal(afterRefresh.checked.甲,false);assert.equal(afterRefresh.checked.乙,false);
 assert.equal(Object.values(afterRefresh.checked).filter(Boolean).length,1);
});
test('already-won players remain ineligible after RTDB representation changes',()=>{
 const b=board();b.raffleState={winners:['丙'],checked:{甲:true,乙:true,丙:false}};
 assert.throws(()=>patch(b,'丙',true),/已中籤/);
 const result=view(b.raffleState);assert.equal(result.checked.丙,false);assert.deepEqual(result.winners,['丙']);
});
