#!/usr/bin/env python3
"""Generate the NEXT empty-schema release. Does NOT deploy or delete live data.
Usage (from the current release directory): python3 MAKE_NEXT_RELEASE.py V0.2
"""
from pathlib import Path
import re, json, shutil, sys
root=Path(__file__).resolve().parent
if len(sys.argv)!=2 or not re.fullmatch(r'V(?:0\.[1-9]\d*|[1-9]\d*\.\d+)',sys.argv[1]):
 raise SystemExit('Usage: python3 MAKE_NEXT_RELEASE.py V0.2')
next_label=sys.argv[1]
config=json.loads((root/'RELEASE_VERSION.json').read_text())
prev_label=config['release']
def prefix(version):
 a,b=version[1:].split('.')
 return f'V{a}{b}'
old_suffix=config['dataSuffix']
new_suffix=prefix(next_label)
if old_suffix==new_suffix or next_label==prev_label:
 raise SystemExit('Refusing to overwrite same version')
# Do not generate older release versions or V0.1 > V0.01 aliases.
def parsed(v): return tuple(map(int,v[1:].split('.')))
if parsed(next_label)<=parsed(prev_label):raise SystemExit('New release must be newer')
out=root.parent/f'BeybladeX-reg-{next_label}'
if out.exists(): raise SystemExit(f'Already exists: {out}')
shutil.copytree(root,out,ignore=shutil.ignore_patterns('node_modules','__pycache__','*.before-*','.last_backup_path'))
# Replace identifiers, all version-specific HTML localStorage keys, and release confirmation strings.
old_api='reg'+old_suffix
new_api='reg'+new_suffix
for f in out.rglob('*'):
 if not f.is_file() or f.name=='MAKE_NEXT_RELEASE.py' or f.suffix in ['.zip','.png','.jpg','.jar']:
  continue
 try:s=f.read_text(encoding='utf-8')
 except UnicodeDecodeError:continue
 s=s.replace(old_api,new_api)
 s=s.replace(old_suffix,new_suffix)
 s=s.replace(prev_label,next_label)
 s=s.replace(f'reg-v{prev_label[1:].replace(".","")}',f'reg-v{next_label[1:].replace(".","")}')
 s=s.replace(f'BeybladeX-reg-{prev_label}',f'BeybladeX-reg-{next_label}')
 f.write_text(s,encoding='utf-8')
cfg=json.loads((out/'RELEASE_VERSION.json').read_text())
cfg.update(release=next_label,apiPrefix=new_api,dataSuffix=new_suffix)
(out/'RELEASE_VERSION.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
print('Generated:',out)
print('New API:',new_api+'*',' New RTDB suffix:',new_suffix)
print('NOT deployed. Run version guard, smoke tests and Emulator before a destructive reset.')
