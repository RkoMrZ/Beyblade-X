#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
if command -v nvm >/dev/null 2>&1; then nvm use 22 || nvm install 22; fi
bash 06_source_guard.sh
node --check functions/index.js
node functions/tests/rules.static.test.js
VERSION="$(node -p "JSON.parse(require('fs').readFileSync('RELEASE_VERSION.json','utf8')).release")"
API="$(node -p "JSON.parse(require('fs').readFileSync('RELEASE_VERSION.json','utf8')).apiPrefix")"
[ -s .last_backup_path ] || { echo 'ERROR: backup must be created before deploying'; exit 3; }
BACKUP="$(cat .last_backup_path)"
[ -s "$BACKUP" ] || { echo 'ERROR: backup no longer exists'; exit 3; }
case "$BACKUP" in *"-$VERSION-reset-"*|*"-before-$VERSION.json") ;; *) echo 'ERROR: backup path is not for this exact release'; exit 3 ;; esac
echo "Target project: $PROJECT / release: $VERSION / functions: $API*"
echo 'STOP: Ensure GitHub /reg/ three pages are already replaced with maintenance pages.'
echo 'Codebase deployment retires old registration functions if asked; confirm ONLY old registration functions.'
read -r -p "To deploy release $VERSION, type DEPLOY-$VERSION-ljtreg-39954: " answer
[ "$answer" = "DEPLOY-$VERSION-ljtreg-39954" ] || { echo CANCELLED; exit 2; }
firebase deploy --only functions:registration --project "$PROJECT"
echo 'Verifying nine new functions and NO old function names...'
FUNCTIONS="$(firebase functions:list --project "$PROJECT")" || exit 4
printf '%s\n' "$FUNCTIONS"
# Check nine expected and detect known historical endpoints; avoid printing secrets.
for suffix in CreateEvent UpdateEvent SetOpen Submit Review EditEntry DeleteEntry DeleteEvent MyRank; do
  printf '%s\n' "$FUNCTIONS" | grep -Fq "${API}${suffix}" || { echo "ERROR: ${API}${suffix} is missing"; exit 4; }
done
if printf '%s\n' "$FUNCTIONS" | grep -E 'reg(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|MyRank)([[:space:]│|]|$)|reg8(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|MyRank)([[:space:]│|]|$)' >/dev/null; then
 echo 'ERROR: legacy reg8 endpoint remains; do not reset'; exit 4
fi
# Detect prior versioned functions, excluding the target API.
if printf '%s\n' "$FUNCTIONS" | grep -Eo 'regV[0-9]+(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|MyRank)' | grep -v "^${API}"; then
 echo 'ERROR: previous version functions remain; do not reset'; exit 4
fi
echo 'Now deploying version-exclusive Realtime Database Rules.'
firebase deploy --only database --project "$PROJECT"
echo 'BACKEND_READY: proceed to clean reset only after confirming maintenance pages remain live.'
