#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
node -v
bash 06_source_guard.sh
PROJECT=ljtreg-39954
INSTANCE=ljtreg-39954-default-rtdb
echo '== DEPLOYED FUNCTION LIST =='
firebase functions:list --project "$PROJECT"
echo '== DATABASE ROOT KEY NAMES ONLY (NO PRIVATE DATA) =='
firebase database:get / --project "$PROJECT" --instance "$INSTANCE" | node -e 'let s="";process.stdin.on("data",x=>s+=x);process.stdin.on("end",()=>{const v=JSON.parse(s);console.log("ROOT NODES:",v===null?"EMPTY":Object.keys(v).join(", "))})'
