#!/usr/bin/env python3
"""Optional local Chromium hit-target/tap matrix. Requires Python playwright + Chromium; no Firebase traffic."""
from pathlib import Path
import shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
css=(root/'assets/index-v020.css').read_text()
js=(root/'assets/index-v020.js').read_text()
code=js[js.index('/* V0.14: one viewport-to-document coordinate'):js.index('bootstrapCloud();')]
html='''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>
<header>Test header</header><main><div style="height:3100px">tournament page with long bracket</div></main>
<div id="matchModal" class="matchModal hidden"><div id="matchSheet" class="matchSheet"><div class="sheetHandle"></div>
<div class="sheetTitle"><h3>選手2 vs 選手3</h3><button id="close" class="sheetClose">✕</button></div>
<div class="sheetRef"><b>裁判狀態</b><button id="edit">✏️修改比分</button></div>
<div class="quickScoreBox"><div class="quickScoreTitle">⚡快速加分</div>
<div class="quickScorePlayers">'''+''.join('<div class="quickScoreSide"><div class="quickScoreHead"><b class="quickScoreName">選手 '+x+'</b><button class="quickScoreTotal" id="total'+x+'">4</button></div><div class="quickScoreBtns">'+''.join('<button id="p'+x+str(k)+'">+'+str(k)+'</button>' for k in range(1,6))+'</div></div>' for x in ['A','B'])+'''</div><p class="quickScoreHint">比分僅由裁判修改</p></div>
<div class="sheetFooter"><button id="back">回到對戰表</button><button id="reset">重設比分</button></div></div></div>
<div id="deleteConfirmModal" class="matchModal hidden"><div class="matchSheet"><h3>刪除賽事</h3><div class="sheetFooter"><button id="deleteCancel">取消</button><button id="deleteOk">刪除</button></div></div></div>
<div id="scorePicker" class="scorePickerPop hidden"><div class="scorePickerCard"><div class="scoreGrid">'''+''.join('<button id="score'+str(i)+'">'+str(i)+'</button>' for i in range(7))+'''</div><button id="zero" class="scoreClear">比分歸零</button></div></div>
<div id="resetChoiceModal" class="resetChoiceModal hidden"><div class="resetChoiceCard"><h3>重設</h3><div class="resetChoiceActions"><button id="only">只重設比分</button><button id="clearAll">清除所有</button><button id="cancelReset">取消</button></div></div></div>
<div id="raffle" class="raffleWinnerModal hidden"><div class="raffleWinnerModalCard"><h3>獎品抽籤</h3><button id="raffleOk" class="raffleWinnerModalClose">確定</button></div></div>
<div id="bracket" class="bracketShell hidden"><div class="bracketTools"><button id="full">⛶</button><button id="zoomIn">+</button><button id="zoomOut">−</button></div><div class="bracketScroll"><div class="bracketCanvas"></div></div></div>
<script>const clicks={};document.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>clicks[b.id]=(clicks[b.id]||0)+1));</script>
</body></html>'''
scenarios=[
 ('iphone-360',360,640,True),('iphone-390',390,740,True),('iphone-landscape',740,390,True),
 ('android-412',412,915,True),('android-360',360,720,True),('tablet-768',768,1024,True),
 ('desktop-1440',1440,900,False),('laptop-1024',1024,768,False)]
groups={
 'matchModal':['close','edit','totalA','pA1','pA2','pA3','pA4','pA5','totalB','pB1','pB2','pB3','pB4','pB5','back','reset'],
 'deleteConfirmModal':['deleteCancel','deleteOk'],
 'scorePicker':['score0','score1','score2','score3','score4','score5','score6','zero'],
 'resetChoiceModal':['only','clearAll','cancelReset'],
 'raffle':['raffleOk'],
 'bracket':['full','zoomIn','zoomOut']}
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=shutil.which('chromium') or shutil.which('chromium-browser') or p.chromium.executable_path,args=['--no-sandbox'])
 for label,w,h,mobile in scenarios:
  page=browser.new_page(viewport={'width':w,'height':h},is_mobile=mobile,has_touch=mobile,device_scale_factor=2 if mobile else 1)
  page.set_content(html.replace('</head>','<style>'+css+'</style></head>'))
  page.add_script_tag(content=code)
  for scroll in [0,950]:
   page.evaluate('(scroll)=>{window.scrollTo(0,scroll);syncAppVisualViewport()}',scroll)
   page.wait_for_timeout(70)
   for group,buttons in groups.items():
    page.evaluate('(group)=>{document.querySelectorAll(".matchModal,.scorePickerPop,.resetChoiceModal,.raffleWinnerModal,.bracketShell").forEach(el=>el.classList.add("hidden"));document.getElementById(group).classList.remove("hidden"); document.body.classList.toggle("bracketFullscreen",group==="bracket");syncAppVisualViewport()}',group)
    page.wait_for_timeout(30)
    for btn in buttons:
     loc=page.locator('#'+btn)
     loc.scroll_into_view_if_needed(timeout=5000)
     box=loc.bounding_box()
     assert box and box['width']>=30 and box['height']>=30,(label,scroll,group,btn,box)
     x=box['x']+box['width']/2;y=box['y']+box['height']/2
     assert x>=0 and x<w and y>=0 and y<h,(label,scroll,group,btn,box)
     hit=page.evaluate('([x,y])=>{let n=document.elementFromPoint(x,y);return n&&n.closest("button")?.id||null}',[x,y])
     assert hit==btn,(label,scroll,group,btn,'hit',hit,box)
     count=page.evaluate('(id)=>clicks[id]||0',btn)
     if mobile:
      page.touchscreen.tap(x,y)
     else:
      page.mouse.click(x,y)
     after=page.evaluate('(id)=>clicks[id]||0',btn)
     assert count+1==after,(label,scroll,group,btn,count,after)
     results.append((label,scroll,group,btn))
  page.close()
 browser.close()
print('PASS simulated Chromium coordinates + click/tap: ',len(results),'across',len(scenarios),'screen profiles, 2 scroll offsets, 6 UI groups')
