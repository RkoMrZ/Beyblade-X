const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ui=fs.readFileSync(path.join(__dirname,'../assets/index-v020.js'),'utf8');
const viewer=fs.readFileSync(path.join(__dirname,'../assets/viewer-v020.js'),'utf8');
const section=ui.slice(ui.indexOf('function listenCloudEvent(id){'),ui.indexOf('async function waitForAuthRestore('));
test('referee and organizer subscribe to the same private event authority',()=>{
 assert.match(section,/onValue\(`refereeClaims\/\$\{id\}`/);
 assert.match(section,/onValue\(`events\/\$\{id\}\/authoritySeq`/);
 assert.match(section,/onChildren\(`events\/\$\{id\}\/rounds\/\$\{ri\}\/matches`/);
});
test('all score changes schedule bracket redraw and keep viewport state',()=>{
 assert.match(section,/V0\.20: update the entire connected bracket state/);
 assert.match(section,/scheduleRender\(\);/);
 assert.match(ui,/bracketViewAfterRender\(bracketView\)/);
});
test('listener cancellation is observable and causes bounded repair',()=>{
 assert.match(section,/BBX_LIVE_LISTENER_CANCELLED/);
 assert.match(section,/scheduleLiveRecovery\('permission-or-listener-error'\)/);
 assert.match(section,/liveRecoveryBusy=true/);
});
test('watchdog checks only tiny sequence; snapshots on gap, active session only',()=>{
 assert.match(section,/rtdbRestGet\(`events\/\$\{id\}\/authoritySeq`,5000\)/);
 assert.match(section,/seq>observedAuthoritySeq/);
 assert.match(section,/if\(!active\(\)\|\|liveRecoveryBusy\)return/);
});
test('claim backup reconciliation only occurs on open referee tab',()=>{
 assert.match(section,/currentAdminTab==='referee' && \(isAdmin\|\|isReferee\)/);
 assert.match(section,/renderReferee\(\{skipCloudRefresh:true\}\)/);
});
test('unsubscribing stops watchdog and recovery timers',()=>{
 assert.match(section,/clearTimeout\(liveRecoveryTimer\)/);
 assert.match(section,/clearInterval\(liveWatchdogTimer\)/);
});
test('viewer retains SSE and watches only small public sequence for missed events',()=>{
 assert.match(viewer,/new EventSource\(streamUrl\(kind,id\)\)/);
 assert.match(viewer,/meta\/authoritySeq\.json/);
 assert.match(viewer,/scheduleReconnectResync\(kind,id,'viewer-missed-sequence'\)/);
});
