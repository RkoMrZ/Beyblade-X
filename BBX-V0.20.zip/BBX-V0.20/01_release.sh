#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.20 deployment is already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.20 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.20 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/BBX-V0.20-檢查.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v020-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
gcloud auth print-access-token >/dev/null
# Frontend-only sync recovery; do not change or redeploy the authoritative backend.
bash deploy/BBX-V0.20-Hosting.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.20 Hosting ONLY deployed; Functions, Rules and saved events untouched.\n'
