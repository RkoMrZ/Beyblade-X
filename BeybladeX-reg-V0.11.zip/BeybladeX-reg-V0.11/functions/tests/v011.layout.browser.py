"""Offline layout checks of the actual shared create/edit formFields markup."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
from browser_support import browser_options
root=Path(__file__).resolve().parents[2]
js=(root/'web/js/index.js').read_text()
fn=re.search(r'function formFields\(m=\{\}\)\{return `.*?`\}',js).group()
css='\n'.join((root/'web/css'/f).read_text() for f in ['common.css','index.css'])
with sync_playwright() as p:
 b=p.chromium.launch(**browser_options())
 for width in [320,375,390,402,430,768,1280]:
  page=b.new_page(viewport={'width':width,'height':844})
  page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style><main class="container"><form class="card" id="form"></form></main>')
  page.evaluate('window.safe=x=>String(x??"");window.deadlineValue=x=>x||"";'+fn+';document.querySelector("#form").innerHTML=formFields()')
  for val in ['', '2026-11-08T21:30']:
   field=page.locator('[name=signupDeadline]');field.fill(val)
   assert field.input_value()==val
   assert field.evaluate('(e)=>{const a=e.getBoundingClientRect(),b=e.parentElement.getBoundingClientRect();return a.left>=b.left-.5&&a.right<=b.right+.5&&getComputedStyle(e).appearance==="none"}')
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  print('PASS shared create/edit date-time field',width,'px: empty/filled, contained, value preserved')
  page.close()
 b.close()
