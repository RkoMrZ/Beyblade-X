V8.1 RTDB transaction-cache 修正版（僅限 DEMO 模擬器）
====================================================
修正：所有交易在 Cloud Functions 暫時監聽單一節點，等待首次伺服器值，
      再執行 Firebase transaction，交易結束後解除監聽。
      避免既有節點第一次收到 provisional null 就中止的問題。
      這不會讓報名網站長期維持 WebSocket。
包括：
  reg_v8_preflight/functions/index.js
  reg_v8_preflight/functions/tests/smoke.test.js

已完成在本地運行：
  node --check functions/index.js
  node --check functions/tests/smoke.test.js
  node functions/tests/smoke.test.js -> PASS（記憶體模擬）
  node functions/tests/rules.static.test.js -> PASS（靜態檢查）

尚未完成：真正 Firebase RTDB Emulator 64 人並發、權限驗證。
絕對不要在正式專案直接部署這個候選版。

iPhone：將本 ZIP 上傳到 GitHub rkomrz/Beyblade-X 的 Repository 根目錄。
再進 Cloud Shell（即使回到 ~ 也可執行）：

cd ~ && cd reg_v8_preflight && cp -n functions/index.js functions/index.js.before-listenerfix && cd ~ && curl -fLsS -o reg-v8-transaction-cachefix.zip https://raw.githubusercontent.com/rkomrz/Beyblade-X/main/reg-v8-transaction-cachefix.zip && unzip -oq reg-v8-transaction-cachefix.zip -d ~ && cd ~/reg_v8_preflight && nvm install 22 && nvm use 22 && node --check functions/index.js && node functions/tests/smoke.test.js && node functions/tests/rules.static.test.js && timeout -k 10s 360s firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'

若出現 FAIL，拍下完整錯誤，勿重複測試或部署。
