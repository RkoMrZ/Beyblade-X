#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ "$(basename "$ROOT")" != BBX-V0.2 ]]; then echo 'STOP: Project directory is not BBX-V0.2' >&2; exit 2; fi
python3 - <<'PY'
import json,hashlib
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.2' and m['firebase_project']=='ljt-beyblade-x'
assert m['release_status']=='TEST_DEPLOY_READY','不是待測試部署包'
for item in m['files']:
 p=Path(item['path']); assert p.is_file(),str(p)
 raw=p.read_bytes()
 assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],f'版本校驗失敗：{p}'
assert 'ljtreg' not in Path('.firebaserc').read_text()
print('PASS: BBX-V0.2 version and SHA-256 manifest')
PY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'Node.js 22 required' >&2; exit 3; }
node --test tests/authority.test.js tests/organizer.test.js tests/integration-mock.test.js tests/compare-brackets.test.js tests/progression-compare.test.js
python3 tests/check_static.py
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI unavailable' >&2; exit 4; }
command -v java >/dev/null || { echo 'STOP: Java unavailable for RTDB emulator' >&2; exit 4; }
# Emulator is local only. It never touches production Firebase or RTDB.
npm --prefix tests install --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v02 'cd tests && node rules-emulator.test.cjs'
node --check functions/index.js
# The marker permits the next command only if the package is unchanged.
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v02-preflight-ok"
printf '\nPASS: BBX-V0.2 complete local checks and RTDB emulator permissions. You may run the deployment command.\n'
