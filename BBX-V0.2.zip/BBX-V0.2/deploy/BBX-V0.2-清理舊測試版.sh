#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
# Called only AFTER the current version has deployed successfully.
# A new release must name EXACTLY one previous BBX-V0.* release in its manifest.
PREVIOUS="$(python3 - <<'PY2'
import json,re,sys
m=json.load(open('MANIFEST.json'))
assert m['firebase_project']=='ljt-beyblade-x'
assert m['release_status']=='TEST_DEPLOY_READY'
prev=m.get('previous_release')
if prev is not None and not re.fullmatch(r'BBX-V0\.[1-9][0-9]*',prev):
 sys.exit('拒絕不明舊版本：'+str(prev))
print(prev or '')
PY2
)"
if [[ -z "$PREVIOUS" ]]; then
 echo 'BBX-V0.2 為首個測試版：沒有前一版需要刪除。'
 exit 0
fi
# Only explicitly manifest-declared V0.1 functions are eligible for removal.
# Verify new V0.2 Functions before deleting any V0.1 function.
python3 - <<'PY_VERIFY_OLD'
import json
m=json.load(open('MANIFEST.json'))
assert m['previous_release']=='BBX-V0.1'
assert len(m['previous_function_exports'])==8
assert all(x.startswith('bbxV01') for x in m['previous_function_exports'])
assert not set(m['previous_function_exports']) & set(m['functions_exports'])
PY_VERIFY_OLD
printf '只檢查 ljt-beyblade-x 專案已存在的前版 bbxV01 函數...\n'
gcloud functions list --v2 --regions=asia-southeast1 --project=ljt-beyblade-x --format=json > /tmp/bbx-v02-previous-functions.json
python3 - <<'PY_OLD_NAMES' > /tmp/bbx-v02-delete-previous.txt
import json
m=json.load(open('MANIFEST.json'))
items=json.load(open('/tmp/bbx-v02-previous-functions.json'))
existing={str(x['name']).split('/')[-1] for x in items}
for name in m['previous_function_exports']:
 if name in existing: print(name)
PY_OLD_NAMES
while IFS= read -r fn; do
  [[ -n "$fn" ]] || continue
  echo "刪除前版函數: $fn"
  firebase functions:delete "$fn" --region asia-southeast1 --project ljt-beyblade-x --force
done </tmp/bbx-v02-delete-previous.txt
# Confirm all explicit old names gone; never delete similarly named non-BBX services.
gcloud functions list --v2 --regions=asia-southeast1 --project=ljt-beyblade-x --format=json > /tmp/bbx-v02-after-cleanup.json
python3 - <<'PY_CHECK_OLD'
import json
m=json.load(open('MANIFEST.json'))
existing={str(x['name']).split('/')[-1] for x in json.load(open('/tmp/bbx-v02-after-cleanup.json'))}
assert not set(m['previous_function_exports']) & existing,'前版 BBX V0.1 Functions 尚有殘留'
assert set(m['functions_exports']) <= existing,'新版 V0.2 Functions 有缺漏'
print('PASS: V0.2 8 支 Functions 保留；V0.1 8 支 Functions 已移除')
PY_CHECK_OLD
# Remove ONLY the previous BBX test build from Cloud Shell. No deployed data removed.
[[ "$PREVIOUS" != 'BBX-V0.2' || "$(basename "$ROOT")" != 'BBX-V0.2' ]] || { echo '拒絕刪除目前版本'; exit 2; }
rm -rf -- "$HOME/$PREVIOUS"
rm -f -- "$HOME/$PREVIOUS.zip"
# GitHub Pages ZIP source cleanup requires authenticated GitHub git push.
# Do not auto-delete anything in a repository without a checked-out source branch.
if [[ -n "${BBX_PAGES_REPO_DIR:-}" && -d "$BBX_PAGES_REPO_DIR/.git" ]]; then
  (cd "$BBX_PAGES_REPO_DIR" && git rm --ignore-unmatch -- "$PREVIOUS.zip" && \
   if ! git diff --cached --quiet; then git commit -m "Remove old BBX test release $PREVIOUS" && git push; fi)
else
  echo "GitHub 舊 ZIP $PREVIOUS.zip 尚未刪除：未提供具寫入權限的 BBX_PAGES_REPO_DIR。"
fi
printf '已完成 BBX 前版函式及 Cloud Shell 檔案清理；不含報名系統函式及 Firebase 賽事資料。\n'
