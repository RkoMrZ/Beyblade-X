'use strict';
// Runs ONLY against the local Firebase RTDB emulator, never the production service.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing');
const {ref,get,update,remove,set}=require('firebase/database');
(async()=>{
 const host=process.env.FIREBASE_DATABASE_EMULATOR_HOST;
 if(!host||!host.includes(':'))throw Error('拒絕：此測試必須在 Firebase Realtime Database Emulator 中執行');
 const env=await initializeTestEnvironment({
  projectId:'demo-bbx-v02',database:{rules:fs.readFileSync('../database.rules.json','utf8')}
 });
 const eventId='BBXTEST_A123456',now=Date.now();
 const board=(active,open=true)=>({id:eventId,ownerUid:'owner',created:now,testOnly:false,authorityBBX:active?'active':null,
  name:'test',mode:'single',pairing:'ordered',freeFinal:'champ',roster:['A','B'],
  rounds:[{name:'第 1 輪',matches:[{a:'A',b:'B',sa:0,sb:0,winner:null}]}],
  publicOpen:open,publicUntil:now+3600000});
 const metadata=(open=true)=>({id:eventId,name:'test',publicOpen:open,publicUntil:now+3600000});
 const owner=env.authenticatedContext('owner');
 const referee=env.authenticatedContext('judge');
 const guest=env.unauthenticatedContext();
 const dbo=owner.database(),dbr=referee.database(),dbg=guest.database();
 try{
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),`events/${eventId}`),board(false));
   await set(ref(ctx.database(),`publicEvents/${eventId}`),{meta:metadata(),rounds:board(false).rounds});
   await set(ref(ctx.database(),`userEvents/owner/0`),eventId);
   await set(ref(ctx.database(),`refereeUsers/${eventId}/judge`),'123456');
   await set(ref(ctx.database(),`authorityBBX/${eventId}/board`),{seq:0,privateToken:'DONOTSHOW'});
  });
  // Old V1.0 frontend remains functional only while authority is NOT active.
  await assertSucceeds(update(ref(dbo,`events/${eventId}/rounds/0/matches/0`),{sa:1}));
  await assertSucceeds(get(ref(dbo,`events/${eventId}`)));
  await assertSucceeds(get(ref(dbg,`publicEvents/${eventId}`)));
  await assertFails(get(ref(dbg,`events/${eventId}`)));
  await assertFails(get(ref(dbg,`authorityBBX/${eventId}/board`)));
  // V1.0 grants registered referees access to private and public match scores
  // before BBX cloud authority is enabled. This must remain backward compatible.
  await assertFails(update(ref(dbg,`publicEvents/${eventId}/rounds/0/matches/0`),{sa:8}));
  await assertSucceeds(update(ref(dbr,`publicEvents/${eventId}/rounds/0/matches/0`),{sa:9}));
  console.log('PASS: legacy V1.0 judge can update pre-authority; guest cannot');
  await env.withSecurityRulesDisabled(async ctx=>{
   await update(ref(ctx.database(),`events/${eventId}`),{authorityBBX:'active'});
  });
  // Active authority refuses ALL legacy direct writes, including owner deletion.
  await assertFails(update(ref(dbo,`events/${eventId}/rounds/0/matches/0`),{sa:3}));
  await assertFails(update(ref(dbo,`events/${eventId}/roster`),{0:'X'}));
  await assertFails(update(ref(dbo,`events/${eventId}/raffleState`),{winners:['A']}));
  await assertFails(update(ref(dbo,`events/${eventId}/refereeNames`),{0:'Evil'}));
  await assertFails(remove(ref(dbo,`events/${eventId}`)));
  await assertFails(update(ref(dbo,`publicEvents/${eventId}/rounds/0/matches/0`),{sa:3}));
  await assertFails(update(ref(dbr,`events/${eventId}/rounds/0/matches/0`),{sb:3}));
  await assertFails(set(ref(dbo,`authorityBBX/${eventId}/board/seq`),99));
  console.log('PASS: active authority blocks all legacy direct writes and private authority access');
  await env.withSecurityRulesDisabled(async ctx=>{
   await update(ref(ctx.database(),`publicEvents/${eventId}/meta`),{publicOpen:false});
  });
  await assertFails(get(ref(dbg,`publicEvents/${eventId}`)));
  await assertSucceeds(get(ref(dbo,`events/${eventId}`)));
  console.log('PASS: Firebase Emulator permissions for viewer, organizer, referee, legacy-write and active authority');
 }finally{await env.cleanup()}
})().catch(e=>{console.error(e);process.exitCode=1});
