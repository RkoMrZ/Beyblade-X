'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const vm=require('node:vm');
const path=require('node:path');
const O=require('../functions/bbx-v02-organizer');
const clone=x=>x===undefined?undefined:JSON.parse(JSON.stringify(x));
const NOW=Date.now();let opSeq=0;
function op(){return (Date.now()).toString(16).padStart(12,'0')+(++opSeq).toString(16).padStart(36,'0')}
function firebaseSandbox(){
 const data={};
 function get(p){let x=data;for(const t of p.split('/').filter(Boolean)){if(x===null||x===undefined)return null;x=x[t]}return clone(x===undefined?null:x)}
 function set(p,v){const tokens=p.split('/').filter(Boolean);if(!tokens.length){for(const k of Object.keys(data))delete data[k];Object.assign(data,clone(v));return}
   let x=data;for(const t of tokens.slice(0,-1)){if(!x[t]||typeof x[t]!=='object')x[t]={};x=x[t]}
   const k=tokens.at(-1);if(v===null)delete x[k];else x[k]=clone(v)}
 const snap=p=>({val:()=>get(p),exists:()=>get(p)!==null});
 const ref=p=>({
  child(x){return ref(p?`${p}/${x}`:x)},
  get:async()=>snap(p),
  set:async v=>set(p,v),
  update:async updates=>{for(const [k,v] of Object.entries(updates))set(p?`${p}/${k}`:k,v)},
  transaction:async fn=>{const updated=fn(get(p));if(updated===undefined)return {committed:false,snapshot:snap(p)};set(p,updated);return {committed:true,snapshot:snap(p)}}
 });
 const db={ref};
 const admin={initializeApp(){},database(){return db}};
 class HttpsError extends Error {constructor(code,message){super(message);this.code=code}}
 const requireMock=name=>name==='node:crypto'?require('node:crypto'):name==='firebase-admin'?admin:name==='firebase-functions/v2/https'?{onCall:(_,fn)=>fn,HttpsError}:name==='firebase-functions/v2/database'?{onValueWritten:(_,fn)=>fn}:require(path.resolve(__dirname,'../functions',name));
 const module={exports:{}};
 const code=fs.readFileSync(path.resolve(__dirname,'../functions/index.js'),'utf8');
 const sandbox={module,exports:module.exports,require:requireMock,console,process:{env:{GCLOUD_PROJECT:'ljt-beyblade-x'}},Date,Buffer};
 vm.runInNewContext(code,sandbox,{filename:'functions/index.js'});
 const handlers=module.exports;
 const owner='owner';
 const req=(action,eventId='bbx2026101601',more={})=>({auth:{uid:owner,token:{firebase:{sign_in_provider:'google.com'}}},data:{clientVersion:'bbx-v0.2-authority-1',eventId,...(action?{action}:{}),...more}});
 function initial(){
  const roster=['A','B','C','D'];const {rounds,finalRR}=O.build(roster,'single','champ');
  const eventId='bbx2026101601';
  const ev={id:eventId,ownerUid:owner,releaseTag:'BBX-V0.2',roster,mode:'single',pairing:'ordered',freeFinal:'champ',rounds,finalRR,refereeNames:['裁判 1'],refereeCount:1,publicOpen:true,publicUntil:NOW+3600000};
  set(`userEvents/${owner}/0`,eventId);set(`events/${eventId}`,ev);
  set(`publicEvents/${eventId}`,{meta:{id:eventId,name:'Test',publicOpen:true,publicUntil:ev.publicUntil},rounds:clone(rounds),finalRR:null});
  return ev;
 }
 return {handlers,data,get,set,req,initial};
}
test('new BBX event can stage, activate, and reject stale browser snapshot after ownership moves to server',async()=>{
 const x=firebaseSandbox(),ev=x.initial(),id=ev.id;
 const staged=await x.handlers.bbxV02StageAuthority(x.req(null,id));assert.equal(staged.staged,true);
 const activated=await x.handlers.bbxV02ActivateAuthority(x.req(null,id));assert.equal(activated.active,true);
 assert.equal(x.get(`events/${id}/authorityBBX`),'active');
 const changed=await x.handlers.bbxV02OrganizerAuthority(x.req('rename',id,{opId:op(),expectedSeq:0,index:0,value:'A-new'}));
 assert.equal(changed.ok,true);
 assert.equal(x.get(`events/${id}/roster/0`),'A-new');
 assert.equal(x.get(`publicEvents/${id}/meta/roster/0`),'A-new');
 await assert.rejects(x.handlers.bbxV02OrganizerAuthority(x.req('rename',id,{opId:op(),expectedSeq:0,index:0,value:'HACK'})),e=>e.code==='aborted');
 assert.equal(x.get(`events/${id}/roster/0`),'A-new');
});
test('scoring and progression are server-side, only affected public match is changed',async()=>{
 const x=firebaseSandbox(),ev=x.initial(),id=ev.id;
 await x.handlers.bbxV02ActivateAuthority(x.req(null,id));
 let r=await x.handlers.bbxV02CommandAuthority(x.req('claim',id,{opId:op(),target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'}));
 assert.equal(r.matchVersion,1);
 r=await x.handlers.bbxV02CommandAuthority(x.req('score',id,{opId:op(),target:{kind:'round',ri:0,mi:0},expectedMatchVersion:1,referee:'裁判 1',sa:4,sb:2}));
 assert.equal(r.matchVersion,2);
 r=await x.handlers.bbxV02CommandAuthority(x.req('complete',id,{opId:op(),target:{kind:'round',ri:0,mi:0},expectedMatchVersion:2,referee:'裁判 1',sa:4,sb:2}));
 assert.equal(r.winner,'A');
 const published=x.get(`publicEvents/${id}/rounds/0/matches/0`);
 assert.equal(published.winner,'A');
 assert.equal(published.claimUid,undefined);
 assert.equal(x.get(`events/${id}/rounds/1/matches/0/a`),'A');
 await assert.rejects(x.handlers.bbxV02CommandAuthority(x.req('score',id,{opId:op(),target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1',sa:0,sb:4})),e=>e.code==='aborted');
});
test('referee configuration, private raffle, closing viewer, and scoring while public closed',async()=>{
 const x=firebaseSandbox(),ev=x.initial(),id=ev.id;
 await x.handlers.bbxV02ActivateAuthority(x.req(null,id));
 const r1=await x.handlers.bbxV02OrganizerAuthority(x.req('setReferees',id,{opId:op(),expectedSeq:0,refereeNames:['Judge 1','Judge 2']}));
 assert.equal(r1.ok,true);assert.deepEqual(x.get(`events/${id}/refereeNames`),['Judge 1','Judge 2']);
 assert.equal(x.get(`publicEvents/${id}/refereeNames`),null);
 const r2=await x.handlers.bbxV02OrganizerAuthority(x.req('setRaffle',id,{opId:op(),expectedSeq:1,raffleState:{winners:['A'],checked:{A:false,B:true,C:true,D:true}}}));
 assert.equal(r2.ok,true);assert.deepEqual(x.get(`events/${id}/raffleState/winners`),['A']);
 const close=await x.handlers.bbxV02OrganizerAuthority(x.req('closePublic',id,{opId:op(),expectedSeq:2}));
 assert.equal(close.ok,true);assert.equal(x.get(`publicEvents/${id}/meta/publicOpen`),false);
 const claim=await x.handlers.bbxV02CommandAuthority(x.req('claim',id,{opId:op(),target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'Judge 1'}));
 assert.equal(claim.ok,true);
});
test('server refuses activating old production event and deletion is test-project/event scoped',async()=>{
 const x=firebaseSandbox(),ev=x.initial(),id=ev.id;
 x.set(`events/${id}/releaseTag`,'V1.0');
 await assert.rejects(x.handlers.bbxV02ActivateAuthority(x.req(null,id)),e=>e.code==='failed-precondition');
 x.set(`events/${id}/releaseTag`,'BBX-V0.2');
 await x.handlers.bbxV02ActivateAuthority(x.req(null,id));
 x.set(`events/OTHER`,{ownerUid:'other',data:1});
 const deleted=await x.handlers.bbxV02DeleteAuthority(x.req(null,id));
 assert.equal(deleted.deleted,true);assert.equal(x.get(`events/${id}`),null);assert.equal(x.get(`authorityBBX/${id}`),null);
 assert.equal(x.get(`userEvents/owner/0`),null);assert.equal(x.get(`events/OTHER/ownerUid`),'other');
});

// Regression: RTDB snapshot trees may have different key insertion order and
// omit null object children. Neither is a real edit to the tournament.
function permuteTree(x){
 if(Array.isArray(x))return x.map(permuteTree);
 if(x&&typeof x==='object'){
  const o={};for(const k of Object.keys(x).reverse()){
   if(x[k]!==null)o[k]=permuteTree(x[k]);
  }return o;
 }
 return x;
}
test('activation succeeds when RTDB reorders keys and omits nulls',async()=>{
 const x=firebaseSandbox(),ev=x.initial(),id=ev.id;
 const staged=await x.handlers.bbxV02StageAuthority(x.req(null,id));
 assert.equal(staged.staged,true);
 x.set(`events/${id}`,permuteTree(x.get(`events/${id}`)));
 const r=await x.handlers.bbxV02ActivateAuthority(x.req(null,id));
 assert.equal(r.active,true);
 assert.equal(x.get(`events/${id}/authorityBBX`),'active');
});
test('activation does not ignore actual stale bracket mutations',async()=>{
 const x=firebaseSandbox(),ev=x.initial(),id=ev.id;
 await x.handlers.bbxV02StageAuthority(x.req(null,id));
 x.set(`events/${id}/rounds/0/matches/0/sa`,2);
 await assert.rejects(x.handlers.bbxV02ActivateAuthority(x.req(null,id)),e=>e.code==='aborted'&&e.message.includes('rounds'));
 assert.equal(x.get(`events/${id}/authorityBBX`),null);
});
test('activation is idempotent after authoritative gate set',async()=>{
 const x=firebaseSandbox(),ev=x.initial(),id=ev.id;
 await x.handlers.bbxV02ActivateAuthority(x.req(null,id));
 const r=await x.handlers.bbxV02ActivateAuthority(x.req(null,id));
 assert.equal(r.existing,true);
});
