'use strict';
// No Firebase credentials required: deterministic in-memory transaction model.
const assert=require('node:assert/strict');
const Module=require('node:module');
const path=require('node:path');
class HttpsError extends Error {constructor(code,message){super(message);this.code=code}}
const root={};let queue=Promise.resolve();
const clone=x=>x===undefined?undefined:structuredClone(x);
const tokens=p=>p.split('/').filter(Boolean);
function get(p){return tokens(p).reduce((cur,k)=>cur?.[k],root)}
function set(p,v){let cur=root;const a=tokens(p);for(const key of a.slice(0,-1))cur=cur[key]??={};const key=a.at(-1);if(!key){Object.assign(root,v);return}if(v===null||v===undefined)delete cur[key];else cur[key]=clone(v)}
function ref(p=''){return {
 child(k){return ref([p,k].filter(Boolean).join('/'))},
 async get(){const value=get(p);return {val(){return clone(value)},exists(){return value!==undefined&&value!==null}}},
 async remove(){return set(p,null)},
 async update(updates){for(const [k,v]of Object.entries(updates))set(k,v)},
 transaction(fn){const job=queue.then(()=>{const prev=clone(get(p))??null;const next=fn(prev);if(next===undefined)return {committed:false};set(p,next);return {committed:true,snapshot:{val:()=>clone(next)}}});queue=job.then(()=>{},()=>{});return job}
}}
const modulePath=path.join(__dirname,'../index.js');
const old=Module._load;
Module._load=function(id,parent,isMain){if(id==='firebase-functions/v2/https')return {onCall:(cfg,fn)=>fn,HttpsError};if(id==='firebase-admin/app')return {initializeApp:()=>{}};if(id==='firebase-admin/database')return {getDatabase:()=>({ref})};return old.apply(this,arguments)};
const fn=require(modulePath);Module._load=old;
const owner={auth:{uid:'owner-1',token:{firebase:{sign_in_provider:'google.com'}}},data:null};
const owner2={auth:{uid:'owner-2',token:{firebase:{sign_in_provider:'google.com'}}},data:null};
const guest={auth:null,data:null};
const call=(name,data,who=owner)=>fn[name]({...who,data});
(async()=>{
 const info={title:'金魚盃',eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'體育館',fee:0,capacity:32};
 const {eid}=await call('regCreateEvent',info);
 assert.match(eid,/^[0-9a-f]{24}$/);assert.equal(get('ownerEvents/owner-1/'+eid)>0,true);
 await assert.rejects(call('regSetOpen',{eid,open:false,expectedVersion:1},owner2),/權限/);
 const randomIds=Array.from({length:64},(_,i)=>i.toString(16).padStart(48,'0'));
 const requests=Array.from({length:64},(_,i)=>call('regSubmit',{eid,rid:randomIds[i],playerName:'選手'+i,phone3:String(100+i),lineName:'LINE'+i},guest));
 const results=await Promise.all(requests);
 const numbers=results.map(x=>x.signupNo).sort((a,b)=>a-b);
 assert.deepEqual(numbers,Array.from({length:64},(_,i)=>i+1));
 assert.equal(get('eventStates/'+eid+'/nextNo'),64);
 const live=get('eventStates/'+eid);
 assert.equal(Object.keys(live.registrations).length,64);assert.equal(Object.keys(live.publicView.rows).length,64);
 assert.equal(live.publicView.rows.p00000033.signupNo,33);
 assert.equal('lineName' in live.publicView.rows.p00000001,false);
 const dupe=await call('regSubmit',{eid,rid:randomIds[0],playerName:'選手0',phone3:'100',lineName:'LINE0'},guest);
 assert.equal(dupe.signupNo,1);assert.equal(get('eventStates/'+eid+'/nextNo'),64);
 await assert.rejects(call('regSubmit',{eid,rid:'f'.repeat(48),playerName:'選手0',phone3:'100',lineName:'LINE0'},guest),/已經報名過/);
 await call('regReview',{eid,rid:randomIds[9],status:'rejected',expectedVersion:1});
 assert.equal(get('eventStates/'+eid+'/publicView/rows/p00000010/status'),'rejected');
 const count=(s,no)=>{let n=0;for(const r of Object.values(s.registrations)){if(r.signupNo<=no&&r.status!=='rejected')n++}return n};
 assert.equal(count(get('eventStates/'+eid),33),32); // original #33 promoted into primary
 await call('regReview',{eid,rid:randomIds[9],status:'approved',expectedVersion:2});
 assert.equal(count(get('eventStates/'+eid),33),33); // returns to waitlist #1
 await assert.rejects(call('regReview',{eid,rid:randomIds[9],status:'pending',expectedVersion:1}),/已在其他裝置修改/);
 await call('regEditEntry',{eid,rid:randomIds[0],playerName:'冠軍候選人',phone3:'100',lineName:'更新名稱',expectedVersion:1});
 assert.equal(get('eventStates/'+eid+'/publicView/rows/p00000001/playerName'),'冠軍候選人');
 assert.equal('lineName' in get('eventStates/'+eid+'/publicView/rows/p00000001'),false);
 await call('regDeleteEntry',{eid,rid:randomIds[1],expectedVersion:1});
 assert.equal(get('eventStates/'+eid+'/publicView/rows/p00000002'),undefined);
 await assert.rejects(call('regUpdateEvent',{eid,...info,capacity:20,expectedVersion:1}),/正選人數不得更動/);
 await call('regDeleteEvent',{eid});assert.equal(get('eventStates/'+eid),undefined);assert.equal(get('ownerEvents/owner-1/'+eid),undefined);
 console.log('PASS: owner security / 64 concurrent signups / unique ranks / idempotency / public data privacy / reject & restore / stale write / edit / delete / capacity lock');
})().catch(e=>{console.error(e);process.exitCode=1});
