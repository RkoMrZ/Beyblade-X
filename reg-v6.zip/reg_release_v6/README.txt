Beyblade X 線上報名系統 V6 正式雲端候選版
==========================================
目標 Firebase：ljtreg-39954 （與原本賽程表不同專案）
網站：rkomrz.github.io/Beyblade-X/reg/

!! 務必確認 !!
- 這個套件與 V5.1「純介面模擬版」不同：V6 才能寫入真實 Firebase。
- 不要把 V5.1 的 index.html/signup.html/status.html 與 V6 後端混用。
- 先在 Firebase Console 備份目前的 Rules 文字與需要保留的資料。
- 第一階段用測試比賽及假的選手資料驗收。不要立即分享給正式選手。
- 目前尚未在您的實際 Firebase 專案部署/驗證，請依順序操作。

A. 電腦部署（Windows PowerShell）
1. 將整個 ZIP 解壓縮，打開 reg_release_v6 資料夾；在該資料夾的 PowerShell 執行：
    npm install --prefix functions
    firebase login
    firebase use ljtreg-39954
    firebase deploy --only functions --project ljtreg-39954
2. 看到 Deploy complete! 再執行：
    firebase deploy --only database --project ljtreg-39954
3. 等兩步都成功，才把 reg/ 裡的 3 個 HTML 上傳到 GitHub 對應資料夾：
    Beyblade-X/reg/index.html
    Beyblade-X/reg/signup.html
    Beyblade-X/reg/status.html
   勿覆蓋 GitHub Repository 根目錄的賽程表 index.html/viewer.html。

B. 為了保護原資料：
- 不要在 Firebase Console 手動刪除節點；不要用測試庫直接覆蓋正式賽事。
- 新版 Events 資料存在 /eventStates/{eid}；主辦索引在 /ownerEvents/{uid}。
- /eventStates/{eid}/publicView 保存公開資訊：正備選順位、選手比賽名稱、手機後三碼與審核狀態。
- /eventStates/{eid}/registrations 保存私人 LINE 名稱，只有 Google 登入之活動主辦可以讀。
- Cloud Functions 透過 Admin SDK 寫入，網頁用戶端完全無直接寫入權限。
- 原本報名專案的歷史資料不會自動刪除或搬移；舊格式活動請另行遷移。
- 同一場的正選名額在第一人報名後不可修改。

C. 上線前驗收
1. Google 登入、建立「測試盃」設定正選 2 人，確認主辦的「我的比賽」出現。
2. 開啟獨立 signup.html (不要登入)，先用 3 個不同名稱報名。
3. status.html 只能顯示 4 欄：正備選編號、比賽名稱、手機後三碼、審核狀態；絕不可顯示 LINE 名稱。
4. 應顯示 正選#1、正選#2、備選#1，初始全部待審核。
5. 主辦把第 1 人改成不通過：第 3 人須遞補為正選#2；第 1 人顯示「—」且在最底。
6. 主辦把第 1 人改回通過：第 3 人須退回備選#1，原始報名順位不變。
7. 使用兩台裝置打開主辦頁，在一台更改審核後，另一台應即時顯示；使用舊畫面更新須得到衝突提醒。
8. 開啟飛航模式嘗試審核，不應有成功訊息或本機資料回寫。
9. 刪除測試活動後，公開連結不得再看見任何報名名單。
10. 在真實手機與 PC 進行小規模測試；正式多人壓測尚未執行，不能保證高負載零故障。

D. 費用/安全注意
- Cloud Functions 需要 Blaze；此方案可能依流量計費。建議設定 Google Cloud Billing 預算通知。
- 公開查詢頁會公開所有選手的「比賽名稱、手機後三碼、審核狀態」，報名前需告知選手。
- 公開報名接口為無登入模式，尚未整合 Firebase App Check 或 CAPTCHA；
  本版包含相同姓名+後三碼重複報名防護、不可預測提交 ID 及單活動 10 萬紀錄防護，
  但不足以阻擋刻意的大量灌報名。正式大規模推廣前建議增加反濫用機制。
- 高並發 64 人的程式模擬測試不等於正式 Firebase Emulator 或真實壓力測試。

故障排查
- auth/unauthorized-domain：Firebase Auth Authorized domains 內加入 rkomrz.github.io（只有網域）。
- functions/unauthenticated：主辦需以 Google 登入；私人操作不允許匿名。
- HTTP 404 / Firebase Functions：確定專案/區域為 asia-southeast1，檢查 Functions 部署輸出。
- permission_denied：確定發布同套件 database.rules.json，注意目標是 ljtreg-39954。
- 公開查詢沒有資料：重新建立 V6 測試賽事，避免混用較早版本的活動欄位。
