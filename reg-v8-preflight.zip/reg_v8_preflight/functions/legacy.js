'use strict';
// Beyblade X Registration V6: Cloud Functions-only mutations.
// All changes affecting private and public views are committed in ONE RTDB transaction.
const {onCall, HttpsError}=require('firebase-functions/v2/https');
const {initializeApp,getApps}=require('firebase-admin/app');
const {getDatabase}=require('firebase-admin/database');
const crypto=require('node:crypto');
// Runtime FIREBASE_CONFIG determines the database for the selected Firebase project.
if(!getApps().length)initializeApp();
const db=getDatabase(), REGION='asia-southeast1';
const CONFIG={region:REGION,memory:'256MiB',timeoutSeconds:90,maxInstances:12,
  cors:['https://rkomrz.github.io',/^https?:\/\/localhost(?::\d+)?$/]};
const call=fn=>onCall(CONFIG,fn);
const fail=(code,msg)=>{throw new HttpsError(code,msg)};
const str=v=>typeof v==='string'?v.trim():'';
const validId=v=>typeof v==='string'&&/^[0-9a-f]{24}$/.test(v);
const validRid=v=>typeof v==='string'&&/^[0-9a-f]{48}$/.test(v);
const validStatus=v=>['pending','approved','rejected'].includes(v);
const has=(obj,key)=>Object.prototype.hasOwnProperty.call(obj||{},key);
function requireGoogle(req){const auth=req.auth;if(!auth||auth.token?.firebase?.sign_in_provider!=='google.com')fail('unauthenticated','請用 Google 帳號登入主辦管理。');return auth.uid}
function requireEventId(eid){if(!validId(eid))fail('invalid-argument','比賽代碼無效');return eid}
const evRef=eid=>db.ref('eventStates/'+requireEventId(eid));
function checkMeta(v){
 const title=str(v?.title),eventDate=str(v?.eventDate),checkinTime=str(v?.checkinTime),startTime=str(v?.startTime),venue=str(v?.venue),fee=Number(v?.fee),capacity=Number(v?.capacity);
 if(!title||title.length>70||!/^\d{4}-\d{2}-\d{2}$/.test(eventDate)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(checkinTime)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)||checkinTime>startTime||!venue||venue.length>150||!Number.isSafeInteger(fee)||fee<0||fee>1000000||!Number.isSafeInteger(capacity)||capacity<1||capacity>10000)fail('invalid-argument','請完整填寫正確的比賽設定。');
 const date=new Date(eventDate+'T12:00:00+08:00');if(!Number.isFinite(date.getTime())||new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(date)!==eventDate)fail('invalid-argument','比賽日期無效。');
 return {title,eventDate,checkinTime,startTime,venue,fee,capacity};
}
function checkEntry(v){
 const playerName=str(v?.playerName),phone3=str(v?.phone3),lineName=str(v?.lineName);
 if(!playerName||playerName.length>50||!/^[0-9]{3}$/.test(phone3)||!lineName||lineName.length>40)fail('invalid-argument','比賽名稱、手機後三碼、LINE 名稱均為必填。');
 return {playerName,phone3,lineName};
}
function ensureOwner(state,uid){if(!state)fail('not-found','比賽已不存在');if(state.ownerUid!==uid)fail('permission-denied','你不是這場比賽的主辦');}
function viewMeta(e){return {eventTitle:e.public.title,capacity:e.public.capacity,open:e.public.open,updatedAt:e.public.updatedAt};}
function rowKey(no){return 'p'+String(no).padStart(8,'0')}
function newView(e){const view={...viewMeta(e),rows:{}};for(const r of Object.values(e.registrations||{})){view.rows[rowKey(r.signupNo)]={signupNo:r.signupNo,playerName:r.playerName,phone3:r.phone3,status:r.status};}return view}
function updateViewMeta(e){if(!e.publicView)e.publicView=newView(e);Object.assign(e.publicView,viewMeta(e));e.publicView.rows??={}}
function setRow(e,r){updateViewMeta(e);e.publicView.rows[rowKey(r.signupNo)]={signupNo:r.signupNo,playerName:r.playerName,phone3:r.phone3,status:r.status}}
function currentRank(e,signupNo){let n=0;for(const r of Object.values(e.registrations||{})){if(r.signupNo<=signupNo&&r.status!=='rejected')n++;}return n<=e.public.capacity?'正選#'+n:'備選#'+(n-e.public.capacity)}
function mutate(eid,uid,fn){
 let reason='',result=null;
 return evRef(eid).transaction(e=>{
   result=null;reason='';
   // RTDB may call this updater with a speculative null before server data arrives.
   // Returning undefined here aborts before Firebase can retry with the real state.
   // Return null (a no-op when the remote node is truly absent), then verify result.
   if(!e){reason='比賽不存在或已刪除';return null}
   if(e.ownerUid!==uid){reason='沒有此比賽的管理權限';return}
   const resultOrReason=fn(e);
   if(resultOrReason?.error){reason=resultOrReason.error;return}
   result=resultOrReason?.result??{ok:true};
   e.revision=(e.revision||0)+1;return e;
 },undefined,false).then(t=>{
   if(!t.committed)fail('failed-precondition',reason||'資料已被更新，請重新載入後操作。');
   if(result===null)fail('not-found',reason||'比賽不存在或已刪除');
   return result;
 });
}
exports.regCreateEvent=call(async req=>{
 const uid=requireGoogle(req),meta=checkMeta(req.data),eid=crypto.randomBytes(12).toString('hex'),now=Date.now();
 const event={ownerUid:uid,public:{...meta,open:true,createdAt:now,updatedAt:now,metaVersion:1},nextNo:0,revision:1,registrations:{},rankLedger:{}};
 event.publicView=newView(event);
 await db.ref().update({['eventStates/'+eid]:event,['ownerEvents/'+uid+'/'+eid]:now});return {eid};
});
exports.regUpdateEvent=call(async req=>{
 const uid=requireGoogle(req),v=checkMeta(req.data),expected=req.data?.expectedVersion;
 return mutate(req.data?.eid,uid,e=>{
   if(e.public.metaVersion!==expected)return {error:'活動設定已被另一台裝置修改，請重新開啟編輯頁。'};
   if(e.nextNo>0&&v.capacity!==e.public.capacity)return {error:'已有選手報名，正選人數不得更動。'};
   e.public={...e.public,...v,updatedAt:Date.now(),metaVersion:e.public.metaVersion+1};updateViewMeta(e);
 });
});
exports.regSetOpen=call(async req=>{
 const uid=requireGoogle(req);if(typeof req.data?.open!=='boolean')fail('invalid-argument','開關資料不正確');
 return mutate(req.data?.eid,uid,e=>{
   if(e.public.metaVersion!==req.data?.expectedVersion)return {error:'報名狀態已被更新，請重新載入。'};
   e.public.open=req.data.open;e.public.metaVersion++;e.public.updatedAt=Date.now();updateViewMeta(e);
 });
});
exports.regSubmit=call(async req=>{
 const eid=requireEventId(req.data?.eid),rid=req.data?.rid,entry=checkEntry(req.data);
 if(!validRid(rid))fail('invalid-argument','提交憑證格式錯誤');
 let reason='',result=null;
 const t=await evRef(eid).transaction(e=>{
   result=null;reason='';
   // Do not abort on speculative null: let RTDB retry with server state.
   if(!e){reason='比賽不存在';return null}
   // Client-generated request ID is an idempotency key. Retry MUST use exactly the same data.
   if(has(e.registrations,rid)){
     const r=e.registrations[rid];
     if(r.playerName!==entry.playerName||r.phone3!==entry.phone3||r.lineName!==entry.lineName){reason='相同報名憑證與資料不一致';return}
     result={rid,signupNo:r.signupNo,rankLabel:currentRank(e,r.signupNo)};return e;
   }
   if(!e.public?.open){reason='這場比賽目前未開放報名';return}
   if((e.nextNo||0)>=100000){reason='此場報名紀錄已達系統上限，請聯絡主辦';return}
   // Prevent identical accidental resubmits on another tab; does not verify real identity.
   if(Object.values(e.registrations||{}).some(r=>r.phone3===entry.phone3&&r.playerName===entry.playerName)){reason='相同比賽名稱與手機後三碼已經報名過，請查詢公開名單。';return}
   const no=(e.nextNo||0)+1,createdAt=Date.now();
   e.nextNo=no;e.revision=(e.revision||0)+1;e.registrations??={};e.rankLedger??={};
   const r={rid,...entry,status:'pending',signupNo:no,createdAt,recordVersion:1};
   e.registrations[rid]=r;e.rankLedger[String(no)]=1;setRow(e,r);
   result={rid,signupNo:no,rankLabel:currentRank(e,no)};return e;
 },undefined,false);
 if(!t.committed)fail('failed-precondition',reason||'報名失敗，請確認網路後重試');
 if(result===null)fail('not-found',reason||'比賽不存在');
 // Return after COMMITTED; the browser must not claim success before this response.
 return result;
});
exports.regReview=call(async req=>{
 const uid=requireGoogle(req),rid=req.data?.rid,status=req.data?.status,expected=req.data?.expectedVersion;
 if(!validRid(rid)||!validStatus(status))fail('invalid-argument','審核參數不正確');
 return mutate(req.data?.eid,uid,e=>{
   const r=e.registrations?.[rid];if(!r)return {error:'找不到這位選手，可能已被刪除'};
   if(r.recordVersion!==expected)return {error:'這位選手已在其他裝置修改，請重新確認最新狀態'};
   if(r.status===status)return {result:{ok:true}};
   r.status=status;r.recordVersion++;e.rankLedger??={};e.rankLedger[String(r.signupNo)]=status==='rejected'?0:1;setRow(e,r);
 });
});
exports.regEditEntry=call(async req=>{
 const uid=requireGoogle(req),rid=req.data?.rid,entry=checkEntry(req.data),expected=req.data?.expectedVersion;
 if(!validRid(rid))fail('invalid-argument','選手資料代碼不正確');
 return mutate(req.data?.eid,uid,e=>{
   const r=e.registrations?.[rid];if(!r)return {error:'找不到選手'};
   if(r.recordVersion!==expected)return {error:'選手資料已在其他裝置修改，請重新確認'};
   Object.assign(r,entry);r.recordVersion++;setRow(e,r);
 });
});
exports.regDeleteEntry=call(async req=>{
 const uid=requireGoogle(req),rid=req.data?.rid,expected=req.data?.expectedVersion;
 if(!validRid(rid))fail('invalid-argument','選手代碼不正確');
 return mutate(req.data?.eid,uid,e=>{
   const r=e.registrations?.[rid];if(!r)return {error:'選手已不存在'};
   if(r.recordVersion!==expected)return {error:'這位選手的資料已被更新，請重新確認'};
   delete e.registrations[rid];e.rankLedger??={};e.rankLedger[String(r.signupNo)]=0;
   updateViewMeta(e);delete e.publicView.rows[rowKey(r.signupNo)];
 });
});
exports.regDeleteEvent=call(async req=>{
 const uid=requireGoogle(req),eid=requireEventId(req.data?.eid),ref=evRef(eid);
 const owner=(await ref.child('ownerUid').get()).val();
 if(owner&&owner!==uid)fail('permission-denied','沒有刪除此比賽的權限');
 // Remove the event first, atomically removing all private and public data.
 if(owner)await ref.remove();
 await db.ref('ownerEvents/'+uid+'/'+eid).remove();return {ok:true};
});
