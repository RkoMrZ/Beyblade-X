from playwright.sync_api import sync_playwright
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[2]/'reg'
EID='a'*24
META={'title':'金魚盃','eventDate':'2026-11-01','checkinTime':'09:00','startTime':'10:00','venue':'淡水體育館','fee':0,'capacity':32,'open':True,'version':1,'createdAt':1234}
ROWS={f'p{i:08d}':{'signupNo':i,'playerName':f'選手{i:02d}','phone3':f'{100+i}','status':'pending','recordVersion':1} for i in range(1,36)}
PRIVATE={f'p{i:08d}':{'lineName':f'LINE玩家{i:02d}','createdAt':1000+i,'version':1} for i in range(1,36)}
MOCK={f'ownerEventsV8/owner':{EID:{'title':'金魚盃','eventDate':'2026-11-01','capacity':32,'createdAt':1234}},'ownerEvents/owner':{},f'eventsV8/{EID}/meta':META,f'publicRowsV8/{EID}':ROWS,f'privateRowsV8/{EID}':PRIVATE,f'syncV8/{EID}':{'token':'a','lastChange':''},f'changesV8/{EID}':{}}

def load(page,name):
 html=(ROOT/name).read_text()
 js=re.findall(r'<script[^>]*>(.*?)</script>',html,re.S)[-1]
 html=re.sub(r'<script[^>]*>.*?</script>','',html,flags=re.S)
 page.set_content(html,wait_until='domcontentloaded')
 page.evaluate("""(mock)=>{
 Object.defineProperty(window.crypto,'subtle',{value:{digest:async()=>new Uint8Array(32).buffer},configurable:true}); window.initializeApp=o=>o;window.getAuth=o=>o;window.GoogleAuthProvider=class{};
 window.onAuthStateChanged=(auth,cb)=>cb({uid:'owner',getIdToken:async()=> 'mock'});
 window.signInWithPopup=async()=>{};window.signOut=async()=>{};
 window.mockCloud=mock;window.hits=[]; window.fetch=async (uri,options={})=>{
  const url=new URL(uri,'https://rkomrz.github.io');
  const k=url.pathname.replace(/^\\//,'').replace(/\\.json$/,'');
  window.hits.push(k);let answer = url.hostname.includes('cloudfunctions.net') ? {result:{signupNo:36,confirmed:true}} : Object.prototype.hasOwnProperty.call(mock,k)?mock[k]:null; if(answer===null&&!url.hostname.includes('cloudfunctions.net')){const m=k.match(/^(publicRowsV8|privateRowsV8)\\/([a-f0-9]{24})\\/(p[0-9]{8})$/);if(m)answer=mock[m[1]+'/'+m[2]]?.[m[3]]??null;}
  return new Response(JSON.stringify(answer),{status:200,headers:{'Content-Type':'application/json'}});
 };
 }""",MOCK)
 js=re.sub(r'^import .*?;\s*$','',js,flags=re.M)
 if name!='index.html':js=js.replace("eid=new URLSearchParams(location.search).get('event')||''",f"eid='{EID}'")
 page.evaluate("(code)=>{(0,eval)(code)}",js)

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [320,390,820,1440]:
  p=browser.new_page(viewport={'width':width,'height':880});errs=[];p.on('pageerror',lambda e:errs.append(str(e)))
  load(p,'status.html');p.wait_for_timeout(500);print('DIAG',p.locator('#notice').inner_text(), p.locator('#count').inner_text(), errs);p.wait_for_function("document.querySelector('#count').textContent.includes('35')");assert p.get_by_text('備選#1').count()==1
  if width==390:
   p.evaluate('''(eid)=>{window.hits=[];window.mockCloud['publicRowsV8/'+eid].p00000010.status='rejected';window.mockCloud['syncV8/'+eid].token='new';window.mockCloud['changesV8/'+eid]['-chg0000000000000001']={type:'review',key:'p00000010'};}''',EID)
   p.locator('#refresh').click();p.wait_for_function("document.querySelector('#count').textContent.includes('34')")
   newHits=p.evaluate('window.hits');assert f'publicRowsV8/{EID}' not in newHits,('incremental GET unexpectedly fetched whole board',newHits)
   assert f'publicRowsV8/{EID}/p00000010' in newHits,newHits
  assert not p.evaluate('document.documentElement.scrollWidth>innerWidth+2'),f'status overflow {width}'
  p.screenshot(path=f'/mnt/data/v8_status_{width}.png')
  load(p,'signup.html');p.wait_for_selector('#entryCard:not(.hide)')
  p.locator('#playerName').fill('阿霆');p.locator('#phone3').fill('093');p.locator('#lineName').fill('LINE霆');p.locator('#submit').click();p.wait_for_timeout(1200);print('SIGNUP',p.locator('#notice').inner_text(),errs);p.wait_for_selector('#modal:not(.hide)',timeout=3000)
  assert ('正選' in p.locator('#rank').inner_text() or '備選' in p.locator('#rank').inner_text() or '報名成功' in p.locator('#rank').inner_text())
  p.screenshot(path=f'/mnt/data/v8_signup_{width}.png')
  assert not errs,(width,errs);p.close();print('PASS public and signup',width)
 for width in [390,1440]:
  p=browser.new_page(viewport={'width':width,'height':900});errs=[];p.on('pageerror',lambda e:errs.append(str(e)))
  load(p,'index.html');p.wait_for_selector('[data-manage]');p.screenshot(path=f'/mnt/data/v8_admin_{width}.png')
  p.locator('[data-manage]').click();p.wait_for_selector('[data-review]');p.locator('[data-review]').first.click();p.wait_for_selector('#modal:not(.hide)')
  p.screenshot(path=f'/mnt/data/v8_review_{width}.png')
  assert not p.evaluate('document.documentElement.scrollWidth>innerWidth+2'),f'admin overflow {width}'
  assert not errs,(width,errs);p.close();print('PASS admin',width)
 browser.close()
