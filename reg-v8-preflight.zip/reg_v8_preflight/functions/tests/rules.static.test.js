'use strict';
// STATIC structure audit ONLY. It does not replace the Firebase Rules Emulator.
const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const obj=JSON.parse(fs.readFileSync(path.join(__dirname,'../../database.rules.json'),'utf8'));
const r=obj.rules;
assert.equal(r['.read'],false);
assert.equal(r['.write'],false);
for(const [k,v] of Object.entries(r)){
 if(k===' .write')throw Error('unexpected');
 if(v&&typeof v==='object')assert.equal(v['.write'],undefined,'client writes must be denied by root for '+k);
}
assert.match(r.privateRowsV8.$eid['.read'],/ownerUid/);
assert.match(r.privateRowsV8.$eid['.read'],/google\.com/);
assert.match(r.ownerEventsV8.$uid['.read'],/auth\.uid === \$uid/);
assert.match(r.publicRowsV8.$eid['.read'],/meta/);
assert.equal(r.receiptsV8,undefined,'private receipts must not be readable by clients');
assert.equal(r.nameClaimsV8,undefined,'name claims must not be readable by clients');
console.log('PASS static Rules audit: root deny, protected privateRows, owner index isolation, no client writes');
