Beyblade X 線上報名 V8.1「精簡節點／部署前驗收候選版」
====================================================
日期：2026-10-14
狀態：工程候選版；尚未正式部署，禁止直接取代正在使用的 V6。
正式後端專案：ljtreg-39954；正式網站：rkomrz.github.io/Beyblade-X/reg/

一、這次整合完成的改善
----------------------
1. 網頁只用 HTTPS 讀取，不需手機維持 RTDB WebSocket／Long Polling 常駐連線；
   主辦登入使用 Firebase Auth，敏感寫入都經 Cloud Functions。
2. 首次進入才下載必要的單場公開／私人名單；之後每 45 秒（且只在前景）
   先讀微型 syncV8 節點，無變動不讀名單；有變動時僅補讀相關單筆。
3. 單場參賽「名稱」獨立唯一；手機後三碼與 LINE 名稱可重複。
   名稱以 NFKC、空白標準化、大小寫轉換後建立 SHA-256 原子占位。
4. 每筆選手的公開資料、私人資料、審核版本各自獨立；一次審核不交易整場名單。
5. 正選/備選依成功報名的原始順位計算；「待審核／通過」佔順位，
   「不通過」暫時排除，恢復後依原始順序重新計算；不需要批次改寫後續所有人。
6. 主辦舊版本修改只拒絕當次操作，保持網頁及未送出的表單，不自動重送。
7. 報名採提交憑證防重複；即使伺服器已寫入而回應遺失，重試沿用原憑證。
8. 主辦「建立比賽」也有 createId 防重複：若回應遺失重試，不重建第二場，
   更不會清空已經使用中的取號計數器。
9. 小型取號交易、活動設定鎖、單筆修改鎖與活動刪除閘門；
   多節點正式結果經 RTDB multi-location update 同時提交。
10. 避免把交易初始的 provisional null 誤認為現有活動已刪除。
11. 事件更新紀錄約每 128 次寫入進行一次「盡力」整理，
    不需要另外排程常駐服務；不是硬保證的 TTL 或絕對長度上限。
12. 正式報名小型計數器加入每場每分鐘 240 筆成功取號的軟限制，
    可應付正常的 64 人同時報名模擬；不是每 IP / 真人驗證，無法阻擋所有惡意攻擊。
13. Cloud Functions 2nd gen 限制每實例 16 並行、最多 8 實例、無最低常駐實例；
    突然超額可能等待或收到暫時性的錯誤，應顯示安全重試訊息。
14. 伺服器不再寫死 ljtreg-39954 RTDB 網址，從 Firebase runtime FIREBASE_CONFIG
    決定資料庫。前端三個 HTML 仍指向正式專案；測試網站不可直接上傳至其他專案。
15. 保留原 V6 APIs、資料節點及 legacy-v6.html；V8 用獨立 reg8* API 與 *V8 路徑。

二、資料節點按用途分流
--------------------
 eventsV8/{eid}/meta                 比賽日期／場地／金額等公開資訊
 allocV8/{eid}                       小型取號計數器、報名開關、使用中短租約／軟限制
 nameClaimsV8/{eid}/{nameHash}       同場參賽名稱占用
 publicRowsV8/{eid}/{p########}      單筆公開：參賽名稱、後三碼、審核、原始順位
 privateRowsV8/{eid}/{p########}     單筆主辦私有：LINE 名稱、提交憑證等
 receiptsV8/{eid}/{rid}              給伺服器查的重試收據（不公開）
 rowLocksV8/{eid}/{p########}        單筆編輯／審核鎖
 ownerEventsV8/{uid}/{eid}           主辦首頁活動摘要
 syncV8/{eid}                        極小的變更標記
 changesV8/{eid}/{key}               公開、不含 LINE 個資的變更路徑
 migrationLocksV8/{eid}              V6→V8 手動複製暫存鎖

沒有必要碰 Firebase 的：切換顏色、搜尋、切換篩選分頁、複製分享連結。

三、本包已經實際執行且通過
------------------------
- Node.js 22 語法：functions/index.js、legacy.js、兩個測試程式
- 本地模擬：64 個 Promise 同時報名、不重號、同名競爭、
  同手機／同 LINE／不同名字允許報名、正備選恢復、舊版本拒絕、主辦權限
- 建立活動 createId 重送不重建／不覆蓋已報名的計數器
- 資料庫 multi-location commit 前故障／commit 後丟失回應，原收據安全重試
- 初次 RTDB 交易只有 provisional null，重新抓取資料後安全重試
- 正在執行其他操作時刪除活動，先停止新操作，之後才能完整清除
- 700 次狀態更新所產生的變更紀錄，低頻整理策略模擬
- Rules JSON 格式及靜態讀寫權限設計檢查（靜態≠實際 Rules Emulator）
- Playwright 模擬主辦 390/1440px、選手與公開查詢 320/390/820/1440px

四、尚未完成，因此目前不可宣布正式大規模上線
----------------------------------------
! 真正 Firebase RTDB Emulator 併發交易與 Rules 模擬器：本地環境無法下載
  Firebase CLI／Emulator。已附 `functions/tests/emulator.integration.js`，
  可在你已有的 Google Cloud Shell（或 Windows Firebase CLI）執行。
! 真實 64/128 支手機或多網路壓力測試（連線數、延遲、帳單、函式冷啟動）。
! Apple Safari 與 Chrome 跨頁 Google OAuth、onCall CORS、正式權限端對端驗收。
! 免登入報名仍需要配置 Firebase App Check / Turnstile / 限流等抗機器人保護。
  本包只有「單場軟限額」，不足以保證不被惡意灌報名或攻擊成本。
! 長期變更紀錄整理是盡力執行，並非嚴格每場只保留 200 筆，
  若活動長期有大量操作，仍需按實測決定是否設每日定期清理。
! V6 舊版 API 的歷史交易設計保留不變，不能把本包當作已修好 V6 所有已知問題。
! V6→V8 同場遷移必須先關閉 V6 報名、備份並人工確認同名；
  這仍是高風險管理作業，上線前不要在正式活動執行。

五、安全順序（暫不部署正式）
------------------------
1. 在 Cloud Shell 用獨立的 RTDB Emulator `demo-ljtreg` 測試：
   cd ~/reg_v8_preflight && nvm use 22 && npm install --prefix functions && firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'
   注意：測試會新增、刪除「模擬器中的測試活動」，不連正式 RTDB；程式內有強制本機 host 保護。
2. 若模擬器測試和正式測試環境成功，再備份正式 Rules 及 V6 活動資料。
3. 可先部署保留 V6 的 V8 後端（新版 reg8* 名稱、獨立節點）並在測試活動驗收。
4. 部署更新 Rules，然後才更新 GitHub 的 reg/index.html、signup.html、status.html、legacy-v6.html。
5. 真實裝置測試成功，才對選手分享新版報名連結。
6. 若 Firebase 部署出現刪除原函式提示，先停止；不接受直接刪除舊版函式。

六、保留使用者手機的特殊作業需求
------------------------------
- 你每次從 ChatGPT 切回 Google Cloud App，Cloud Shell 都可能重新連線、回到 `~`。
- 以後給你的指令都會包含 `cd ~/資料夾`，獨立執行、一行貼上，適時 `nvm use 22`。
- 此時不需要修改目前正式 V6 的任何檔案，也不需要重新部署 Rules 或 Functions。
