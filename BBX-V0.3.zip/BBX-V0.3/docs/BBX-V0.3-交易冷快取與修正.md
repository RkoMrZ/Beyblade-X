# BBX-V0.3｜RTDB 冷快取交易與清理問題

- 發生現象：V0.1、V0.2 於首次建立雲端賽事之後呼叫 ActivateAuthority，客戶端收到 `functions/aborted`，其中 V0.2 返回「啟用期間賽事已被修改或刪除」。
- 核心可能原因：Firebase Realtime Database 的交易回呼第一次可能先收到 `null`，即使遠端已有資料；V0.2 直接以 `if (!cur) return undefined` 放棄，導致未向遠端確認賽事是否仍存在便誤報已被刪除。
- 修正：交易前對**同一個 SDK reference** 呼叫 `once('value')` 取得並快取實際資料，之後由 transaction 原子地重新檢查所有版本與權限條件。沒有用 `set()` 強行覆寫資料、沒有略過版本檢查。
- 同類問題修正範圍：建權威資料時的 staging、權威啟用、比分、主辦編輯以及 publish lock 釋放；全部使用待資料載入的 transaction。lock 取得仍使用自身競爭安全的 null=>claim 交易。
- 建賽出錯不再只刪 `events/` 私人資料而留公開或 authority 孤兒節點；由同一 Firebase 專案內、已驗證主辦與 releaseTag 的雲端函數按該 eventId 清理對應專屬資料。`cleanupOnly:true` 不得刪除已啟用賽事。
- 新增冷快取 Mock 測試，並覆蓋前端建立時缺少可選裁判欄位、`finalRR=null`，新建、編輯、比分與清理。

**證據限制：** 僅依當時手機截圖與本機程式推定。尚未讀取 Cloud Functions 服務端日誌，因此不能保證這是唯一的線上根因。Cloud Shell 的 Firebase Rules Emulator 測試及真實手機後端驗證仍必須完成。
