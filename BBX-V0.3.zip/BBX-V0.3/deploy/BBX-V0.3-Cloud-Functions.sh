#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == BBX-V0.3 ]] || { echo 'STOP: incorrect project folder'; exit 2; }
python3 - <<'PY'
import json,sys
m=json.load(open('MANIFEST.json'))
assert m['project_id']=='BBX-V0.3' and m['firebase_project']=='ljt-beyblade-x'
assert m['release_status']=='TEST_DEPLOY_READY','尚未核准供測試部署'
PY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == '22' ]] || { echo 'STOP: Node.js 22 required'; exit 3; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v03-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: run the complete preflight and emulator tests first'; exit 3; }
for c in firebase gcloud curl python3; do command -v "$c" >/dev/null || { echo "STOP: missing $c"; exit 3; }; done
# Cloud Shell frequently opens a fresh terminal without an active gcloud user.
# Re-select ONLY an existing unique login; never launch a phone browser mid-deploy.
if ! gcloud auth print-access-token >/dev/null 2>&1; then
  mapfile -t ACCOUNTS < <(gcloud auth list --format='value(account)' | sed '/^$/d')
  if [[ ${#ACCOUNTS[@]} -ne 1 ]]; then echo 'STOP: authenticate gcloud account first'; exit 3; fi
  gcloud config set account "${ACCOUNTS[0]}" --quiet
fi
gcloud auth print-access-token >/dev/null || { echo 'STOP: gcloud authentication expired'; exit 3; }
gcloud config set project ljt-beyblade-x --quiet >/dev/null
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: gcloud selected wrong project'; exit 3; }
[[ "$(python3 -c 'import json; print(json.load(open(".firebaserc"))["projects"]["default"])')" == ljt-beyblade-x ]] || { echo 'STOP: Firebase project mismatch'; exit 3; }
PROJECT=ljt-beyblade-x
INSTANCE=ljt-beyblade-x-default-rtdb
RULES_URL="https://${INSTANCE}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
echo '=== Fetching existing BBX Realtime Database Rules for safe merge ==='
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS --retry 3 --connect-timeout 10 --max-time 45 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v03-live-rules.json
python3 deploy/BBX-V0.3-安全合併Rules.py /tmp/bbx-v03-live-rules.json /tmp/bbx-v03-merged-rules.json
# Keep the verified package source immutable, including its Rules patch.
# Firebase CLI requires a relative path, so use a temporary runtime Rules file.
RUNTIME_RULES='deploy/.BBX-V0.3-runtime-rules.json'
ORIGINAL_FIREBASE_JSON="$(mktemp)"
cp firebase.json "$ORIGINAL_FIREBASE_JSON"
trap 'cp "$ORIGINAL_FIREBASE_JSON" "$ROOT/firebase.json"; rm -f -- "$ORIGINAL_FIREBASE_JSON" "$ROOT/$RUNTIME_RULES"' EXIT
cp /tmp/bbx-v03-merged-rules.json "$RUNTIME_RULES"
firebase target:apply database bbxv03-main "$INSTANCE" --project "$PROJECT"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('firebase.json');j=json.loads(p.read_text());j['database']={'target':'bbxv03-main','rules':'deploy/.BBX-V0.3-runtime-rules.json'};p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
PY
echo '=== Deploying BBX ONLY, no other project/cloud functions ==='
npm --prefix functions install --no-audit --no-fund
FN='functions:bbxV03StageAuthority,functions:bbxV03CommandAuthority,functions:bbxV03GetOperation,functions:bbxV03RepairPublication,functions:bbxV03PublishAuthority,functions:bbxV03OrganizerAuthority,functions:bbxV03ActivateAuthority,functions:bbxV03DeleteAuthority'
firebase deploy --only "$FN" --project "$PROJECT" --non-interactive --force
firebase deploy --only database:bbxv03-main --project "$PROJECT" --non-interactive
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS --retry 3 --connect-timeout 10 --max-time 45 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v03-rules-post.json
python3 - <<'PY'
import json
from pathlib import Path
def load(p):
 d=json.loads(Path(p).read_text());return json.loads(d) if isinstance(d,str) else d
want=load('/tmp/bbx-v03-merged-rules.json')
have=load('/tmp/bbx-v03-rules-post.json')
assert have==want,'STOP: online Rules did not match verified merged BBX rules'
print('PASS: Firebase Rules online matches merged rules, unrelated existing rules preserved')
PY
# Do not use firebase deploy --only functions: it could affect unrelated apps.
gcloud functions list --v2 --regions=asia-southeast1 --project "$PROJECT" --format=json > /tmp/bbx-v03-deployed-functions.json
python3 - <<'PYVERIFY'
import json
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
items=json.loads(Path('/tmp/bbx-v03-deployed-functions.json').read_text())
names={str(f['name']).split('/')[-1] for f in items}
missing=set(m['functions_exports'])-names
assert not missing, 'STOP: expected BBX functions missing from cloud deployment: '+str(sorted(missing))
print('PASS: all',len(m['functions_exports']),'BBX V0.3 Cloud Functions are deployed in expected region')
PYVERIFY
bash deploy/BBX-V0.3-清理舊測試版.sh
printf '\nPASS: BBX-V0.3 Functions and Rules deployed for TESTING.\n'
printf 'Next: deploy the index.html and viewer.html from this SAME BBX package to your GitHub Pages root.\n'
