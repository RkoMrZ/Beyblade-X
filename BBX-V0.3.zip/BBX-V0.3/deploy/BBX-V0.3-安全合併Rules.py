#!/usr/bin/env python3
"""Patch only BBX authority-specific rules into verified live rules; preserve all unrelated rules."""
import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=json.loads((root/'baseline/rules.v1.json').read_text())
patch=json.loads((root/'database.rules.json').read_text())
if len(sys.argv)!=3:sys.exit('Usage: 安全合併Rules.py live-rules.json output-rules.json')
raw=json.loads(Path(sys.argv[1]).read_text())
live=json.loads(raw) if isinstance(raw,str) else raw
assert isinstance(live,dict) and isinstance(live.get('rules'),dict),'線上 Rules 不合法'
assert live['rules'].get('.read') is False and live['rules'].get('.write') is False,'不允許覆蓋未關閉的根節點'
assert base['rules'].get('.read') is False and base['rules'].get('.write') is False
assert patch['rules'].get('.read') is False and patch['rules'].get('.write') is False
notfound=object()
changed=[]
def merge(b,p,d,path='rules'):
    if isinstance(b,dict) and isinstance(p,dict):
        assert isinstance(d,dict),f'禁止替換物件節點 {path}'
        for k,v in p.items():
            npath=f'{path}/{k}'
            if k not in b:
                # Only the BBX version lock/authority branches may be appended.
                if npath not in ('rules/authorityBBX','rules/events/$eventId/authorityBBX'):
                    raise ValueError(f'不允許新增非 BBX 權威分支 {npath}')
                if k in d and d[k]!=v:raise ValueError(f'線上分支已存在不同內容: {npath}')
                d[k]=v;changed.append(npath)
            else:
                if k not in d:raise ValueError(f'線上 Rules 缺少基礎節點 {npath}；禁止猜測補回')
                d[k]=merge(b[k],v,d[k],npath)
        return d
    if b==p:return d
    if d!=b and d!=p:raise ValueError(f'線上 Rules 已經過額外修改，停止以免覆寫 {path}')
    changed.append(path)
    return p
live['rules']=merge(base['rules'],patch['rules'],live['rules'],'rules')
out=live
assert all(x.startswith(('rules/events/','rules/publicEvents/','rules/authorityBBX')) for x in changed)
assert out['rules']['.read'] is False and out['rules']['.write'] is False
Path(sys.argv[2]).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS: 原有無關分支全部保留；只合併 BBX 權威分支',len(changed),'項變更')
