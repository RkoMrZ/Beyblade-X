'use strict';
// BBX V0.3 server-authoritative match and organizer commands.
const admin=require('firebase-admin');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onValueWritten}=require('firebase-functions/v2/database');
const C=require('./bbx-v03-core');
const O=require('./bbx-v03-organizer');
const PROJECT='ljt-beyblade-x';
const DB_URL='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app';
const VERSION='bbx-v0.3-authority-1';
admin.initializeApp({projectId:PROJECT,databaseURL:DB_URL});
const db=admin.database();
const OPT={region:'asia-southeast1',timeoutSeconds:60,maxInstances:4};
const ID=/^[A-Za-z0-9_-]{6,100}$/;
const id=x=>{if(!ID.test(x||''))throw new HttpsError('invalid-argument','賽事代碼格式錯誤');return x};
function auth(req,google=false){
 if(req.data?.clientVersion!==VERSION)throw new HttpsError('failed-precondition','舊版網頁無法修改此賽事，請更新網頁');
 if(!req.auth?.uid)throw new HttpsError('unauthenticated','請先登入');
 if(google&&req.auth.token?.firebase?.sign_in_provider!=='google.com')throw new HttpsError('permission-denied','主辦需 Google 身分');
 return req.auth.uid;
}
function catchError(e){
 if(e instanceof HttpsError)throw e;
 if(e instanceof C.CommandError)throw new HttpsError(e.code,e.message);
 console.error('V1 authority error',e);
 throw new HttpsError('internal','伺服器尚未確認結果；請使用相同操作代碼查詢，不要重複點擊');
}
const base=eventId=>`authorityBBX/${eventId}`;
// RTDB transaction callbacks can receive null on a cold SDK cache even when the
// server node exists. Warm the same SDK reference with an actual value listener
// BEFORE a read-modify-write transaction. Never insert an assumed client snapshot.
async function compareAndSwap(ref,change){
 await ref.once('value');
 return ref.transaction(change,undefined,false);
}

function projectGuard(){
 const project=process.env.GCLOUD_PROJECT||process.env.GCP_PROJECT||JSON.parse(process.env.FIREBASE_CONFIG||'{}').projectId;
 if(project!==PROJECT)throw new HttpsError('failed-precondition','Firebase 專案不符');
}
async function authz(uid,eventId){
 const [e,claims,ref,adminFlag]=await Promise.all([
   db.ref(`events/${eventId}/ownerUid`).get(),
   db.ref(`refereeClaims/${eventId}`).get(),
   db.ref(`refereeUsers/${eventId}/${uid}`).get(),
   db.ref(`admins/${eventId}/${uid}`).get()
 ]);
 const owner=e.val()===uid;
 let refereeName=null;
 if(ref.exists())for(const x of Object.values(claims.val()||{}))if(x?.uid===uid){refereeName=String(x.name||'');break;}
 return {owner,admin:adminFlag.exists(),referee:ref.exists()&&!!refereeName,refereeName};
}
async function publish(eventId){
 const ref=db.ref(base(eventId));const ownerToken=require('node:crypto').randomBytes(16).toString('hex');
 let claimed=false;
 const lock=ref.child('publishing');const now=Date.now();
 const taken=await lock.transaction(x=>!x||x.expiresAt<now?{token:ownerToken,expiresAt:now+45000}:undefined,undefined,false);
 if(!taken.committed)return {busy:true};claimed=true;
 try{
  const liveGate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(liveGate!=='active'||(await ref.child('board/deleted').get()).val()===true)return {ok:false,disabled:true};
  let cursor=Number((await ref.child('publishedSeq').get()).val()||0);
  for(let batch=0;batch<24;batch++){
   const item=(await ref.child(`board/outbox/${String(cursor+1).padStart(12,'0')}`).get()).val();
   if(!item)break;
   const stillLive=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
   if(stillLive!=='active'||(await ref.child('board/deleted').get()).val()===true)return {ok:false,disabled:true};
   const changes={};let structure=false;
   for(const ch of item.changes||[]){
     changes[`events/${eventId}/${ch.path}`]=ch.value;
     if(ch.publicChanged!==false)changes[`publicEvents/${eventId}/${ch.publicPath||ch.path}`]=ch.publicValue;
     if(ch.structure===true||ch.path==='finalRR/players')structure=true;
   }
   if(structure){
     const t=Date.now();changes[`events/${eventId}/syncVersion`]=t;changes[`publicEvents/${eventId}/meta/syncVersion`]=t;
   }
   changes[`events/${eventId}/authoritySeq`]=cursor+1;
   if(Object.keys(changes).length)await db.ref().update(changes);
   // Idempotent updates above can safely be retried if this bookkeeping write fails.
   await ref.update({publishedSeq:cursor+1,[`board/outbox/${String(cursor+1).padStart(12,'0')}`]:null});
   cursor++;
  }
  return {ok:true,publishedSeq:cursor};
 }finally{
   if(claimed)await compareAndSwap(lock,x=>x?.token===ownerToken?null:undefined);
 }
}
// Explicit owner-initiated staging; does not touch the website or existing Rules.
exports.bbxV03StageAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const ev=(await db.ref(`events/${eventId}`).get()).val();
  if(!ev||ev.ownerUid!==uid||ev.releaseTag!=='BBX-V0.3')throw new HttpsError('permission-denied','只允許本測試版新賽事建立權威資料');
  const b=C.bootstrap(ev);
  const t=await compareAndSwap(db.ref(`${base(eventId)}/board`),cur=>cur===null?b:undefined);
  return {ok:true,staged:true,created:t.committed,active:ev.authorityBBX==='active'};
 }catch(e){catchError(e)}
});
// This endpoint deliberately refuses to activate until operator has verified Rule deployment
// and tested all V1 organizer flows. Safe default: stage only, not automatic migration.
exports.bbxV03CommandAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active')throw new HttpsError('failed-precondition','尚未切換為雲端權威版本');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin&&!permission.referee)throw new HttpsError('permission-denied','未取得主辦或裁判授權');
  let error=null,replay=null;
  const t=await compareAndSwap(db.ref(`${base(eventId)}/board`),cur=>{
   error=null;replay=null;
   try{
     if(cur?.deleted)throw new C.CommandError('failed-precondition','賽事已刪除');
     const result=C.apply(cur,uid,req.data,Date.now(),permission);
     if(result.replay){replay=result.receipt;return undefined;}
     return result.board;
   }catch(e){error=e;return undefined;}
  });
  if(!t.committed){if(error)throw error;if(replay)return {...replay,replayed:true};throw new HttpsError('aborted','變更尚未確認，請按原操作代碼查詢');}
  const b=t.snapshot.val(),result=b.receipts?.[req.data.opId]?.result;
  if(!result)throw new HttpsError('aborted','操作尚未確認，請用操作代碼查詢');
  const published=await publish(eventId);
  return {...result,published:published.publishedSeq>=result.seq};
 }catch(e){catchError(e)}
});
exports.bbxV03GetOperation=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId),opId=req.data?.opId;
  if(typeof opId!=='string'||!/^[a-f0-9]{48}$/.test(opId))throw new HttpsError('invalid-argument','操作代碼無效');
  const r=(await db.ref(`${base(eventId)}/board/receipts/${opId}`).get()).val();
  if(!r)return {found:false};
  if(r.uid!==uid)throw new HttpsError('permission-denied','不能讀取別人的操作結果');
  return {found:true,...r.result};
 }catch(e){catchError(e)}
});
exports.bbxV03RepairPublication=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const owner=(await db.ref(`events/${eventId}/ownerUid`).get()).val();
  if(owner!==uid)throw new HttpsError('permission-denied','只有主辦能要求修復');
  return publish(eventId);
 }catch(e){catchError(e)}
});
exports.bbxV03PublishAuthority=onValueWritten({ref:'authorityBBX/{eventId}/board/seq',region:'asia-southeast1',instance:'ljt-beyblade-x-default-rtdb',retry:true},async e=>{
 projectGuard();if(!e.data.after.exists())return;
 const n=id(e.params.eventId),target=Number(e.data.after.val());
 const r=await publish(n);
 if(r.busy)return;
 if(r.publishedSeq<target)throw Error('Incremental publication pending');
});

// Organizer mutations use the same atomic event authority as match commands.
// Never accepts a client-provided roster, rounds, or complete event snapshot.
exports.bbxV03OrganizerAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active')throw new HttpsError('failed-precondition','尚未啟用雲端權威');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin)throw new HttpsError('permission-denied','需要主辦權限');
  if(req.data?.action==='setReferees') {
   const claims=(await db.ref(`refereeClaims/${eventId}`).get()).val()||{};
   if(Object.values(claims).some(Boolean))throw new HttpsError('failed-precondition','仍有已領取的裁判身分，請先釋放全部裁判再修改名單');
  }
  let error=null,replay=null,unchanged=null;
  const t=await compareAndSwap(db.ref(`${base(eventId)}/board`),cur=>{
   error=null;replay=null;unchanged=null;
   try{
    if(cur?.deleted)throw new C.CommandError('failed-precondition','賽事已刪除');
    const out=O.apply(cur,uid,req.data,Date.now(),permission);
    if(out.replay){replay=out.receipt;return undefined;}
    if(out.unchanged){unchanged=out;return undefined;}
    return out.board;
   }catch(e){error=e;return undefined;}
  });
  if(!t.committed){if(error)throw error;if(replay)return {...replay,replayed:true};if(unchanged)return {...unchanged,ok:true};throw new HttpsError('aborted','雲端沒有確認更新');}
  const result=t.snapshot.val().receipts?.[req.data.opId]?.result;
  if(!result)throw new HttpsError('aborted','操作尚未確認');
  const published=await publish(eventId);
  return {...result,published:published.publishedSeq>=result.seq};
 }catch(e){catchError(e)}
});


// Only tournaments created from this BBX test build are eligible for activation.
// Activation compares the complete source bracket inside an RTDB transaction;
// any stale pre-activation phone update aborts instead of being overwritten.
// Firebase RTDB may omit null-valued properties and return fields in a different
// insertion order after a transaction. Compare a deterministic semantic tree,
// NEVER stringify raw snapshot objects (which can falsely abort activation).
function normalizeBoard(x){
 if(Array.isArray(x))return x.map(normalizeBoard);
 if(x&&typeof x==='object'){
  const o={};
  for(const k of Object.keys(x).sort()){
   if(k==='matchVersion'||k==='reviewPublished'||k==='claimUid')continue;
   const v=x[k];
   if(v===null||v===undefined)continue; // RTDB removes null object children
   o[k]=normalizeBoard(v);
  }
  return o;
 }
 return x;
}
function activationComparable(e){
 return normalizeBoard({roster:e.roster||[],rounds:e.rounds||[],finalRR:e.finalRR||null,
   mode:e.mode,freeFinal:e.freeFinal,pairing:e.pairing||'ordered',
   publicOpen:e.publicOpen!==false,publicUntil:e.publicUntil,
   refereeNames:e.refereeNames||['裁判 1'],refereeCount:Number(e.refereeCount)||1});
}
exports.bbxV03ActivateAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  let ev=(await db.ref(`events/${eventId}`).get()).val();
  if(!ev||ev.ownerUid!==uid)throw new HttpsError('permission-denied','只有建立者能啟用雲端權威');
  if(ev.releaseTag!=='BBX-V0.3')throw new HttpsError('failed-precondition','只能啟用本測試版建立的新賽事，舊正式賽事不自動轉換');
  if(ev.authorityBBX==='active')return {ok:true,active:true,existing:true};
  const root=db.ref(base(eventId));const initial=C.bootstrap(ev);
  const stage=await compareAndSwap(root.child('board'),cur=>cur===null?initial:undefined);
  const staged=stage.snapshot.val();
  if(!staged||staged.deleted)throw new HttpsError('failed-precondition','賽事權威資料不可用');
  const ref=db.ref(`events/${eventId}`);let mismatch=false;let mismatchFields=[];let missingAtCommit=false;
  const t=await compareAndSwap(ref,cur=>{
   mismatch=false;mismatchFields=[];missingAtCommit=false;
   if(!cur){missingAtCommit=true;return undefined;}
   if(cur.ownerUid!==uid||cur.releaseTag!=='BBX-V0.3'){mismatch=true;return undefined;}
   if(cur.authorityBBX==='active')return undefined;
   const live=activationComparable(cur),saved=activationComparable(staged);
   if(JSON.stringify(live)!==JSON.stringify(saved)){
    mismatch=true;
    mismatchFields=Object.keys(saved).filter(k=>JSON.stringify(live[k])!==JSON.stringify(saved[k]));
    return undefined;
   }
   cur.authorityBBX='active';cur.authoritySeq=0;return cur;
  });
  if(t.committed)return {ok:true,active:true,created:true};
  if(!mismatch&&(await ref.child('authorityBBX').get()).val()==='active')return {ok:true,active:true,existing:true};
  if(mismatchFields.length)console.warn('BBX authority activation mismatch (field names only):',eventId,mismatchFields);
  if(missingAtCommit)throw new HttpsError('not-found','建立中的賽事已不存在，請重新建立新測試賽事');
  throw new HttpsError('aborted',mismatchFields.length?'賽程內容在啟用前已變更：'+mismatchFields.join('、')+'。請刷新資料再建立新測試賽事':'啟用期間賽事已被修改或刪除，請重新確認');
 }catch(e){catchError(e)}
});

// Delete is scoped to a single verified, active BBX test tournament.
// In-flight operations see the tombstone and will not recreate removed data.
exports.bbxV03DeleteAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const ev=(await db.ref(`events/${eventId}`).get()).val();
  if(!ev||ev.ownerUid!==uid||ev.releaseTag!=='BBX-V0.3')
   throw new HttpsError('permission-denied','只允許建立者刪除本測試版的賽事');
  if(req.data?.cleanupOnly === true && ev.authorityBBX === 'active')
   return {ok:false,active:true,deleted:false};
  if(req.data?.cleanupOnly !== true && ev.authorityBBX !== 'active')
   throw new HttpsError('failed-precondition','尚未啟用的測試賽事只允許執行失敗後清理');
  const boardRef=db.ref(`${base(eventId)}/board`);
  await boardRef.child('deleted').set(true);
  const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
  const updates={};
  for(const path of ['events','publicEvents','refereeClaims','refereeUsers','refereeSecrets','secrets','admins','authorityBBX'])
   updates[`${path}/${eventId}`]=null;
  for(const [slot,value] of Object.entries(slots))if(value===eventId)updates[`userEvents/${uid}/${slot}`]=null;
  await db.ref().update(updates);
  return {ok:true,deleted:true};
 }catch(e){catchError(e)}
});
