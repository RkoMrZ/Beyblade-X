# BBX-V0.3｜正式版 V1.0 介面延伸雲端權威測試版

**Firebase 專案：`ljt-beyblade-x`。這不是獨立線上報名系統 `ljtreg-39954`。**

本版使用使用者最後核准的正式 V1.0 `index.html`、`viewer.html`、`rules` 為母版，HTML 元素、ID、CSS 保留。`BBX-V0.2` 曾在現場建立新測試賽事時出現 `functions/aborted`；本版修正 `Firebase Admin SDK` 冷快取的交易初始值可能為 `null` 的情況，不以空的本機暫存直接判定賽事不存在。

## 修正

- 在已存在的賽事與場次資料上開始 RTDB transaction 前，使用同一 SDK ref 的 `once('value')` 等待完整快照；每一次交易仍在伺服器檢查場次版本與賽事狀態，不允許舊版直接寫回。
- 建立新賽事啟用失敗時，由已驗證的主辦 Callable 清除該筆未啟用測試賽事的私人／公開／索引／權威節點，避免只刪私人賽事留下孤兒資料；已啟用的賽事禁止透過自動失敗清理刪除。
- GitHub ZIP 只用於 Cloud Shell 下載，不會自動更新網站首頁；更新網站需另上傳本版 `index.html` 與 `viewer.html`。
- Cloud Shell 部署支援重新選擇唯一已登入帳號，並用暫存合併 Rules，不改寫已校驗的專案原檔。
- 函數限定版本前綴 `bbxV03`，新 8 支 Functions 部署與驗證成功後，僅清理 `bbxV02` 名單中的前 8 支；**不清理 Firebase 賽事資料、不刪報名系統 Functions，也不刪原正式 V1.0 檔案**。

## 手機 Cloud Shell 兩段指令

先把 `BBX-V0.3.zip` 放入 GitHub `rkomrz/Beyblade-X` 的 `main` 根目錄。

一鍵下載、驗證、執行單元與 Firebase Emulator Rules 測試：

```bash
cd ~ && curl -fLsS --retry 3 -H 'Cache-Control: no-cache' -o BBX-V0.3.zip "https://raw.githubusercontent.com/rkomrz/Beyblade-X/main/BBX-V0.3.zip?v=$(date +%s)" && unzip -tq BBX-V0.3.zip && unzip -oq BBX-V0.3.zip && cd ~/BBX-V0.3 && bash deploy/BBX-V0.3-檢查.sh
```

完成前項檢查後，部署新版 BBX Functions + 必要的 Database Rules，並清理舊 Functions：

```bash
cd ~/BBX-V0.3 && bash deploy/BBX-V0.3-Cloud-Functions.sh
```

**重要：** 交付時會另外提供 ZIP 的 SHA-256；請使用 ChatGPT 給的包含完整 hash 驗證的 Cloud Shell 指令。

## 驗證範圍與限制

本地通過 Node.js 核心/整合模擬測試、原版 UI 結構/語法比對及腳本靜態檢查；Cloud Shell 預檢必須再跑 Firebase Rules Emulator（本地環境無法下載其套件），才能執行部署。

本地沒有登入使用者的 Firebase 專案，也沒有用真實手機與 Firebase 後端執行完整端到端測試。**V0.3 是經過本地測試的上線候選，並不能宣稱 `functions/aborted` 已在真實環境中排除。**

測試上線後先用新建賽事測試，避免改動正式既有賽事。若再見 `aborted`，以新版本回傳的訊息及 Cloud Functions log 追查，不要刪除整個 Firebase 專案。
