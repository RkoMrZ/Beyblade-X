'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v030.js'),'utf8');
const code=src.slice(src.indexOf('function listenCloudEvent(id){'),src.indexOf('async function waitForAuthRestore('));
function setup(){
 const handlers=new Map(), renders=[];
 const ev={id:'TEST20',rounds:[{matches:[{a:'A',b:'B',sa:'',sb:'',matchVersion:0}]}],refereeClaims:{},authoritySeq:1};
 const callbacks=new Map();
 const ctx={console,Date,Number,JSON,setTimeout,clearTimeout,setInterval,clearInterval,
  cloudReady:true,ev,isAdmin:true,isReferee:false,cloudUnsub:null,cloudListenerEpoch:0,
  document:{visibilityState:'visible'},
  fbDb:{ref(p){const entry=handlers.get(p)||{};handlers.set(p,entry);return {on(event,cb){entry[event]=cb;},off(event,cb){if(entry[event]===cb)delete entry[event];}}}},
  isV1Authority:()=>false,v05ScorePending:()=>false,normalizeRefereeClaimsData:x=>Array.isArray(x)?Object.fromEntries(x.map((v,i)=>[i,v])):(x||{}),
  rtdbRestGet:async()=>1, renderAdmin:args=>renders.push(args),
  renderReferee:()=>renders.push({referee:true}), cloudEventsCache:{},
  currentAdminTab:'bracket',cloudResyncBlocked:false,liveRetryAttempts:new Map(),liveTransportRecoveryAt:new Map(),
  $:name=>({classList:{contains:()=>false}}),
  listenPublicProjectionEvent:()=>{},backgroundRefreshCurrentEvent:async()=>{},
  refereeClaimsStreamRevision:0,refereeClaimsConfirmed:()=>false,confirmRefereeClaims:()=>false,
  };
 vm.createContext(ctx);vm.runInContext(code,ctx);
 return {ctx,handlers,renders};
}
test('live match child event updates score and redraws bracket while page remains open',async()=>{
 const s=setup();s.ctx.listenCloudEvent('TEST20');
 const listener=s.handlers.get('events/TEST20/rounds/0/matches');
 assert.equal(typeof listener.child_changed,'function');
 listener.child_changed({key:'0',val:()=>({a:'A',b:'B',sa:0,sb:6,winner:'B',matchVersion:2})});
 await new Promise(r=>setTimeout(r,240));
 assert.equal(s.ctx.ev.rounds[0].matches[0].sb,6);
 assert.equal(s.ctx.ev.rounds[0].matches[0].winner,'B');
 assert.ok(s.renders.length>0,'redraw is scheduled from child_changed, without navigation');
 s.ctx.cloudUnsub();
});
test('live claims array snapshot refreshes referee tab immediately',async()=>{
 const s=setup();s.ctx.currentAdminTab='referee';s.ctx.listenCloudEvent('TEST20');
 const onClaim=s.handlers.get('refereeClaims/TEST20').value;
 onClaim({exists:()=>true,val:()=>[{uid:'JUDGE',name:'裁判 1'}]});
 assert.equal(s.ctx.ev.refereeClaims[0].uid,'JUDGE');
 assert.ok(s.renders.some(r=>r.referee),'repaint referee page without leaving it');
 s.ctx.cloudUnsub();
});
test('unsubscribe cancels child listeners before stale match can repaint the screen',async()=>{
 const s=setup();s.ctx.listenCloudEvent('TEST20');const listener=s.handlers.get('events/TEST20/rounds/0/matches');
 const old=listener.child_changed;s.ctx.cloudUnsub();
 old({key:'0',val:()=>({sb:7,matchVersion:5})});
 await new Promise(r=>setTimeout(r,210));
 assert.equal(s.ctx.ev.rounds[0].matches[0].sb,'');
});
