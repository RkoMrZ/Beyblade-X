# BBX-V0.35 — 主辦／裁判 SSE 安全備援（測試版）

本版以使用者上傳的 BBX-V0.34(2).zip 為基準；參考報名系統 BeybladeX-reg-V0.6(1).zip 的「SSE 小通知 → HTTPS REST 權威補讀」思想。

## 改動範圍

1. 保留既有 Firebase RTDB SDK 監聽。SDK 若在 3 秒內沒有完成初始化，或已連線後失聯，啟動只限本場的 **2 條經驗證的私人 SSE**：`events/{id}/publishedMatchHints` 和 `refereeClaims/{id}`。
2. 分數／執裁狀態：收到發布回執後沿用既有的 `matchVersion`、已發布回執、局部 REST 單場修復及 `syncVersion` 結構變更檢測；不能因 SSE 接到通知就當作比分已經寫入畫面。
3. 裁判身分：領取與釋放通知觸發獨立 RTDB REST 權威讀取；僅由該路徑決定身分，不從 events GET 或 localStorage 還原權限。
4. 只有 SDK 已確認連線，或 SSE 的兩條私人串流均已收到初始事件且已確認裁判身分，才視作即時連線可用。任何原本不安全的狀態，均需先完成權威全場核對，才解除記分阻擋。
5. SDK 已經正常工作的 Chrome 不必另外維持 SSE；SDK 持續離線時不再每隔 30 秒整組解除重訂閱，改讓 SSE 重連與低頻 REST 監督負責安全恢復。
6. 診斷分別顯示 SDK 狀態與私人 SSE；所有追蹤只記錄事件類型，**不記錄 ID Token、比分或私人領取資料**。
7. 針對新賽事尚未有發布回執 (`null`)，仍允許 SSE 收到合法空初始值並啟動權威驗證。

## 隱私與限制

- 私人 SSE 使用 Firebase 官方 REST EventSource `auth=` ID Token 查詢參數，僅於記憶體中建立 URL；不寫入 localStorage、URL location、診斷或日誌。RTDB Rules 按原身分保護該路徑；**不新增任何公開私人資料節點**。Firebase REST SSE 在網路層仍會把短期 Token 放在請求 URL，需避免公開網路除錯記錄。
- 前景才連線；返回背景會依原本生命週期解除連線。Token 約 42 分鐘輪替。
- SSE 是備援而不是 SDK 完全替換；若它也失效，記分依舊會暫停。Safari／Chrome 實機測試還沒完成，不能標成正式 V1.0。
- 權威比分交易、Functions、RTDB Rules、觀眾頁 SSE、賽制／淘汰／永久刪除流程完全沿用 V0.34。
- 本版為 Hosting-only 部署，只部署 `ljt-beyblade-x` 的 `bbxs-tamsui`，不部署其他 Firebase 專案。

## 實機回歸

先確認首頁顯示 BBX-V0.35。手機 A 主辦登入、手機 B 裁判匿名掃 QR；測試領取／釋放、不同場次同時記分、完賽下一場、主辦兼任裁判，以及觀眾同步。在 Safari 展開同步診斷，觀察 SDK 與 SSE 分別的狀態、事件／局部補讀／重畫計數。測試過程維持畫面在前景，若兩條管道都無法驗證，應保持記分阻擋。

本地測試不等於實機驗收；部署時執行 Cloud Shell Emulator preflight，失敗即停止。
