"use strict";
const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'),vm=require('node:vm');
const {buildProjectionPatch}=require('../functions/bbx-v011-publication');
const js=fs.readFileSync(require('node:path').join(__dirname,'../assets/index-v036.js'),'utf8');
const start=js.indexOf('  const receiptMatches=(m,h)=>{'),end=js.indexOf('  };',start)+4;
assert.ok(start>0&&end>start);
const src=js.slice(start,end)+'\nreturn receiptMatches;';
const same=new Function(src)();
function match(active,who,version){return {a:'A',b:'B',sa:0,sb:0,winner:null,refereeActive:active,referee:who,matchVersion:version}}
test('equal matchVersion with stale active lock must not be treated as synchronized',()=>{
 const hint={version:4,refereeActive:false,referee:'',winner:null,sa:0,sb:0};
 assert.equal(same(match(true,'裁判 2',4),hint),false);
 assert.equal(same(match(false,'',4),hint),true);
});
test('status mismatches of equal version, including score and winner, demand a scoped read',()=>{
 const hint={version:5,refereeActive:true,referee:'裁判 1',winner:null,sa:3,sb:0};
 assert.equal(same(match(true,'裁判 1',5),hint),false);
 assert.equal(same(match(true,'裁判 2',5),hint),false);
 assert.equal(same({...match(true,'裁判 1',5),sa:3},hint),true);
 assert.equal(same({...match(true,'裁判 1',5),sa:3,matchVersion:6},hint),true);
 assert.equal(same({...match(true,'裁判 1',5),sa:3,matchVersion:4},hint),false);
});
test('V0.25 historical numeric notifications remain compatible',()=>{
 assert.equal(same(match(true,'',7),7),true);
 assert.equal(same(match(true,'',6),7),false);
});
test('single claim publishes version AND actual lock status for both target and previous match',()=>{
 const old=match(false,'',4);const next=match(true,'裁判 2',5);
 const patch=buildProjectionPatch('BBX123456',{seq:8,changes:[
  {path:'rounds/0/matches/0',value:old,publicValue:{refereeActive:false}},
  {path:'rounds/0/matches/3',value:next,publicValue:{refereeActive:true}}
 ]});
 assert.equal(patch['events/BBX123456/publishedMatchHints'].matches.r0_0.refereeActive,false);
 assert.equal(patch['events/BBX123456/publishedMatchHints'].matches.r0_3.refereeActive,true);
 assert.equal(patch['events/BBX123456/publishedMatchHints'].matches.r0_3.referee,'裁判 2');
 assert.equal(patch['publicEvents/BBX123456/rounds/0/matches/3'].refereeActive,true);
});
test('public animation exposes only referee display label, never UID',()=>{
 const css=fs.readFileSync(require('node:path').join(__dirname,'../assets/viewer-v036.css'),'utf8');
 assert.match(css,/\.bracketMatch\.judging,.rrMini\.judging\{[^}]*animation:judgePulse/);
 assert.match(css,/@keyframes judgePulse/);
 const patch=buildProjectionPatch('BBX123456',{seq:9,changes:[{path:'rounds/0/matches/4',value:match(true,'裁判 3',6),publicValue:{refereeActive:true}}]});
 assert.equal(patch['publicEvents/BBX123456/rounds/0/matches/4'].referee,undefined); // this explicit projection fixture contains only the active flag
});
test('real authority switching matches releases the old lock in the same projected operation',()=>{
 const Core=require('../functions/bbx-v011-core');
 const epoch=1792159000000;
 const uid='owner-current-device';
 const m=(a,b)=>({a,b,sa:'',sb:'',winner:null,referee:'',refereeActive:false});
 const base=Core.bootstrap({id:'BBX123456',ownerUid:uid,mode:'single',freeFinal:'champ',roster:['A','B','C','D'],rounds:[{name:'round',matches:[m('A','B'),m('C','D')]}]});
 const run=(board,index,opIndex)=>Core.apply(board,uid,{opId:epoch.toString(16).padStart(12,'0')+String(opIndex).padStart(36,'0'),action:'claim',target:{kind:'round',ri:0,mi:index},expectedStructureVersion:0,expectedMatchVersion:board.rounds[0].matches[index].matchVersion,referee:'裁判 2'},epoch,{owner:true});
 const first=run(base,0,1);
 assert.equal(first.board.rounds[0].matches[0].refereeActive,true);
 const switched=run(first.board,1,2);
 assert.equal(switched.board.rounds[0].matches[0].refereeActive,false);
 assert.equal(switched.board.rounds[0].matches[1].refereeActive,true);
 assert.deepEqual(switched.changes.map(c=>c.path),['rounds/0/matches/0','rounds/0/matches/1']);
 const projected=buildProjectionPatch('BBX123456',{seq:2,changes:switched.changes});
 assert.equal(projected['events/BBX123456/publishedMatchHints'].matches.r0_0.refereeActive,false);
 assert.equal(projected['events/BBX123456/publishedMatchHints'].matches.r0_1.refereeActive,true);
 assert.equal(projected['publicEvents/BBX123456/rounds/0/matches/0'].refereeActive,false);
 assert.equal(projected['publicEvents/BBX123456/rounds/0/matches/1'].refereeActive,true);
 assert.equal(projected['publicEvents/BBX123456/rounds/0/matches/1'].referee,'裁判 2');
});
