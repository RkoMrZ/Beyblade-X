'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'assets/index-v036.js'),'utf8');
const start=src.indexOf('  // V0.36: Use REG V0.6\'s notification');
const end=src.indexOf("  const connectedRef=fbDb.ref('.info/connected');",start);
assert.ok(start>0&&end>start,'authenticated SSE fallback must be within private event controller');
const code=src.slice(start,end);
function mock(){
 const streams=[],requests=[],traces=[],reloads=[],unsafeCalls=[],drawCalls=[];
 class EventSource {
  constructor(url){this.url=url;this.listeners={};this.readyState=0;streams.push(this);}
  addEventListener(t,f){this.listeners[t]=f;}
  emit(t,data){const f=this.listeners[t];if(f)f({data:JSON.stringify(data)});}
  open(){this.readyState=1;this.onopen?.()}
  fail(){this.onerror?.({})}
  close(){this.readyState=2;}
 }
 const metric={errors:0,claims:0,connected:false,ready:false,claimsReady:false,trace:[]};
 const context={EventSource,URL,encodeURIComponent,Date,JSON,Object,Number,String,Math,Error,Set,Array,Promise,
  active:()=>true,sseEnabled:true,sseStarting:false,sseRetryTimer:null,sseRetryCount:0,
  sseForceTokenNext:false,sseGeneration:0,sseOpen:{hints:false,claims:false},
  sseInitialized:{hints:false,claims:false},sseLinks:{hints:null,claims:null},sdkConnected:false,
  connected:false,ready:false,claimsReady:false,failed:true,cloudResyncBlocked:true,
  metric,ev:{refereeClaims:{0:{uid:'old'}},syncVersion:1},id:'EVENTID',syncVersion:1,
  latestPublished:0,receipts:null,refereeClaimsStreamRevision:0,currentAdminTab:'bracket',
  unsubs:[],sseClaimsReadBusy:false,sseClaimsReadAgain:false,sseHintsTimer:null,
  later:(f,ms)=>({f,ms}),cancel:()=>{},
  getRestIdToken:async()=> 'PRIVATE_CANARY_TOKEN',
  FIREBASE_CONFIG:{databaseURL:'https://example.test'},
  rtdbRestGet:async p=>{requests.push(p);if(p.includes('refereeClaims'))return null;
    if(p.endsWith('syncVersion'))return 1;
    return {seq:1,matches:{}}},
  normalizeRefereeClaimsData:v=>v||{},confirmRefereeClaims:()=>{},
  renderReferee:()=>{},draw:()=>drawCalls.push(1),trace:(...args)=>traces.push(args),
  healthy:()=>{},status:()=>{},scheduleReload:(...args)=>reloads.push(args),
  unsafe:r=>{unsafeCalls.push(r);context.cloudResyncBlocked=true},
  scheduleHints:()=>{},setTimeout,clearTimeout,console:{warn:()=>{},error:()=>{}}
 };
 vm.createContext(context);
 vm.runInContext(code+'\nglobalThis.__start=startPrivateSse;globalThis.__state=()=>({connected,sseOpen,sseInitialized,ready,claimsReady,receipts,metric});',context);
 return {context,streams,requests,traces,reloads,unsafeCalls,drawCalls};
}
test('private streams are scoped to only two authenticated paths; no public claims or URL logs',async()=>{
 const m=mock();await m.context.__start('test');
 assert.equal(m.streams.length,2);
 const paths=m.streams.map(x=>new URL(x.url).pathname);
 assert.deepEqual(paths,['/events/EVENTID/publishedMatchHints.json','/refereeClaims/EVENTID.json']);
 for(const stream of m.streams)assert.equal(new URL(stream.url).searchParams.get('auth'),'PRIVATE_CANARY_TOKEN');
 assert.doesNotMatch(JSON.stringify(m.traces),/PRIVATE_CANARY_TOKEN/);
 assert.doesNotMatch(code,/localStorage|sessionStorage|location\.assign|console\.log\(url/);
});
test('empty unpublished event and empty claims establish verified SSE only after initial events',async()=>{
 const m=mock();await m.context.__start('test');
 m.streams.forEach(s=>s.open());
 assert.equal(m.context.__state().connected,false,'HTTP open is not proof of a received snapshot');
 m.streams[0].emit('put',{path:'/',data:null});
 assert.equal(m.context.__state().connected,false,'needs independent claims verification');
 m.streams[1].emit('put',{path:'/',data:null});
 await new Promise(resolve=>setImmediate(resolve));
 const st=m.context.__state();
 assert.equal(st.connected,true);assert.equal(st.ready,true);assert.equal(st.claimsReady,true);
 assert.deepEqual(JSON.parse(JSON.stringify(m.context.ev.refereeClaims)),{},'server deletion revokes local claims');
 assert.ok(m.requests.includes('refereeClaims/EVENTID'));
});
test('changed publication uses match hints instead of whole-board polling',async()=>{
 const m=mock();await m.context.__start('test');
 m.streams[0].open();m.streams[0].emit('put',{path:'/',data:{seq:1,matches:{r0_0:{version:1,sa:1,sb:0}}}});
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(m.context.__state().receipts.seq,1);
 assert.ok(m.requests.includes('events/EVENTID/syncVersion'));
 assert.equal(m.requests.includes('events/EVENTID'),false,'never full read per match notification');
});
test('losing private SSE while SDK is offline closes both streams and maintains write block',async()=>{
 const m=mock();await m.context.__start('test');
 m.streams[0].open();m.streams[1].open();
 m.streams[0].emit('put',{path:'/',data:null});m.streams[1].emit('put',{path:'/',data:null});
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(m.context.__state().connected,true);
 m.streams[0].fail();
 assert.equal(m.context.__state().connected,false);
 assert.equal(m.context.cloudResyncBlocked,true);
 assert.ok(m.unsafeCalls.length>0);
 assert.ok(m.streams.every(x=>x.readyState===2));
});
test('SSE fallback never changes the public projection or critical write paths',()=>{
 assert.match(src,/events\/\$\{id\}\/publishedMatchHints/);
 assert.match(src,/refereeClaims\/\$\{id\}/);
 assert.doesNotMatch(code,/publicEvents\/\$\{id\}\/refereeClaims/);
 assert.doesNotMatch(code,/\.ref\(|\.set\(|\.update\(/);
});
