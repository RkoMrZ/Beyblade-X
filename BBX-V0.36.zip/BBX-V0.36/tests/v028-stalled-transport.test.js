
'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v036.js'),'utf8');
const listen=src.slice(src.indexOf('function listenCloudEvent(id){'),src.indexOf('async function waitForAuthRestore('));
function harness(){
 const paths=new Map(),reads=[];let watchdog=null;
 const element=()=>({classList:{contains:()=>false,toggle(){},add(){},remove(){}},append(){},prepend(){},after(){},querySelector:()=>element(),getAttribute:()=>null,setAttribute(){},addEventListener(){},textContent:''});
 const ctx={console,Date,JSON,Number,Map,Set,setTimeout,clearTimeout,setInterval:fn=>{watchdog=fn;return 18},clearInterval:()=>{},
  ev:{id:'EV123456',rounds:[{matches:[{a:'A',b:'B',sa:0,sb:0,refereeActive:false,matchVersion:1}]}],refereeClaims:{},refereeNames:['裁判 1'],publishedSeq:1},
  cloudReady:true,isAdmin:true,isReferee:false,cloudUnsub:null,cloudListenerEpoch:0,cloudResyncBlocked:false,cloudEventsCache:{},
  liveRetryAttempts:new Map(),liveTransportRecoveryAt:new Map(),liveTransportRecoveryAt:new Map(),refereeClaimsStreamRevision:0,currentAdminTab:'referee',
  document:{visibilityState:'visible',createElement:element},$:k=>k==='admin'?element():null,
  fbDb:{ref(p){if(!paths.has(p))paths.set(p,new Map());return{on(t,fn){paths.get(p).set(t,fn)},off(t,fn){if(paths.get(p).get(t)===fn)paths.get(p).delete(t)}}}},
  normalizeRefereeClaimsData:raw=>raw||{},confirmRefereeClaims:()=>false,refereeClaimsConfirmed:()=>false,v05ScorePending:()=>false,
  rtdbRestGet:async p=>{reads.push(p);if(p.endsWith('/publishedSeq'))return 2;if(p.startsWith('refereeClaims/'))return {'0':{uid:'judge',name:'裁判 1'}};return null},
  renderAdmin:()=>{},renderReferee:()=>{},listenPublicProjectionEvent(){},firebase:{database:()=>({goOnline(){}})}
 };
 vm.createContext(ctx);vm.runInContext(listen,ctx);ctx.listenCloudEvent('EV123456');
 return {ctx,reads,paths,tick:()=>watchdog(),close:()=>ctx.cloudUnsub()};
}
test('stalled organizer SDK still probes publishedSeq and claims and schedules recovery',async()=>{
 const h=harness();
 try{
   // Intentionally never deliver .info/connected=true or a child_changed event.
   await h.tick();
   assert.ok(h.reads.includes('events/EV123456/publishedSeq'));
   assert.ok(h.reads.includes('refereeClaims/EV123456'));
   assert.equal(h.ctx.ev.refereeClaims['0'].uid,'judge');
 }finally{h.close()}
});
test('a healthy RTDB stream does not trigger redundant claims REST fallback',async()=>{
 const h=harness();try{
  const cb=h.paths.get('.info/connected').get('value');cb({val:()=>true});
  // Being connected alone is not proof that the independent claims stream is ready.
  h.paths.get('events/EV123456/publishedSeq').get('value')({val:()=>1});
  h.paths.get('refereeClaims/EV123456').get('value')({val:()=>({})});
  await h.tick();
  assert.ok(h.reads.includes('events/EV123456/publishedSeq'));
  assert.ok(!h.reads.includes('refereeClaims/EV123456'));
 }finally{h.close()}
});
