'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../assets/index-v036.js'),'utf8');
function between(start,end){const i=source.indexOf(start);const j=source.indexOf(end,i);assert.ok(i>=0&&j>i);return source.slice(i,j);}
const globalScope=between('// Home subscription identity:', 'function events(){');
function context(extra={}){
  const home={classList:{contains:()=>false}};
  const refs=[];
  const user={uid:'OWNER1',providerData:[{providerId:'google.com'}]};
  const c={console,Date,JSON,Number,Map,Set,URLSearchParams,setTimeout:()=>20,clearTimeout:()=>{},
    document:{visibilityState:'visible',getElementById:name=>name==='home'?home:null},location:{search:''},isGoogleUser:()=>true,
    $:name=>name==='home'?home:null,fbAuth:{currentUser:user},fbDb:{ref(route){
      const r={route,callbacks:[],detached:0,on(type,fn){this.callbacks.push({type,fn})},off(){this.detached++}};
      refs.push(r);return r;
    }},
    clearOwnerRetryTimers(){},setOwnerIndexState(){},ownerIndexState:{},
    cloudEventsCache:{},cloudEventIds:[],ownerIndexLastUid:'OWNER1',
    indexedOwnerSlots:()=>({}),ownerIndexSlotFingerprint:()=>'',
    ...extra};
  vm.createContext(c);vm.runInContext(globalScope,c);
  vm.runInContext('bbxBootstrapping=false',c);
  return {c,home,refs};
}
test('single-flight Firebase initialization: owner and referee startup share one Auth listener',async()=>{
  const c={console,fbAuth:null,cloudReady:false,cloudInitPromise:null,fbUser:null};
  let resolveInit,starts=0;
  c.initializeCloudOnce=()=>{starts++;return new Promise(r=>{resolveInit=r;});};
  vm.createContext(c);
  vm.runInContext(between('async function initCloud(){','async function initializeCloudOnce(){'),c);
  const a=c.initCloud(),b=c.initCloud();
  assert.equal(starts,1,'two callers must never create two Auth observers');
  resolveInit(true);assert.equal(await a,true);assert.equal(await b,true);
  assert.equal(c.cloudInitPromise,null);
});
test('organizer Home index attaches once; tabs, auth callback and pageshow cannot duplicate it',()=>{
  const h=context();
  vm.runInContext(between('function stopMyCloudEventIndexListener(){','async function refreshCloudListOnHome(){'),h.c);
  h.c.listenMyCloudEventIndex();h.c.listenMyCloudEventIndex();h.c.listenMyCloudEventIndex();
  assert.equal(h.refs.length,1,'only one userEvents SDK subscription');
  assert.equal(h.refs[0].callbacks.length,1);
  vm.runInContext('bbxEnteringPrivateEvent=1',h.c);
  h.c.listenMyCloudEventIndex();
  assert.equal(h.refs.length,1,'no new index while a private event is opening');
  h.c.stopMyCloudEventIndexListener();
  assert.equal(h.refs[0].detached,1);
  vm.runInContext('bbxEnteringPrivateEvent=0',h.c);
  h.c.listenMyCloudEventIndex();
  assert.equal(h.refs.length,2,'Home index can resume after leaving event');
  h.c.stopMyCloudEventIndexListener();
});
test('organizer route shuts Home SDK stream BEFORE private event load; referee direct entry never starts Home index',async()=>{
  for(const role of ['organizer','referee']){
    const calls=[];let resolveLoad;
    const h=context({
      stopMyCloudEventIndexListener(){calls.push('home-index-off')},
      listenMyCloudEventIndex(){calls.push('home-index-on')},
      loadCloudEventOnce(){calls.push('private-event-load');return new Promise(r=>{resolveLoad=r})}
    });
    vm.runInContext(between('async function loadCloudEvent(id){','async function loadCloudEventOnce(id){'),h.c);
    if(role==='referee')h.c.isGoogleUser=()=>false;
    const pending=h.c.loadCloudEvent('E1');
    assert.deepEqual(calls,['home-index-off','private-event-load']);
    assert.equal(h.c.bbxCanRunOwnerIndex(),false);
    const same=h.c.loadCloudEvent('E1');
    assert.equal(calls.filter(x=>x==='private-event-load').length,1,'dedupe same event opening');
    resolveLoad('error');assert.equal(await pending,'error');assert.equal(await same,'error');
    assert.equal(calls.includes('home-index-on'),role==='organizer','only organizer Home resumes on failure');
  }
});
test('Google Auth callback cannot restart Home index during private event transition; anonymized referee has no owner index',async()=>{
  const h=context();let authCallback=null,starts=0,stops=0;
  const auth=()=>h.c.fbAuth;
  auth.Auth={Persistence:{LOCAL:'local'}};
  h.c.firebase={apps:[],initializeApp(){return {}},auth,database:()=>h.c.fbDb};
  h.c.fbAuth.setPersistence=async()=>{};
  h.c.fbAuth.onAuthStateChanged=fn=>{authCallback=fn;return ()=>{}};
  Object.assign(h.c,{FIREBASE_CONFIG:{databaseURL:'https://example.invalid'},firebaseConfigured:()=>true,
    configureBbxRealtimeTransport(){},
    bbxRealtimeTransport:'long-polling',bbxTransportSelectionError:null,
    cloudReady:false,fbApp:null,fbDb:null,fbUser:null,cloudUnsub:null,
    ownerIndexLastUid:null,ev:null,restTokenCache:null,
    renderHeaderAuth(){},renderHomeSelections(){},renderSavedEvents(){},
    listenMyCloudEventIndex(){starts++},stopMyCloudEventIndexListener(){stops++},
    setOwnerIndexState(){},resyncCurrentCloudEventOnForeground:async()=>true,
    readCloudViewPointer(){return null},
    alert(){throw new Error('unexpected initialization error')}});
  // Ensure fake RTDB exists as the database function's return value.
  const db={ref(){return {on(){},off(){}}}};
  h.c.firebase.database=()=>db;
  vm.runInContext(between('async function initializeCloudOnce(){','function localEventSave(){'),h.c);
  assert.equal(await h.c.initializeCloudOnce(),true);
  assert.equal(typeof authCallback,'function');
  vm.runInContext('bbxEnteringPrivateEvent=1',h.c);
  await authCallback({uid:'OWNER1',providerData:[{providerId:'google.com'}]});
  assert.equal(starts,0,'Google restoration during event entry must not attach owner index');
  vm.runInContext('bbxEnteringPrivateEvent=0',h.c);
  await authCallback({uid:'OWNER1',providerData:[{providerId:'google.com'}]});
  assert.equal(starts,1,'Google Home can attach one owner index');
  h.c.isGoogleUser=()=>!!h.c.fbAuth.currentUser?.providerData?.some(p=>p.providerId==='google.com');
  h.c.fbAuth.currentUser={uid:'REF1',providerData:[]};
  await authCallback(h.c.fbAuth.currentUser);
  assert.equal(starts,1,'anonymous referee cannot subscribe to Google owner index');
  assert.ok(stops>=1,'identity change must detach old owner index');
});
