#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.36 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.36 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.36 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v036.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v036-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
# The organizer append-only operation must reach the Cloud before the UI invokes it.
# Do not deploy database rules or any match-scoring/cloud deletion function.
gcloud auth print-access-token >/dev/null
bash deploy/functions-v036.sh
bash deploy/hosting-v036.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.36 OrganizerAuthority + Hosting deployed; Rules, scoring Functions and saved events untouched.\n'
