# BBX-V0.36 — 賽程進行中安全追加裁判（測試版）

基準：使用者實測 V0.35（SSE 連線已驗證），解決賽事已有比分或已完賽時，原 `setReferees` 被 `anyStarted` 阻擋而無法增加裁判的問題。

- 新增雲端權威操作 `appendReferee`：後端以最新權威名單，只在尾端追加 1 個尚未被領取的位置；上限 12 位。
- 不接受客戶端整張名單替換：所有既有裁判索引、claims、比賽比分、賽制與執裁鎖均保持不變。
- 仍然要求有效 Google 主辦權限或既有共同管理員、正確權威 seq、一次性 opId、操作鎖與發布回執。
- 原有 `setReferees` 的全面調整／刪除限制未解除；有已領取裁判時仍拒絕重排。
- 前端「＋增加裁判」改呼叫 `appendReferee`；新版雲端與前端需成對部署。
- 診斷把錯誤的「訂閱初始化耗時」改成「本次訂閱已持續」，增加 SSE 發布通知計數，方便區分 SDK 與 SSE 的即時事件。
- 不動計分、完賽、晉級、裁判領取、資料庫 Rules、觀眾資料或歷史清理流程。

部署只更新 **一個** Functions callable `bbxV011OrganizerAuthority` 和 Hosting `bbxs-tamsui`。部署先更新 Function，再更新 Hosting，任一部署或驗證失敗即停止。舊版網頁的新增裁判功能仍會使用 `setReferees`，必須確認實際網頁載入 V0.36。

本地模擬測試不能替代 Firebase Emulator 和 Safari/Chrome 多手機實機驗收。
