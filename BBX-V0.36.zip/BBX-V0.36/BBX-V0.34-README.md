# BBX-V0.34 — 此場完成後裁判身分被清空修正

根據實機反映：「裁判完成上一場後，開啟下一場卻顯示未領取裁判身分；必須切回裁判頁才能恢復。」

## 找到的原因

身分領取紀錄位於獨立的 `refereeClaims/{eventId}`，不屬於 `events/{eventId}`。
舊版 `backgroundRefreshCurrentEvent()` 在完賽後讀取 `events/{eventId}`，將 `ev` 替換成回傳物件，隨後以 `ev.refereeClaims || {}` 填補，意外把原本已驗證的裁判領取紀錄清空。打開裁判頁才重新 GET 紀錄並恢復。

另一個 `refreshEventBeforeCriticalAction()` 也會替換同一物件，存在同類缺口。

## 修正

- 新增 `preserveLiveRefereeClaimsOnEventSnapshot()`，僅在**同一個賽事 ID** 下保留既有已收到的獨立領取資料；`events/` 的 REST 快照不會被誤當成領取資料來源。
- 在完賽後背景刷新及操作前刷新時使用此規則；不以 localStorage 的舊裁判名稱冒充有效領取。
- 原本獨立 `refereeClaims/` 即時更新、釋放流程、UID 驗證和雲端裁判鎖都保留；當真正收到釋放紀錄時，本機仍會失去裁判身分。
- 沒有修改 Functions、Rules、公開觀眾 SSE、賽制或現有雲端資料。

## 回歸測試

專項 5 項：完賽→背景 GET→下一場、主辦兼裁判、操作前 GET、不同賽事隔離、真正釋放不會由本機舊資料復活。
完整 Node.js 374／374 通過；HTML 靜態檢查、Rules JSON/歷史清理檢查、Chromium 375/390/768/1366px 診斷與 DOM 保留檢查通過。

測試不構成實機驗收；Firebase Emulator 需在 Cloud Shell preflight 執行。Safari 的底層 SDK 離線問題仍是獨立的、尚未驗證解決的問題。

## 部署

Hosting only，Firebase project `ljt-beyblade-x`、Hosting site `bbxs-tamsui`。ZIP 上傳到 GitHub `rkomrz/Beyblade-X` main 根目錄，解壓後於 `~/BBX-V0.34` 執行 `bash 00_start.sh`；前置測試失敗會停止部署。
