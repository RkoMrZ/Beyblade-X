# BBX-V0.32 — 主辦／裁判 Firebase 連線生命週期稽核修正版

2026-10-29。以 V0.31 為基準，修正主辦與裁判進入同一 `listenCloudEvent()` **之前** 不同的啟動路徑；不是改變裁判權限或加快輪詢。

## V0.31 實測證據

- 主辦：Google 已登入，授權 REST `publishedSeq` 成功，但 RTDB SDK `.info/connected=false`，發布及裁判領取訂閱尚未初始化。
- 裁判：匿名／裁判授權路徑，RTDB SDK online，發布、領取訂閱初始化，既有場次 `child_added` 逐筆送達。
- 因而不能把主辦端離線直接歸咎於缺少同一份 `listenCloudEvent()`，也無法只靠 REST 成功證明 RTDB 長連線健康。

## 實際的兩端差異及本版改動

1. 主辦先經 Google Auth 恢復、首頁 `userEvents/{uid}` 訂閱及私人賽事載入；裁判經獨立裁判授權核對後才進入相同賽事。主辦 Auth 回呼／首頁列表可能與進入賽事並行。
2. `initCloud()` 改成 single-flight，避免同時間兩個呼叫對同一個 Firebase App 重複做 Persistence 和 `onAuthStateChanged` 初始化。
3. `bootstrapCloud()` 期間禁止首頁索引自動掛載；待身分恢復及路由判定完成後才允許首頁訂閱。
4. `loadCloudEvent()` 進入前先結束首頁索引；路由進行中，Google Auth 回呼不能重掛它；失敗回首頁才恢復。相同賽事的同時開啟請求合併。
5. 主辦首頁索引同 UID 已綁定時不重複取消／重新訂閱；離開首頁或 UID 變更後立即撤銷舊訂閱。UID 變更會使舊私人賽事監聽失效、暫停提交，必須重新核驗權限。
6. 觀察用的生命週期 trace 獨立於比分 trace：可記錄初始化、Auth 類型（Google／匿名／null）、首頁訂閱、私人賽事進出，但不記錄 Token、UID、驗證碼或選手資料。
7. 額外保留 V0.32 的 `child_added` / `child_changed` / `child_removed` 分類計數、重複訂閱數及 **手動** A/B 測試傳輸模式。A/B 只針對該手機，不自動 reload 正在執裁的賽事。

## 未變更

記分、完賽、賽制、抽籤、Cloud Functions、Rules、公開觀眾 SSE 和既有資料。沒有新增高頻輪詢或共用記分鎖。

## 驗證

- Node.js：365 / 365（涵蓋 Google Auth 與裁判入口、Home index 重複回呼、相同賽事開啟合併、UID 切換，以及歷史功能回歸）。
- Chromium：375 / 390 / 768 / 1366px 診斷與實際 DOM 事件測試通過。
- Firebase Emulator、實機 SDK 連線、60 名觀眾與裁判同時連線：尚未於本地驗證，須部署腳本和實機驗收。

**注意：** 這次確實修正「主辦首頁索引與私人賽事入口重疊」的可重現時序缺陷，但不能依此斷言它就是 V0.31 主辦 SDK offline 的唯一成因。若主辦仍 offline，需要保留兩支手機診斷，對照 Auth／首頁／賽事生命週期，以及相同手機的 long-polling／auto 傳輸實測，不能把 REST 補讀當即時同步成功。
