#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.36 ]] || { echo 'STOP: wrong version folder';exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v036-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight missing';exit 3; }
P=ljt-beyblade-x;SITE=bbxs-tamsui
gcloud auth print-access-token >/dev/null
firebase hosting:sites:get "$SITE" --project "$P" >/dev/null
mkdir -p hosting-public/assets
rm -rf hosting-public/assets
mkdir -p hosting-public/assets
cp -f index.html viewer.html hosting-public/
cp -f assets/index-v036-*.css assets/index-v036-*.js assets/viewer-v036-*.css assets/viewer-v036-*.js hosting-public/assets/
python3 - <<'PY_HASH'
from pathlib import Path
import hashlib,re
for page in ('index','viewer'):
 s=Path(page+'.html').read_text()
 refs=re.findall(r'assets/'+page+r'-v036-[a-f0-9]{12}\.(?:js|css)',s)
 assert len(refs)==2,(page,refs)
 for ref in refs:
  f=Path(ref)
  assert hashlib.sha256(f.read_bytes()).hexdigest().startswith(re.search(r'-([a-f0-9]{12})\.',ref).group(1))
print('PASS: Hosting files content-fingerprinted')
PY_HASH
firebase deploy --only hosting --config firebase.hosting.json --project "$P" --non-interactive
for attempt in 1 2 3 4 5 6;do
 temp=$(mktemp)
 if curl --fail --location --silent --show-error --max-time 15 -H 'Cache-Control: no-cache' "https://${SITE}.web.app/" -o "$temp" && cmp -s index.html "$temp";then rm -f "$temp";break;fi
 rm -f "$temp"
 if [[ "$attempt" == 6 ]];then echo 'STOP: deployed HTML verification failed';exit 4;fi
 sleep 3
done
ASSET=$(grep -o 'assets/index-v036-[0-9a-f]\{12\}\.js' index.html | head -1)
test -n "$ASSET"
temp=$(mktemp)
curl --fail --location --silent --show-error --max-time 20 "https://${SITE}.web.app/${ASSET}" -o "$temp"
cmp -s "$ASSET" "$temp" || { rm -f "$temp";echo 'STOP: CDN JS mismatch';exit 4; }
rm -f "$temp"
printf 'PASS: V0.36 exact HTML and fingerprinted JS live on %s.web.app\n' "$SITE"
