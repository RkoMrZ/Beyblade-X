#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.36 ]] || { echo 'STOP: wrong version folder';exit 2; }
[[ "$(gcloud config get-value project 2>/dev/null)" == 'ljt-beyblade-x' ]] || { echo 'STOP: wrong Firebase project';exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v036-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight missing';exit 3; }
python3 - <<'PY_VERIFY'
import hashlib,json
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
assert m['functions_deploy_only']==['bbxV011OrganizerAuthority']
for f,h in m['updated_backend_hashes'].items():
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
assert 'ljt-beyblade-x' in Path('functions/index.js').read_text()
assert 'bbxV011OrganizerAuthority' in Path('functions/index.js').read_text()
print('PASS: only organizer callable and its reducer changed')
PY_VERIFY
# Updating ONE callable function does not touch other functions, RTDB Rules, or saved events.
firebase deploy --only functions:bbxV011OrganizerAuthority --config firebase.json --project ljt-beyblade-x --non-interactive
printf 'PASS: organizer authority callable deployed (not a match-scoring function)\n'
