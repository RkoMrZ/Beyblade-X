#!/usr/bin/env python3
"""BBX spectator read-only background diagnostic; Python standard library only.
Each simulated visitor loads the public viewer and holds exactly one RTDB SSE.
No credentials, no writes, no Functions calls.
"""
import argparse
import json
import os
import random
import re
import resource
import signal
import statistics
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SITE = 'https://bbxs-tamsui.web.app'
DB = 'https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app'
CODE = '2NUBH'
UA = 'BBX-spectator-loadtest/2.0 (owner authorized; read-only)'
STOP = threading.Event()
LOCK = threading.RLock()
STATE = {
  'started': 0, 'html_ok': 0, 'assets_ok': 0, 'alias_ok': 0,
  'active_sse': 0, 'peak_active_sse': 0, 'unique_sse_connected': 0,
  'initial_put_ok': 0, 'put': 0, 'patch': 0, 'reconnect': 0,
  'http_attempt_errors': 0, 'sse_errors': 0, 'homepage_ok': 0,
  'homepage_fail': 0, 'sse_bytes': 0,
  'first_put_sec': [], 'error_samples': [], 'errors_by_stage': {},
}
UNIQUE = set()


def log(msg):
    print(time.strftime('%H:%M:%S') + ' ' + msg, flush=True)


def add(key, count=1):
    with LOCK:
        STATE[key] += count


def record(stage, error):
    details = str(error).replace('\n', ' ')[:170]
    with LOCK:
        if stage.startswith('sse'):
            STATE['sse_errors'] += 1
        elif stage == 'homepage':
            STATE['homepage_fail'] += 1
        else:
            STATE['http_attempt_errors'] += 1
        d = STATE['errors_by_stage']
        d[stage] = d.get(stage, 0) + 1
        example = f'{stage}: {type(error).__name__}: {details}'
        if example not in STATE['error_samples'] and len(STATE['error_samples']) < 16:
            STATE['error_samples'].append(example)


def request(url, accept=None, timeout=20):
    head = {'User-Agent': UA, 'Cache-Control': 'no-cache'}
    if accept:
        head['Accept'] = accept
    return urllib.request.urlopen(urllib.request.Request(url, headers=head, method='GET'), timeout=timeout)


def bounded(url, accept=None, limit=2_000_000, timeout=20):
    with request(url, accept, timeout) as res:
        if res.status != 200:
            raise ValueError(f'HTTP {res.status}')
        data = res.read(limit + 1)
        if len(data) > limit:
            raise ValueError('oversized public response')
        return data


def preflight():
    html = bounded(f'{SITE}/v/{CODE}', 'text/html').decode('utf-8', 'replace')
    assets = sorted(set(re.findall(r'assets/viewer-v\d{3}-[a-f0-9]{12}\.(?:js|css)', html)))
    if not assets:
        raise ValueError('viewer HTML has no version-fingerprinted assets')
    for asset in assets:
        bounded(f'{SITE}/{asset}')
    eid = json.loads(bounded(f'{DB}/bbxPublicCodeLookup/{CODE}.json', 'application/json').decode('utf-8'))
    if not isinstance(eid, str) or not re.fullmatch(r'[A-Za-z0-9_-]{6,100}', eid):
        raise ValueError('public lookup did not resolve to a valid event ID')
    bounded(f'{DB}/publicEvents/{urllib.parse.quote(eid, safe="")}/meta/authoritySeq.json', 'application/json', limit=100_000)
    log(f'PREFLIGHT PASS: viewer={CODE}, asset_count={len(assets)}, public RTDB lookup OK')
    return eid, assets


def sleep_until(start, delay):
    while not STOP.is_set():
        wait = start + delay - time.monotonic()
        if wait <= 0:
            break
        STOP.wait(min(wait, 0.25))


def fetch_visitor(idx, event_id, assets, mode):
    # Ramped mode may retry transient errors; burst mode deliberately captures first-attempt failures.
    tries = 3 if mode == 'ramp' else 1
    counted = set()
    for attempt in range(tries):
        if STOP.is_set():
            return False
        step = 'html'
        try:
            bounded(f'{SITE}/v/{CODE}', 'text/html')
            if 'html' not in counted:
                add('html_ok')
                counted.add('html')
            step = 'assets'
            for asset in assets:
                bounded(f'{SITE}/{asset}')
            if 'assets' not in counted:
                add('assets_ok')
                counted.add('assets')
            step = 'alias'
            alias = json.loads(bounded(f'{DB}/bbxPublicCodeLookup/{CODE}.json', 'application/json').decode('utf-8'))
            if alias != event_id:
                raise ValueError('public alias changed while testing')
            if 'alias' not in counted:
                add('alias_ok')
                counted.add('alias')
            return True
        except Exception as exc:
            record(f'{step}', exc)
            if attempt + 1 < tries:
                STOP.wait(1.5 + attempt * 2 + random.uniform(0, 0.5))
    return False


def guest(idx, event_id, assets, start_gate, start_at, end_at, mode, rate):
    start_gate.wait()
    if mode == 'ramp':
        sleep_until(start_at, idx / rate)
    if STOP.is_set() or time.monotonic() >= end_at:
        return
    begin = time.monotonic()
    add('started')
    if not fetch_visitor(idx, event_id, assets, mode):
        return
    stream_url = f'{DB}/publicEvents/{urllib.parse.quote(event_id, safe="")}.json'
    first_put = False
    attempt = 0
    while not STOP.is_set() and time.monotonic() < end_at:
        attempt += 1
        active = False
        try:
            with request(stream_url, 'text/event-stream', timeout=90) as res:
                mime = res.headers.get('Content-Type', '')
                if res.status != 200 or 'text/event-stream' not in mime:
                    raise ValueError(f'SSE HTTP={res.status} mime={mime}')
                with LOCK:
                    STATE['active_sse'] += 1
                    STATE['peak_active_sse'] = max(STATE['peak_active_sse'], STATE['active_sse'])
                    if idx not in UNIQUE:
                        UNIQUE.add(idx)
                        STATE['unique_sse_connected'] += 1
                active = True
                event = ''
                while not STOP.is_set() and time.monotonic() < end_at:
                    line = res.readline(1_000_000)
                    if not line:
                        raise ConnectionError('SSE ended by server/proxy')
                    add('sse_bytes', len(line))
                    s = line.decode('utf-8', 'replace').rstrip('\r\n')
                    if not s:
                        if event in ('put', 'patch'):
                            add(event)
                            if event == 'put' and not first_put:
                                first_put = True
                                with LOCK:
                                    STATE['initial_put_ok'] += 1
                                    STATE['first_put_sec'].append(round(time.monotonic() - begin, 3))
                        elif event in ('cancel', 'auth_revoked'):
                            raise PermissionError('SSE permission revoked')
                        event = ''
                    elif s.startswith('event:'):
                        event = s[6:].strip()
        except Exception as exc:
            if not STOP.is_set() and time.monotonic() < end_at:
                record('sse', exc)
        finally:
            if active:
                add('active_sse', -1)
        if STOP.is_set() or time.monotonic() >= end_at:
            break
        add('reconnect')
        STOP.wait(min(6, 2 + random.random()*3))


def snapshot():
    with LOCK:
        s = dict(STATE)
        s['error_samples'] = STATE['error_samples'][:]
        s['errors_by_stage'] = STATE['errors_by_stage'].copy()
        times = sorted(s.pop('first_put_sec'))
    if times:
        s['initial_put_p50_sec'] = round(statistics.median(times), 3)
        s['initial_put_p95_sec'] = times[min(len(times) - 1, int(.95 * (len(times) - 1)))]
        s['initial_put_max_sec'] = times[-1]
    s['worker_threads'] = threading.active_count()
    return s


def save_json(folder, name, state):
    tmp = folder / (name + '.tmp')
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, folder / name)


def terminate(signum, frame):
    STOP.set()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--viewers', type=int, required=True)
    parser.add_argument('--duration', type=int, required=True)
    parser.add_argument('--mode', choices=('ramp', 'burst'), required=True)
    parser.add_argument('--rate', type=int, default=10)
    parser.add_argument('--output', type=Path, required=True)
    opt = parser.parse_args()
    if not 1 <= opt.viewers <= 100 or not 15 <= opt.duration <= 900 or not 1 <= opt.rate <= 25:
        parser.error('viewers 1..100, duration 15..900, rate 1..25')
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    opt.output.mkdir(parents=True, exist_ok=True)
    log('BBX LOAD TEST V2: public read-only; no Firebase writes, no Google credentials')
    try:
        eid, assets = preflight()
    except Exception as exc:
        log(f'PREFLIGHT FAIL: {type(exc).__name__}: {exc}')
        sys.exit(2)
    try:
        limit = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
    except Exception:
        limit = -1
    log(f'CLIENT DIAGNOSTIC: pid={os.getpid()} file_descriptor_limit={limit}; mode={opt.mode}')
    gate = threading.Event()
    start_at = time.monotonic() + 1
    end_at = start_at + opt.duration
    pool = ThreadPoolExecutor(max_workers=opt.viewers, thread_name_prefix='bbx-guest')
    jobs = [pool.submit(guest, idx, eid, assets, gate, start_at, end_at, opt.mode, opt.rate) for idx in range(opt.viewers)]
    log(f'LAUNCH requested={opt.viewers}, duration={opt.duration}s, mode={opt.mode}, rate={opt.rate}/second (ramp only)')
    gate.set()
    next_probe = time.monotonic()
    while not STOP.is_set() and time.monotonic() < end_at:
        now = time.monotonic()
        if now >= next_probe:
            next_probe = now + 30
            try:
                bounded(f'{SITE}/', 'text/html', timeout=8)
                add('homepage_ok')
            except Exception as exc:
                record('homepage', exc)
        s = snapshot()
        s['requested'] = opt.viewers
        s['mode'] = opt.mode
        save_json(opt.output, 'live.json', s)
        log(f"STATUS SSE={s['active_sse']}/{opt.viewers} peak={s['peak_active_sse']} unique={s['unique_sse_connected']} initialPut={s['initial_put_ok']} html={s['html_ok']} aliases={s['alias_ok']} errorsHTTP={s['http_attempt_errors']} errorsSSE={s['sse_errors']} errorsByStage={s['errors_by_stage']} homeOK={s['homepage_ok']} homeFAIL={s['homepage_fail']}")
        STOP.wait(10)
    STOP.set()
    s = snapshot()
    s['requested'] = opt.viewers
    s['duration_limit_sec'] = opt.duration
    s['mode'] = opt.mode
    s['finished_at'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
    s['note'] = '100 independent SSE+HTTP clients (not browser UI). Organizer re-entry checked manually by signed-in user.'
    save_json(opt.output, 'summary.json', s)
    save_json(opt.output, 'live.json', s)
    log(f"FINAL peak={s['peak_active_sse']}, unique={s['unique_sse_connected']}, initialPut={s['initial_put_ok']}, errorsByStage={s['errors_by_stage']}")
    log('FINAL summary.json written; all sockets will close when this process exits')
    sys.stdout.flush()
    os._exit(0)

if __name__ == '__main__':
    main()
