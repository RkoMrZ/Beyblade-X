#!/usr/bin/env bash
set -euo pipefail
ROOT="$HOME/BBX-viewer-loadtest-v2"
[[ -f "$ROOT/test.pid" ]] || { echo '沒有執行中測試'; exit 0; }
pid="$(cat "$ROOT/test.pid")"
[[ "$pid" =~ ^[0-9]+$ ]] || { echo 'PID 格式異常，未停止其他程式'; exit 2; }
if [[ -r "/proc/$pid/cmdline" ]] && tr '\0' ' ' < "/proc/$pid/cmdline" | grep -q 'viewer_load.py'; then
 kill -TERM "$pid" 2>/dev/null || true
 for n in 1 2 3 4 5; do
  if ! [[ -r "/proc/$pid/cmdline" ]] || ! tr '\0' ' ' < "/proc/$pid/cmdline" | grep -q 'viewer_load.py'; then break; fi
  sleep 1
 done
 if [[ -r "/proc/$pid/cmdline" ]] && tr '\0' ' ' < "/proc/$pid/cmdline" | grep -q 'viewer_load.py'; then kill -KILL "$pid" 2>/dev/null || true; fi
 echo '已停止背景測試，連線會隨程序結束而關閉'
else
 echo '測試已結束，無須停止'
fi
rm -f "$ROOT/test.pid"
