#!/usr/bin/env bash
set -euo pipefail
ROOT="$HOME/BBX-viewer-loadtest-v2"
VIEWERS="${1:-100}"; DURATION="${2:-600}"; MODE="${3:-ramp}"
[[ "$VIEWERS" =~ ^[0-9]+$ ]] && ((VIEWERS>=1 && VIEWERS<=100)) || { echo '觀眾數須為 1～100'; exit 2; }
[[ "$DURATION" =~ ^[0-9]+$ ]] && ((DURATION>=15 && DURATION<=900)) || { echo '秒數須為 15～900'; exit 2; }
[[ "$MODE" == 'ramp' || "$MODE" == 'burst' ]] || { echo '模式須為 ramp 或 burst'; exit 2; }
# Prevent accidentally running the old and new load tests concurrently.
for where in "$HOME/BBX-loadtest" "$ROOT"; do
  if [[ -f "$where/test.pid" ]]; then
    pid="$(cat "$where/test.pid")"
    if [[ "$pid" =~ ^[0-9]+$ ]] && [[ -r "/proc/$pid/cmdline" ]] && tr '\0' ' ' < "/proc/$pid/cmdline" | grep -q 'viewer_load.py'; then
      echo "已有壓力測試執行中 (PID=$pid)，請先停止，避免重複測試。"; exit 2
    fi
  fi
done
mkdir -p "$ROOT"
rm -f "$ROOT/live.json" "$ROOT/summary.json"
nohup python3 -u "$ROOT/viewer_load.py" --viewers "$VIEWERS" --duration "$DURATION" --mode "$MODE" --output "$ROOT" > "$ROOT/test.log" 2>&1 < /dev/null &
pid=$!
printf '%s\n' "$pid" > "$ROOT/test.pid"
sleep 2
if ! kill -0 "$pid" 2>/dev/null; then echo '背景程式啟動失敗'; tail -20 "$ROOT/test.log"; exit 1; fi
echo "PASS: 背景測試啟動 PID=$pid，共 $VIEWERS 人，${DURATION} 秒，模式 $MODE"
echo '狀態：bash ~/BBX-viewer-loadtest-v2/status.sh'
echo '停止：bash ~/BBX-viewer-loadtest-v2/stop.sh'
