#!/usr/bin/env bash
set -euo pipefail
ROOT="$HOME/BBX-viewer-loadtest-v2"
if [[ -f "$ROOT/test.pid" ]]; then
 pid="$(cat "$ROOT/test.pid")"
 if [[ "$pid" =~ ^[0-9]+$ ]] && [[ -r "/proc/$pid/cmdline" ]] && tr '\0' ' ' < "/proc/$pid/cmdline" | grep -q 'viewer_load.py'; then echo "執行中 PID=$pid"; else echo '測試已結束'; fi
else echo '尚未啟動'; fi
if [[ -f "$ROOT/live.json" ]]; then
 python3 - "$ROOT/live.json" <<'PY'
import json,sys
s=json.load(open(sys.argv[1]))
for k in ('mode','requested','active_sse','peak_active_sse','unique_sse_connected','initial_put_ok','html_ok','assets_ok','alias_ok','put','patch','reconnect','http_attempt_errors','sse_errors','errors_by_stage','homepage_ok','homepage_fail','initial_put_p50_sec','initial_put_p95_sec'):
  if k in s: print(f'{k}: {s[k]}')
if s.get('error_samples'):
  print('--- 前幾種錯誤（協助定位，不含比分） ---')
  for x in s['error_samples'][:8]: print(x)
PY
else
 echo '尚未產生 live.json；最近輸出：'
 tail -12 "$ROOT/test.log" 2>/dev/null || true
fi
if [[ -f "$ROOT/summary.json" ]]; then echo '已輸出最終報告：~/BBX-viewer-loadtest-v2/summary.json'; fi
