BBX-Viewer-LoadTest-V2 (standalone; no website deployment)
Only authorized test: https://bbxs-tamsui.web.app/v/2NUBH
Firebase RTDB public read paths only; NO writes, credentials, or organizer Functions.
Cloud Shell shell commands:
  bash ~/BBX-viewer-loadtest-v2/start.sh 100 600 ramp
  bash ~/BBX-viewer-loadtest-v2/status.sh
  bash ~/BBX-viewer-loadtest-v2/stop.sh
  bash ~/BBX-viewer-loadtest-v2/start.sh 100 600 burst
ramp: 10 new clients/second; tests sustained 100 simultaneous SSE and reduces Cloud Shell launch spike.
burst: 100 start simultaneously (like old version). Run after ramp result is understood.
Status includes error_samples, errors_by_stage, actual active SSE, peak active SSE, initial put.
Background process survives browser page switches only while Cloud Shell VM stays running.
Auto-stop <= 15 mins. No limits exceed requested 100 clients. Blaze may incur usage.
Important: 100 SSE clients running here do not equal 100 real browsers executing JavaScript.
For organizer journey, manually open your signed-in host page and test home -> event under load.
