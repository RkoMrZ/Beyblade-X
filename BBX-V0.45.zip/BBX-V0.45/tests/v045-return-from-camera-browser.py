#!/usr/bin/env python3
"""V0.45 browser regression, isolated Firebase stubs: camera return and safe sheet restore.
No requests to production Firebase. A local loopback origin is only for Web Storage.
"""
from pathlib import Path
import shutil,json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
code=(root/'assets/index-v045.js').read_text()
def pick(start,end):
 a=code.index(start);b=code.index(end,a)
 return code[a:b]
logic='\n'.join([
 pick('function canEditMatchScore(m){','async function refreshEventBeforeCriticalAction'),
 pick("const ACTIVE_MATCH_SHEET_KEY='bx_v045_active_match_sheet';",'function matchSheetContext(){'),
 pick('async function resyncCurrentCloudEventOnForeground(reason=',"window.addEventListener('pageshow',e=>")
])
html='''<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">
<div id=admin><div id=bracketTab></div></div>
<div id=matchModal class=hidden><div id=matchSheet><button class=sheetClose>✕</button><button id=scoreBtn>＋1</button></div></div>'''
fixture=r'''
window.$=id=>document.getElementById(id);
window.ev={id:'E1',ownerUid:'U1',testOnly:false,releaseTag:'BBX-V0.11',authorityBBX:'active',
  roster:['A','B'],rounds:[{matches:[{a:'A',b:'B',sa:0,sb:0,matchVersion:1,referee:'裁判 1',refereeActive:true,claimUid:'U1',winner:null}]}],
  finalRR:null,publishedSeq:2,structureVersion:1,publishedStructureVersion:1,refereeClaims:{'0':{uid:'U1'}}};
window.fbAuth={currentUser:{uid:'U1'}};window.fbUser=fbAuth.currentUser;
window.isAdmin=true;window.isReferee=false;window.cloudEventsCache={};window.currentAdminTab='bracket';
window.confirmedRefereeClaimsContext='E1:U1';window.refereeClaimsStreamRevision=0;
window.cloudResyncBlocked=false;window.foregroundCloudResyncBusy=false;window.foregroundCloudResyncLastAt=0;
window.cloudUnsub=null;window.v05ScoreQueues=new Map();window.v05ScorePending=()=>false;window.v05FlushScores=async()=>{};
window.projectedStructureOf=e=>e.structureVersion===e.publishedStructureVersion?e.structureVersion:null;
window.sameProjectedStructure=(a,b)=>a.structureVersion===b.structureVersion;
window.isV1Authority=()=>true;window.currentRefereeName=()=> '裁判 1';
window.refereeClaimsConfirmed=()=>confirmedRefereeClaimsContext==='E1:U1';
window.confirmRefereeClaims=()=>{confirmedRefereeClaimsContext='E1:U1'};
window.normalizeRefereeClaimsData=x=>x||{};
window.preserveVerifiedRaffleOnOldEventSnapshot=(latest)=>latest;
window.renderHeaderAuth=()=>{};window.waitForAuthRestore=async()=>{};
window.getRestIdToken=async()=> 'token';window.backgroundedCalls=0;
window.renderAdmin=()=>{};window.showTab=t=>{currentAdminTab=t};
window.listenCloudEvent=()=>{window.listenCalls=(window.listenCalls||0)+1};
window.bracketScale=1;window.setBracketScale=()=>{};window.drawBracketLinks=()=>{};
window.closeScorePicker=()=>{};window.closeResetChoice=()=>{};
window.openCalls=0;
window.openMatchEditor=(ri,mi)=>{openCalls++;const m=ev.rounds[ri].matches[mi];
  $('matchModal').classList.remove('hidden');
  $('matchSheet').innerHTML=`<button class=sheetClose>✕</button><button id=scoreBtn>＋1</button><span id=scoreValue>${m.sa}</span>`;
  rememberActiveMatchSheet('round',ri,mi,m);
};
window.openRRMatch=i=>{openCalls++;};
window.latest=null;window.shouldFailReads=false;
window.rtdbRestGet=async path=>{if(shouldFailReads)throw new Error('offline');
  if(path.startsWith('refereeClaims/'))return JSON.parse(JSON.stringify(latest.refereeClaims));
  if(path.startsWith('events/'))return JSON.parse(JSON.stringify(latest));return null;};
'''
storage_shim=r"""
function fakeStorage(seed={}){const data=new Map(Object.entries(seed));return {
 getItem(k){return data.get(k)??null},setItem(k,v){data.set(k,String(v))},
 removeItem(k){data.delete(k)},clear(){data.clear()}};}
Object.defineProperty(window,'localStorage',{configurable:true,value:fakeStorage(window.__seed||{})});
Object.defineProperty(window,'sessionStorage',{configurable:true,value:fakeStorage()});
"""
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox','--no-zygote'])
  for width in [375,390,412,1366]:
   page=browser.new_page(viewport={'width':width,'height':760},is_mobile=width<500,has_touch=width<500)
   page.set_content(html)
   page.add_style_tag(content='.hidden{display:none!important}')
   page.add_script_tag(content=storage_shim+'\n'+fixture+'\n'+logic)
   page.evaluate('openMatchEditor(0,0);latest=JSON.parse(JSON.stringify(ev));latest.rounds[0].matches[0].sa=2;latest.rounds[0].matches[0].matchVersion=2;')
   assert page.evaluate('!!readActiveMatchSheet()')
   assert page.evaluate('openCalls')==1
   assert page.evaluate('resyncCurrentCloudEventOnForeground("camera")') is True
   assert page.evaluate('openCalls')==2
   assert page.locator('#matchModal').is_visible()
   assert page.locator('#scoreValue').inner_text()=='2'
   assert page.evaluate('cloudResyncBlocked') is False
   record=page.evaluate('localStorage.getItem("bx_v045_active_match_sheet")')
   page.close()
   # Fresh JS environment, same UID and same saved locator: no score is restored from storage.
   page=browser.new_page(viewport={'width':width,'height':760},is_mobile=width<500,has_touch=width<500)
   page.set_content(html)
   page.add_style_tag(content='.hidden{display:none!important}')
   page.add_script_tag(content='window.__seed='+json.dumps({'bx_v045_active_match_sheet':record})+';'+storage_shim+'\n'+fixture+'\n'+logic)
   assert page.evaluate('readActiveMatchSheet().eventId')=='E1'
   assert page.evaluate('restoreActiveMatchSheetIfSafe()') is True
   assert page.locator('#matchModal').is_visible()
   assert page.evaluate('openCalls')==1
   # Guard role / claim UID: never resume if same index belongs to another judge.
   page.evaluate("ev.rounds[0].matches[0].claimUid='U2'; ev.rounds[0].matches[0].referee='裁判 2';")
   assert page.evaluate('restoreActiveMatchSheetIfSafe()') is False
   assert page.locator('#matchModal').is_hidden()
   assert page.evaluate('readActiveMatchSheet()') is None
   # A network outage keeps the sheet visible, but disables all score commands.
   page.evaluate("ev.rounds[0].matches[0].claimUid='U1';ev.rounds[0].matches[0].referee='裁判 1'; openMatchEditor(0,0);latest=JSON.parse(JSON.stringify(ev));shouldFailReads=true;")
   assert page.evaluate('resyncCurrentCloudEventOnForeground("camera-offline")') is False
   assert page.locator('#matchModal').is_visible()
   assert page.locator('#matchSyncPending').is_visible()
   assert page.locator('#scoreBtn').is_disabled()
   assert page.evaluate('cloudResyncBlocked') is True
   # Later resumed full cloud check reactivates same match.
   page.evaluate('shouldFailReads=false;foregroundCloudResyncLastAt=0')
   assert page.evaluate('resyncCurrentCloudEventOnForeground("back-online")') is True
   assert page.locator('#matchModal').is_visible()
   assert not page.locator('#scoreBtn').is_disabled()
   page.close()
   print(f'PASS {width}px: camera background return, cloud score refresh, tab eviction, role revoke, offline read-only, retry')
  browser.close()
finally:
 pass
