#!/usr/bin/env python3
"""V0.45: the one roster redraw action must never be a silent disabled button."""
from pathlib import Path
import shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
js=(root/'assets/index-v045.js').read_text()
def pick(a,b):return js[js.index(a):js.index(b,js.index(a))]
code=pick('function renderRoster(){','function closeRaffleWinnerModal(')
head='''<!doctype html><html><head><meta name=viewport content="width=device-width,initial-scale=1"></head>
<body><div id=rosterTab></div></body></html>'''
mock='''
window.$=id=>document.getElementById(id);window.esc=s=>String(s).replaceAll('"','&quot;');
window.ev={id:'E1',releaseTag:'BBX-V0.11',authorityBBX:'active',testOnly:false,roster:['A','B','C','D'],
 rounds:[{matches:[{a:'A',b:'B',sa:'',sb:'',winner:null,refereeActive:false},{a:'C',b:'D',sa:'',sb:'',winner:null,refereeActive:false}]}],publishedSeq:1,structureVersion:1,publishedStructureVersion:1};
window.currentAdminTab='roster';window.hasOrganizerAccess=()=>true;window.cloudResyncBlocked=false;
window.projectedStructureOf=()=>1;window.pendingPublications=new Map();window.rosterWrites=new Set();
window.isV1Authority=()=>true;window.calls=0;
window.v1OrganizerAction=async a=>{calls++;return true};
window.backgroundRefreshCurrentEvent=async()=>{};
window.alert=()=>{};
'''
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 for width in (375,390,412,1366):
  page=browser.new_page(viewport={'width':width,'height':760},has_touch=width<500,is_mobile=width<500)
  page.set_content(head)
  page.add_script_tag(content=mock+code+'\nrenderRoster();')
  btn=page.get_by_role('button',name='依目前名單重新抽籤比賽順序')
  assert btn.is_enabled()
  if width<500:btn.tap()
  else:btn.click()
  assert page.evaluate('calls')==1
  assert '已提交' in page.locator('#rosterRebuildStatus').inner_text()
  page.evaluate('pendingPublications.set(ev.id,{seq:5});updateRosterControls()')
  assert btn.is_enabled()
  btn.click()
  assert page.evaluate('calls')==1
  assert '上一筆操作' in page.locator('#rosterRebuildStatus').inner_text()
  page.evaluate('pendingPublications.clear();ev.rounds[0].matches[0].refereeActive=true;updateRosterControls()')
  assert btn.is_enabled()
  btn.click()
  assert page.evaluate('calls')==1
  assert '不能重新抽籤' in page.locator('#rosterRebuildStatus').inner_text()
  page.evaluate('ev.rounds[0].matches[0].refereeActive=false;rosterWrites.add(ev.id);updateRosterControls()')
  assert btn.is_enabled()
  btn.click()
  assert page.evaluate('calls')==1
  assert '上一筆名單' in page.locator('#rosterRebuildStatus').inner_text()
  page.close()
  print('PASS',width,'roster redraw actionable, synchronous guard, pending publish and active match protection')
 browser.close()
