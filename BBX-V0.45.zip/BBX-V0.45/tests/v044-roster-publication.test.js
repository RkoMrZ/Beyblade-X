'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {randomBytes}=require('node:crypto');
const O=require('../functions/bbx-v011-organizer');
const C=require('../functions/bbx-v011-core');
const P=require('../functions/bbx-v011-publication');
const now=Date.now(),id='LOCAL_V044';
const op=()=>now.toString(16).padStart(12,'0')+randomBytes(18).toString('hex');
function fixture(names=['甲','乙','丙','丁'],size='auto16'){
 const mode='free',freeFinal=O.deriveFormat(names.length).freeFinal;
 return {ownerUid:'owner',roster:names,mode,freeFinal,formatPolicy:size,pairing:'ordered',seq:8,structureVersion:2,
  raffleState:{winners:['甲'],checked:{甲:false,乙:false}},...O.build(names,mode,freeFinal,null,{formatPolicy:size})};
}
const request=(action,extra={})=>({opId:op(),action,expectedSeq:1,expectedStructureVersion:2,...extra});
const send=(b,req)=>O.apply(b,'owner',req,now,{});
const path=(p)=>`events/${id}/${p}`;
const publicPath=(p)=>`publicEvents/${id}/${p}`;
const rtdb=x=>Array.isArray(x)?(x.length?x.map(rtdb):null):x&&typeof x==='object'?Object.fromEntries(Object.entries(x).flatMap(([k,v])=>{const value=rtdb(v);return value===null?[]:[[k,value]]})):x;
test('numeric-looking string 001 is added once and identical receipt replays even after seq/epoch advance',()=>{
 const b=fixture(), req=request('addPlayer',{value:'001'}), a=send(b,req);
 assert.equal(a.board.roster.at(-1),'001');assert.equal(a.board.roster.length,5);
 assert.equal(a.board.seq,9);assert.equal(a.board.structureVersion,3);
 assert.deepEqual(send(a.board,req).receipt,a.result);
 assert.throws(()=>send(a.board,request('addPlayer',{expectedStructureVersion:3,value:'001'})),{code:'already-exists'});
 assert.throws(()=>send(a.board,request('addPlayer',{value:'001'})),{code:'aborted'});
});
test('unrelated global seq is ignored, but stale roster indexes and active judging are still protected',()=>{
 const b=fixture();
 assert.throws(()=>send(b,request('delPlayer',{index:0,expectedStructureVersion:1})),{code:'aborted'});
 b.rounds[0].matches[0].refereeActive=true;
 assert.throws(()=>send(b,request('randomRebuild')),{code:'failed-precondition'});
 assert.throws(()=>send(b,request('addPlayer',{value:'001'})),{code:'failed-precondition'});
});
test('one reshuffle changes order, preserves membership and does not change any prize raffle data',()=>{
 const b=fixture(),a=send(b,request('randomRebuild'));
 assert.notDeepEqual(a.board.roster,b.roster);
 assert.deepEqual([...a.board.roster].sort(),[...b.roster].sort());
 assert.deepEqual(a.board.raffleState,b.raffleState);
});
test('RTDB-omitted RR deletion is projected privately and publicly before cursor advances',()=>{
 const b=fixture(['甲','乙','丙']);
 const a=send(b,request('addPlayer',{value:'001'}));
 const item=rtdb(Object.values(a.board.outbox)[0]);
 assert.equal(item.changes.find(c=>c.path==='finalRR').publicValue,undefined);
 const patch=P.buildProjectionPatch(id,item);
 assert.equal(patch[path('finalRR')],null);assert.equal(patch[publicPath('finalRR')],null);
 assert.equal(patch[path('publishedStructureVersion')],3);assert.equal(patch[path('publishedSeq')],9);
 assert.equal(patch[path('structureVersion')],undefined);
});
test('RTDB-omitted knockout deletion publishes the new direct three-person RR',()=>{
 const a=send(fixture(),request('delPlayer',{index:3}));
 const item=rtdb(Object.values(a.board.outbox)[0]);
 const patch=P.buildProjectionPatch(id,item);
 assert.equal(patch[path('rounds')],null);assert.equal(patch[publicPath('rounds')],null);
 assert.equal(patch[path('finalRR')].matches.length,3);assert.equal(patch[publicPath('finalRR')].matches.length,3);
});
test('historical null-omitted items also repair downstream deleted matches, but malformed present values do not silently delete',()=>{
 for(const p of ['rounds/0/matches/1','finalRR/matches/1','finalRR/players']){
  const patch=P.buildProjectionPatch(id,{seq:9,changes:[{path:p}]});
  assert.equal(patch[path(p)],null);assert.equal(patch[publicPath(p)],null);
 }
 assert.throws(()=>P.buildProjectionPatch(id,{seq:9,changes:[{path:'finalRR',value:{players:['A','B','C']}}]}),/MISSING_PUBLIC_VALUE/);
 assert.throws(()=>P.buildProjectionPatch(id,{seq:9,changes:[{path:'roster'}]}),/MISSING_PUBLIC_VALUE/);
});
test('RTDB-omitted empty fields on an old normal bracket do not become unrelated structural deletions',()=>{
 const b=rtdb(fixture());
 const a=send(b,request('addPlayer',{value:'001'}));
 assert.equal(a.changes.some(c=>c.path==='finalRR'),false);
});
test('old match client cannot claim different players at a reused slot',()=>{
 const a=send(fixture(),request('randomRebuild'));
 assert.throws(()=>C.apply(a.board,'owner',{opId:op(),action:'claim',target:{kind:'round',ri:0,mi:0},
  expectedStructureVersion:2,expectedMatchVersion:0,referee:'裁判 1'},now,{owner:true}),{code:'aborted'});
});
