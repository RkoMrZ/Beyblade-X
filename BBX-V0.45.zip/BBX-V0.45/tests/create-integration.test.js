'use strict';
const assert=require('node:assert/strict');
const test=require('node:test');
const Module=require('node:module');
const originalLoad=Module._load;
process.env.GCLOUD_PROJECT='ljt-beyblade-x';
const COPY=v=>v===undefined?undefined:JSON.parse(JSON.stringify(v));
// Mimic Firebase RTDB path/value key validation (mock previously accepted '.').
// This reproduces the production-only V0.5 CREATE failure caused by the
// registry.releases['BBX-V0.5'] object property: a period is illegal in a key.
function validateRtdb(value,path=''){
 if(value===null||typeof value!=='object')return;
 for(const [k,v] of Object.entries(value)){
  if(/[.#$\[\]\/\x00-\x1f\x7f]/.test(k))throw Error('RTDB_INVALID_KEY '+path+'/'+k);
  validateRtdb(v,path+'/'+k);
 }
}
const store={};
let deleteBeforeSeq=false;
const transactions=[];const writes=[];const readPaths=[];const lockReads={fullBoard:0,seq:0};
function parts(p){return String(p||'').split('/').filter(Boolean)}
function getAt(path){let n=store;for(const k of parts(path)){if(!n||typeof n!=='object'||!(k in n))return null;n=n[k]}return COPY(n)}
function setAt(path,v){validateRtdb(v,path);let a=parts(path),o=store;for(let i=0;i<a.length-1;i++){o[a[i]]??={};o=o[a[i]]}if(v===null)delete o[a.at(-1)];else o[a.at(-1)]=COPY(v)}
class Ref{
 constructor(p=''){this.p=p}
 child(n){return new Ref(this.p+'/'+n)}
 async get(){
  readPaths.push(this.p);
  const match=this.p.match(/^authorityBBXV011\/([^/]+)\/board(\/seq)?$/);
  if(match?.[2]&&deleteBeforeSeq){deleteBeforeSeq=false;setAt(`authorityBBXV011/${match[1]}/board`,null);setAt(`events/${match[1]}`,null);}
  if(match&&getAt(`authorityBBXV011/${match[1]}/operationLock`)?.token){
   if(match[2])lockReads.seq++;else lockReads.fullBoard++;
  }
  return new Snap(getAt(this.p))
 }
 on(){}
 off(){}
 async once(){return this.get()}
 orderByChild(){return this}
 limitToFirst(){return this}
 async set(v){setAt(this.p,v)}
 async update(up){for(const [k,v] of Object.entries(up))validateRtdb(v,this.p+'/'+k);for(const [k,v] of Object.entries(up)){writes.push(this.p+'/'+k);setAt(this.p+'/'+k,v)}}
 async transaction(change){transactions.push(this.p);const current=getAt(this.p);const res=change(COPY(current));if(res===undefined)return {committed:false,snapshot:new Snap(current)};setAt(this.p,res);return {committed:true,snapshot:new Snap(getAt(this.p))}}
}
class Snap{constructor(v){this.v=v}val(){return COPY(this.v)}exists(){return this.v!==null&&this.v!==undefined}}
const fakeDb={ref:p=>new Ref(p)};
class HttpsError extends Error{constructor(code,message){super(message);this.code=code}}
Module._load=function(request,parent,isMain){
 if(parent?.filename?.endsWith('/functions/index.js')){
  if(request==='firebase-admin')return {initializeApp(){},database:()=>fakeDb};
  if(request==='firebase-functions/v2/https')return {onCall:(_opt,fn)=>fn,HttpsError};
  if(request==='firebase-functions/v2/database')return {onValueWritten:(_opt,fn)=>fn};
  if(request==='firebase-functions/v2/scheduler')return {onSchedule:(_opt,fn)=>fn};
 }
 return originalLoad.apply(this,arguments);
};
const f=require('../functions/index.js');Module._load=originalLoad;
function op(){return Date.now().toString(16).padStart(12,'0')+'d'.repeat(36)}
function request(data,uid='owner',google=true){return {data:{clientVersion:'bbx-v0.11-authority-1',...(data?.target?{expectedStructureVersion:0}:{}),...data},auth:uid?{uid,token:{firebase:{sign_in_provider:google?'google.com':'anonymous'}}}:null}}
const roster=['A','B','C','D'];const make=opId=>request({opId,name:'Test Event',roster,mode:'single',pairing:'ordered',freeFinal:'champ'});
let eventId;
test('atomic server CREATE writes owner index / private / public / board together',async()=>{
 const result=await f.bbxV011CreateAuthority(make(op()));assert.equal(result.ok,true);eventId=result.eventId;
 assert.equal(result.slot,'0');assert.equal(result.eventId.startsWith('B10_'),true);
 assert.equal(getAt('events/'+eventId+'/releaseTag'),'BBX-V0.11');
 assert.deepEqual(getAt('bbxEventCleanupRegistry/'+eventId+'/releases'),['BBX-V0.11']);
 assert.equal(getAt('events/'+eventId+'/authorityBBX'),'active');
 assert.equal(getAt('publicEvents/'+eventId+'/meta/id'),eventId);
 assert.equal(getAt('userEvents/owner/0'),eventId);
 assert.equal(getAt('authorityBBXV011/'+eventId+'/board/seq'),0);
 assert.equal(getAt('authorityBBXV011/'+eventId+'/board/rounds/0/matches/0/a'),'A');
 assert.equal(getAt('admins/'+eventId+'/owner')!==null,true);
 assert.equal(getAt('bbxV011CreateLocks/owner'),null);
});
test('same create operation is idempotent and does not allocate another slot',async()=>{
 const id='d'.repeat(36),o=Date.now().toString(16).padStart(12,'0')+id;
 const a=await f.bbxV011CreateAuthority(make(o));const b=await f.bbxV011CreateAuthority(make(o));
 assert.equal(a.eventId,b.eventId);assert.equal(b.existing,true);assert.equal(b.slot,'1');
});
test('new request increments owner slot, but fourth create is refused',async()=>{
 await f.bbxV011CreateAuthority(make(op().slice(0,12)+'e'.repeat(36)));
 await assert.rejects(()=>f.bbxV011CreateAuthority(make(op().slice(0,12)+'f'.repeat(36))),e=>e.code==='resource-exhausted');
 assert.equal(Object.keys(getAt('userEvents/owner')).length,3);
});
test('anonymous and non-Google cannot create authoritative event',async()=>{
 await assert.rejects(()=>f.bbxV011CreateAuthority(request(make(op()).data,null)),e=>e.code==='unauthenticated');
 await assert.rejects(()=>f.bbxV011CreateAuthority(request(make(op()).data,'bad',false)),e=>e.code==='permission-denied');
});
test('server score/claim advances one match and rejects old matchVersion',async()=>{
 const a=await f.bbxV011CommandAuthority(request({eventId,opId:op(),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'}));
 assert.equal(a.ok,true);
 assert.equal(a.matchVersion,1);
 assert.equal(a.published,true); assert.equal(getAt(`events/${eventId}/rounds/0/matches/0/referee`),'裁判 1'); assert.equal(getAt(`authorityBBXV011/${eventId}/board/rounds/0/matches/0/referee`),'裁判 1');
 await assert.rejects(()=>f.bbxV011CommandAuthority(request({eventId,opId:op().slice(0,12)+'b'.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,sa:4,sb:1})),e=>e.code==='aborted');
 const s=await f.bbxV011CommandAuthority(request({eventId,opId:op().slice(0,12)+'c'.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:1,sa:4,sb:1}));assert.equal(s.ok,true);
 assert.equal(getAt(`authorityBBXV011/${eventId}/board/rounds/0/matches/0/sa`),4); assert.equal(getAt(`publicEvents/${eventId}/rounds/0/matches/0/sa`),4);
 assert.equal(transactions.some(p=>p.endsWith('/board')),false,'the private board must never be transacted wholesale');
 assert.equal(writes.includes(`authorityBBXV011/${eventId}/board/rounds`),false,'score must not write the entire rounds tree');
 assert.ok(writes.some(p=>p.endsWith('/board/rounds/0/matches/0/sa')),'score writes its match leaf');
});
test('private match read and public projection both reflect confirmed score and denies strangers',async()=>{
 const target={kind:'round',ri:0,mi:0};
 const privateMatch=(await f.bbxV011GetOperation(request({eventId,readMatch:true,target}))).match;
 assert.equal(privateMatch.sa,4);assert.equal(privateMatch.sb,1);
 assert.equal(privateMatch.matchVersion,2);
 assert.equal(privateMatch.refereeActive,true);
 assert.equal('claimUid' in privateMatch,false,'do not expose private referee UID');
 assert.equal(getAt(`publicEvents/${eventId}/rounds/0/matches/0/sa`),4,'public projection must already be confirmed');
 await assert.rejects(()=>f.bbxV011GetOperation(request({eventId,readMatch:true,target},'stranger',false)),e=>e.code==='permission-denied');
 await assert.rejects(()=>f.bbxV011GetOperation(request({eventId,readMatch:true,target:{kind:'round',ri:77,mi:5}})),e=>e.code==='invalid-argument');
 await assert.rejects(()=>f.bbxV011GetOperation(request({eventId,readMatch:true,target:{kind:'round',ri:12,mi:5}})),e=>e.code==='not-found');
});
test('publish runs with separate lease and drains ordered outbox',async()=>{
 assert.equal(getAt(`authorityBBXV011/${eventId}/board/seq`),2);
 assert.equal(getAt(`authorityBBXV011/${eventId}/publishedSeq`),2);
 const r=await f.bbxV011PublishAuthority({params:{eventId},data:{after:new Snap(2)}});
 assert.equal(r,undefined);
 assert.equal(getAt(`authorityBBXV011/${eventId}/publishedSeq`),2);
 assert.equal(getAt(`events/${eventId}/rounds/0/matches/0/referee`),'裁判 1');
 assert.equal(getAt(`publicEvents/${eventId}/rounds/0/matches/0/sa`),4);
 assert.equal(getAt(`authorityBBXV011/${eventId}/publishing`),null);
 assert.equal(getAt(`authorityBBXV011/${eventId}/operationLock`),null);
 // Publisher should only inspect the minimal authority gate; never GET the
 // complete event (including roster, bracket and scores) for each outbox item.
 assert.ok(readPaths.includes(`events/${eventId}/authorityBBX`));
 assert.ok(readPaths.includes(`events/${eventId}/releaseTag`));
 assert.ok(!readPaths.includes(`events/${eventId}`) || readPaths.lastIndexOf(`events/${eventId}`)<readPaths.lastIndexOf(`events/${eventId}/releaseTag`),
   'no full event read while publishing increments');
});
test('occupied publication lease retries without locking organizer writes',async()=>{
 const path=`authorityBBXV011/${eventId}/publishing`;
 setAt(path,{token:'someone-else',expiresAt:Date.now()+60000});
 const opId=op().slice(0,12)+'9'.repeat(36);
 const a=await f.bbxV011OrganizerAuthority(request({eventId,opId,expectedSeq:2,action:'closePublic'}));
 assert.equal(a.ok,true);assert.equal(a.publicationPending,true);
 assert.equal(getAt(`authorityBBXV011/${eventId}/board/publicOpen`),false);
 assert.equal(getAt(`publicEvents/${eventId}/meta/publicOpen`),false);
 await f.bbxV011PublishAuthority({params:{eventId},data:{after:new Snap(3)}});
 assert.equal(getAt(`bbxV011PublicationPending/${eventId}/seq`),3);
 assert.equal(getAt(path).token,'someone-else');
 setAt(path,{token:'expired',expiresAt:Date.now()-1000});
 await f.bbxV011PublishAuthority({params:{eventId},data:{after:new Snap(3)}});
 assert.equal(getAt(`publicEvents/${eventId}/meta/publicOpen`),false);
 assert.equal(getAt(`authorityBBXV011/${eventId}/publishedSeq`),3);
});
test('different tournaments do not share command locks',async()=>{
 const r=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'2'.repeat(36),name:'Other tournament',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'isolated'));
 const other=r.eventId;
 setAt(`authorityBBXV011/${eventId}/operationLock`,{token:'other-event-working',expiresAt:Date.now()+60000});
 const out=await f.bbxV011CommandAuthority(request({eventId:other,opId:op().slice(0,12)+'3'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},'isolated'));
 assert.equal(out.ok,true);
 assert.equal(getAt(`authorityBBXV011/${eventId}/operationLock`).token,'other-event-working');
 setAt(`authorityBBXV011/${eventId}/operationLock`,null);
});
test('old release client version cannot operate V0.6 event',async()=>{
 await assert.rejects(()=>f.bbxV011CommandAuthority({data:{clientVersion:'bbx-v0.3-authority-1',eventId,action:'claim'},auth:request({}).auth}),e=>e.code==='failed-precondition');
});
test('orphaned slot from prior failed release can be reclaimed without deleting existing events',async()=>{
 setAt('userEvents/newowner/0','ORPHAN_OLD_A');
 const made=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'a'.repeat(36),name:'Clean old orphan',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'newowner'));
 assert.equal(made.slot,'0');assert.equal(getAt('userEvents/newowner/0'),made.eventId);
 assert.equal(getAt('userEvents/owner/0'),eventId);
});
test('server deletion is scoped, serialized against publisher and removes private/public/index together',async()=>{
 const removed=await f.bbxV011DeleteAuthority(request({eventId}));
 assert.deepEqual(removed,{ok:true,deleted:true,verified:true});
 for(const p of [`events/${eventId}`,`publicEvents/${eventId}`,`authorityBBXV011/${eventId}`,'userEvents/owner/0'])assert.equal(getAt(p),null,p);
 assert.ok(getAt('userEvents/owner/1'),'other existing event untouched');
 assert.ok(getAt('events/'+getAt('userEvents/owner/1')),'other event still exists');
});
test('V0.6 callable deletes an owned orphan V0.4 tournament without deleting another event',async()=>{
 const eid='B4_0f1edf53b9_test';
 setAt(`events/${eid}`,{id:eid,ownerUid:'legacy-owner',releaseTag:'BBX-V0.4',authorityBBX:'active',name:'old test'});
 setAt(`authorityBBXV04/${eid}/board`,{seq:2,deleted:false});
 setAt(`authorityBBXV04/${eid}/operationLock`,{token:'expired-old',until:Date.now()-100000});
 setAt(`authorityBBXV04/${eid}/publishing`,{token:'expired-old-publication',expiresAt:Date.now()-100000});
 setAt(`publicEvents/${eid}`,{meta:{publicOpen:true}});
 setAt(`authorityBBX/${eid}`,{oldReceipt:'residual'});
 setAt(`authorityBBXV011/${eid}`,{oldReceipt:'erroneous-cross-version'});
 setAt(`bbxV011PublicationPending/${eid}`,{seq:2,updatedAt:Date.now()});
 setAt(`refereeUsers/${eid}/someone`,{active:true});
 setAt(`refereeSecrets/${eid}/someone`,'legacy-secret');
 setAt(`admins/${eid}/legacy-owner`,'owner-access');
 setAt('bbxV04CreateLocks/legacy-owner',{token:'other-create',until:Date.now()+25000});
 setAt(`secrets/${eid}`,{adminCode:'123456'});
 setAt(`refereeClaims/${eid}`,{ref1:{uid:'someone'}});
 setAt('userEvents/legacy-owner/0',eid);
 setAt('userEvents/legacy-owner/1','BBX_EXISTING_PROTECTED');
 setAt('events/BBX_EXISTING_PROTECTED',{id:'BBX_EXISTING_PROTECTED',ownerUid:'legacy-owner',releaseTag:'BBX-V1.0'});
 await assert.rejects(()=>f.bbxV011DeleteAuthority(request({eventId:eid},'impostor')),e=>e.code==='permission-denied');
 await assert.rejects(()=>f.bbxV011DeleteAuthority(request({eventId:eid},'legacy-owner',false)),e=>e.code==='permission-denied');
 assert.ok(getAt(`events/${eid}`),'failed authentication must not delete anything');
 await assert.rejects(()=>f.bbxV011DeleteAuthority(request({eventId:'BBX_EXISTING_PROTECTED'},'legacy-owner')),e=>e.code==='permission-denied');
 const deleted=await f.bbxV011DeleteAuthority(request({eventId:eid},'legacy-owner'));
 assert.deepEqual(deleted,{ok:true,deleted:true,verified:true});
 for(const path of [`events/${eid}`,`publicEvents/${eid}`,`authorityBBXV04/${eid}`,`authorityBBXV011/${eid}`,`authorityBBX/${eid}`,`bbxV011PublicationPending/${eid}`,`refereeSecrets/${eid}`,`refereeUsers/${eid}`,`admins/${eid}`,`secrets/${eid}`,`refereeClaims/${eid}`,'userEvents/legacy-owner/0'])
  assert.equal(getAt(path),null,path);
 assert.equal(getAt('bbxV04CreateLocks/legacy-owner').token,'other-create','account-wide create lock must not be deleted');
 assert.equal(getAt('userEvents/legacy-owner/1'),'BBX_EXISTING_PROTECTED');
 assert.equal(getAt('events/BBX_EXISTING_PROTECTED/releaseTag'),'BBX-V1.0');
 assert.equal(getAt(`authorityBBXV011/${eid}`),null,'legacy cleanup must not create a new V0.6 authority');
});
test('retired V0.1-V0.3 staged and active events delete every namespaced artifact, but never V1.0',async()=>{
 for(const [i,version] of ['BBX-V0.1','BBX-V0.2','BBX-V0.3'].entries()){
  const eid=`OLD_RELEASE_${i}`;const uid=`prior-owner-${i}`;
  setAt(`events/${eid}`,{id:eid,ownerUid:uid,releaseTag:version,authorityBBX:i===0?null:'active'});
  for(const root of ['publicEvents','authorityBBX','authorityBBXV04','authorityBBXV011','bbxV011PublicationPending','refereeClaims','refereeUsers','refereeSecrets','secrets','admins'])
   setAt(`${root}/${eid}`,{v:version});
  setAt(`userEvents/${uid}/0`,eid);
  setAt(`userEvents/${uid}/1`,'OTHER_PROTECTED');
  await assert.rejects(()=>f.bbxV011DeleteAuthority(request({eventId:eid},'wrong-owner')),e=>e.code==='permission-denied');
  const removed=await f.bbxV011DeleteAuthority(request({eventId:eid},uid));
  assert.equal(removed.verified,true);
  for(const root of ['events','publicEvents','authorityBBX','authorityBBXV04','authorityBBXV011','bbxV011PublicationPending','refereeClaims','refereeUsers','refereeSecrets','secrets','admins'])
   assert.equal(getAt(`${root}/${eid}`),null,root+'/'+eid);
  assert.equal(getAt(`userEvents/${uid}/0`),null);
  assert.equal(getAt(`userEvents/${uid}/1`),'OTHER_PROTECTED');
 }
});
test('V0.6 deletion removes repair-hint and legacy crumbs without touching owner creation lock',async()=>{
 const uid='clean-v05-owner';
 const made=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'7'.repeat(36),name:'clean V05',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},uid));
 const eid=made.eventId;
 setAt(`authorityBBX/${eid}`,{version:'old orphan'});
 setAt(`authorityBBXV04/${eid}`,{version:'old orphan'});
 setAt(`bbxV011PublicationPending/${eid}`,{seq:5});
 setAt(`refereeClaims/${eid}/0`,{uid:'judge'});
 setAt(`refereeUsers/${eid}/judge`,true);
 setAt(`refereeSecrets/${eid}/judge`,'test');
 setAt(`bbxV011CreateLocks/${uid}`,{token:'creating-other-event',expiresAt:Date.now()+60000});
 const removed=await f.bbxV011DeleteAuthority(request({eventId:eid},uid));
 assert.equal(removed.verified,true);
 for(const root of ['events','publicEvents','authorityBBX','authorityBBXV04','authorityBBXV011','bbxV011PublicationPending','refereeClaims','refereeUsers','refereeSecrets','secrets','admins'])
  assert.equal(getAt(`${root}/${eid}`),null,root+'/'+eid);
 assert.equal(getAt(`userEvents/${uid}/0`),null);
 assert.equal(getAt(`bbxV011CreateLocks/${uid}/token`),'creating-other-event');
});
test('simultaneous stale score commands cannot both commit',async()=>{
 const r=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'8'.repeat(36),name:'Racing scoreboard',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'newowner'));
 const eid=r.eventId;
 await f.bbxV011CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+'1'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},'newowner'));
 const score=(ending,tail)=>f.bbxV011CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+tail.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:1,sa:ending,sb:1},'newowner'));
 const results=await Promise.allSettled([score(3,'2'),score(4,'3')]);
 assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
 assert.ok(['aborted','resource-exhausted'].includes(results.find(x=>x.status==='rejected').reason.code));
 assert.equal(getAt(`authorityBBXV011/${eid}/board/rounds/0/matches/0/matchVersion`),2);
});
test('durable scheduled repair drains a missed publication trigger without blocking a different tournament',async()=>{
 const user='repair-user';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'4'.repeat(36),name:'Repair test',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},user));
 const eid=created.eventId;
 setAt(`authorityBBXV011/${eid}/publishing`,{token:'busy-transport',expiresAt:Date.now()+60000});
 const claim=await f.bbxV011CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+'5'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},user));
 assert.equal(claim.seq,1);
 assert.equal(claim.publicationPending,true);
 setAt(`authorityBBXV011/${eid}/publishing`,null);
 assert.equal(getAt(`authorityBBXV011/${eid}/publishedSeq`),0);
 assert.equal(getAt(`bbxV011PublicationPending/${eid}/seq`),1);
 await f.bbxV011RepairQueue();
 assert.equal(getAt(`authorityBBXV011/${eid}/publishedSeq`),1);
 assert.equal(getAt(`bbxV011PublicationPending/${eid}`),null);
});
test('outbox sequence gap remains on repair queue and never skips publication cursor',async()=>{
 const user='missing-outbox-user';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'6'.repeat(36),name:'Lost record',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},user));
 const eid=created.eventId;
 setAt(`authorityBBXV011/${eid}/publishing`,{token:'busy-gap',expiresAt:Date.now()+60000});
 await f.bbxV011CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+'7'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},user));
 setAt(`authorityBBXV011/${eid}/publishing`,null);
 setAt(`authorityBBXV011/${eid}/board/outbox/000000000001`,null);
 await f.bbxV011PublishAuthority({params:{eventId:eid},data:{after:new Snap(1)}});
 assert.equal(getAt(`authorityBBXV011/${eid}/publishedSeq`),0);
 assert.equal(getAt(`bbxV011PublicationPending/${eid}/seq`),1);
});

// V0.6 concurrent court regression: preserve the original one-referee-per-
// match claim. Six DIFFERENT matches may prepare independently, but every
// shared sequence / outbox commit must still be atomic and gap-free.
test('six referees across six courts: claim, score and simultaneous advancement are lossless',async()=>{
 const owner='parallel-owner';
 const roster=Array.from({length:12},(_,i)=>`選手${i+1}`);
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'8',name:'六場同時執裁',roster,mode:'free',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const refNames=Array.from({length:6},(_,i)=>`裁判${i+1}`);
 for(let i=0;i<6;i++){
  setAt(`refereeUsers/${eid}/judge${i}`,true);
  setAt(`refereeClaims/${eid}/${i}`,{uid:`judge${i}`,name:refNames[i],claimedAt:Date.now()});
 }
 let nonce=10000;
 const uniqueOp=()=>Date.now().toString(16).padStart(12,'0')+(nonce++).toString(16).padStart(36,'0');
 const command=(i,action,expectedMatchVersion,extra={})=>f.bbxV011CommandAuthority(request({
  eventId:eid,opId:uniqueOp(),action,target:{kind:'round',ri:0,mi:i},expectedMatchVersion,...extra
 },`judge${i}`,false));
 for(const [action,version,extra] of [
  ['claim',0,i=>({referee:refNames[i]})],
  ['score',1,()=>({sa:4,sb:1})],
  ['complete',2,()=>({sa:4,sb:1})]
 ]){
  const outcomes=await Promise.allSettled(Array.from({length:6},(_,i)=>command(i,action,version,extra(i))));
  assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,6,
   `${action} rejected: ${outcomes.filter(x=>x.status==='rejected').map(x=>x.reason?.message)}`);
 }
 const root=`authorityBBXV011/${eid}/board`;
 assert.equal(getAt(`${root}/seq`),18);
 assert.equal(getAt(`authorityBBXV011/${eid}/publishedSeq`),18,'each confirmed command must publish promptly');
 assert.equal(Object.keys(getAt(`${root}/outbox`)||{}).length,0,'published outbox does not accumulate');
 for(let i=0;i<6;i++){
  const m=getAt(`${root}/rounds/0/matches/${i}`);
  assert.equal(m.matchVersion,3);assert.equal(m.winner,roster[i*2]);
  assert.equal(m.refereeActive,false);assert.equal(m.claimUid??null,null);
 }
 for(let i=0;i<3;i++){
  const next=getAt(`${root}/rounds/1/matches/${i}`);
  assert.equal(next.a,roster[i*4]);assert.equal(next.b,roster[i*4+2]);
 }
 await f.bbxV011PublishAuthority({params:{eventId:eid},data:{after:new Snap(18)}});
 await f.bbxV011PublishAuthority({params:{eventId:eid},data:{after:new Snap(18)}});
 assert.equal(getAt(`authorityBBXV011/${eid}/publishedSeq`),18);
 assert.equal(getAt(`bbxV011PublicationPending/${eid}`),null);
 for(let i=0;i<6;i++)assert.equal(getAt(`publicEvents/${eid}/rounds/0/matches/${i}/winner`),roster[i*2]);
});

test('two referee UIDs claiming SAME match cannot both become active',async()=>{
 const owner='same-court-owner';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'9',name:'互斥接手',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 for(const [slot,uid] of ['judge-a','judge-b'].entries()){
  setAt(`refereeUsers/${eid}/${uid}`,true);
  setAt(`refereeClaims/${eid}/${slot}`,{uid,name:uid,claimedAt:Date.now()});
 }
 const claims=['judge-a','judge-b'].map((uid,i)=>f.bbxV011CommandAuthority(request({
  eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+(i+501).toString(16).padStart(36,'0'),
  action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:uid
 },uid,false)));
 const results=await Promise.allSettled(claims);
 assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
 assert.equal(results.filter(x=>x.status==='rejected').length,1);
 const m=getAt(`authorityBBXV011/${eid}/board/rounds/0/matches/0`);
 assert.equal(m.matchVersion,1);
 assert.ok(['judge-a','judge-b'].includes(m.claimUid));
});


test('normal court command reads full board BEFORE lock and only verifies seq UNDER lock',async()=>{
 const owner='latency-owner';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'a',name:'快速正常路徑',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const before={...lockReads};
 const r=await f.bbxV011CommandAuthority(request({eventId:created.eventId,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'b',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},owner));
 assert.equal(r.ok,true);
 assert.equal(lockReads.fullBoard-before.fullBoard,0,'uncontended match prep must not download entire board under the write lock');
 assert.equal(lockReads.seq-before.seq,1,'atomic commit must compare the current event revision under lock');
});

test('bracket rebuild invalidates an old referee claim even if matchVersion resets to zero',async()=>{
 const owner='rebuild-owner';
 const roster=['紅','橙','黃','綠'];
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'c',name:'換籤版本保護',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const swap=await f.bbxV011OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'d',action:'swapPlayers',ri:0,i:0,j:2,expectedSeq:0},owner));
 assert.equal(swap.ok,true);
 const privateRoot=`authorityBBXV011/${eid}/board`;
 assert.equal(getAt(`${privateRoot}/structureVersion`),1);
 assert.equal(getAt(`events/${eid}/structureVersion`),1);
 assert.equal(getAt(`${privateRoot}/rounds/0/matches/0/matchVersion`),0);
 const stale=request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'e',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,expectedStructureVersion:0,referee:'裁判 1'},owner);
 await assert.rejects(()=>f.bbxV011CommandAuthority(stale),e=>e.code==='aborted');
 assert.equal(getAt(`${privateRoot}/rounds/0/matches/0/refereeActive`),false);
 const fresh=request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'f',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,expectedStructureVersion:1,referee:'裁判 1'},owner);
 const r=await f.bbxV011CommandAuthority(fresh);assert.equal(r.ok,true);
 assert.equal(getAt(`${privateRoot}/rounds/0/matches/0/matchVersion`),1);
});

test('close then reopen viewer access is immediate even while old publication is queued',async()=>{
 const owner='gate-owner';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'1',name:'公開權限交錯',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const old=await f.bbxV011OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'2',action:'closePublic',expectedSeq:0},owner));
 assert.equal(old.ok,true);
 assert.equal(getAt(`publicEvents/${eid}/meta/publicOpen`),false);
 const opened=await f.bbxV011OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'3',action:'extendPublic',expectedSeq:1},owner));
 assert.equal(opened.ok,true);
 assert.equal(getAt(`events/${eid}/publicOpen`),true);
 assert.equal(getAt(`publicEvents/${eid}/meta/publicOpen`),true);
 assert.equal(getAt(`authorityBBXV011/${eid}/publishedSeq`),2);
 await f.bbxV011PublishAuthority({params:{eventId:eid},data:{after:new Snap(2)}});
 assert.equal(getAt(`publicEvents/${eid}/meta/publicOpen`),true);
 assert.equal(getAt(`authorityBBXV011/${eid}/publishedSeq`),2);
});

test('concurrent bracket rebuild vs stale judge claim cannot both change incompatible state',async()=>{
 const owner='barrier-owner';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'4',name:'重編與執裁互斥',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const fnA=f.bbxV011OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'5',action:'swapPlayers',ri:0,i:0,j:2,expectedSeq:0},owner));
 const fnB=f.bbxV011CommandAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'6',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,expectedStructureVersion:0,referee:'裁判 1'},owner));
 const settled=await Promise.allSettled([fnA,fnB]);
 assert.equal(settled.filter(x=>x.status==='fulfilled').length,1,JSON.stringify(settled.map(x=>x.reason?.message)));
 assert.equal(settled.filter(x=>x.status==='rejected').length,1);
 const b=getAt(`authorityBBXV011/${eid}/board`);
 assert.equal(b.seq,1);
 if(b.structureVersion===1)assert.equal(b.rounds[0].matches[0].refereeActive,false);
 else assert.equal(b.rounds[0].matches[0].refereeActive,true);
});


let aliasTestEvent;
test('five-character public IDs are unique reserved aliases and never direct data keys',async()=>{
 const owner='alias-owner';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'7',name:'五碼代號',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 aliasTestEvent=created.eventId;
 const evt=getAt(`events/${aliasTestEvent}`);
 assert.match(evt.publicCode,/^[A-HJ-NP-Z2-9]{5}$/);
 assert.equal(getAt(`bbxPublicCodeLookup/${evt.publicCode}`),aliasTestEvent);
 assert.equal(getAt(`bbxEventCleanupRegistry/${aliasTestEvent}/eventId`),aliasTestEvent);
 assert.equal(getAt(`bbxEventCleanupRegistry/${aliasTestEvent}/originVersion`),'BBX-V0.11');
 assert.equal(getAt(`bbxPublicCodeReservations/${evt.publicCode}/state`),'active');
 assert.equal(getAt(`events/${evt.publicCode}`),null);
});
test('legacy V0.4 event may receive an alias without changing its real ID or version',async()=>{
 const legacy='B4_previous_tournament';const uid='legacy-owner';
 setAt(`events/${legacy}`,{id:legacy,ownerUid:uid,releaseTag:'BBX-V0.4',authorityBBX:'active',created:Date.now()});
 setAt(`userEvents/${uid}/0`,legacy);
 const result=await f.bbxV011AssignPublicCode(request({eventId:legacy},uid));
 assert.match(result.publicCode,/^[A-HJ-NP-Z2-9]{5}$/);
 assert.equal(getAt(`events/${legacy}/releaseTag`),'BBX-V0.4');
 assert.equal(getAt(`bbxEventCleanupRegistry/${legacy}/originVersion`),'BBX-V0.4');
 assert.equal(getAt(`bbxPublicCodeLookup/${result.publicCode}`),legacy);
 const repeated=await f.bbxV011AssignPublicCode(request({eventId:legacy},uid));
 assert.equal(repeated.publicCode,result.publicCode);
 await assert.rejects(()=>f.bbxV011AssignPublicCode(request({eventId:legacy},'intruder')),e=>e.code==='permission-denied');
});
test('owner deletion removes legacy event, alias, historical roots, slot and code reservation, preserving only replay guard',async()=>{
 const legacy='B4_previous_tournament';const uid='legacy-owner';
 const code=getAt(`events/${legacy}/publicCode`);
 setAt(`authorityBBX/${legacy}`,{ownerUid:uid,legacy:'test'});
 setAt(`admins/${legacy}/${uid}`,'test');
 setAt(`publicEvents/${legacy}/rounds`,{});
 const result=await f.bbxV011DeleteAuthority(request({eventId:legacy},uid));
 assert.equal(result.verified,true);
 for(const root of require('../functions/bbx-v011-cleanup').EVENT_ROOTS)
  assert.equal(getAt(`${root}/${legacy}`),null,'residual: '+root);
 assert.equal(getAt(`userEvents/${uid}/0`),null);
 assert.equal(getAt(`bbxPublicCodeLookup/${code}`),null);
 assert.deepEqual(getAt(`bbxEventCleanupRegistry/${legacy}`),{status:'deleted',verified:true});
 assert.equal(getAt(`bbxPublicCodeReservations/${code}`),null);
});
test('cross-account malicious delete request cannot touch another event',async()=>{
 await assert.rejects(()=>f.bbxV011DeleteAuthority(request({eventId:aliasTestEvent},'not-original-owner')),e=>e.code==='permission-denied');
 assert.equal(getAt(`events/${aliasTestEvent}/ownerUid`),'alias-owner');
});

test('interrupted deletion safely resumes from private registry after main event disappeared',async()=>{
 const eid=aliasTestEvent,uid='alias-owner';
 const code=getAt(`events/${eid}/publicCode`);
 assert.ok(code,'fixture was created with short code');
 setAt(`bbxEventCleanupRegistry/${eid}/status`,'deleting');
 setAt(`events/${eid}`,null); // simulate after atomic deletion but before verification
 setAt(`userEvents/${uid}/0`,'B6_DIFFERENT_NEW_EVENT');
 const done=await f.bbxV011DeleteAuthority(request({eventId:eid},uid));
 assert.equal(done.recovered,true);
 assert.equal(getAt(`publicEvents/${eid}`),null);
 assert.equal(getAt(`bbxPublicCodeLookup/${code}`),null);
 assert.equal(getAt(`userEvents/${uid}/0`),'B6_DIFFERENT_NEW_EVENT','do not clear slot now holding another tournament');
 assert.deepEqual(getAt(`bbxEventCleanupRegistry/${eid}`),{status:'deleted',verified:true});
 assert.equal(getAt(`bbxPublicCodeReservations/${code}`),null);
 await assert.rejects(()=>f.bbxV011DeleteAuthority(request({eventId:eid},'unknown-owner')),e=>e.code==='permission-denied');
});

test('five-character reservation collision retries and never reuses a different event alias',async()=>{
 const crypto=require('node:crypto');const L=require('../functions/bbx-v011-lifecycle');
 const owner='code-collision-owner';
 const opId=op().slice(0,12)+'c'.repeat(36);
 const internal='B9_'+crypto.createHash('sha256').update(owner+':'+opId).digest('hex').slice(0,26);
 const collidingCode=L.shortCode(owner,internal,0);
 setAt(`bbxPublicCodeReservations/${collidingCode}`,{eventId:'B6_SOMEONE_ELSE',state:'active'});
 const result=await f.bbxV011CreateAuthority(request({opId,name:'collision event',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 assert.notEqual(result.publicCode,collidingCode);
 assert.equal(getAt(`bbxPublicCodeReservations/${collidingCode}/eventId`),'B6_SOMEONE_ELSE');
 assert.equal(getAt(`bbxPublicCodeLookup/${result.publicCode}`),result.eventId);
});

test('replayed CREATE cannot resurrect a deleted event using its original idempotency operation',async()=>{
 const owner='delete-replay-owner';
 const opId=op().slice(0,12)+'a'.repeat(36);
 const body=request({opId,name:'deleted must stay deleted',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner);
 const created=await f.bbxV011CreateAuthority(body);
 await f.bbxV011DeleteAuthority(request({eventId:created.eventId},owner));
 await assert.rejects(()=>f.bbxV011CreateAuthority(body),e=>e.code==='failed-precondition');
 assert.equal(getAt(`events/${created.eventId}`),null);
 assert.deepEqual(getAt(`bbxEventCleanupRegistry/${created.eventId}`),{status:'deleted',verified:true});
});

test('first prepared operation cannot recreate deleted board',async()=>{
 const made=await f.bbxV011CreateAuthority(request(make(op().slice(0,12)+'a'.repeat(36)).data,'race-owner'));
 deleteBeforeSeq=true;
 await assert.rejects(()=>f.bbxV011CommandAuthority(request({eventId:made.eventId,opId:op(),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'Judge'},'race-owner')),e=>e.code==='not-found');
 assert.equal(getAt(`authorityBBXV011/${made.eventId}/board`),null);assert.equal(getAt(`events/${made.eventId}`),null);
});
test('historical V06 cleanup retains sibling events',async()=>{
 const id='HISTORY_V06';setAt(`events/${id}`,{id,ownerUid:'history-owner',releaseTag:'BBX-V0.6',authorityBBX:'active',created:1});
 setAt(`authorityBBXV06/${id}/board`,{seq:2});setAt(`bbxV06PublicationPending/${id}`,{seq:2});
 setAt('userEvents/history-owner/0',id);setAt('events/KEEP_V06',{ownerUid:'someone'});
 await f.bbxV011DeleteAuthority(request({eventId:id},'history-owner'));
 assert.equal(getAt(`authorityBBXV06/${id}`),null);assert.equal(getAt(`bbxV06PublicationPending/${id}`),null);
 assert.equal(getAt(`events/${id}`),null);assert.ok(getAt('events/KEEP_V06'));
});
test('V0.8 can delete an older V0.7 event under its ORIGINAL leases without touching other events',async()=>{
 const id='B7_HISTORY_SAFE01',owner='historical-v07-owner';
 setAt(`events/${id}`,{id,ownerUid:owner,releaseTag:'BBX-V0.7',authorityBBX:'active',name:'history',created:1});
 setAt(`authorityBBXV07/${id}/board`,{seq:2,deleted:false});
 setAt(`publicEvents/${id}`,{meta:{id,publicOpen:true}});
 setAt(`bbxV07PublicationPending/${id}`,{seq:2,updatedAt:Date.now()});
 setAt(`userEvents/${owner}/0`,id);
 setAt(`userEvents/${owner}/1`,'ANOTHER_EVENT');
 const result=await f.bbxV011DeleteAuthority(request({eventId:id},owner));
 assert.equal(result.verified,true);
 for(const root of ['events','publicEvents','authorityBBXV07','bbxV07PublicationPending'])
  assert.equal(getAt(`${root}/${id}`),null,root);
 assert.equal(getAt(`userEvents/${owner}/0`),null);
 assert.equal(getAt(`userEvents/${owner}/1`),'ANOTHER_EVENT');
});

// Hosting V0.12/V0.13 use the unchanged V0.11 authority schema; their new
// tournaments MUST remain deletable after switching to the V0.14 frontend.
test('V0.13-hosted tournament remains fully deletable using its actual V0.11 authority schema',async()=>{
 const owner='cross-version-owner';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'e'.repeat(36),name:'Created under V0.13 hosting',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId,code=created.publicCode;
 assert.equal(getAt(`events/${eid}/releaseTag`),'BBX-V0.11');
 for(const root of ['authorityBBX','authorityBBXV04','authorityBBXV05','bbxV05PublicationPending','authorityBBXV06','authorityBBXV07','bbxV07PublicationPending','authorityBBXV08','bbxV08PublicationPending','authorityBBXV09','bbxV09PublicationPending','authorityBBXV010','bbxV010PublicationPending']){
  setAt(`${root}/${eid}`,{oldData:'historical residue'});
 }
 const unrelated='B9_safe_neighbor';
 setAt(`authorityBBXV09/${unrelated}`,{board:{seq:10}});
 const out=await f.bbxV011DeleteAuthority(request({eventId:eid},owner));
 assert.equal(out.verified,true);
 for(const root of require('../functions/bbx-v011-cleanup').EVENT_ROOTS){
  assert.equal(getAt(`${root}/${eid}`),null,`residual ${root}/${eid}`);
 }
 assert.equal(getAt(`userEvents/${owner}/0`),null);
 assert.equal(getAt(`bbxPublicCodeLookup/${code}`),null);
 assert.equal(getAt(`bbxPublicCodeReservations/${code}`),null);
 assert.deepEqual(getAt(`bbxEventCleanupRegistry/${eid}`),{status:'deleted',verified:true});
 assert.deepEqual(getAt(`authorityBBXV09/${unrelated}`),{board:{seq:10}},'unrelated event untouched');
});

test('a short-code reservation now owned by another event stops deletion before touching the board',async()=>{
 const owner='code-ownership-guard';
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'a'.repeat(36),name:'Protect code collision',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const {eventId,publicCode}=created;
 setAt(`bbxPublicCodeReservations/${publicCode}`,{eventId:'SOME_OTHER_EVENT',state:'active'});
 await assert.rejects(()=>f.bbxV011DeleteAuthority(request({eventId},owner)),e=>e.code==='failed-precondition');
 assert.ok(getAt(`events/${eventId}`));
 assert.ok(getAt(`authorityBBXV011/${eventId}/board`));
 assert.equal(getAt(`bbxPublicCodeReservations/${publicCode}/eventId`),'SOME_OTHER_EVENT');
});

test('V0.16 40-player CREATE is server-authoritative: 48 slots / eight BYEs / 24 strong, with index untouched elsewhere',async()=>{
 const owner='new-auto-owner-40';
 const entrant=Array.from({length:40},(_,i)=>`V16P${i+1}`);
 const created=await f.bbxV011CreateAuthority(request({opId:op().slice(0,12)+'b'.repeat(36),name:'Auto 40',roster:entrant,mode:'free',pairing:'ordered',freeFinal:'champ',formatPolicy:'auto16'},owner));
 const {eventId}=created;
 const ev=getAt('events/'+eventId),board=getAt(`authorityBBXV011/${eventId}/board`);
 assert.equal(ev.formatPolicy,'auto16');
 assert.equal(ev.freeFinal,'rr3','client-provided champion final must be ignored');
 assert.equal(board.formatPolicy,'auto16','auto mode must survive all future rebuilds');
 assert.deepEqual(ev.rounds.map(r=>r.matches.length),[24,12,6,3]);
 assert.equal(ev.rounds[0].matches.filter(m=>m.winner).length,8);
 assert.equal(getAt(`publicEvents/${eventId}/meta/formatPolicy`),'auto16');
 assert.equal(getAt(`userEvents/${owner}/0`),eventId);
 const organizer=await f.bbxV011OrganizerAuthority(request({eventId,opId:op().slice(0,12)+'c'.repeat(36),action:'randomRebuild',expectedSeq:0},owner));
 assert.equal(organizer.ok,true);
 assert.equal(getAt(`authorityBBXV011/${eventId}/board/formatPolicy`),'auto16');
 assert.equal(getAt(`authorityBBXV011/${eventId}/board/rounds/0/matches`).length,24);
});
test('V0.16 denies unfinished repechage requests and does not create data',async()=>{
 const owner='new-auto-deny-repechage';
 await assert.rejects(()=>f.bbxV011CreateAuthority(request({opId:op(),name:'Reject rep',roster:roster,mode:'free',pairing:'ordered',freeFinal:'rr3',formatPolicy:'auto16',repechage:true},owner)),e=>e.code==='invalid-argument');
 assert.equal(getAt(`userEvents/${owner}`),null);
});

test('invite rotation is organizer-only, shared across hosts, expires on server clock, and never advances board seq',async()=>{
 const eventId='ROTATION_LOCAL_TEST',owner='rotation-owner';
 setAt(`events/${eventId}`,{ownerUid:owner,releaseTag:'BBX-V0.11'});
 setAt(`admins/${eventId}/cohost`,true);
 setAt(`refereeUsers/${eventId}/judge`,'123456');
 setAt(`authorityBBXV011/${eventId}/board/seq`,8);
 setAt(`refereeSecrets/${eventId}`,{code:'111111',expiresAt:Date.now()-1});
 const input={eventId,action:'getRefereeInviteCode'};
 await assert.rejects(()=>f.bbxV011OrganizerAuthority(request(input,'judge')),e=>e.code==='permission-denied');
 const [a,b]=await Promise.all([f.bbxV011OrganizerAuthority(request(input,owner)),f.bbxV011OrganizerAuthority(request(input,'cohost'))]);
 assert.match(a.code,/^\d{6}$/);assert.notEqual(a.code,'111111');assert.equal(a.code,b.code);assert.equal(a.expiresAt,b.expiresAt);
 assert.ok(a.expiresAt>a.serverNow&&a.expiresAt-a.serverNow<=60000);
 assert.equal(getAt(`authorityBBXV011/${eventId}/board/seq`),8);
 assert.equal(getAt(`publicEvents/${eventId}`),null);
 assert.equal(getAt(`refereeUsers/${eventId}/judge`),'123456');
});
