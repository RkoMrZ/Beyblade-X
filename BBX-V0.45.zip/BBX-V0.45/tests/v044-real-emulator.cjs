'use strict';
// Exercises the actual callable handlers and real RTDB encoding on localhost only.
const assert=require('node:assert/strict');
const Module=require('node:module');
const {randomBytes}=require('node:crypto');
const host=process.env.FIREBASE_DATABASE_EMULATOR_HOST;
if(!/^(127\.0\.0\.1|localhost):\d+$/.test(host||''))throw Error('LOCAL RTDB EMULATOR REQUIRED');
process.env.GCLOUD_PROJECT='ljt-beyblade-x';
for(const k of ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','WS_PROXY','WSS_PROXY'])delete process.env[k];
const ns='demo-bbx-v011-default-rtdb';
const admin=require('../functions/node_modules/firebase-admin');
const old=Module._load;
Module._load=function(name,parent){
 if(parent?.filename.endsWith('/functions/index.js')){
  if(name==='firebase-admin')return {database:()=>admin.database(),initializeApp:()=>admin.initializeApp({projectId:'demo-bbx-v011',databaseURL:`https://${ns}.firebaseio.com`})};
  if(name==='firebase-functions/v2/https')return {...old.apply(this,arguments),onCall:(_,fn)=>fn};
  if(name==='firebase-functions/v2/database')return {onValueWritten:(_,fn)=>fn};
  if(name==='firebase-functions/v2/scheduler')return {onSchedule:(_,fn)=>fn};
 }
 return old.apply(this,arguments);
};
const api=require('../functions/index');Module._load=old;
const db=admin.database(),prefix=`LOCAL${Date.now()}`;
const op=()=>Date.now().toString(16).padStart(12,'0')+randomBytes(18).toString('hex');
const invoke=(fn,data,uid=prefix)=>api['bbxV011'+fn]({auth:{uid,token:{firebase:{sign_in_provider:'google.com'}}},data:{clientVersion:'bbx-v0.11-authority-1',...data}});
const read=async p=>(await db.ref(p).get()).val();
(async()=>{
 const created=await invoke('CreateAuthority',{opId:op(),name:'V044 local',roster:['A','B','C'],mode:'free',pairing:'ordered',freeFinal:'rr3',formatPolicy:'auto16'});
 const id=created.eventId,authority=`authorityBBXV011/${id}`,priv=`events/${id}`,pub=`publicEvents/${id}`;
 const add={eventId:id,opId:op(),action:'addPlayer',value:'001',expectedSeq:999,expectedStructureVersion:0};
 // Reproduce an old outbox item persisted with RTDB's actual null omission,
 // then use the same publisher path the production repair trigger calls.
 const org=require('../functions/bbx-v011-organizer');
 const board=await read(`${authority}/board`);
 const applied=org.apply(board,prefix,add,Date.now(),{owner:true});
 await db.ref().update({[`${authority}/board`]:applied.board,[`${priv}/authoritySeq`]:1,[`${priv}/structureVersion`]:1,
  [`bbxV011PublicationPending/${id}`]:{seq:1,updatedAt:Date.now()}});
 const item=await read(`${authority}/board/outbox/000000000001`);
 const removal=item.changes.find(x=>x.path==='finalRR');
 assert.ok(removal&&!Object.hasOwn(removal,'publicValue')&&!Object.hasOwn(removal,'value'));
 await api.bbxV011PublishAuthority({data:{after:{exists:()=>true}},params:{eventId:id}});
 assert.equal(await read(`${priv}/publishedSeq`),1);
 assert.equal(await read(`${priv}/publishedStructureVersion`),1);
 assert.equal(await read(`${priv}/finalRR`),null);assert.equal(await read(`${pub}/finalRR`),null);
 assert.deepEqual(await read(`${priv}/roster`),['A','B','C','001']);assert.deepEqual(await read(`${pub}/meta/roster`),['A','B','C','001']);
 assert.equal(await read(`${authority}/board/outbox`),null);
 const replay=await invoke('OrganizerAuthority',add);
 assert.equal(replay.replayed,true);assert.equal(replay.published,true);assert.equal(await read(`${authority}/board/seq`),1);
 const claim=await invoke('CommandAuthority',{eventId:id,opId:op(),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,expectedStructureVersion:1,referee:'裁判 1'});
 assert.equal(claim.published,true);
 await assert.rejects(()=>invoke('OrganizerAuthority',{eventId:id,opId:op(),action:'randomRebuild',expectedStructureVersion:1}),{code:'failed-precondition'});
 await invoke('CommandAuthority',{eventId:id,opId:op(),action:'release',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:claim.matchVersion,expectedStructureVersion:1,referee:'裁判 1'});
 const rebuild=await invoke('OrganizerAuthority',{eventId:id,opId:op(),action:'randomRebuild',expectedSeq:0,expectedStructureVersion:1});
 assert.equal(rebuild.published,true);assert.equal(await read(`${priv}/publishedStructureVersion`),2);
 const last=(await read(`${priv}/roster`)).indexOf('001');
 const deleted=await invoke('OrganizerAuthority',{eventId:id,opId:op(),action:'delPlayer',index:last,expectedStructureVersion:2});
 assert.equal(deleted.published,true);assert.equal(await read(`${priv}/rounds`),null);assert.equal(await read(`${pub}/rounds`),null);
 assert.equal((await read(`${pub}/finalRR/matches`)).length,3);
 console.log('PASS V0.44 RTDB real outbox null omission, backlog repair, 001/receipt replay, active lock, reshuffle and RR conversion');
 const invite={eventId:id,action:'getRefereeInviteCode'};
 await db.ref(`admins/${id}/COHOST`).set(true);
 await db.ref(`refereeSecrets/${id}`).set({code:'111111',expiresAt:Date.now()-20});
 const [a,b]=await Promise.all([invoke('OrganizerAuthority',invite),invoke('OrganizerAuthority',invite,'COHOST')]);
 assert.equal(a.code,b.code);assert.notEqual(a.code,'111111');assert.equal(a.expiresAt,b.expiresAt);
 await assert.rejects(()=>invoke('OrganizerAuthority',invite,'UNAUTHORIZED'),{code:'permission-denied'});
 assert.equal(await read(`${authority}/board/seq`),deleted.seq);
 await invoke('DeleteAuthority',{eventId:id});
 assert.equal(await read(`refereeSecrets/${id}`),null);
 assert.equal(await read(priv),null);
 console.log('PASS V0.44 RTDB shared referee code rotation, organizer authorization and complete event cleanup');
})().catch(e=>{console.error(e);process.exitCode=1}).finally(()=>admin.app().delete());
