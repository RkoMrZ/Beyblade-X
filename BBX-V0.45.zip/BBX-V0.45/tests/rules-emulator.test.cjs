'use strict';
// Runs ONLY against the local Firebase RTDB emulator, never the production service.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing');
const {ref,get,update,remove,set}=require('firebase/database');
(async()=>{
 const host=process.env.FIREBASE_DATABASE_EMULATOR_HOST;
 if(!host||!host.includes(':'))throw Error('拒絕：此測試必須在 Firebase Realtime Database Emulator 中執行');
 const env=await initializeTestEnvironment({
  projectId:'demo-bbx-v011',database:{rules:fs.readFileSync('../database.rules.json','utf8')}
 });
 const eventId='BBXTEST_A123456',now=Date.now();
 const board=(active,open=true)=>({id:eventId,ownerUid:'owner',created:now,testOnly:false,authorityBBX:active?'active':null,
  name:'test',mode:'single',pairing:'ordered',freeFinal:'champ',roster:['A','B'],
  rounds:[{name:'第 1 輪',matches:[{a:'A',b:'B',sa:0,sb:0,winner:null}]}],
  publicOpen:open,publicUntil:now+3600000});
 const metadata=(open=true)=>({id:eventId,name:'test',publicOpen:open,publicUntil:now+3600000});
 const owner=env.authenticatedContext('owner');
 const referee=env.authenticatedContext('judge');
 const guest=env.unauthenticatedContext();
 const dbo=owner.database(),dbr=referee.database(),dbg=guest.database();
 try{
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),`events/${eventId}`),board(false));
   await set(ref(ctx.database(),`publicEvents/${eventId}`),{meta:metadata(),rounds:board(false).rounds});
   await set(ref(ctx.database(),`userEvents/owner/0`),eventId);
   await set(ref(ctx.database(),`refereeUsers/${eventId}/judge`),'123456');
   await set(ref(ctx.database(),`authorityBBXV07/${eventId}/board`),{seq:0,privateToken:'DONOTSHOW'});
  });
  // Old V1.0 frontend remains functional only while authority is NOT active.
  await assertSucceeds(update(ref(dbo,`events/${eventId}/rounds/0/matches/0`),{sa:1}));
  await assertSucceeds(get(ref(dbo,`events/${eventId}`)));
  await assertSucceeds(get(ref(dbg,`publicEvents/${eventId}`)));
  await assertFails(get(ref(dbg,`events/${eventId}`)));
  await assertFails(get(ref(dbg,`authorityBBXV07/${eventId}/board`)));
  // V1.0 grants registered referees access to private and public match scores
  // before BBX cloud authority is enabled. This must remain backward compatible.
  await assertFails(update(ref(dbg,`publicEvents/${eventId}/rounds/0/matches/0`),{sa:8}));
  await assertSucceeds(update(ref(dbr,`publicEvents/${eventId}/rounds/0/matches/0`),{sa:9}));
  console.log('PASS: legacy V1.0 judge can update pre-authority; guest cannot');
  await env.withSecurityRulesDisabled(async ctx=>{
   await update(ref(ctx.database(),`events/${eventId}`),{authorityBBX:'active'});
  });
  // Active authority refuses ALL legacy direct writes, including owner deletion.
  await assertFails(update(ref(dbo,`events/${eventId}/rounds/0/matches/0`),{sa:3}));
  await assertFails(update(ref(dbo,`events/${eventId}/roster`),{0:'X'}));
  await assertFails(update(ref(dbo,`events/${eventId}/raffleState`),{winners:['A']}));
  await assertFails(update(ref(dbo,`events/${eventId}/refereeNames`),{0:'Evil'}));
  await assertFails(remove(ref(dbo,`events/${eventId}`)));
  await assertFails(update(ref(dbo,`publicEvents/${eventId}/rounds/0/matches/0`),{sa:3}));
  await assertFails(update(ref(dbr,`events/${eventId}/rounds/0/matches/0`),{sb:3}));
  await assertFails(set(ref(dbo,`authorityBBXV07/${eventId}/board/seq`),99));
  console.log('PASS: active authority blocks all legacy direct writes and private authority access');
  await env.withSecurityRulesDisabled(async ctx=>{
   await update(ref(ctx.database(),`publicEvents/${eventId}/meta`),{publicOpen:false});
  });
  await assertFails(get(ref(dbg,`publicEvents/${eventId}`)));
  await assertSucceeds(get(ref(dbo,`events/${eventId}`)));
  // v0.5 viewer permission follows the authoritative board, not stale public metadata.
  const v05='B6_TEST_PUBLIC';
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),`events/${v05}`),{id:v05,ownerUid:'owner',releaseTag:'BBX-V0.9',authorityBBX:'active'});
   await set(ref(ctx.database(),`publicEvents/${v05}`),{meta:{id:v05,name:'test',publicOpen:true,publicUntil:now+3600000}});
   await set(ref(ctx.database(),`authorityBBXV09/${v05}/board`),{publicOpen:false,publicUntil:now+3600000});
  });
  await assertFails(get(ref(dbg,`publicEvents/${v05}`)));
  await env.withSecurityRulesDisabled(async ctx=>{
   await update(ref(ctx.database(),`authorityBBXV09/${v05}/board`),{publicOpen:true});
  });
  await assertSucceeds(get(ref(dbg,`publicEvents/${v05}`)));
  console.log('PASS: stale V0.8 public-open cannot bypass authoritative access gate');
  const modern='B10_TEST_PUBLIC';
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),`events/${modern}`),{id:modern,ownerUid:'owner',releaseTag:'BBX-V0.11',authorityBBX:'active'});
   await set(ref(ctx.database(),`publicEvents/${modern}`),{meta:{id:modern,name:'new',publicOpen:true,publicUntil:now+3600000}});
   await set(ref(ctx.database(),`authorityBBXV011/${modern}/board`),{publicOpen:false,publicUntil:now+3600000});
  });
  await assertFails(get(ref(dbg,`publicEvents/${modern}`)));
  await env.withSecurityRulesDisabled(async ctx=>{
   await update(ref(ctx.database(),`authorityBBXV011/${modern}/board`),{publicOpen:true});
  });
  await assertSucceeds(get(ref(dbg,`publicEvents/${modern}`)));
  await assertFails(get(ref(dbo,`authorityBBXV011/${modern}/board`)));
  console.log('PASS current V0.11 and historical V0.9 retain separate public access gating');
  const codePath=`refereeSecrets/${modern}`;
  const joinPath=`refereeUsers/${modern}/judge`;
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),codePath),{code:'123456',expiresAt:Date.now()-2000});
  });
  await assertSucceeds(get(ref(dbo,codePath)));
  await assertFails(get(ref(dbr,codePath)));
  await assertFails(get(ref(dbg,codePath)));
  await assertFails(set(ref(dbr,joinPath),'123456'));
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),codePath),{code:'654321',expiresAt:Date.now()+60000});
  });
  await assertFails(set(ref(dbr,joinPath),'123456'));
  await assertSucceeds(set(ref(dbr,joinPath),'654321'));
  await assertFails(get(ref(dbr,`admins/${modern}/owner`)));
  console.log('PASS V0.44 referee join uses only the current six-digit code and grants no organizer access');

  const historical='B7_TEST_PUBLIC';
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),`events/${historical}`),{id:historical,ownerUid:'owner',releaseTag:'BBX-V0.7',authorityBBX:'active'});
   await set(ref(ctx.database(),`publicEvents/${historical}`),{meta:{id:historical,name:'history',publicOpen:true,publicUntil:now+3600000}});
   await set(ref(ctx.database(),`authorityBBXV07/${historical}/board`),{publicOpen:false,publicUntil:now+3600000});
  });
  await assertFails(get(ref(dbg,`publicEvents/${historical}`)));
  await env.withSecurityRulesDisabled(async ctx=>{
   await update(ref(ctx.database(),`authorityBBXV07/${historical}/board`),{publicOpen:true});
  });
  await assertSucceeds(get(ref(dbg,`publicEvents/${historical}`)));
  console.log('PASS historical V0.7 release retains its own viewer access authority');
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),`authorityBBXV04/${eventId}/board`),{privateToken:'NO_CLIENT_ACCESS'});
  });
  await assertFails(get(ref(dbo,`authorityBBXV04/${eventId}/board`)));
  await assertFails(set(ref(dbo,`authorityBBXV04/${eventId}/board/seq`),99));
  const five='ABCDE';
  await env.withSecurityRulesDisabled(async ctx=>{
   await set(ref(ctx.database(),`bbxPublicCodeLookup/${five}`),eventId);
   await set(ref(ctx.database(),`bbxEventCleanupRegistry/${eventId}`),{ownerUid:'owner',status:'active'});
   await set(ref(ctx.database(),`bbxPublicCodeReservations/${five}`),{eventId});
  });
  await assertSucceeds(get(ref(dbg,`bbxPublicCodeLookup/${five}`)));
  await assertFails(get(ref(dbg,`bbxPublicCodeLookup`)));
  await assertFails(set(ref(dbo,`bbxPublicCodeLookup/${five}`),'attacker-event'));
  await assertFails(get(ref(dbo,`bbxEventCleanupRegistry/${eventId}`)));
  await assertFails(get(ref(dbo,`bbxPublicCodeReservations/${five}`)));
  await assertFails(set(ref(dbo,`bbxEventCleanupRegistry/${eventId}/status`),'deleted'));
  console.log('PASS: 5-character lookup readable only by exact code, alias and registry server-write-only');
  console.log('PASS: historical V0.4 authority stays server-only after V0.7 Rules merge');
  console.log('PASS: Firebase Emulator permissions for viewer, organizer, referee, legacy-write and active authority');
 }finally{await env.cleanup()}
})().catch(e=>{console.error(e);process.exitCode=1});
