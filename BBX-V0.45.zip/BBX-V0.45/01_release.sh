#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.45 release already running';exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: V0.45 release already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.45 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v045.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v045-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight mismatch';exit 3; }
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: wrong Firebase project';exit 2; }
# V0.45 is a Hosting-only UI update; preserve existing backend Functions and Rules.
bash deploy/hosting-v045.sh
date -u > .release-completed
printf '\nPASS: V0.45 Hosting deployed and live fingerprint verified; Functions, RTDB Rules and existing tournaments unchanged.\n'
