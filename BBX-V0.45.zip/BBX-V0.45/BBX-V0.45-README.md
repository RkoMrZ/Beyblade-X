# BBX-V0.45｜主辦／裁判 iPhone 前景恢復、名單重抽回饋、可見版本

## 這次修改
1. iPhone Safari 切至相機／其他 App 回來，不再因為前景同步而強制關閉已開始執裁的小視窗。背景停止 SSE，回前景檢查完整賽事與獨立的 `refereeClaims`，驗證原場次／UID／結構版本；通過才重新開啟原場次的比分操作，顯示雲端最新比分。失聯期間保留視窗但停用記分；場次完成、權限被收回或籤表版本已變更則不恢復舊操作。
2. 在同一分頁 reload／iOS 丟棄分頁後，儲存僅含賽事 ID、Firebase UID、場次索引與賽程結構版本的短期定位資訊（最多 2 小時）；**不儲存比分、姓名、執裁權限、登入 Token**，必須重新雲端驗證才能恢復編輯。手動關閉彈窗、返回首頁或切換分頁清除定位。
3. 「依目前名單重新抽籤比賽順序」始終可點，依狀態回饋具體訊息；未開賽可送出後端 `randomRebuild`，已開始執裁／已有比分／同步中的情況明確顯示拒絕原因，不會偷偷重設比賽。原主辦雲端權限／版本檢查保持不變。
4. 標題「戰鬥陀螺賽程表」旁固定顯示 **V0.45**，手機窄螢幕採緊湊排版，保留原首頁、裁判、觀眾原有功能。

## 部署影響
- **Hosting only**：`bbxs-tamsui`，Firebase 專案 `ljt-beyblade-x`。
- Functions、RTDB Rules、Firebase 設定與 V0.44 完全相同，不變更資料架構、不清除任何舊版賽事或歷史刪除清理路徑；不碰獨立報名系統 `ljtreg-39954`。
- ZIP / 資料夾使用 `BBX-V0.45`，存 GitHub `rkomrz/Beyblade-X/main` 根目錄。部署前 Cloud Shell 必須跑 Node 22 測試與 Firebase RTDB Emulator，任何失敗中止，不部署。
- 本機 Chromium 並不是 iOS WebKit 或兩台真手機，正式環境使用者仍需實機確認。

## Cloud Shell 執行狀態
`~/BBX-V0.45-deploy.log`、`~/BBX-V0.45/release.log`。單指令背景執行，進度 `tail -n 60 ~/BBX-V0.45-deploy.log`。
