const THEME_KEY='bx_live_theme';
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyD2PsTKnlcFbHQvkZCYeaM_DIoJcl1c5zk",
  authDomain: "ljt-beyblade-x.firebaseapp.com",
  databaseURL: "https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "ljt-beyblade-x",
  messagingSenderId: "811309004070",
  appId: "1:811309004070:web:2e246f0a0ac7dae2e8fde7"
};
const STORE='bx_live_events_v3', CURRENT='bx_live_current_v3', SAVED='bx_live_saved_events_v3', KEEP='bx_live_event_v1';
const LEGACY_STORE='bx_live_legacy_disabled';
const CLOUD_LOCAL_POLICY_VERSION=1; // 雲端賽事：Firebase only；本機只保留本機賽事與純 UI / 身分資訊。
let draftMode=null, draftStorage=null, ev=null;
let cloudEventsCache={}, cloudEventIds=[], cloudEventSlots={}; // 僅 RAM，重新載入即清空。
let fbApp=null,fbAuth=null,fbUser=null,cloudReady=false,cloudUnsub=null,isAdmin=false,isReferee=false,adminCodeTimer=null,adminCodeCountdownTimer=null;
const bbxRealtimeTransport='SSE + REST'; // Auth and callable SDK only; no RTDB SDK transport
// Home subscription identity: stale responses must not overwrite a new session.
let ownerIndexUnsub=null,ownerIndexSyncBusy=false,ownerIndexPendingSnapshot=null,ownerIndexGeneration=0;
// V0.34: Home is a different subscription scope from one opened private match.
// Guard the route transition; do not let delayed Google-auth callbacks attach
// the organizer's Home index while the tournament view is opening.
let ownerIndexBoundUid=null,bbxBootstrapping=true,bbxEnteringPrivateEvent=0;
let cloudInitPromise=null,bbxEventOpeningPromise=null,bbxEventOpeningId=null;
const bbxLifecycleEvents=[];
function bbxLifecycleNote(stage,detail=''){
  bbxLifecycleEvents.push({at:Date.now(),stage,detail});
  if(bbxLifecycleEvents.length>48)bbxLifecycleEvents.shift();
}
function bbxCanRunOwnerIndex(){
  return !bbxBootstrapping && bbxEnteringPrivateEvent===0 &&
    document.visibilityState!=='hidden' && !!$('home') &&
    !$('home').classList.contains('hidden') &&
    !new URLSearchParams(location.search).has('event') && isGoogleUser();
}

let cloudListenerEpoch=0;
const liveTransportRecoveryAt=new Map(); // per-event bounded reconnect attempts
// Diagnostic state is ephemeral. Never store Firebase UID, auth tokens or private data
// in a cross-browser cache; the user may copy this diagnostic report explicitly.
let ownerIndexState={phase:'restoring',uid:null,provider:null,restSlots:null,
  verified:false,source:null,error:null,checkedAt:null,indexMismatch:false};
let ownerIndexProbeTimer=null,ownerIndexRetryTimer=null,ownerIndexRetryAttempts=0;
let ownerIndexLastProbe=0,ownerIndexRetryDelay=4000,ownerIndexLastUid=null;

const $=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function events(){
  let localTests={};
  try{
    const raw=JSON.parse(localStorage.getItem(STORE)||'{}');
    for(const [id,e] of Object.entries(raw||{})){
      if(e?.testOnly)localTests[id]=e;
    }
  }catch(e){}
  return {...localTests,...cloudEventsCache};
}
function savedEventIds(){
  let testIds=[];
  try{
    testIds=JSON.parse(localStorage.getItem(SAVED)||'[]');
    if(!Array.isArray(testIds))testIds=[];
  }catch(e){testIds=[]}

  const all=events();
  testIds=testIds.filter(id=>all[id]?.testOnly);
  // A transient Firebase Auth null must not expose a previous organizer's
  // RAM cache to a signed-out user. Keep the cache internally for recovery.
  return [...new Set([...(isGoogleUser()?cloudEventIds:[]),...testIds])];
}
function setSavedEventIds(ids){
  const all=events();
  const testIds=[...new Set(ids)].filter(id=>all[id]?.testOnly);
  localStorage.setItem(SAVED,JSON.stringify(testIds));
}
function keepLocalEnabled(){return localStorage.getItem(KEEP)==='1'}

function cleanupLegacyCloudLocalData(){
  try{
    // STORE 永遠只允許 testOnly=true 的本機賽事。
    const raw=JSON.parse(localStorage.getItem(STORE)||'{}');
    const tests={};
    for(const [id,e] of Object.entries(raw||{})){
      if(e?.testOnly===true)tests[id]=e;
    }
    localStorage.setItem(STORE,JSON.stringify(tests));

    // SAVED 也只留下本機賽事 ID。
    let savedIds=[];
    try{savedIds=JSON.parse(localStorage.getItem(SAVED)||'[]')}catch(e){}
    if(!Array.isArray(savedIds))savedIds=[];
    savedIds=savedIds.filter(id=>tests[id]?.testOnly===true);
    localStorage.setItem(SAVED,JSON.stringify([...new Set(savedIds)]));

    // CURRENT 只服務本機賽事。
    const current=localStorage.getItem(CURRENT);
    if(current && !tests[current])localStorage.removeItem(CURRENT);

    // 舊版若曾把雲端 active view 寫進 localStorage，直接丟掉。
    try{
      const activeRaw=localStorage.getItem(ACTIVE_VIEW_KEY);
      if(activeRaw){
        const active=JSON.parse(activeRaw);
        if(active && active.testOnly!==true)localStorage.removeItem(ACTIVE_VIEW_KEY);
      }
    }catch(e){
      localStorage.removeItem(ACTIVE_VIEW_KEY);
    }

    // 舊版的主辦 flag / 管理驗證碼不是權限來源，全部清掉。
    // 真正權限一律由 Firebase Auth + ownerUid / admins 節點判斷。
    for(let i=localStorage.length-1;i>=0;i--){
      const k=localStorage.key(i)||'';
      if(
        k.startsWith('bx_testenv_cloud_admin_') ||
        k.startsWith('bx_testenv_cloud_admin_code_')
      ){
        localStorage.removeItem(k);
      }
    }

    // 抽籤 localStorage 只允許本機賽事保留。
    for(let i=localStorage.length-1;i>=0;i--){
      const k=localStorage.key(i)||'';
      const prefix='bx_live_raffle_round_';
      if(k.startsWith(prefix)){
        const id=k.slice(prefix.length);
        if(!tests[id])localStorage.removeItem(k);
      }
    }
  }catch(e){
    console.warn('cleanupLegacyCloudLocalData skipped',e);
  }
}


function migrateLegacyTestEvents(){
  try{
    const current=JSON.parse(localStorage.getItem(STORE)||'{}');
    if(current && Object.keys(current).length)return;

    const legacy=JSON.parse(localStorage.getItem(LEGACY_STORE)||'{}');
    const tests={};
    const ids=[];

    for(const [id,e] of Object.entries(legacy||{})){
      if(e?.testOnly){
        tests[id]=e;
        ids.push(id);
      }
    }

    if(ids.length){
      localStorage.setItem(STORE,JSON.stringify(tests));
      localStorage.setItem(SAVED,JSON.stringify(ids));
    }
  }catch(e){
    console.warn('legacy test migration skipped',e);
  }
}

async function ensureRefereeAuth(){
  if(!(await initCloud()))return false;

  // 已有 Google 或先前保留的匿名登入就直接沿用，不重新建立帳號。
  if(fbAuth.currentUser){
    fbUser=fbAuth.currentUser;
    return true;
  }

  try{
    await fbAuth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);
    const result=await fbAuth.signInAnonymously();
    fbUser=result.user||fbAuth.currentUser;
    return !!fbUser;
  }catch(e){
    console.error('ensureRefereeAuth failed',e);
    alert('建立裁判登入身分失敗：'+(e?.message||e));
    return false;
  }
}

function isGoogleUser(){
  return !!(fbAuth?.currentUser && fbAuth.currentUser.providerData?.some(p=>p.providerId==='google.com'));
}
function renderHeaderAuth(){
  const b=$('googleLoginBtn'); if(!b)return;
  if(isGoogleUser()){
    const u=fbAuth.currentUser;
    const label=u.displayName||u.email||'Google 帳號';
    b.classList.add('logged');
    b.innerHTML=`✓ 已登入<span class="miniUser">${esc(label)}</span>`;
    b.title='點一下可登出 Google 帳號';
  }else{
    b.classList.remove('logged');
    b.textContent='Google 登入';
    b.title='主辦方使用 Google 帳號登入';
  }
}
async function handleHeaderLogin(){
  if(!cloudReady){
    if(!(await initCloud()))return alert('Firebase 尚未連線成功。');
  }
  if(isGoogleUser()){
    if(!confirm('要登出目前的 Google 帳號嗎？'))return;
    try{
      // An explicit sign-out (unlike iOS's temporary auth restoration null)
      // intentionally discards this account's private in-memory listing.
      stopMyCloudEventIndexListener();
      clearActiveView();
      cloudEventsCache={};cloudEventIds=[];cloudEventSlots={};
      ownerIndexLastUid=null;
      setOwnerIndexState({phase:'signed-out',uid:null,verified:false,restSlots:null,error:null,indexMismatch:false});
      await fbAuth.signOut();
      await fbAuth.signInAnonymously();
      fbUser=fbAuth.currentUser;
      renderHeaderAuth();renderHomeSelections();
    }catch(e){alert('登出失敗：'+e.message)}
    return;
  }
  await requireGoogleLogin();
}
function ownerIndexErrorLabel(error){
  const code=String(error?.code||'');
  const message=String(error?.message||error||'');
  if(code.includes('PERMISSION_DENIED')||code.includes('PERMISSION_DENIED')||
     code==='HTTP_403'||/permission.denied|permission denied|Firebase REST 403/i.test(message))return 'permission_denied';
  if(code==='HTTP_401'||/Firebase REST 401/i.test(message))return 'auth_401';
  if(error?.name==='AbortError'||/timeout|逾時/i.test(message))return 'timeout';
  if(!navigator.onLine||/network|failed to fetch|offline/i.test(message))return 'network';
  return code||'read_failed';
}
function indexedOwnerSlots(raw){
  if(raw===null||raw===undefined)return {};
  // RTDB may serialise numeric slots 0/1/2 as an Array rather than an Object.
  // Both formats represent the same legitimate owner index. Reject primitives,
  // never the Firebase-generated Array; Object.entries handles sparse arrays.
  if(typeof raw!=='object')throw new Error('invalid_owner_index_payload');
  const slots={};
  for(const [slot,value] of Object.entries(raw)){
    if(['0','1','2'].includes(slot) && typeof value==='string' && value)slots[slot]=value;
  }
  return slots;
}
function ownerIndexSlotFingerprint(raw){
  const s=indexedOwnerSlots(raw);
  return ['0','1','2'].map(k=>s[k]||'').join('|');
}
function setOwnerIndexState(patch){
  Object.assign(ownerIndexState,patch);
  renderOwnerIndexDiagnostics();
}
function ownerIndexStatusLabel(){
  if(!isGoogleUser())return '尚未登入 Google 主辦帳號';
  const state=ownerIndexState;
  if(state.uid && state.uid!==fbAuth.currentUser.uid)return '登入身分已變更，正在重新讀取';
  if(state.indexMismatch)return '主辦索引不一致：請查看同步診斷（不會自動刪除）';
  if(state.phase==='verified'){
    const pending=cloudEventIdsForCurrentGoogle().filter(id=>cloudEventsCache[id]?.pendingSync).length;
    return `雲端已核對・${state.restSlots} 個索引${pending?'，'+pending+' 場主檔待確認':''}`;
  }
  if(state.phase==='error')return `雲端讀取失敗（${state.error||'read_failed'}），不是 0 場`;
  if(state.phase==='degraded')return `雲端核對未完成（${state.error||'read_failed'}），保留已知資料`;
  return '雲端索引讀取中；尚未確認賽事數量';
}
function renderOwnerIndexDiagnostics(){
  const status=$('ownerIndexStatus'),panel=$('ownerDiagPanel');
  if(status)status.textContent=ownerIndexStatusLabel();
  if(!panel||panel.classList.contains('hidden'))return;
  const target=$('ownerDiagDetails');
  if(target)target.textContent=ownerDiagnosticsText();
}
function ownerDiagnosticsText(){
  const u=fbAuth?.currentUser||null;
  const google=!!u?.providerData?.some(p=>p.providerId==='google.com');
  const owner=ownerIndexState;
  return [
    'BBX-V0.44 跨瀏覽器 REST／SSE 唯讀診斷',
    `目前時間：${new Date().toISOString()}`,
    `Firebase 專案：${FIREBASE_CONFIG.projectId}`,
    `Firebase UID：${u?.uid||'(尚未恢復)'}`,
    `登入 Provider：${u?.providerData?.map(p=>p.providerId).join(',')||'(無)'}`,
    `Google 主辦登入：${google?'是':'否'}`,
    `主辦索引路徑：${u?.uid?'userEvents/'+u.uid:'(尚未登入)'}`,
    `索引狀態：${owner.phase}`,
    `索引所屬 UID：${owner.uid||'(尚未讀取)'}`,
    `REST 索引數：${owner.restSlots??'(尚未完成)'}`,
    `最後核對來源：${owner.source||'(尚未核對)'}`,
    `REST 核對成功：${owner.verified?'是':'否'}`,
    `索引核對異常：${owner.indexMismatch?'是':'否'}`,
    `錯誤代碼：${owner.error||'(無)'}`,
    `最後核對：${owner.checkedAt?new Date(owner.checkedAt).toISOString():'(尚未完成)'}`,
    `目前可見雲端賽事數：${cloudEventIdsForCurrentGoogle().length}`,
    `待重新確認賽事數：${cloudEventIdsForCurrentGoogle().filter(id=>cloudEventsCache[id]?.pendingSync).length}`,
    '安全說明：這份文字沒有 ID Token、驗證碼或比分。UID 是帳號識別碼，請只交給可信任的維護人員。'
  ].join('\n');
}
function toggleOwnerDiagnostics(){
  const el=$('ownerDiagPanel');if(!el)return;
  el.classList.toggle('hidden');renderOwnerIndexDiagnostics();
}
async function copyOwnerDiagnostics(){
  const text=ownerDiagnosticsText();
  try{await navigator.clipboard.writeText(text);alert('診斷資料已複製，可比較 Safari 與 Chrome 的 UID 與 REST 索引數。');}
  catch(e){const target=$('ownerDiagDetails');if(target){target.textContent=text;target.focus?.();}alert('瀏覽器未允許自動複製，請長按下方診斷文字複製。');}
}
function clearOwnerRetryTimers(){
  if(ownerIndexProbeTimer!==null){clearTimeout(ownerIndexProbeTimer);ownerIndexProbeTimer=null;}
  if(ownerIndexRetryTimer!==null){clearTimeout(ownerIndexRetryTimer);ownerIndexRetryTimer=null;}
}
function renderHomeSelections(){
  const free=$('choiceFree'),single=$('choiceSingle'),cloud=$('choiceCloud'),test=$('choiceTest');

  if(free)free.classList.toggle('selected',draftMode==='free');
  if(single)single.classList.toggle('selected',draftMode==='single');
  if(cloud)cloud.classList.toggle('selected',draftStorage==='cloud');
  if(test)test.classList.toggle('selected',draftStorage==='test');

  const s=$('homeSelectionSummary');
  const next=$('homeNextBtn');

  const hasMode=draftMode==='free'||draftMode==='single';
  const hasStorage=draftStorage==='cloud'||draftStorage==='test';
  const count=(draftStorage==='cloud'&&isGoogleUser())?cloudEventCountForCurrentGoogle():0;
  const ownerIndexReady=ownerIndexState.verified && ownerIndexState.uid===fbAuth?.currentUser?.uid && !ownerIndexState.indexMismatch;
  const cloudFull=draftStorage==='cloud'&&isGoogleUser()&&count>=CLOUD_EVENT_LIMIT;
  const ready=hasMode&&hasStorage&&!cloudFull && (draftStorage!=='cloud'||!isGoogleUser()||ownerIndexReady);

  const modeText=draftMode==='free'?'自由編排':draftMode==='single'?'單淘汰賽':'尚未選擇賽制';
  const storageText=draftStorage==='cloud'?'雲端賽事':draftStorage==='test'?'本機賽事':'尚未選擇建立方式';

  if(s){
    if(cloudFull){
      s.textContent=`目前選擇：${modeText} ＋ ${storageText}｜雲端賽事 ${count}/${CLOUD_EVENT_LIMIT}，請先刪除一場舊賽事`;
    }else if(!hasMode||!hasStorage){
      s.textContent=`目前選擇：${modeText} ＋ ${storageText}`;
    }else if(draftStorage==='cloud' && isGoogleUser()){
      const who=fbAuth.currentUser.email||fbAuth.currentUser.displayName||'Google 帳號';
      s.textContent=`目前選擇：${modeText} ＋ ${storageText}｜已登入：${who}｜${ownerIndexReady?'雲端賽事 '+count+'/'+CLOUD_EVENT_LIMIT:'雲端名額待核對，不可視為 0 場'}`;
    }else if(draftStorage==='cloud'){
      s.textContent=`目前選擇：${modeText} ＋ ${storageText}｜建立前需登入 Google`;
    }else{
      s.textContent=`目前選擇：${modeText} ＋ ${storageText}`;
    }
  }

  if(next){
    next.disabled=!ready;

    if(cloudFull){
      next.textContent=`雲端賽事已達 ${CLOUD_EVENT_LIMIT} 場上限`;
    }else if(!hasMode||!hasStorage){
      next.textContent='請先選擇賽制與建立方式';
    }else if(draftStorage==='cloud'&&isGoogleUser()&&!ownerIndexReady){
      next.textContent='雲端名額核對中，暫停建立';
    }else if(draftStorage==='cloud'&&!isGoogleUser()){
      next.textContent='使用 Google 登入並設定賽事';
    }else{
      next.textContent='下一步：設定賽事';
    }
  }
}
function selectHomeMode(mode){
  if(mode!=='free'&&mode!=='single')return;
  draftMode=mode;
  renderHomeSelections();
}
function selectStorageMode(mode){
  if(mode!=='cloud'&&mode!=='test')return;
  draftStorage=mode;
  localStorage.setItem(KEEP,mode==='test'?'1':'0');
  renderHomeSelections();
}
let googleLoginBusy=false;

function isInAppBrowser(){
  const ua=navigator.userAgent||'';
  return /Line\/|FBAN|FBAV|Instagram|MicroMessenger|Twitter/i.test(ua);
}

function setGoogleLoginBusy(busy){
  googleLoginBusy=!!busy;
  const b=$('googleLoginBtn');
  if(!b)return;
  b.disabled=!!busy;
  if(busy){
    b.classList.remove('logged');
    b.textContent='Google 登入中…';
  }else{
    renderHeaderAuth();
  }
}

async function requireGoogleLogin(){
  if(isGoogleUser())return true;
  if(googleLoginBusy)return false;

  // LINE / FB / IG 內建瀏覽器對 Google popup 特別容易卡住或無法返回。
  if(isInAppBrowser()){
    alert('目前使用的是 App 內建瀏覽器，Google 登入可能會卡住。\n\n請用右上角 / 分享選單，改用 Safari 或 Chrome 開啟此網頁後再登入。');
    return false;
  }

  if(!cloudReady){
    const ok=await initCloud();
    if(!ok)return false;
  }

  setGoogleLoginBusy(true);

  try{
    const provider=new firebase.auth.GoogleAuthProvider();
    provider.setCustomParameters({prompt:'select_account'});

    // 加入逾時保護，避免某些手機瀏覽器 popup promise 永遠不回來。
    const loginPromise=fbAuth.signInWithPopup(provider);
    const timeoutPromise=new Promise((_,reject)=>{
      setTimeout(()=>{
        const err=new Error('Google 登入逾時');
        err.code='auth/login-timeout';
        reject(err);
      },20000);
    });

    const result=await Promise.race([loginPromise,timeoutPromise]);

    fbUser=result?.user||fbAuth.currentUser;
    renderHeaderAuth();
    renderHomeSelections();
    return isGoogleUser();

  }catch(e){
    console.error('Google popup login failed',e);

    if(e?.code==='auth/popup-blocked'){
      alert('Google 登入視窗被瀏覽器阻擋。\n\n請允許彈出式視窗，或改用 Safari / Chrome 開啟後再試一次。');
    }else if(e?.code==='auth/popup-closed-by-user'){
      // 使用者自行關閉，不顯示錯誤。
    }else if(e?.code==='auth/cancelled-popup-request'){
      // 重複點擊造成舊 popup 被取消，不另外提示。
    }else if(e?.code==='auth/login-timeout'){
      alert('Google 登入等待過久，已自動取消等待。\n\n如果你是從 LINE、Facebook 或 Instagram 內開啟，請改用 Safari / Chrome 開啟這個網頁再登入。');
    }else if(e?.code==='auth/network-request-failed'){
      alert('Google 登入失敗：網路連線不穩定，請確認網路後再試一次。');
    }else if(e?.code==='auth/unauthorized-domain'){
      alert('Google 登入失敗：目前網址尚未加入 Firebase Authorized domains。');
    }else{
      alert('Google 登入失敗：'+(e?.message||e));
    }

    return false;
  }finally{
    setGoogleLoginBusy(false);
  }
}
async function proceedCreate(){
  const next=$('homeNextBtn');

  if(!draftMode || !draftStorage){
    renderHomeSelections();
    return;
  }

  if(next){
    next.disabled=true;
    next.textContent='準備中…';
  }

  try{
    if(draftStorage==='cloud' && !isGoogleUser()){
      const ok=await requireGoogleLogin();
      if(!ok)return;
    }

    if(draftStorage==='cloud'){
      // 先看本機已知數量；雲端數量只做短暫確認，不能因 Firebase 回應慢把「下一步」卡死。
      const localCount=cloudEventCountForCurrentGoogle();

      if(localCount>=CLOUD_EVENT_LIMIT){
        return alert(`這個 Google 帳號目前已有 ${localCount} 場雲端賽事，已達 ${CLOUD_EVENT_LIMIT} 場上限。請先刪除一場舊賽事後再建立。`);
      }

      const serverCount=await getCloudEventCountFromServer(2500);

      if(serverCount>=CLOUD_EVENT_LIMIT){
        return alert(`這個 Google 帳號目前已有 ${serverCount} 場雲端賽事，已達 ${CLOUD_EVENT_LIMIT} 場上限。請先刪除一場舊賽事後再建立。`);
      }
    }

    $('home').classList.add('hidden');
    $('create').classList.remove('hidden');

    $('createTitle').textContent=`建立${draftMode==='free'?'自由編排':'單淘汰賽'}・${draftStorage==='cloud'?'雲端賽事':'本機賽事'}`;
    $('freeOpts').classList.toggle('hidden',draftMode!=='free');

    updatePreview();
  }catch(e){
    console.error('proceedCreate failed',e);
    alert('開啟賽事設定失敗：'+(e?.message||e));
  }finally{
    // 若仍停留首頁，就恢復按鈕狀態；已進入建立頁則不用管。
    if($('home')&&!$('home').classList.contains('hidden')){
      renderHomeSelections();
    }
  }
}
function markEventSaved(id){
  if(!id)return;
  const e=(ev?.id===id?ev:events()[id]);

  if(e?.testOnly){
    let current=[];
    try{current=JSON.parse(localStorage.getItem(SAVED)||'[]')}catch(e){}
    if(!Array.isArray(current))current=[];
    const ids=current.filter(x=>x!==id);
    ids.unshift(id);
    localStorage.setItem(SAVED,JSON.stringify(ids.slice(0,30)));
    return;
  }

  cloudEventIds=[id,...cloudEventIds.filter(x=>x!==id)];
}
function unmarkEventSaved(id){
  cloudEventIds=cloudEventIds.filter(x=>x!==id);
  let ids=[];
  try{ids=JSON.parse(localStorage.getItem(SAVED)||'[]')}catch(e){}
  if(!Array.isArray(ids))ids=[];
  localStorage.setItem(SAVED,JSON.stringify(ids.filter(x=>x!==id)));
}
function purgeLocalEvent(id){
  try{
    const tests=JSON.parse(localStorage.getItem(STORE)||'{}');
    if(tests?.[id]){
      delete tests[id];
      localStorage.setItem(STORE,JSON.stringify(tests));
    }
  }catch(e){}

  delete cloudEventsCache[id];
  cloudEventIds=cloudEventIds.filter(x=>x!==id);
  delete cloudEventSlots[id];

  unmarkEventSaved(id);
  localStorage.removeItem(adminFlagKey(id));
  localStorage.removeItem(adminCodeKey(id));
  localStorage.removeItem(`bx_live_ref_identity_${id}`);
  if(localStorage.getItem(CURRENT)===id)localStorage.removeItem(CURRENT);
}
function formatSavedTime(ts){
  if(!ts)return '';
  try{return new Date(ts).toLocaleString('zh-TW',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})}catch{return ''}
}


const CLOUD_EVENT_LIMIT=3;

async function getCloudEventCountFromServer(timeoutMs=2500){
  if(!isGoogleUser())return 0;

  const uid=fbAuth.currentUser.uid;
  const fallback=cloudEventCountForCurrentGoogle();

  try{
    // Rules 已經允許 owner 讀自己的 userEvents；直接以 0/1/2 三個 slot 計算，
    // 不再讀不存在的 userEventCounts 節點。
    const slots=(await rtdbRestGet(`userEvents/${uid}`,timeoutMs))||{};
    const n=Object.values(slots).filter(v=>typeof v==='string'&&v).length;
    return Number.isFinite(n)&&n>=0?Math.max(n,fallback):fallback;
  }catch(e){
    console.warn('getCloudEventCountFromServer fallback',e);
    return fallback;
  }
}


const PUBLIC_WINDOW_MS=4*60*60*1000;

function cloudEventIdsForCurrentGoogle(){
  if(!isGoogleUser())return [];
  const uid=fbAuth.currentUser.uid;
  return cloudEventIds.filter(id=>cloudEventsCache[id]?.ownerUid===uid);
}

function cloudEventCountForCurrentGoogle(){
  return cloudEventIdsForCurrentGoogle().length;
}

function publicStatusText(e){
  if(!e || e.testOnly)return '';
  if(e.publicOpen===false)return '公開已關閉';

  const until=Number(e.publicUntil||0);
  if(!until || until<=Date.now())return '公開已到期';

  const ms=until-Date.now();
  const mins=Math.max(1,Math.ceil(ms/60000));
  if(mins>=60){
    const h=Math.floor(mins/60);
    const m=mins%60;
    return `公開中・剩餘 ${h} 小時${m?` ${m} 分`:''}`;
  }
  return `公開中・剩餘 ${mins} 分`;
}

async function closePublicEvent(id){
  const e=cloudEventsCache[id] || (ev?.id===id?ev:null);
  if(!e||e.testOnly)return;

  if(!isGoogleUser()||e.ownerUid!==fbAuth.currentUser.uid){
    return alert('只有這場賽事的主辦帳號可以關閉公開連結。');
  }

  const buttons=[...document.querySelectorAll(`[data-close-public-id="${CSS.escape(id)}"]`)];
  const oldTexts=buttons.map(b=>b.textContent);

  try{
    buttons.forEach(btn=>{btn.disabled=true;btn.textContent='關閉中…'});
    const now=Date.now();
    let closedAt=now;
    if(e.authorityBBX==='active'){
      const answer=await v1CloudOrganizerCommand('closePublic',{},id);
      if(!answer.published){alert('關閉請求已記錄，公開同步仍在進行；系統會繼續發布，請稍候重新確認狀態。');await backgroundRefreshCurrentEvent(id).catch(()=>{});return;}
      closedAt=answer.publicUntil;
    }else{
      await cloudUpdate({
        [`events/${id}/publicOpen`]:false,
        [`events/${id}/publicUntil`]:now,
        [`publicEvents/${id}/meta/publicOpen`]:false,
        [`publicEvents/${id}/meta/publicUntil`]:now
      },5000);
    }
    e.publicOpen=false;
    e.publicUntil=closedAt;
    cloudEventsCache[id]=e;

    if(ev?.id===id){
      ev.publicOpen=false;
      ev.publicUntil=closedAt;
      const keepTab=currentAdminTab;
      renderAdmin();
      if(keepTab)showTab(keepTab);
    }
    renderSavedEvents();
  }catch(err){
    console.error('closePublicEvent failed',err);
    alert('關閉公開連結失敗：'+(err?.message||err));
  }finally{
    buttons.forEach((btn,i)=>{
      if(document.body.contains(btn)){
        btn.disabled=false;
        btn.textContent=oldTexts[i]||'關閉公開連結';
      }
    });
  }
}

async function extendPublicEvent(id){
  const e=cloudEventsCache[id] || (ev?.id===id?ev:null);
  if(!e||e.testOnly)return;

  if(!isGoogleUser()||e.ownerUid!==fbAuth.currentUser.uid){
    return alert('只有這場賽事的主辦帳號可以延長公開時間。');
  }

  const buttons=[...document.querySelectorAll(`[data-extend-id="${CSS.escape(id)}"]`)];
  const oldTexts=buttons.map(b=>b.textContent);
  const keepTab=currentAdminTab||'share';

  try{
    buttons.forEach(btn=>{btn.disabled=true;btn.textContent='增加中…'});
    let nextUntil=Date.now()+PUBLIC_WINDOW_MS;
    if(e.authorityBBX==='active'){
      const answer=await v1CloudOrganizerCommand('extendPublic',{},id);
      if(!answer.published){alert('延長請求已記錄，公開同步仍在進行；請稍候重新確認狀態。');await backgroundRefreshCurrentEvent(id).catch(()=>{});return;}
      nextUntil=answer.publicUntil;
    }else{
      await cloudUpdate({
        [`events/${id}/publicOpen`]:true,
        [`events/${id}/publicUntil`]:nextUntil,
        [`publicEvents/${id}/meta/publicOpen`]:true,
        [`publicEvents/${id}/meta/publicUntil`]:nextUntil
      },5000);
    }
    e.publicOpen=true;
    e.publicUntil=nextUntil;
    cloudEventsCache[id]=e;

    if(ev?.id===id){
      ev.publicOpen=true;
      ev.publicUntil=nextUntil;
      renderAdmin();
      showTab(keepTab);
    }
    renderSavedEvents();
  }catch(err){
    console.error('extendPublicEvent failed',err);
    alert('增加公開時間失敗：'+(err?.message||err));
  }finally{
    buttons.forEach((btn,i)=>{
      if(document.body.contains(btn)){
        btn.disabled=false;
        btn.textContent=oldTexts[i]||'增加 4 小時';
      }
    });
  }
}

async function syncMyCloudEvents(snapshot=undefined,isCurrent=()=>true){
  // On iOS, Firebase Auth may temporarily report null while restoring the
  // previous Google user. This is NOT an explicit sign-out or a deletion.
  if(!isGoogleUser())return cloudEventIds.length;

  const uid=fbAuth.currentUser.uid;
  const oldCache=cloudEventsCache;
  const oldIds=cloudEventIds;
  const oldSlots=cloudEventSlots;

  try{
    const raw=(snapshot===undefined?await rtdbRestGet(`userEvents/${uid}`,6000):snapshot);
    if(!isCurrent()||fbAuth?.currentUser?.uid!==uid)return cloudEventIds.length;
    // A missing index while known tournaments still exist is an inconsistency,
    // not permission to silently clear the organizer's list.
    const slots=indexedOwnerSlots(raw);
    const slotEntries=Object.entries(slots)
      .filter(([slot,id])=>['0','1','2'].includes(String(slot)) && typeof id==='string' && id);
    if(slotEntries.length===0 && oldIds.length){
      console.warn('Owner index empty while previously known events exist; retaining last known list for recovery');
      // Never let a missing index leave privileged buttons enabled from RAM.
      cloudEventsCache=Object.fromEntries(Object.entries(oldCache).map(([id,item])=>
        [id,item?.ownerUid===uid?{...item,pendingSync:true}:item]));
      return oldIds.length;
    }

    const nextCache={};
    const nextIds=[];
    const nextSlots={};
    for(const [slot,id] of slotEntries){
      let data=null;
      try{
        data=await rtdbRestGet(`events/${id}`,6000);
      }catch(e){
        console.warn('Owner event temporarily unavailable; preserving index',id,e);
      }
      if(!isCurrent()||fbAuth?.currentUser?.uid!==uid)return cloudEventIds.length;
      // A 200/null is not proof that this organizer pressed Delete. Only the
      // authenticated DeleteAuthority operation may remove userEvents slots.
      // A single failed read must not erase other entries from RAM either.
      const usable=data?.id===id && data?.ownerUid===uid;
      nextCache[id]=usable?{...data,pendingSync:false}:{
        ...(oldCache[id]?.ownerUid===uid?oldCache[id]:{id,ownerUid:uid,name:'雲端資料暫時無法載入'}),
        pendingSync:true
      };
      nextIds.push(id);
      nextSlots[id]=String(slot);
    }

    if(!isCurrent()||fbAuth?.currentUser?.uid!==uid)return cloudEventIds.length;
    // A listener snapshot can temporarily omit a formerly indexed event. Do
    // not silently discard a known tournament just because its slot vanished.
    // A legitimate DeleteAuthority command removes that ID explicitly.
    for(const oldId of oldIds){
      if(nextIds.includes(oldId)||oldCache[oldId]?.ownerUid!==uid)continue;
      nextCache[oldId]={...oldCache[oldId],pendingSync:true};
      nextIds.push(oldId);
      if(oldSlots[oldId]!==undefined)nextSlots[oldId]=oldSlots[oldId];
    }
    cloudEventsCache=nextCache;
    cloudEventIds=nextIds;
    cloudEventSlots=nextSlots;
    return nextIds.length;
  }catch(e){
    console.warn('syncMyCloudEvents transient failure; retaining cached index',e);
    return oldIds.length;
  }
}


function renderSavedEvents(){
  const box=$('savedEvents'),count=$('savedCount');
  if(!box||!count)return;

  const all=events();
  const ids=savedEventIds().filter(id=>all[id]);
  const cloudCount=isGoogleUser()?cloudEventIds.length:0;
  const testCount=ids.filter(id=>all[id]?.testOnly).length;

  const verified=ownerIndexState.verified && ownerIndexState.uid===fbAuth?.currentUser?.uid && !ownerIndexState.indexMismatch;
  count.textContent=isGoogleUser()
    ? `${verified?cloudCount+'/'+CLOUD_EVENT_LIMIT+' 場雲端':'雲端待核對'+(cloudCount?'（已知 '+cloudCount+' 場）':'')}・${testCount} 場本機`
    : `${testCount} 場本機`;
  renderOwnerIndexDiagnostics();

  if(!ids.length){
    box.innerHTML=isGoogleUser() && !verified
      ? '<div class=savedEmpty>雲端賽事尚未核對完成。這不是已確認的 0 場，請查看下方同步診斷；系統不會自行刪除任何賽事。</div>'
      : '<div class=savedEmpty>目前沒有賽事。☁️ 雲端賽事使用跨裝置同步；📱 本機賽事只存在這支裝置。</div>';
    return;
  }

  box.innerHTML=ids.map(id=>{
    const e=all[id];
    if(!e)return '';

    const mode=e.mode==='free'?'自由編排':'單淘汰';
    const when=formatSavedTime(e.created);
    const isTest=!!e.testOnly;
    const typeHtml=isTest
      ? '<span class="savedType test">📱 本機賽事</span>'
      : '<span class="savedType cloud">☁️ 雲端賽事</span>';
    const ownerControls=!isTest && !e.pendingSync && isGoogleUser() && e.ownerUid===fbAuth.currentUser.uid;
    const status=e.pendingSync
      ? '<div class="savedPublicStatus off">雲端讀取尚未確認，紀錄已保留；請稍候重試</div>'
      : !isTest
        ? `<div class="savedPublicStatus ${e.publicOpen===false||Number(e.publicUntil||0)<=Date.now()?'off':'on'}">${publicStatusText(e)}</div>`
        : '';

    return `<div class="savedEvent ${isTest?'test':'cloud'}">
      <div>
        <div class=savedEventName>${typeHtml}${esc(e.name||'Beyblade X Tournament')}</div>
        <div class=savedEventMeta>${e.publicCode?'活動 ID：'+esc(e.publicCode)+'・':''}${e.roster?.length||0} 人・${mode}${when?'・'+when:''}</div>
        ${status}
      </div>
      <div class=savedEventActions>
        <button type="button" data-open-id="${id}">繼續</button>
        ${ownerControls?`
          <button type="button" class="secondary" data-extend-id="${id}">增加 4 小時</button>
          <button type="button" class="secondary" data-close-public-id="${id}" ${e.publicOpen===false?'disabled':''}>關閉公開連結</button>
        `:''}
        ${!e.pendingSync?`<button type="button" class="danger" data-delete-id="${id}">${isTest?'刪除本機':'刪除雲端'}</button>`:''}
      </div>
    </div>`;
  }).join('');

  box.querySelectorAll('[data-open-id]').forEach(btn=>btn.addEventListener('click',()=>openSavedEvent(btn.dataset.openId)));
  box.querySelectorAll('[data-extend-id]').forEach(btn=>btn.addEventListener('click',()=>extendPublicEvent(btn.dataset.extendId)));
  box.querySelectorAll('[data-close-public-id]').forEach(btn=>btn.addEventListener('click',()=>closePublicEvent(btn.dataset.closePublicId)));
  box.querySelectorAll('[data-delete-id]').forEach(btn=>btn.addEventListener('click',()=>requestDeleteSavedEvent(btn.dataset.deleteId)));
}

async function openCachedOwnerEvent(cached){
  if(!cached?.id)return false;
  return (await loadCloudEvent(cached.id))==='ok';
}

async function openSavedEvent(id){
  const btn=document.querySelector(`[data-open-id="${CSS.escape(id)}"]`);
  const oldText=btn?.textContent||'繼續';

  if(btn){
    btn.disabled=true;
    btn.textContent='載入中…';
  }

  try{
    const local=events()[id];

    if(local?.testOnly){
      ev=local;
      isAdmin=true;
      isReferee=false;

      $('home').classList.add('hidden');
      $('create').classList.add('hidden');
      $('admin').classList.remove('hidden');

      history.replaceState(null,'',location.pathname);
      renderAdmin();
      showTab('bracket');
      return;
    }

    const result=await Promise.race([
      loadCloudEvent(id),
      new Promise(resolve=>setTimeout(()=>resolve('timeout'),9000))
    ]);

    if(result==='ok'){
      history.replaceState(null,'',`${location.pathname}?event=${encodeURIComponent(id)}&tab=${encodeURIComponent(currentAdminTab||'bracket')}`);
      return;
    }

    if(result==='missing'){
      delete cloudEventsCache[id];
      cloudEventIds=cloudEventIds.filter(x=>x!==id);
      renderSavedEvents();
      return alert('這場雲端賽事已不存在。');
    }

    if(result==='expired'){
      return alert('目前無法讀取這場賽事。若你是主辦，請確認仍登入建立這場賽事的 Google 帳號。');
    }

    if(result==='timeout'){
      return alert('載入超過 9 秒仍未完成。已停止等待，不會再卡在「載入中」。請確認網路後再按一次。');
    }

    alert('目前無法從 Firebase 載入這場賽事，請檢查網路後再試。');
  }catch(e){
    console.error('openSavedEvent failed',e);
    alert('開啟賽事失敗：'+(e?.message||e));
  }finally{
    if(btn&&document.body.contains(btn)){
      btn.disabled=false;
      btn.textContent=oldText;
    }
  }
}
let pendingDeleteId='';
function requestDeleteSavedEvent(id){
  const cached=events()[id];
  if(!cached)return alert('找不到這場賽事的本機資料。');
  pendingDeleteId=id;
  const modal=$('deleteConfirmModal'),text=$('deleteConfirmText'),ok=$('deleteOkBtn');
  if(cached.testOnly){
    text.innerHTML='這會刪除這支裝置上的<strong>本機賽事</strong>。<br>這場沒有雲端資料。';
    ok.textContent='刪除本機';
  }else{
    text.innerHTML='這會<strong>永久刪除整場雲端賽事</strong>，包含完整賽程、公開觀看投影、管理員、裁判權限、驗證碼與雲端名額。<br><br>只有全部刪除成功後，首頁才會移除這場賽事。此動作無法復原。';
    ok.textContent='刪除雲端';
  }
  syncAppVisualViewport();
  modal.classList.remove('hidden');
}
function closeDeleteConfirm(){
  pendingDeleteId='';
  $('deleteConfirmModal')?.classList.add('hidden');
}

function cloudDeleteErrorLabel(step,e){
  const msg=String(e?.message||e||'未知錯誤');
  return `刪除停在「${step}」：${msg}`;
}

async function deleteSavedEvent(id){
  const cached=events()[id];
  if(!cached)return alert('找不到這場賽事資料。');

  if(cached.testOnly){
    purgeLocalEvent(id);
    if(typeof clearActiveView==='function')clearActiveView();
    closeDeleteConfirm();
    renderSavedEvents();
    return;
  }

  const btn=$('deleteOkBtn');
  let deleteStep='確認主辦身分';

  try{
    if(btn){btn.disabled=true;btn.textContent='確認身分…'}

    if(!(await initCloud()))throw new Error('目前無法初始化 Firebase');
    if(!isGoogleUser())throw new Error('請先登入建立這場賽事的 Google 帳號');

    const remote=await rtdbRestGet(`events/${id}`,5000);
    if(!remote)throw new Error('這場雲端賽事已不存在');
    if(remote.ownerUid!==fbAuth.currentUser.uid)throw new Error('目前登入帳號不是這場賽事的建立者');

    const uid=fbAuth.currentUser.uid;
    const slots=(await rtdbRestGet(`userEvents/${uid}`,5000))||{};
    const slot=Object.keys(slots).find(k=>slots[k]===id);
    if(slot===undefined)throw new Error('找不到這場賽事的 owner slot，請重新整理後再試');

    if(remote.authorityBBX==='active'){
      deleteStep='由 Cloud Functions 刪除整場權威賽事';
      if(btn)btn.textContent='雲端刪除中…';
      const fn=firebase.app().functions('asia-southeast1').httpsCallable('bbxV011DeleteAuthority');
      const reply=(await fn({clientVersion:V1_AUTH_CLIENT,eventId:id})).data;
      if(!reply?.deleted)throw new Error('伺服器沒有確認刪除');
    }else{
    const deps=[
      ['公開賽程投影',`publicEvents/${id}`],
      ['裁判身分領取',`refereeClaims/${id}`],
      ['裁判登入權限',`refereeUsers/${id}`],
      ['裁判驗證碼',`refereeSecrets/${id}`],
      ['主辦驗證碼',`secrets/${id}`],
      ['共同主辦權限',`admins/${id}`]
    ];

    for(const [label,path] of deps){
      deleteStep=`刪除${label}`;
      if(btn)btn.textContent=`${deleteStep}…`;
      await rtdbRestDelete(path,5000);
    }

    deleteStep='刪除賽事本體';
    if(btn)btn.textContent='刪除賽事…';
    await rtdbRestDelete(`events/${id}`,5000);

    deleteStep='釋放雲端名額';
    await rtdbRestDelete(`userEvents/${uid}/${slot}`,5000);
    } // end legacy direct-delete path

    delete cloudEventsCache[id];
    cloudEventIds=cloudEventIds.filter(x=>x!==id);
    delete cloudEventSlots[id];

    if(typeof clearActiveView==='function')clearActiveView();
    closeDeleteConfirm();

    if(ev?.id===id){
      stopAdminCodeRotation();
      if(typeof stopRefereeCodeRotation==='function')stopRefereeCodeRotation();
      ev=null;
      if(cloudUnsub){cloudUnsub();cloudUnsub=null}
      $('admin')?.classList.add('hidden');
      $('create')?.classList.add('hidden');
      $('home')?.classList.remove('hidden');
      history.replaceState(null,'',location.pathname);
    }

    renderSavedEvents();
    alert('雲端賽事已完整刪除。');

  }catch(e){
    console.error('deleteSavedEvent failed',deleteStep,e);
    alert(`刪除雲端賽事失敗：${e?.message||e}\n\n失敗步驟：${deleteStep}`);
  }finally{
    if(btn){
      btn.disabled=false;
      btn.textContent='確認刪除';
    }
  }
}


// V0.37: RTDB SDK transport and manual WebSocket/long-poll diagnostics removed.
// Auth identity and Cloud Functions continue using Firebase Auth/Functions compat.
// Tournament reads/writes and live notifications use HTTPS REST / authenticated SSE.
function bbxSseSupported(){return typeof EventSource==='function';}
// Shared, bounded event stream used for Home and legacy projection screens.
// Each screen owns exactly one stream; navigation/background closes it.
function bbxOpenRestStream(path, onMessage, onDisconnected, isActive, authenticated=true){
  let closed=false,source=null,retryTimer=null,renewTimer=null,attempt=0,generation=0;
  const clear=()=>{
    if(retryTimer!==null){clearTimeout(retryTimer);retryTimer=null;}
    if(renewTimer!==null){clearTimeout(renewTimer);renewTimer=null;}
    try{source?.close()}catch(_e){}source=null;
  };
  const reconnect=()=>{
    if(closed||!isActive()||retryTimer!==null)return;
    clear();onDisconnected?.();
    const delay=Math.min(18000,800*2**Math.min(attempt++,4));
    retryTimer=setTimeout(()=>{retryTimer=null;start()},delay);
  };
  async function start(){
    if(closed||!isActive())return;
    if(!bbxSseSupported()){onDisconnected?.('EventSource 不支援');return;}
    const gen=++generation;
    try{
      const root=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
      if(!root)throw Error('DATABASE_URL_MISSING');
      const token=authenticated?await getRestIdToken(false):null;
      if(closed||!isActive()||gen!==generation)return;
      const url=root+'/'+path+'.json'+(token?'?auth='+encodeURIComponent(token):'');
      source=new EventSource(url);
      const handle=event=>{
        if(closed||!isActive()||gen!==generation)return;
        try{const data=JSON.parse(event.data);if(data&&typeof data.path==='string'){
          attempt=0;onMessage(data,event.type);
        }}catch(e){console.warn('BBX_SSE_INVALID_EVENT',String(e?.message||e));reconnect();}
      };
      source.addEventListener('put',handle);source.addEventListener('patch',handle);
      source.addEventListener('cancel',reconnect);
      source.addEventListener('auth_revoked',reconnect);
      source.onerror=reconnect;
      // Auth token expires; reconnect before expiry, never save tokens to storage.
      renewTimer=setTimeout(()=>{if(!closed&&isActive()){clear();start();}},42*60*1000);
      if(typeof renewTimer?.unref==='function')renewTimer.unref();
    }catch(e){console.warn('BBX_SSE_OPEN_FAILED',path,String(e?.code||e?.message||e));reconnect();}
  }
  start();
  return ()=>{closed=true;generation++;clear()};
}

function firebaseConfigured(){return !Object.values(FIREBASE_CONFIG).some(v=>String(v).includes('PASTE_'))}
// Single-flight Firebase initialization. Privileged routes and auth restore must
// share the exact same Firebase Auth observer.
async function initCloud(){
  if(cloudReady){fbUser=fbAuth?.currentUser||null;return true;}
  if(cloudInitPromise)return cloudInitPromise;
  cloudInitPromise=initializeCloudOnce().finally(()=>{cloudInitPromise=null});
  return cloudInitPromise;
}
async function initializeCloudOnce(){
  if(cloudReady){
    fbUser=fbAuth?.currentUser||null;
    return true;
  }

  if(!firebaseConfigured())return false;

  try{
    bbxLifecycleNote('firebase-init','begin');
    fbApp=firebase.apps.length?firebase.app():firebase.initializeApp(FIREBASE_CONFIG);
    fbAuth=firebase.auth();

    // 主辦 Google 登入、裁判匿名身分都採 LOCAL persistence。
    // 一般觀眾不建立 Firebase Authentication 使用者。
    await fbAuth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);
    bbxLifecycleNote('auth-persistence','ready');

    fbUser=fbAuth.currentUser||null;

    fbAuth.onAuthStateChanged(async u=>{
      // A different Firebase UID must never inherit the prior organizer's
      // in-memory event list. Transient null is not a sign-out/deletion.
      const nextUid=u?.uid||null;
      bbxLifecycleNote('auth-callback',u?.providerData?.some(p=>p.providerId==='google.com')?'google':u?'anonymous':'null');
      if(nextUid && ownerIndexLastUid && nextUid!==ownerIndexLastUid){
        // A different UID must not keep private observers from the old account.
        if(ev&&!ev.testOnly&&!ev.publicViewOnly && cloudUnsub){
          cloudUnsub();cloudUnsub=null;
          cloudResyncBlocked=true;isAdmin=false;isReferee=false;
          bbxLifecycleNote('private-subscription','auth-changed');
        }
        stopMyCloudEventIndexListener();
        cloudEventsCache={};cloudEventIds=[];cloudEventSlots={};
        setOwnerIndexState({phase:'restoring',uid:nextUid,verified:false,restSlots:null,
          error:null,indexMismatch:false,source:null,checkedAt:null});
      }
      if(nextUid)ownerIndexLastUid=nextUid;
      fbUser=u||null;
      restTokenCache={token:null,ts:0};
      // A late iOS authentication restoration must restart an event left
      // without subscriptions by pagehide, without returning to Home.
      if(u&&ev&&!ev.testOnly&&!ev.publicViewOnly&&
         !$('admin')?.classList.contains('hidden')&&!cloudUnsub&&
         document.visibilityState!=='hidden'){
        resyncCurrentCloudEventOnForeground('late-auth-restored').catch(console.warn);
      }

      renderHeaderAuth();
      if(!u){
        setOwnerIndexState({phase:'restoring',verified:false,error:null});
      }else if(!u.providerData?.some(p=>p.providerId==='google.com')){
        setOwnerIndexState({phase:'signed-out',uid:u.uid,verified:false,error:null});
      }
      if(u?.providerData?.some(p=>p.providerId==='google.com') && ev?.publicViewOnly &&
         new URLSearchParams(location.search).has('event') &&
         new URLSearchParams(location.search).get('ref')!=='1'){
        const id=new URLSearchParams(location.search).get('event');
        loadCloudEvent(id).catch(e=>console.warn('late Google owner restore pending',e));
      }

      // The saved view may survive as a session hint even when the visible
      // page is Home. It must not suppress the owner index after auth restore.
      if(!bbxBootstrapping && bbxEnteringPrivateEvent===0 &&
         $('home') && !$('home').classList.contains('hidden') &&
         !new URLSearchParams(location.search).has('event')){
        renderHomeSelections();

        // Only the Google Home route opens the owner index; a signed-out
        // callback closes it rather than leaving an old UID subscribed.
        if(isGoogleUser()){
          try{
            renderSavedEvents();
            listenMyCloudEventIndex();
          }catch(e){
            console.warn('auth home sync skipped',e);
          }
        }else{
          stopMyCloudEventIndexListener();
        }
      }
    });

    cloudReady=true;
    bbxLifecycleNote('firebase-init','ready');
    return true;
  }catch(e){
    console.error(e);
    alert('Firebase 連線失敗：'+e.message);
    return false;
  }
}
function localEventSave(){
  if(!ev)return;

  if(ev.testOnly){
    // 本機賽事：完整資料只存在這支裝置。
    let tests={};
    try{tests=JSON.parse(localStorage.getItem(STORE)||'{}')}catch(e){}
    tests[ev.id]=ev;
    localStorage.setItem(STORE,JSON.stringify(tests));
    localStorage.setItem(CURRENT,ev.id);
    markEventSaved(ev.id);
    return;
  }

  // 雲端賽事：絕不寫 localStorage。
  // 這份 cache 只是目前頁面 RAM，Firebase 才是唯一真實資料來源。
  cloudEventsCache[ev.id]=ev;
  if(isGoogleUser() && ev.ownerUid===fbAuth?.currentUser?.uid && !cloudEventIds.includes(ev.id)){
    cloudEventIds.unshift(ev.id);
  }
}


function publicMatchView(m){
  if(!m)return null;
  return {
    a:m.a??'待定',
    b:m.b??'待定',
    sa:m.sa??'',
    sb:m.sb??'',
    winner:m.winner??null,
    refereeActive:m.refereeActive===true,
    referee:m.refereeActive===true?String(m.referee||'').slice(0,40):''
  };
}

function publicRoundView(r){
  if(!r)return null;
  return {
    name:r.name||'',
    placementFinal:r.placementFinal===true,
    matches:Array.isArray(r.matches)?r.matches.map(publicMatchView):[]
  };
}

function publicFinalRRView(rr){
  if(!rr)return null;
  return {
    players:Array.isArray(rr.players)?[...rr.players]:[],
    matches:Array.isArray(rr.matches)?rr.matches.map(publicMatchView):[]
  };
}

function publicEventProjectionFromEvent(e){
  if(!e)return null;
  return {
    meta:{
      id:e.id,
      name:e.name||'Beyblade X Tournament',
      mode:e.mode||'free',
      pairing:e.pairing||'ordered',
      freeFinal:e.freeFinal||'champ',
      roster:Array.isArray(e.roster)?[...e.roster]:[],
      created:Number(e.created)||Date.now(),
      cloudVersion:Number(e.cloudVersion)||5,
      syncVersion:Number(e.syncVersion)||0,
      publicOpen:e.publicOpen!==false,
      publicUntil:Number(e.publicUntil)||0
    },
    rounds:Array.isArray(e.rounds)?e.rounds.map(publicRoundView):[],
    finalRR:publicFinalRRView(e.finalRR)
  };
}

// Cloud authority adapter: same V1.0 markup and event model, only match operations move server-side.
const V1_AUTH_CLIENT='bbx-v0.11-authority-1';
// Existing V0.9 tournaments retain their original callable and credentials.
function authorityFnName(action, event=ev){return 'bbxV'+(event?.releaseTag==='BBX-V0.9'?'09':event?.releaseTag==='BBX-V0.10'?'010':'011')+action}
function authorityClientVersion(event=ev){return event?.releaseTag==='BBX-V0.9'?'bbx-v0.9-authority-1':event?.releaseTag==='BBX-V0.10'?'bbx-v0.10-authority-1':V1_AUTH_CLIENT}
const isV1Authority=()=>!!ev&&!ev.testOnly&&ev.authorityBBX==='active'&&['BBX-V0.9','BBX-V0.10','BBX-V0.11'].includes(ev.releaseTag);
// The authority epoch advances at commit, the published epoch advances WITH
// the actual roster/bracket. Never target the new epoch using old DOM rows.
function projectedStructureOf(event){
 if(!event)return null;
 const authority=Number(event.structureVersion)||0;
 if(event.releaseTag!=='BBX-V0.11'||authority===0)return authority;
 if(event.publishedStructureVersion!=null)return Number(event.publishedStructureVersion)===authority?authority:null;
 return Number(event.publishedSeq||0)>=Number(event.authoritySeq||0)?authority:null;
}
function sameProjectedStructure(previous,next){
 const a=Number(previous?.publishedStructureVersion??previous?.structureVersion)||0;
 const b=Number(next?.publishedStructureVersion??next?.structureVersion)||0;
 return a===b && (next?.publishedStructureVersion!=null||projectedStructureOf(next)!==null);
}
function closeStaleMatchSheet(previous,next){
 const a=Number(previous?.publishedStructureVersion??previous?.structureVersion)||0;
 const b=Number(next?.publishedStructureVersion??next?.structureVersion)||0;
 if(a===b||previous?.id!==next?.id||!$('matchModal')||$('matchModal').classList.contains('hidden'))return;
 $('matchModal').classList.add('hidden');closeScorePicker();closeResetChoice();clearActiveMatchSheet();
}
const makeV1OpId=()=>Date.now().toString(16).padStart(12,'0')+
 Array.from(crypto.getRandomValues(new Uint8Array(18)),b=>b.toString(16).padStart(2,'0')).join('');
function v1Match(kind,ri,mi){return kind==='rr'?ev.finalRR?.matches?.[mi]:ev.rounds?.[ri]?.matches?.[mi]}
// Single authoritative in-flight score command per match. Rapid taps are coalesced,
// but never start a second score command before the previous one is confirmed.
// The server matchVersion is held here independently of the delayed public mirror.
const v05ScoreQueues=new Map();
const v05ScoreKey=(eventId,kind,ri,mi)=>`${eventId}:${kind}:${ri}:${mi}`;
function v05ScoreState(kind,ri,mi){
 const eventId=ev?.id;
 return v05ScoreQueues.get(v05ScoreKey(eventId,kind,ri,mi));
}
function v05ScorePending(kind,ri,mi){
 const s=v05ScoreState(kind,ri,mi);
 return !!(s&&(s.timer||s.run||s.desired));
}
function v05PrivateMatch(m){
 return {a:m.a,b:m.b,sa:m.sa??'',sb:m.sb??'',winner:m.winner||null,
  referee:m.referee||'',refereeActive:m.refereeActive===true,
  matchVersion:Number(m.matchVersion)||0};
}
function v05AcceptServerMatch(kind,ri,mi,remote,{force=false}={}){
 if(!ev||!remote)return false;
 const m=v1Match(kind,ri,mi);
 if(!m)return false;
 if((remote.a!==undefined&&remote.a!==m.a)||(remote.b!==undefined&&remote.b!==m.b))return false;
 const pending=v05ScorePending(kind,ri,mi);
 if(!force && (pending||Number(m.matchVersion||0)>Number(remote.matchVersion||0)))return false;
 Object.assign(m,remote);
 const state=v05ScoreState(kind,ri,mi);
 if(state&&!pending){state.version=Number(remote.matchVersion)||0;state.confirmed=null;}
 localEventSave();
 return true;
}
async function v05ReadAuthoritativeMatch(kind,ri,mi,{apply=true}={}){
 if(!isV1Authority()||!(await initCloud()))throw new Error('賽事權威狀態無法讀取');
 const eventId=ev.id;
 const fn=firebase.app().functions('asia-southeast1').httpsCallable(authorityFnName('GetOperation'));
 const r=(await fn({clientVersion:authorityClientVersion(),eventId,readMatch:true,
  target:{kind,ri:kind==='rr'?0:ri,mi}})).data;
 if(!r?.found||!r.match)throw new Error('雲端尚未提供這場比賽的權威比分');
 if(ev?.id===eventId && apply)v05AcceptServerMatch(kind,ri,mi,r.match);
 return r;
}
async function v05ReadOperationReceipt(eventId,opId){
 const fn=firebase.app().functions('asia-southeast1').httpsCallable(authorityFnName('GetOperation'));
 return (await fn({clientVersion:authorityClientVersion(),eventId,opId})).data;
}
function v05QueueScore(kind,ri,mi,delay=150){
 const m=v1Match(kind,ri,mi),eventId=ev?.id;
 if(!m||!isV1Authority())return;
 const key=v05ScoreKey(eventId,kind,ri,mi);
 let state=v05ScoreQueues.get(key);
 if(!state){
  state={eventId,kind,ri,mi,version:Number(m.matchVersion)||0,
   desired:null,timer:null,run:null,lastError:null,confirmed:null};
  v05ScoreQueues.set(key,state);
 }
 if(!state.run&&!state.desired&&!state.timer){
  state.version=Number(m.matchVersion)||0;
  state.structureVersion=Number(ev.publishedStructureVersion??ev.structureVersion)||0;
 }
 state.desired={sa:Number(m.sa||0),sb:Number(m.sb||0)};
 state.lastError=null;
 if(state.run)return;
 if(state.timer)clearTimeout(state.timer);
 state.timer=setTimeout(()=>{
  state.timer=null;
  v05DrainScores(state).catch(()=>{});
 },delay);
}
function v05DrainScores(state){
 if(state.run)return state.run;
 state.run=(async()=>{
  while(state.desired){
   if(!isV1Authority()||ev.id!==state.eventId)throw new Error('賽事已切換，停止舊比分操作');
   if(state.structureVersion!==(Number(ev.publishedStructureVersion??ev.structureVersion)||0))throw new Error('籤表已更新，請重新選擇場次');
   const score=state.desired;
   state.desired=null;
   const beforeVersion=state.version;
   const opId=makeV1OpId();
   let confirmedScore=score;
   let confirmedVersion;
   try{
    // Match version advances ONLY after a confirmed authoritative command.
    const res=await v1CloudMatchCommand('score',state.kind,state.ri,state.mi,{
     ...score,opId,expectedMatchVersion:beforeVersion,skipConflictRefresh:true});
    confirmedVersion=Number(res.matchVersion);
   }catch(error){
    // Check the EXACT original operation receipt. A matching score/version
    // alone would not prove which judge committed a concurrent mutation.
    let receipt=null;
    try{receipt=await v05ReadOperationReceipt(state.eventId,opId);}
    catch(e){console.warn('operation receipt lookup unavailable',e)}
    let authoritative=null;
    try{authoritative=(await v05ReadAuthoritativeMatch(state.kind,state.ri,state.mi,{apply:false})).match;}
    catch(e){console.warn('authoritative score lookup unavailable',e)}
    if(authoritative){
     state.version=Number(authoritative.matchVersion)||0;
     v05AcceptServerMatch(state.kind,state.ri,state.mi,authoritative,{force:!state.desired});
    }
    // Only a receipt for this opId is proof of successful commit. Also
    // require the latest authoritative value still to match this score.
    const committed=receipt?.found===true&&receipt.ok===true&&authoritative&&
      Number(authoritative.matchVersion)>=Number(receipt.matchVersion)&&
      Number(authoritative.sa||0)===score.sa&&Number(authoritative.sb||0)===score.sb;
    if(committed){
     confirmedVersion=state.version;
    }else{
     state.desired=null;
     if(authoritative){
      v05AcceptServerMatch(state.kind,state.ri,state.mi,authoritative,{force:true});
      renderAdmin();
     }
     throw error;
    }
   }
   state.version=confirmedVersion;
   state.confirmed={...confirmedScore,matchVersion:state.version};
   if(!state.desired&&ev?.id===state.eventId&&state.structureVersion===(Number(ev.publishedStructureVersion??ev.structureVersion)||0)){
    const m=v1Match(state.kind,state.ri,state.mi);
    if(m){m.matchVersion=state.version;m.sa=score.sa;m.sb=score.sb;localEventSave();}
   }
  }
  state.lastError=null;
 })().catch(e=>{
  state.lastError=e;
  state.desired=null;
  if(ev?.id===state.eventId)
   backgroundSyncAlert('比分尚未取得雲端確認，已停止後續記分。請核對最新比分再操作。\n原因：'+(e.code||'unknown')+' '+(e.message||'未取得回應'));
  throw e;
 }).finally(()=>{state.run=null;});
 return state.run;
}
async function v05FlushScores(kind,ri,mi){
 const state=v05ScoreState(kind,ri,mi);
 if(!state)return;
 if(state.timer){clearTimeout(state.timer);state.timer=null;}
 // Do not discard an unsubmitted final score when the judge presses Complete.
 if(state.run)await state.run;
 if(state.desired)await v05DrainScores(state);
 if(state.lastError)throw new Error('上一筆比分沒有確認成功，請先重新核對比分');
}
async function v1CloudMatchCommand(action,kind,ri,mi,options={}){
  if(cloudResyncBlocked)throw new Error('最新賽程尚未確認，請等待重新同步');
 if(!isV1Authority())throw new Error('賽事尚未切換至雲端權威模式');
 const m=v1Match(kind,ri,mi);if(!m)throw new Error('找不到場次');
 const eventId=ev.id,expectedStructureVersion=projectedStructureOf(ev);
 if(expectedStructureVersion===null)throw new Error('籤表正在同步，請等待最新場次');
 if(!(await initCloud()))throw new Error('雲端尚未連線');
 if(ev?.id!==eventId||projectedStructureOf(ev)!==expectedStructureVersion)throw new Error('籤表已更新，請重新選擇場次');
 const name=options.referee??currentRefereeName();
 const body={clientVersion:authorityClientVersion(),eventId:ev.id,
   opId:options.opId||makeV1OpId(),action,target:{kind,ri:kind==='rr'?0:ri,mi},
   expectedMatchVersion:options.expectedMatchVersion??(Number(m.matchVersion)||0),expectedStructureVersion,referee:name,
   sa:options.sa??Number(m.sa||0),sb:options.sb??Number(m.sb||0)};
 try{
   const fn=firebase.app().functions('asia-southeast1').httpsCallable(authorityFnName('CommandAuthority'));
   const res=(await fn(body)).data;
   if(!res?.ok)throw new Error('伺服器未確認操作成功');
   if(res.publicationPending===true){
     console.warn('Score committed but realtime projection not yet confirmed',body.eventId,body.action,res.seq);
     // A valid authority receipt is not proof that the OTHER phones saw it.
     // Keep the original receipt, and report publication separately from navigation.
     notePendingPublication(body.eventId,res.seq);
   }
   // The server is authoritative. Never retry a new opId after an ambiguous response.
   // The object captured before await may have been replaced by another refresh.
   const live=ev?.id===body.eventId&&projectedStructureOf(ev)===expectedStructureVersion?v1Match(kind,ri,mi):null;
   if(live){
    live.matchVersion=res.matchVersion;
    if(action!=='score'){
     const pending=v05ScoreState(kind,ri,mi);
     if(pending && !pending.run && !pending.desired && !pending.timer){
      pending.version=Number(res.matchVersion)||0;
      pending.confirmed=null;
     }
    }
    if(action==='claim'){
     const myUid=fbAuth?.currentUser?.uid;
     if(myUid){
      for(const round of ev.rounds||[])for(const other of round.matches||[]){
       if(other!==live&&other?.claimUid===myUid&&other.refereeActive&&!other.winner){
        other.refereeActive=false;other.referee='';other.claimUid=null;
        // Keep its version unchanged; only the cloud can supply its new version.
       }
      }
      for(const other of ev.finalRR?.matches||[]){
       if(other!==live&&other?.claimUid===myUid&&other.refereeActive&&!other.winner){
        other.refereeActive=false;other.referee='';other.claimUid=null;
       }
      }
      live.claimUid=myUid;
     }
     live.referee=name;live.refereeActive=true;
    }
    if(action==='release'||action==='clear'||action==='complete'){
      live.referee='';live.refereeActive=false;
    }
    if(action==='complete')live.winner=res.winner;
    if(action==='reset'||action==='clear'){live.sa=0;live.sb=0;if(action==='clear')live.winner=null;}
   }
   return res;
 }catch(e){
   console.warn('authority operation response missing or rejected',action,e);
   // Completion may have committed while Safari lost the response. Query the
   // SAME operation receipt, never issue a fresh completion blindly.
   if(action==='complete'){
    try{
     const receipt=await v05ReadOperationReceipt(body.eventId,body.opId);
     if(receipt?.found===true&&receipt.ok===true){
      const live=ev?.id===body.eventId&&projectedStructureOf(ev)===expectedStructureVersion?v1Match(kind,ri,mi):null;
      if(live){live.matchVersion=receipt.matchVersion;live.winner=receipt.winner;live.refereeActive=false;live.referee='';}
      return receipt;
     }
    }catch(err){console.warn('completion receipt lookup unavailable',err)}
   }
   // A definite rejection or ambiguous write needs one scoped private-match
   // reconciliation; do not reload the whole tournament for a single score.
   if(!options.skipConflictRefresh && ev?.id===body.eventId){
    try{await v05ReadAuthoritativeMatch(kind,ri,mi)}catch(err){console.warn('match reconciliation deferred',err)}
   }
   throw e;
 }
}
async function v1FinishCloud(kind,ri,mi){
 const eventId=ev?.id;
 const sheet=matchSheetContext();
 try{
   // Drain only this match's pending score requests; unrelated judges proceed.
   await v05FlushScores(kind,ri,mi);
   const m=v1Match(kind,ri,mi);
   if(!m||!canCompleteMatch(m))throw new Error('比分尚未符合完賽條件，請確認最新分數');
   // The score command receipt already confirmed this matchVersion. Avoid an
   // unnecessary extra GET on every successful completion. The server verifies
   // both the match version AND the exact persisted score before advancing.
   await v1CloudMatchCommand('complete',kind,ri,mi,{
    sa:Number(m.sa||0),sb:Number(m.sb||0),
    expectedMatchVersion:Number(m.matchVersion)||0});
   if(ev?.id===eventId){
    if(matchSheetStillCurrent(sheet))backToBracketFromMatch();
    // Rebuild the visual bracket asynchronously; do not block completion on
    // eventual projection/observer updates.
    backgroundRefreshCurrentEvent(eventId).catch(()=>{});
   }
 }catch(e){alert('雲端完成未確認：'+(e.message||e));}
}
async function v1CloudOrganizerCommand(action,payload={},targetId=ev?.id,options={}){
  if(cloudResyncBlocked)throw new Error('最新賽程尚未確認，請等待重新同步');
  if(!targetId)throw new Error('賽事代碼遺失');
  if(ev?.id===targetId && !hasOrganizerAccess())throw new Error('只有主辦可以修改賽事');
  const known=ev?.id===targetId?ev:cloudEventsCache[targetId];
  const structureScoped=known?.releaseTag==='BBX-V0.11'&&V044_ROSTER_ACTIONS.has(action);
  const expectedStructureVersion=structureScoped?projectedStructureOf(known):undefined;
  if(structureScoped&&expectedStructureVersion===null)throw new Error('籤表正在同步，請稍候再試');
  if(!(await initCloud()))throw new Error('Firebase 尚未連線');
  if(structureScoped&&(ev?.id!==targetId||projectedStructureOf(ev)!==expectedStructureVersion))
    throw new Error('參賽名單已更新，請核對畫面再操作');
  if(known?.authorityBBX!=='active'){
    const gate=await rtdbRestGet(`events/${targetId}/authorityBBX`,7000);
    if(gate!=='active')throw new Error('雲端權威版本未啟用');
  }
  // Send the seq attached to the UI snapshot, not a just-fetched seq that
  // could incorrectly authorize a command made against stale displayed data.
  const currentSeq=structureScoped?0:Number.isInteger(Number(known?.authoritySeq))
    ? Number(known.authoritySeq)
    : Number(await rtdbRestGet(`events/${targetId}/authoritySeq`,7000))||0;
  const fn=firebase.app().functions('asia-southeast1').httpsCallable(authorityFnName('OrganizerAuthority',known));
  // Never submit a locally cached board or public state: only a scoped command.
  const req={clientVersion:authorityClientVersion(known),eventId:targetId,opId:makeV1OpId(),
    expectedSeq:Number(currentSeq)||0,action,...payload,...(structureScoped?{expectedStructureVersion}:{})};
  try{
    let answer;
    try{answer=(await fn(req)).data;}
    catch(error){
      const uncertain=['internal','unknown','unavailable','deadline-exceeded','cancelled'].includes(String(error?.code||'').split('/').pop())||!error?.code;
      if(!structureScoped||!uncertain)throw error;
      const receipt=await v05ReadOperationReceipt(targetId,req.opId).catch(()=>null);
      if(!receipt?.found||!receipt.ok)throw error;
      answer={...receipt,publicationPending:true};
    }
    if(!answer?.ok)throw new Error('操作尚未成功');
    // A scoped raffle change has its own read-after-write publication check.
    // A full event GET here can be older than the authoritative board update
    // and must not roll back the optimistic checkbox before it is confirmed.
    if(!options.deferEventRefresh){
      if(ev?.id===targetId){
        if(structureScoped&&!answer.unchanged)notePendingPublication(targetId,answer.seq);
        await backgroundRefreshCurrentEvent(targetId);
      }
      else {
        const fresh=await rtdbRestGet(`events/${targetId}`,7000);
        if(fresh)cloudEventsCache[targetId]=fresh;
      }
    }
    return answer;
  }catch(e){
    if(!options.deferEventRefresh && ev?.id===targetId){
      await backgroundRefreshCurrentEvent(targetId).catch(()=>{});
      if(structureScoped&&action==='addPlayer'&&String(e?.code||'').split('/').pop()==='already-exists'){
        if(ev?.id===targetId&&ev.roster.includes(payload.value))throw new Error(`「${payload.value}」已在雲端名單，畫面已核對。`);
        if(ev?.id===targetId&&Number(ev.authoritySeq)>Number(ev.publishedSeq||0)){
          notePendingPublication(targetId,Number(ev.authoritySeq));
          throw new Error(`「${payload.value}」已在雲端名單，畫面仍在同步，請勿再新增。`);
        }
      }
    }
    throw e;
  }
}
const V044_ROSTER_ACTIONS=new Set(['rename','addPlayer','delPlayer','rebuild','randomRebuild','swapPlayers']);
const rosterWrites=new Set();
async function v1OrganizerAction(action,payload={}){
 const id=ev?.id,rosterAction=V044_ROSTER_ACTIONS.has(action);
 if(rosterAction&&rosterWrites.has(id))return false;
 if(rosterAction){rosterWrites.add(id);updateRosterControls();}
 try{
  // v1CloudOrganizerCommand already awaits the authoritative event refresh,
  // which reconciles the active tab. No second render or extra claims probe.
  await v1CloudOrganizerCommand(action,payload);
  return true;
 }catch(e){
  if(ev?.id===id)alert('雲端主辦操作失敗：'+(e?.message||e));
  return false;
 }finally{
  if(rosterAction){rosterWrites.delete(id);if(ev?.id===id){renderRoster();updateRosterControls();}}
 }
}
function publicMatchCloudPath(kind,ri,mi){
  return kind==='rr'
    ? `publicEvents/${ev.id}/finalRR/matches/${mi}`
    : `publicEvents/${ev.id}/rounds/${ri}/matches/${mi}`;
}

async function writeMatchCloudBoth(kind,ri,mi,m,timeoutMs=5000){
  if(ev?.authorityBBX==='active'&&!isV1Authority())throw new Error('此賽事使用其他版本的雲端權威，禁止直接寫入；請建立 V0.11 測試賽事');
  if(isV1Authority()){
    await v1CloudMatchCommand('score',kind,ri,mi,{sa:Number(m.sa||0),sb:Number(m.sb||0)});
    return true;
  }
  const updates={};
  updates[matchCloudPath(kind,ri,mi)]=cloneJson(m);
  updates[publicMatchCloudPath(kind,ri,mi)]=publicMatchView(m);
  await rtdbRestPatchRoot(updates,Math.max(4000,timeoutMs));
  return true;
}

function publicProjectionRootUpdate(e){
  return {[`publicEvents/${e.id}`]:publicEventProjectionFromEvent(e)};
}

async function ensurePublicProjectionForOwner(){
  if(!ev || ev.testOnly || !hasOrganizerAccess() || isV1Authority())return false;
  try{
    await rtdbRestPut(`publicEvents/${ev.id}`,publicEventProjectionFromEvent(ev),7000);
    return true;
  }catch(e){
    console.warn('ensurePublicProjectionForOwner failed',e);
    return false;
  }
}

function listenPublicProjectionEvent(id){
  if(!cloudReady||!ev||document.visibilityState==='hidden')return;
  if(cloudUnsub)cloudUnsub();
  const epoch=++cloudListenerEpoch;
  const active=()=>epoch===cloudListenerEpoch&&document.visibilityState!=='hidden'&&ev?.id===id;
  let timer=null,busy=false,again=false,received=false;
  const reload=async()=>{
    if(!active())return;
    if(busy){again=true;return;}
    busy=true;
    try{
      const fresh=await publicCloudGet(`publicEvents/${id}`,7000);
      if(!active()||!fresh?.meta)return;
      const old=ev;
      ev={...fresh.meta,rounds:Array.isArray(fresh.rounds)?fresh.rounds:[],finalRR:fresh.finalRR||null,
        testOnly:false,publicViewOnly:true,refereeNames:[],refereeCount:0,refereeClaims:{}};
      cloudEventsCache[id]=ev;
      // Public-projection route is uncommon; preserve the user's bracket view.
      if(JSON.stringify(old?.rounds)!==JSON.stringify(ev.rounds)||JSON.stringify(old?.finalRR)!==JSON.stringify(ev.finalRR)||
        old?.syncVersion!==ev.syncVersion)renderPublicBracketOnly();
    }catch(e){console.warn('public SSE refresh failed',e)}
    finally{busy=false;if(again&&active()){again=false;schedule(100)}}
  };
  const schedule=(ms=160)=>{if(!active()||timer)return;timer=setTimeout(()=>{timer=null;reload()},ms)};
  const legacy=ev?.authoritySeq==null;
  const streamPath=legacy?`publicEvents/${id}`:`publicEvents/${id}/meta/authoritySeq`;
  const off=bbxOpenRestStream(streamPath,(data)=>{
    if(legacy){
      if(!received&&data.path==='/'){received=true;return;}
      received=true;schedule(120);return;
    }
    // A changed public authority watermark triggers a verified projection GET.
    const seq=Number(data.data)||0;
    const old=Number(ev?.authoritySeq)||0;
    if(!received||seq>old){received=true;if(seq!==old)schedule(120)}
  },()=>{if(active())schedule(1200)},active,false);
  cloudUnsub=()=>{if(timer)clearTimeout(timer);if(epoch===cloudListenerEpoch)cloudListenerEpoch++;off();};
}

async function loadPublicProjectionEvent(id){
  if(!(await initCloud()))return 'error';
  try{
    const data=await publicCloudGet(`publicEvents/${id}`,7000);
    if(!data?.meta)return 'missing';

    ev={
      ...data.meta,
      rounds:Array.isArray(data.rounds)?data.rounds:[],
      finalRR:data.finalRR||null,
      testOnly:false,
      publicViewOnly:true,
      refereeNames:[],
      refereeCount:0,
      refereeClaims:{}
    };

    isAdmin=false;
    isReferee=false;
    cloudEventsCache[id]=ev;

    stopMyCloudEventIndexListener(); // V0.34: home index does not need to remain live inside a match
    $('home').classList.add('hidden');
    $('create').classList.add('hidden');
    $('refereeJoin')?.classList.add('hidden');
    $('admin').classList.remove('hidden');

    renderAdmin();
    listenPublicProjectionEvent(id);
    showTab('bracket');
    return 'ok';
  }catch(e){
    console.error('loadPublicProjectionEvent failed',e);
    const msg=String(e?.message||e);
    if(msg.includes('Permission')||msg.includes('401')||msg.includes('403'))return 'expired';
    return 'error';
  }
}

function cloudOrganizerUpdatesFromEvent(){
  if(!ev||ev.testOnly)return {};
  const base=`events/${ev.id}`;
  const fields=['name','mode','pairing','freeFinal','roster','rounds','finalRR','refereeNames','refereeCount','raffleState'];
  const updates={};

  for(const field of fields){
    if(ev[field]===undefined)continue;
    updates[`${base}/${field}`]=cloneJson(ev[field]);
  }

  const nextSyncVersion=Date.now();
  ev.syncVersion=nextSyncVersion;
  updates[`${base}/syncVersion`]=nextSyncVersion;
  updates[`publicEvents/${ev.id}`]=publicEventProjectionFromEvent(ev);
  return updates;
}

function addDeepDiff(updates,before,after,path){
  if(before===after)return;

  const beforeObj=before!==null && typeof before==='object';
  const afterObj=after!==null && typeof after==='object';

  if(!beforeObj || !afterObj || Array.isArray(before)!==Array.isArray(after)){
    updates[path]=after===undefined?null:cloneJson(after);
    return;
  }

  const keys=new Set([...Object.keys(before||{}),...Object.keys(after||{})]);
  for(const k of keys){
    const nextPath=`${path}/${k}`;
    if(!(k in (after||{}))){
      updates[nextPath]=null;
    }else if(!(k in (before||{}))){
      updates[nextPath]=cloneJson(after[k]);
    }else{
      addDeepDiff(updates,before[k],after[k],nextPath);
    }
  }
}

async function syncBracketDiff(beforeEvent,afterEvent=ev){
  if(!afterEvent)return false;
  if(isV1Authority())throw new Error('雲端權威賽事禁止從舊前端同步賽程快照');
  if(afterEvent.testOnly){
    localEventSave();
    return true;
  }

  const updates={};
  addDeepDiff(updates,beforeEvent?.rounds||[],afterEvent.rounds||[],`events/${afterEvent.id}/rounds`);
  addDeepDiff(updates,beforeEvent?.finalRR??null,afterEvent.finalRR??null,`events/${afterEvent.id}/finalRR`);

  const beforePub=publicEventProjectionFromEvent(beforeEvent);
  const afterPub=publicEventProjectionFromEvent(afterEvent);
  addDeepDiff(updates,beforePub?.rounds||[],afterPub?.rounds||[],`publicEvents/${afterEvent.id}/rounds`);
  addDeepDiff(updates,beforePub?.finalRR??null,afterPub?.finalRR??null,`publicEvents/${afterEvent.id}/finalRR`);

  const beforeShape=JSON.stringify((beforeEvent?.rounds||[]).map(r=>[r?.name,(r?.matches||[]).length]))+'|'+JSON.stringify((beforeEvent?.finalRR?.matches||[]).length);
  const afterShape=JSON.stringify((afterEvent?.rounds||[]).map(r=>[r?.name,(r?.matches||[]).length]))+'|'+JSON.stringify((afterEvent?.finalRR?.matches||[]).length);

  if(beforeShape!==afterShape){
    afterEvent.syncVersion=Date.now();
    updates[`events/${afterEvent.id}/syncVersion`]=afterEvent.syncVersion;
    updates[`publicEvents/${afterEvent.id}/meta`]=publicEventProjectionFromEvent(afterEvent).meta;
  }

  localEventSave();
  if(!Object.keys(updates).length)return true;

  try{
    await cloudUpdate(updates,5000);
    return true;
  }catch(e){
    console.error('syncBracketDiff failed',e);
    alert('雲端同步失敗，將重新載入 Firebase 最新賽程，避免本機舊資料覆蓋其他裁判。');
    await backgroundRefreshCurrentEvent(afterEvent.id);
    return false;
  }
}

function put(){
  if(!ev)return;
  if(isV1Authority()){
    alert('這個雲端賽事已啟用版本保護；主辦結構操作尚未轉移雲端，不能用舊版直接覆蓋。');
    backgroundRefreshCurrentEvent(ev.id);
    return;
  }

  localEventSave();
  renderAdmin();

  if(ev.testOnly)return;
  if(!hasOrganizerAccess())return;

  cloudUpdate(cloudOrganizerUpdatesFromEvent(),5000).catch(e=>{
    console.error('organizer structure sync failed',e);
    alert('主辦雲端同步失敗：'+(e?.message||e));
  });
}
function adminFlagKey(id){return `bx_testenv_cloud_admin_${id}`} // legacy cleanup only
function adminCodeKey(id){return `bx_testenv_cloud_admin_code_${id}`} // legacy cleanup only
async function refreshAdminState(id){
  if(!fbAuth?.currentUser){
    isAdmin=false;
    return false;
  }

  if(ev?.id===id && ev?.ownerUid===fbAuth.currentUser.uid){
    isAdmin=true;
    return true;
  }

  isAdmin=false;

  try{
    const value=await rtdbRestGet(`admins/${id}/${fbAuth.currentUser.uid}`,4000);
    isAdmin=value!==null && value!==undefined && value!==false;

  }catch(e){
    console.warn('refreshAdminState failed',e);
    isAdmin=false;
  }

  return isAdmin;
}
// V0.27: One event-scoped realtime owner for all privileged tabs.
// Only the authoritative Firebase streams mutate the live match and claim state.
// Publication receipts repair MISSED messages; they never pretend a command was rendered.
function listenCloudEvent(id){
  if(!cloudReady||!ev||ev.id!==id||document.visibilityState==='hidden')return;
  if(ev.publicViewOnly){listenPublicProjectionEvent(id);return;}
  if(cloudUnsub)cloudUnsub();
  const epoch=++cloudListenerEpoch;
  const active=()=>epoch===cloudListenerEpoch&&ev?.id===id&&document.visibilityState!=='hidden';
  const unsubs=[], timers=new Set();
  const metric={eventId:id,startedAt:Date.now(),events:0,draws:0,fullReads:0,matchReads:0,claims:0,errors:0,
    connected:false,connectionObserved:false,connectionCheckedAt:null,ready:false,claimsReady:false,bootstrapIssue:null,trace:[],lastLiveAt:null,lastDrawAt:null,
    transport:'SSE + REST',
    transportSetupError:null,restLastOk:null,restLastError:null,
    uniqueSubscriptions:0,duplicateSubscriptions:0,subscriptionErrors:0};
  const trace=(stage,kind='')=>{
    // Keep only event categories and clock times. Never log UID, tokens, scores or names.
    metric.trace.push({at:Date.now(),stage,kind});
    if(metric.trace.length>64)metric.trace.shift();
  };
  trace('subscribe','privileged');
  if(typeof bbxLifecycleNote==='function')bbxLifecycleNote('private-subscription',isAdmin?'organizer':isReferee?'referee':'unverified');
  if(typeof window!=='undefined')window.__bbxSyncMetrics=metric;
  // Compact, opt-in details in the event screen; no permanent warning banner.
  if(typeof window!=='undefined' && typeof navigator!=='undefined' && document.getElementById){
    const tabs=document.querySelector('#admin .adminTabs');
    if(tabs && !document.getElementById('bbxLiveDiag')){
      const details=document.createElement('details');details.id='bbxLiveDiag';
      details.style.cssText='width:100%;font-size:12px;margin:5px 0';
      const summary=document.createElement('summary');summary.textContent='同步診斷（需要時展開）';
      const btn=document.createElement('button');btn.type='button';btn.className='secondary';
      btn.textContent='複製最近事件紀錄';
      const pre=document.createElement('pre');pre.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px;max-height:180px;overflow:auto';
      const snapshot=()=>{
        const m=window.__bbxSyncMetrics||{};
        const time=t=>t?new Date(t).toLocaleTimeString('zh-TW',{hour12:false}):'—';
        return ['版本 BBX-V0.44','狀態 '+(m.connected?'即時通道已連線':'即時通道未連線'),
          '同步架構 私人 SSE + REST / SSE '+(m.sseState||'未啟動')+' / SSE 重連 '+(m.sseRetries||0),
          '傳輸模式 '+(m.transport||'auto')+(m.transportSetupError?' / '+m.transportSetupError:''),
          'REST 最後成功 '+time(m.restLastOk)+' / 失敗 '+time(m.restLastError),
          '連線通知 '+(m.connectionObserved?'已回報':'尚未回報')+' / 最近連線狀態 '+time(m.connectionCheckedAt),
          '發布訂閱 '+(m.ready?'已初始化':'尚未初始化'),'領取訂閱 '+(m.claimsReady?'已初始化':'尚未初始化'),
          '本次訂閱已持續 '+Math.floor((Date.now()-(m.startedAt||Date.now()))/1000)+' 秒'+(m.bootstrapIssue?' / '+m.bootstrapIssue:''),
          '私人 SSE 串流 '+(m.uniqueSubscriptions||0)+' / 串流錯誤 '+(m.errors||0),
          'SSE 發布通知 '+(m.sseReceipts||0)+' / 最近通知 '+time(m.lastLiveAt),
          '場次變更 '+(m.events||0)+' / SSE 發布回執 '+(m.sseReceipts||0),
          '首頁索引 '+(ownerIndexUnsub?'啟用':'未啟用')+' / 賽事進入中 '+bbxEnteringPrivateEvent,
          'Firebase 初始化 '+(cloudInitPromise?'進行中':cloudReady?'完成':'尚未完成'),
          '登入恢復 '+(fbAuth?.currentUser?.providerData?.some(p=>p.providerId==='google.com')?'Google':fbAuth?.currentUser?'匿名':'等待中'),
          '瀏覽器網路指示 '+(navigator.onLine?'online':'offline'),
          '生命週期（最新 20 筆）',
          ...bbxLifecycleEvents.slice(-20).map(x=>time(x.at)+'  '+x.stage+' '+x.detail),
          '事件 '+(m.events||0)+' / 畫面更新 '+(m.draws||0)+' / 單場補讀 '+(m.matchReads||0)+' / 全場補讀 '+(m.fullReads||0),
          '最近賽事資料通知 '+time(m.lastLiveAt),'最近畫面更新 '+time(m.lastDrawAt),
          ...(m.trace||[]).map(x=>time(x.at)+'  '+x.stage+' '+x.kind)].join('\n');
      };
      details.addEventListener('toggle',()=>{if(details.open)pre.textContent=snapshot()});
      btn.addEventListener('click',()=>{
        const body=snapshot();pre.textContent=body;
        if(navigator.clipboard?.writeText)navigator.clipboard.writeText(body).catch(()=>{});
      });
      details.append(summary,btn,pre);tabs.after(details);
    }
  }
  let connected=false,ready=false,stopped=false,failed=false;
  // V0.37: SSE is the ONLY private live transport, never SDK RTDB.
  // Legacy events retain a scoped events/{id} SSE compatibility path.
  let sseEnabled=bbxSseSupported(),legacySse=!isV1Authority(),legacySseInitialSeen=false;
  let sseOpen={hints:false,claims:false},sseInitialized={hints:false,claims:false};
  let sseLinks={hints:null,claims:null},sseGeneration=0,sseStarting=false,sseRetryTimer=null,sseRenewTimer=null,sseRetryCount=0,sseForceTokenNext=false;
  metric.sseState=sseEnabled?'待啟動':'瀏覽器不支援';metric.sseRetries=0;
  let latestPublished=Math.max(0,Number(ev.publishedSeq)||0);
  let appliedPublished=latestPublished;
  let syncVersion=ev.syncVersion??null;
  let queuedDraw=false,reloadTimer=null,reloadBusy=false,reloadAgain=false;
  let hintTimer=null,receipts=null,repairInFlight=false;
  let pendingPublished=0,publicationTimer=null,watchdogBusy=false;
  let retryTimer=null,attempts=0;
  let claimsReady=false,claimsRevision=refereeClaimsStreamRevision;
  const later=(fn,ms)=>{
    const h=setTimeout(()=>{timers.delete(h);if(active()&&!stopped)fn()},ms);
    timers.add(h);return h;
  };
  const cancel=h=>{if(h){clearTimeout(h);timers.delete(h)}};
  const privateMatch=(path)=>{
    let m=/^rounds\/(\d+)\/matches\/(\d+)$/.exec(path);
    if(m)return ev?.rounds?.[Number(m[1])]?.matches?.[Number(m[2])];
    m=/^finalRR\/matches\/(\d+)$/.exec(path);
    return m?ev?.finalRR?.matches?.[Number(m[1])]:null;
  };
  const placeMatch=(path,match)=>{
    let m=/^rounds\/(\d+)\/matches\/(\d+)$/.exec(path);
    if(m&&ev?.rounds?.[Number(m[1])]?.matches){ev.rounds[Number(m[1])].matches[Number(m[2])]=match;return true;}
    m=/^finalRR\/matches\/(\d+)$/.exec(path);
    if(m&&ev?.finalRR?.matches){ev.finalRR.matches[Number(m[1])]=match;return true;}
    return false;
  };
  const scorePending=path=>{
    const r=/^rounds\/(\d+)\/matches\/(\d+)$/.exec(path);
    const f=/^finalRR\/matches\/(\d+)$/.exec(path);
    return r?v05ScorePending('round',Number(r[1]),Number(r[2])):f?v05ScorePending('rr',0,Number(f[1])):false;
  };
  const matchFingerprint=m=>JSON.stringify([m?.a,m?.b,m?.sa??'',m?.sb??'',m?.winner||null,
    m?.referee||'',m?.refereeActive===true,m?.claimUid??null,Number(m?.matchVersion)||0]);
  const receiptMatches=(m,h)=>{
    if(!m)return false;
    const v=Number(typeof h==='object'?h?.version:h);
    if(!Number.isSafeInteger(v)||v<0)return false;
    if(Number(m.matchVersion||0)!==v)return Number(m.matchVersion||0)>v;
    if(!h||typeof h!=='object')return true; // legacy publisher
    return !!m.refereeActive===!!h.refereeActive&&String(m.referee||'')===String(h.referee||'')
      &&String(m.winner||'')===String(h.winner||'')
      &&String(m.sa??'')===String(h.sa??'')&&String(m.sb??'')===String(h.sb??'');
  };
  const status=(msg='')=>{
    const admin=$('admin');if(!admin)return;
    let el=$('bbxLiveTransportWarning');
    if(!el){
      el=document.createElement('div');el.id='bbxLiveTransportWarning';el.className='bbxSyncStatus hidden';
      const btn=document.createElement('button');btn.type='button';btn.className='bbxSyncStatusButton';
      btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-controls','bbxLiveTransportDetail');
      const detail=document.createElement('div');detail.id='bbxLiveTransportDetail';detail.className='bbxSyncStatusDetail hidden';detail.setAttribute('role','status');
      btn.addEventListener('click',()=>{const open=btn.getAttribute('aria-expanded')==='true';btn.setAttribute('aria-expanded',String(!open));detail.classList.toggle('hidden',open)});
      el.append(btn,detail);
      const tabs=admin.querySelector('.adminTabs');if(tabs)tabs.after(el);else admin.prepend(el);
    }
    el.classList.toggle('hidden',!msg);
    const btn=el.querySelector('.bbxSyncStatusButton'),detail=el.querySelector('.bbxSyncStatusDetail');
    if(!msg){btn.setAttribute('aria-expanded','false');detail.classList.add('hidden');}
    btn.textContent='⚠ 同步中斷 · 暫停提交';detail.textContent=msg;
  };
  const unsafe=(reason)=>{
    if(!active())return;
    trace('unhealthy','subscriber');failed=true;cloudResyncBlocked=true;status(reason);
    if(currentAdminTab==='roster')updateRosterControls();
  };
  const healthy=()=>{
    if(!active()||!connected||!ready||((isAdmin||isReferee)&&!claimsReady))return;
    // Once unsafe, an online flag alone cannot certify up-to-date scores.
    // Verify one authoritative snapshot before allowing another submission.
    if(failed){scheduleReload('transport-recovered',150);return;}
    cloudResyncBlocked=false;status('');attempts=0;liveRetryAttempts.delete(id);
    if(currentAdminTab==='roster')updateRosterControls();
  };
  const draw=()=>{
    if(!active()||queuedDraw)return;
    queuedDraw=true;
    later(()=>{
      queuedDraw=false;
      if(!active())return;
      cloudEventsCache[id]=ev;metric.draws++;metric.lastDrawAt=Date.now();trace('paint','bracket');
      // patchPrivateBracket preserves every unaffected card and scroll container.
      if($('admin')&&!$('admin').classList.contains('hidden'))renderAdmin({bracketOnly:true});
      if(currentAdminTab==='roster')updateRosterControls();
    },90);
  };
  const accept=(path,next)=>{
    if(!active()||!next||typeof next!=='object')return;
    const old=privateMatch(path);
    if(!old){scheduleReload('structure',200);return;}
    if(old.a!==next.a||old.b!==next.b){scheduleReload('structure',200);return;}
    const oldVer=Number(old.matchVersion)||0,nextVer=Number(next.matchVersion)||0;
    if(nextVer<oldVer)return;
    if(scorePending(path)){
      // Live lock may change during a local score queue, never overwrite the queued score.
      const patch={...old,referee:next.referee||'',refereeActive:next.refereeActive===true,claimUid:next.claimUid??null};
      if(matchFingerprint(patch)!==matchFingerprint(old)){placeMatch(path,patch);draw();}
      return;
    }
    if(matchFingerprint(next)===matchFingerprint(old))return;
    placeMatch(path,next);metric.events++;trace('accepted',path);draw();
  };
  async function reload(reason){
    if(!active())return;
    if(reloadBusy){reloadAgain=true;return;}
    reloadBusy=true;
    try{
      metric.fullReads++;trace('full-get',reason);
      const fresh=await rtdbRestGet(`events/${id}`,8500);
      if(!active())return;
      if(!fresh){unsafe('伺服器暫時無法確認賽事，保留最後有效畫面。');return;}
      if((Number(fresh.publishedSeq)||0)<Math.max(appliedPublished,Number(ev?.publishedSeq)||0))return;
      // Never regress a local confirmed match or an unflushed score command.
      const current=ev;
      if(sameProjectedStructure(current,fresh)){
        for(let ri=0;ri<(current?.rounds||[]).length;ri++){
          for(let mi=0;mi<(current.rounds[ri]?.matches||[]).length;mi++){
            const prev=current.rounds[ri].matches[mi],next=fresh.rounds?.[ri]?.matches?.[mi];
            if(prev&&next&&prev.a===next.a&&prev.b===next.b&&(v05ScorePending('round',ri,mi)||(Number(prev.matchVersion)||0)>(Number(next.matchVersion)||0)))fresh.rounds[ri].matches[mi]=prev;
          }
        }
        for(let mi=0;mi<(current?.finalRR?.matches||[]).length;mi++){
          const prev=current.finalRR.matches[mi],next=fresh.finalRR?.matches?.[mi];
          if(prev&&next&&prev.a===next.a&&prev.b===next.b&&(v05ScorePending('rr',0,mi)||(Number(prev.matchVersion)||0)>(Number(next.matchVersion)||0)))fresh.finalRR.matches[mi]=prev;
        }
      }
      // Claims use their own authoritative stream; a full event GET must never erase them.
      closeStaleMatchSheet(current,fresh);
      const claims=ev?.refereeClaims;
      ev=preserveVerifiedRaffleOnOldEventSnapshot(fresh,current,id);
      ev.refereeClaims=normalizeRefereeClaimsData(claims);
      appliedPublished=Math.max(appliedPublished,Number(fresh.publishedSeq)||0);
      latestPublished=Math.max(latestPublished,appliedPublished);
      cloudEventsCache[id]=ev;
      renderAdmin({bracketOnly:true});metric.draws++;
      if(currentAdminTab==='roster')renderRoster();
      updatePendingPublicationStatus();
      if(currentAdminTab==='referee')renderReferee({skipCloudRefresh:true});
      failed=false;healthy();
      // Structural events require reattaching the exact new set of match paths.
      // SSE paths are stable across bracket structure changes: do not restart streams.
    }catch(e){console.warn('BBX_V027_SCOPED_RELOAD_FAILED',reason,e);metric.errors++;unsafe('雲端核對失敗，保留已顯示的賽事。');}
    finally{
      reloadBusy=false;
      if(reloadAgain&&active()){reloadAgain=false;scheduleReload('queued',300)}
    }
  }
  function scheduleReload(reason,delay=450){
    if(!active())return;
    if(reloadTimer){if(reason!=='structure')return;cancel(reloadTimer);}
    reloadTimer=later(()=>{reloadTimer=null;reload(reason)},delay);
  }

  const hintPath=k=>{
    let m=/^r(\d+)_(\d+)$/.exec(k);
    if(m)return `rounds/${Number(m[1])}/matches/${Number(m[2])}`;
    m=/^f(\d+)$/.exec(k);return m?`finalRR/matches/${Number(m[1])}`:null;
  };
  async function repairHints(){
    if(!active()||repairInFlight||!receipts)return;
    repairInFlight=true;const batch=receipts;receipts=null;
    try{
      for(const [k,h] of Object.entries(batch.matches||{})){
        if(!active())return;
        const p=hintPath(k);if(!p)continue;
        if(receiptMatches(privateMatch(p),h)||scorePending(p))continue;
        try{
          metric.matchReads++;trace('match-get',p);
          const latest=await rtdbRestGet(`events/${id}/${p}`,6000);
          if(!active())return;
          if(latest&&!receiptMatches(latest,h)&&Number(latest.matchVersion||0)<Number(h?.version??h))continue;
          if(latest)accept(p,latest);else scheduleReload('structure',400);
        }catch(e){metric.errors++;console.warn('BBX_V027_MATCH_REPAIR',p,e);scheduleReload('repair-failed',1100);}
      }
    }finally{repairInFlight=false;if(receipts&&active())scheduleHints();}
  }
  function scheduleHints(){
    if(!active()||hintTimer)return;
    hintTimer=later(()=>{hintTimer=null;repairHints().catch(console.error)},350);
  }
  const checkPublication=()=>{
    publicationTimer=null;
    if(!active()||!pendingPublished)return;
    const seq=pendingPublished;pendingPublished=0;
    if(ev?.publishedMatchHints?.seq>=seq){receipts=ev.publishedMatchHints;scheduleHints();}
    else scheduleReload('publisher-no-receipt',250);
  };
  // V0.37: REG V0.6's notification -> authoritative REST repair is primary,
  // but NEVER expose private claims or scores in public sync nodes.
  // RTDB REST SSE authenticates Firebase ID tokens through ?auth= (documented).
  // The token is kept only inside an EventSource URL: never log/copy/store it.
  // Two small channels: publication receipts and independently owned claims.
  const sseIsVerified=()=>sseOpen.hints&&sseOpen.claims&&sseInitialized.hints&&sseInitialized.claims;
  const sseLiveStatus=()=>{
    if(!active())return;
    connected=sseIsVerified();metric.connected=connected;
    metric.connectionObserved=sseOpen.hints||sseOpen.claims;metric.connectionCheckedAt=Date.now();
    metric.sseState=sseIsVerified()?'已驗證':sseOpen.hints||sseOpen.claims?'建立中':'未連線';
    if(sseIsVerified()){
      sseRetryCount=0;
      ready=true;metric.ready=true;claimsReady=true;metric.claimsReady=true;
      healthy();
    }
  };
  const closeSse=()=>{
    cancel(sseRenewTimer);sseRenewTimer=null;
    sseGeneration++;
    for(const kind of ['hints','claims']){
      try{sseLinks[kind]?.close()}catch(_e){}
      sseLinks[kind]=null;sseOpen[kind]=false;sseInitialized[kind]=false;
    }
    sseLiveStatus();
  };
  const retrySse=(kind)=>{
    if(!active())return;
    trace('sse-retry',kind);
    closeSse();
    connected=false;metric.connected=false;
    unsafe('私人即時通知中斷，正在重新驗證賽事；暫停提交。');
    if(sseRetryTimer)return;
    const delay=Math.min(16000,750*2**Math.min(sseRetryCount++,4));
    metric.sseRetries=sseRetryCount;
    sseRetryTimer=later(()=>{sseRetryTimer=null;startPrivateSse('retry')},delay);
  };
  let sseClaimsReadBusy=false,sseClaimsReadAgain=false;
  async function refreshSseClaims(){
    if(!active())return;
    if(sseClaimsReadBusy){sseClaimsReadAgain=true;return;}
    sseClaimsReadBusy=true;
    const generation=sseGeneration;
    try{
      // The independent claims path, not events/{id}, is authoritative.
      const current=normalizeRefereeClaimsData(await rtdbRestGet(`refereeClaims/${id}`,6000));
      if(!active()||generation!==sseGeneration)return;
      const changed=JSON.stringify(current)!==JSON.stringify(normalizeRefereeClaimsData(ev.refereeClaims));
      ev.refereeClaims=current;
      confirmRefereeClaims();refereeClaimsStreamRevision++;
      if(changed){metric.claims++;trace('sse-claims','accepted');
        if(currentAdminTab==='referee')renderReferee({skipCloudRefresh:true});else draw();}
      sseInitialized.claims=true;
      sseLiveStatus();
    }catch(e){metric.errors++;trace('sse-claims','rest-failed');
      sseInitialized.claims=false;claimsReady=false;metric.claimsReady=false;connected=false;
      unsafe('裁判身分雲端核對失敗，暫停提交。');}
    finally{
      sseClaimsReadBusy=false;
      if(sseClaimsReadAgain){sseClaimsReadAgain=false;if(active())later(refreshSseClaims,120);}
    }
  }
  let sseHintsTimer=null;
  let structureProbeTimer=null,structureProbeBusy=false,structureProbeAgain=false;
  const scheduleStructureProbe=()=>{
    if(!active()||structureProbeTimer)return;
    if(structureProbeBusy){structureProbeAgain=true;return;}
    structureProbeTimer=later(async()=>{
      structureProbeTimer=null;
      if(!active())return;
      structureProbeBusy=true;
      try{
        const ver=await rtdbRestGet(`events/${id}/syncVersion`,6000);
        if(active()&&ver!==null&&ver!==syncVersion){syncVersion=ver;scheduleReload('structure',250);}
      }catch(_e){if(active())scheduleReload('sse-structure-check',500)}
      finally{structureProbeBusy=false;if(structureProbeAgain&&active()){structureProbeAgain=false;scheduleStructureProbe();}}
    },200);
  };
  const sseHintReceipt=(value)=>{
    if(!active())return;
    if(value==null)value={seq:0,matches:{}}; // Fresh events have no publication receipt yet.
    if(typeof value!=='object'||!Number.isSafeInteger(Number(value.seq))||Number(value.seq)<0)return;
    const seq=Number(value.seq);
    // A received snapshot is an actual stream event, not merely HTTP open.
    sseInitialized.hints=true;ready=true;metric.ready=true;metric.sseReceipts=(metric.sseReceipts||0)+1;
    metric.lastLiveAt=Date.now();trace('sse-publication','receipt');
    if(seq>latestPublished){
      latestPublished=seq;
      if(value.matches&&Object.keys(value.matches).length){
        receipts=value;scheduleHints();
        // Coalesce bursts: one in-flight syncVersion probe for consecutive SSE receipts.
        scheduleStructureProbe();
      }else scheduleReload('sse-publication-no-hints',180);
    }
    sseLiveStatus();
  };
  const parseSseMessage=(kind,message)=>{
    if(!active())return;
    let payload;
    try{payload=JSON.parse(message.data)}catch(_e){retrySse(kind);return;}
    // Firebase sends / initially and may later send a nested put/patch.
    if(!payload||typeof payload.path!=='string')return;
    metric.lastLiveAt=Date.now();
    if(kind==='claims'){
      // Coalesce partial claim mutations; never treat them as a full snapshot.
      refreshSseClaims();return;
    }
    if(legacySse){
      sseInitialized.hints=true;ready=true;metric.ready=true;
      metric.sseReceipts=(metric.sseReceipts||0)+1;trace('sse-legacy-event','receipt');
      // Legacy events have no publishedMatchHints. Reconcile on actual SSE change.
      // Initial snapshot proves the stream is alive; on reconnection perform
      // one REST revalidation before accepting critical writes.
      if(!legacySseInitialSeen){legacySseInitialSeen=true;if(failed)scheduleReload('legacy-initial',100);}
      else scheduleReload('legacy-sse',180);
      sseLiveStatus();return;
    }
    if(payload.path==='/')sseHintReceipt(payload.data);
    else{
      cancel(sseHintsTimer);
      sseHintsTimer=later(async()=>{
        sseHintsTimer=null;
        try{sseHintReceipt(await rtdbRestGet(`events/${id}/publishedMatchHints`,6000))}
        catch(_e){if(active())retrySse('hints')}
      },120);
    }
  };
  async function startPrivateSse(reason){
    if(!active()||!sseEnabled||sseStarting||sseLinks.hints||sseLinks.claims)return;
    if(sseRetryTimer)return;
    sseStarting=true;
    failed=true;cloudResyncBlocked=true;
    status('正在建立私人 SSE 即時連線，須核對雲端後才能提交。');
    const generation=sseGeneration;
    try{
      const token=await getRestIdToken(sseForceTokenNext||reason==='token-renewal');
      sseForceTokenNext=false;
      if(!active()||generation!==sseGeneration)return;
      const root=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
      if(!root||!token)throw Error('SSE_AUTH_UNAVAILABLE');
      const endpoints={hints:legacySse?`events/${id}`:`events/${id}/publishedMatchHints`,claims:`refereeClaims/${id}`};
      for(const kind of ['hints','claims']){
        const url=`${root}/${endpoints[kind]}.json?auth=${encodeURIComponent(token)}`;
        const stream=new EventSource(url);
        sseLinks[kind]=stream;
        stream.onopen=()=>{if(!active()||generation!==sseGeneration)return;
          sseOpen[kind]=true;trace('sse-open',kind);sseLiveStatus();};
        for(const type of ['put','patch'])stream.addEventListener(type,msg=>{
          if(active()&&generation===sseGeneration)parseSseMessage(kind,msg);
        });
        for(const type of ['cancel','auth_revoked'])stream.addEventListener(type,()=>{
          if(active()&&generation===sseGeneration){
            if(type==='auth_revoked')sseForceTokenNext=true;
            retrySse(kind);
          }
        });
        stream.onerror=()=>{if(active()&&generation===sseGeneration)retrySse(kind)};
      }
      metric.uniqueSubscriptions=2;metric.sseState='連線中';trace('sse-start',reason);
      // Rotate the Firebase ID token before expiry. No persistent storage.
      sseRenewTimer=later(()=>{sseRenewTimer=null;if(active()&&generation===sseGeneration){closeSse();startPrivateSse('token-renewal')}},42*60*1000);
      if(typeof sseRenewTimer?.unref==='function')sseRenewTimer.unref();
    }catch(_e){metric.errors++;trace('sse-start-failed','auth-or-network');
      if(active()){
        unsafe('私人 SSE 初始化失敗，保留畫面並等待重試。');
        if(!sseRetryTimer){sseRetryTimer=later(()=>{sseRetryTimer=null;startPrivateSse('startup-retry')},3500);}
      }
    }finally{sseStarting=false;}
  }
  // No Database SDK transport or realtime subscriptions.
  // Start immediately on event entry, without waiting for another transport to fail.
  if(sseEnabled)startPrivateSse('primary');
  else unsafe('此瀏覽器不支援 SSE，無法安全提交記分。');
  unsubs.push(()=>{cancel(sseRetryTimer);cancel(sseHintsTimer);closeSse()});

  // One tiny watermark watchdog guards silent WebView stalls; zero full-board polling.
  // This low-frequency REST watermark is only a missed-SSE safety net.
  // It never triggers periodic full-board reads.
  let lastClaimsProbe=0;
  const requestTransportRecovery=()=>{if(sseEnabled&&!sseLinks.hints&&!sseRetryTimer)startPrivateSse('watermark-repair')};

  const watchdog=async()=>{
    if(!active()||watchdogBusy||reloadBusy)return;
    watchdogBusy=true;
    try{
      // A page that has been open for minutes is not 'still initializing'.
      // Track each independent stream instead of treating a valid REST response
      // or any transport-level open callback as proof that subscriptions are healthy.
      const elapsed=Date.now()-metric.startedAt;
      if(elapsed>18000 && (!connected||!ready||((isAdmin||isReferee)&&!claimsReady))){
        const issue=!connected?'SSE offline':!ready?'publication stream uninitialized':'claims stream uninitialized';
        if(metric.bootstrapIssue!==issue){
          metric.bootstrapIssue=issue;trace('bootstrap-stalled',issue);
          unsafe('即時訂閱持續未初始化，暫停記分並嘗試恢復；雲端賽事不會被清除。');
        }
      }else if(connected&&ready&&(!(isAdmin||isReferee)||claimsReady)){
        metric.bootstrapIssue=null;
      }
      trace('watermark-probe','publishedSeq');
      let seqValue;
      try{
        seqValue=await rtdbRestGet(`events/${id}/publishedSeq`,5000);
        metric.restLastOk=Date.now();
        trace('rest-ok','publishedSeq');
      }catch(e){metric.restLastError=Date.now();trace('rest-failed','publishedSeq');throw e;}
      if(!active())return;
      const seq=Number(seqValue)||0;
      const missed=seq>latestPublished;
      if(missed){
        latestPublished=seq;
        pendingPublished=Math.max(pendingPublished,seq);
        if(!publicationTimer)publicationTimer=later(checkPublication,350);
        // Repair missed publication using existing receipt path; do not restart healthy SSE.
        requestTransportRecovery();
      }
      // Claims live on an independent path and DO NOT increase publishedSeq.
      // When SSE is unavailable, recover those claims through one
      // bounded read instead of leaving organizer UI frozen until refresh.
      if((!connected||!claimsReady) && (isAdmin||isReferee) && Date.now()-lastClaimsProbe>30000){
        lastClaimsProbe=Date.now();
        try{
          const current=normalizeRefereeClaimsData(await rtdbRestGet(`refereeClaims/${id}`,5000));
          if(active()&&JSON.stringify(current)!==JSON.stringify(normalizeRefereeClaimsData(ev.refereeClaims))){
            ev.refereeClaims=current;confirmRefereeClaims();refereeClaimsStreamRevision++;metric.claims++;
            if(currentAdminTab==='referee')renderReferee({skipCloudRefresh:true});else draw();
          }else if(active()){confirmRefereeClaims();}
        }catch(e){console.warn('BBX_V030_CLAIMS_FALLBACK',e)}
      }
      // A successful REST lookup does not prove realtime delivery.
      // Never unlock writing until the SSE channels are verified.
      if((!connected||!ready||((isAdmin||isReferee)&&!claimsReady)) &&
         Date.now()-metric.startedAt>18000){
        // Reattach just this event's subscriptions, at most once per cooldown.
        // Missing publications and broken streams share the SAME bounded recovery request.
        requestTransportRecovery();
      }
    }catch(e){metric.errors++;console.warn('BBX_V030_WATCHDOG',e)}
    finally{watchdogBusy=false;}
  };
  const watchdogHandle=setInterval(watchdog,12000);
  unsubs.push(()=>clearInterval(watchdogHandle));
  cloudUnsub=()=>{
    if(stopped)return;stopped=true;trace('unsubscribe','privileged');if(typeof bbxLifecycleNote==='function')bbxLifecycleNote('private-unsubscribe','event');metric.connected=false;metric.ready=false;metric.claimsReady=false;
    if(epoch===cloudListenerEpoch)cloudListenerEpoch++;
    for(const h of timers)clearTimeout(h);timers.clear();
    for(const off of unsubs){try{off()}catch(e){console.warn('BBX_V027_UNSUB',e)}}
  };
}
async function waitForAuthRestore(timeoutMs=5000){
  if(!fbAuth)return null;
  if(fbAuth.currentUser)return fbAuth.currentUser;

  return await new Promise(resolve=>{
    let done=false;
    let off=null;

    const finish=user=>{
      if(done)return;
      done=true;
      clearTimeout(timer);
      try{off&&off()}catch(e){}
      resolve(user||fbAuth.currentUser||null);
    };

    const timer=setTimeout(()=>finish(fbAuth.currentUser||null),timeoutMs);

    try{
      off=fbAuth.onAuthStateChanged(user=>{
        // iOS 關掉分頁再開時，Firebase Auth 有時會先短暫回傳 null。
        // 對正在恢復主辦賽事的情境，不要在第一個 null 就放棄；
        // 只有真的拿到 user 才立即結束，其餘等到 timeout。
        if(user)finish(user);
      });
    }catch(e){
      finish(fbAuth.currentUser||null);
    }
  });
}

// Navigate into a private event as one scoped transition. In particular the
// organizer Home index MUST be stopped before the private SSE streams attach.
async function loadCloudEvent(id){
  if(bbxEventOpeningPromise && bbxEventOpeningId===String(id))return bbxEventOpeningPromise;
  bbxEnteringPrivateEvent++;
  bbxLifecycleNote('event-enter','begin');
  stopMyCloudEventIndexListener();
  bbxEventOpeningId=String(id);
  const task=loadCloudEventOnce(id).finally(()=>{
    bbxEnteringPrivateEvent=Math.max(0,bbxEnteringPrivateEvent-1);
    bbxLifecycleNote('event-enter','finished');
    if(bbxEventOpeningPromise===task){bbxEventOpeningPromise=null;bbxEventOpeningId=null;}
    // Failed event opens may leave Home visible; restore its one index listener.
    if(bbxCanRunOwnerIndex())listenMyCloudEventIndex();
  });
  bbxEventOpeningPromise=task;
  return task;
}
async function loadCloudEventOnce(id){
  if(!(await initCloud()))return 'error';
  // Five-character code only resolves an alias; every write still uses the
  // immutable long internal ID after resolution. Never resolve by releaseTag.
  if(/^[A-HJ-NP-Z2-9]{5}$/.test(String(id))){
    try{
      const real=await rtdbRestGet(`bbxPublicCodeLookup/${id}`,6000);
      if(typeof real!=='string'||!/^[A-Za-z0-9_-]{6,100}$/.test(real))return 'missing';
      id=real;
    }catch(err){console.warn('Five-character code lookup failed',err);return 'error';}
  }

  confirmedRefereeClaimsContext=''; // Re-entering a QR/event requires a fresh cloud claims verification.
  const params=new URLSearchParams(location.search);
  const wantsPrivileged=params.get('admin')==='1' || params.get('ref')==='1' || cloudEventIds.includes(id) || isGoogleUser();

  // 公開觀眾直接走 publicEvents 投影，不再下載完整 events。
  if(!wantsPrivileged){
    return await loadPublicProjectionEvent(id);
  }

  try{
    let data=null;

    // 登入狀態下優先走帶 token 的 REST。
    // 這條路徑有明確 timeout，避免 iOS Safari Firebase SDK once() 偶發一直等待，
    // 造成首頁「載入中…」永遠卡住。
    if(fbAuth?.currentUser){
      try{
        data=await rtdbRestGet(`events/${id}`,7000);
      }catch(authErr){
        console.warn('authenticated event read failed, refresh token and retry',authErr);

        try{
          // 關閉 Safari / PWA 視窗再開時，舊 token 偶爾尚未恢復完成。
          // 強制刷新 token 後再用主辦身分讀一次，不要立刻降級成公開讀取。
          await getRestIdToken(true);
          data=await rtdbRestGet(`events/${id}`,7000);
        }catch(retryErr){
          console.warn('authenticated private read temporarily unavailable',retryErr);
          return 'error'; // Never turn the organizer into a public-only viewer after a network error.
        }
      }
    }else{
      await waitForAuthRestore(5000);
      if(fbAuth?.currentUser){
        try{data=await rtdbRestGet(`events/${id}`,7000)}
        catch(err){console.warn('private auth restoration pending',err);return 'error'}
      }else return 'error';
    }

    if(!data){
      console.warn('Authenticated event read returned null; preserving recovery route',id);
      return 'error';
    }

    ev=data;
    ev.refereeClaims=normalizeRefereeClaimsData(cloudEventsCache[id]?.refereeClaims);
    cloudEventsCache[id]=ev;

    isAdmin=false;
    isReferee=false;

    if(fbAuth?.currentUser){
      // owner 判斷完全本地完成；非 owner 才查 admin/referee。
      if(data.ownerUid===fbAuth.currentUser.uid){
        isAdmin=true;
          }else{
        await Promise.all([
          refreshAdminState(id),
          refreshRefereeState(id)
        ]);
      }
    }

    $('home').classList.add('hidden');
    $('create').classList.add('hidden');
    $('refereeJoin')?.classList.add('hidden');
    $('admin').classList.remove('hidden');

    cloudResyncBlocked=false;
    renderAdmin();
    listenCloudEvent(id);

    const params=new URLSearchParams(location.search);

    if(params.get('admin')==='1'){
      showTab('organizer');
    }else if(params.get('ref')==='1'){
      showTab('referee');
    }else{
      const saved=readActiveView();
      const wanted=params.get('tab') || (saved?.eventId===id?saved.tab:null) || 'bracket';
      const allowed=['bracket','draw','roster','referee','organizer','share'];
      showTab(allowed.includes(wanted)?wanted:'bracket');
      if(currentAdminTab==='bracket'&&readActiveMatchSheet()){
        await refreshRefereeClaimsNow();
        restoreActiveMatchSheetIfSafe();
      }
    }

    return 'ok';
  }catch(e){
    console.error('loadCloudEvent failed',e);
    const msg=String(e?.message||e);

    const code=String(e?.code||'');
    if(
      msg.includes('PERMISSION_DENIED') ||
      msg.includes('permission_denied') ||
      msg.includes('Permission denied') ||
      msg.includes('Firebase REST 401') ||
      msg.includes('Firebase REST 403') ||
      msg.includes('HTTP_401') ||
      msg.includes('HTTP_403') ||
      code==='HTTP_401' ||
      code==='HTTP_403'
    ){
      return 'expired';
    }

    return 'error';
  }
}


function hideMainSections(){
  ['home','create','admin','refereeJoin'].forEach(id=>$(id)?.classList.add('hidden'));
}
async function rtdbRestMultiUpdate(updates,timeoutMs=6000){
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  if(!base)throw new Error('Firebase databaseURL 未設定');
  const token=await getRestIdToken(false);
  const ctrl=new AbortController();
  const timer=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{
    const res=await fetch(`${base}/.json?auth=${encodeURIComponent(token)}`,{
      method:'PATCH',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(updates),
      signal:ctrl.signal,
      cache:'no-store'
    });
    const body=await res.text();
    if(!res.ok){
      const err=new Error(`Firebase REST ${res.status}: ${body}`);
      err.code=`HTTP_${res.status}`;
      throw err;
    }
    return body?JSON.parse(body):updates;
  }catch(e){
    if(e?.name==='AbortError'){
      const err=new Error('Firebase REST 寫入逾時');
      err.code='TIMEOUT';
      throw err;
    }
    throw e;
  }finally{
    clearTimeout(timer);
  }
}

function goHome(){
  clearActiveMatchSheet();
  $('matchModal')?.classList.add('hidden');
  stopAdminCodeRotation();
  stopRefereeCodeRotation();

  clearActiveView();
  ev=null;
  draftMode=null;
  draftStorage=null;
  // A fresh creation flow must start with the verified V0.16 automatic policy.
  if($('byePolicy'))$('byePolicy').value='auto';
  if($('noByeFinal'))$('noByeFinal').value='rr3';

  if(cloudUnsub){
    cloudUnsub();
    cloudUnsub=null;
  }

  ['create','admin','refereeJoin'].forEach(x=>$(x)?.classList.add('hidden'));
  refereeJoinEventId=null;
  $('home').classList.remove('hidden');

  history.replaceState(null,'',location.pathname);

  renderHeaderAuth();
  renderHomeSelections();
  renderSavedEvents();
  if(isGoogleUser()){
    listenMyCloudEventIndex();
  }
}
function startCreate(m){selectHomeMode(m);proceedCreate()}
let draftRoster=[];

$('bulkNames').addEventListener('input',()=>{
  // 上方文字名單被直接修改時，才重新解析整份資料。
  draftRoster=parseRosterText($('bulkNames').value);
  demoExpectedCount=null;
  renderRosterPreviewFromDraft();
  updateAutoFormatInfo();
});

function parseRosterText(raw){
  return String(raw||'')
    .split(/\n|,/)
    .map(x=>x.trim())
    .filter(Boolean);
}

function rosterFromText(){
  // 建立賽事時以目前 textarea 為最終來源，同時刷新 draft，
  // 避免畫面與真正送出的名單不同步。
  draftRoster=parseRosterText($('bulkNames').value);
  return [...draftRoster];
}

// V0.16: local preview only. The CREATE Function independently validates
// and derives this same format; browser-provided BYE and results are forbidden.
const AUTO_FORMAT_TARGETS=Object.freeze([2,3,4,6,8,12,16,24,32,48,64,96,128]);
function autoFormatPlan(n){
  if(!Number.isInteger(n)||n<2||n>128)throw new Error('人數須介於 2～128');
  const target=AUTO_FORMAT_TARGETS.find(x=>x>=n);
  return {target,freeFinal:target%3===0?'rr3':'champ',byes:target-n};
}
// V0.18: no-bye is the legacy free pairing, NOT a new server-side format.
// This intentionally leaves V0.16 auto16 format and server allocation untouched.
function draftCreateFormat(n,byeOption,manualFinal){
  if(byeOption!=='none'){
    const p=autoFormatPlan(n);
    return {...p,formatPolicy:'auto16'};
  }
  if(!Number.isInteger(n)||n<2||n>128)throw new Error('參賽人數須介於 2～128');
  if(n!==3&&n%2!==0)throw new Error('奇數人無法在首輪全部兩兩對戰；請改用系統自動輪空，或調整名單人數');
  if(n===3&&manualFinal!=='rr3')throw new Error('3 人不輪空須直接採用最後三人循環');
  if(!['rr3','champ'].includes(manualFinal))throw new Error('賽制目標無效');
  if(manualFinal==='rr3'&&!canFreeReachThree(n))throw new Error('此人數無法依現有自由編排自然晉級至三人循環；請選淘汰至冠軍');
  return {target:n,byes:0,freeFinal:manualFinal,formatPolicy:null};
}
function updateAutoFormatInfo(){
  const info=$('autoFormatInfo');
  if(!info||draftMode!=='free')return;
  const noBye=$('byePolicy').value==='none';
  $('noByeFinalOpts').classList.toggle('hidden',!noBye);
  const n=parseRosterText($('bulkNames').value).length;
  if(n<2){info.textContent=noBye?'輸入至少兩位選手；不自動補滿首輪人數。':'至少輸入兩位選手後，自動計算賽制與輪空數。';return;}
  if(noBye&&n===3)$('noByeFinal').value='rr3';
  else if(noBye&&!canFreeReachThree(n)&&$('noByeFinal').value==='rr3')$('noByeFinal').value='champ';
  try{
    const p=draftCreateFormat(n,$('byePolicy').value,$('noByeFinal').value);
    $('freeFinal').value=p.freeFinal;
    if(noBye){
      info.textContent=`${n} 人 → 不補滿首輪人數（首輪 ${n===3?'直接三人循環':n/2+' 場對戰'}）→ ${p.freeFinal==='rr3'?'最後三人循環':'淘汰至冠軍'}。注意：後續輪次若剩奇數人，現有兩兩淘汰機制仍可能產生自然輪空。`;
    }else{
      info.textContent=`${n} 人 → ${p.target} 人賽制（${p.byes} 人輪空直接晉級）→ ${p.freeFinal==='rr3'?'最後三人循環':'單淘汰冠軍賽'}。`;
    }
  }catch(e){info.textContent='目前設定無法建立：'+e.message;}
}
function renderRosterPreviewFromDraft(){
  $('countBadge').textContent=draftRoster.length+' 人';
  $('rosterPreview').innerHTML=draftRoster.length
    ?draftRoster.map((n,i)=>`<div class="player"><span class="num">${i+1}</span><input value="${esc(n)}" oninput="editPreviewName(${i},this.value)" aria-label="選手 ${i+1} 名稱"></div>`).join('')
    :'輸入名單後會顯示在這裡。';
}

function updatePreview(){
  draftRoster=parseRosterText($('bulkNames').value);
  renderRosterPreviewFromDraft();
  updateAutoFormatInfo();
}

function editPreviewName(i,v){
  // 下方單一姓名編輯只允許改該索引，不再重新解析 textarea。
  // 這可避免 iPhone/Safari 輸入法或快速輸入期間，其他列被意外吃掉。
  if(i<0||i>=draftRoster.length)return;
  const nv=String(v??'').replace(/[\r\n,]/g,' ').trim();
  draftRoster[i]=nv || draftRoster[i];
  $('bulkNames').value=draftRoster.join('\n');
  $('countBadge').textContent=draftRoster.length+' 人';
  updateAutoFormatInfo();
}

let demoExpectedCount=null;
function makeDemo(){
  let n=Math.max(2,+$('demoCount').value||24);
  // 3 players + free/rr3 goes directly into three round-robin matches.
  // Never force an earlier elimination round for this format.
  demoExpectedCount=n;
  draftRoster=Array.from({length:n},(_,i)=>`選手 ${i+1}`);
  $('bulkNames').value=draftRoster.join('\n');
  renderRosterPreviewFromDraft();
  updateAutoFormatInfo();
}
function clearDraftRoster(){
  // Only draft names; never edit an existing cloud event or its prize draw.
  $('bulkNames').value='';
  draftRoster=[];
  demoExpectedCount=null;
  renderRosterPreviewFromDraft();
  updateAutoFormatInfo();
  $('bulkNames').focus();
}
function shuffle(a){a=[...a];for(let i=a.length-1;i;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function uid(){return Math.random().toString(36).slice(2,9).toUpperCase()}
function withTimeout(promise,ms=12000,label='Firebase'){
  return Promise.race([
    promise,
    new Promise((_,reject)=>setTimeout(()=>reject(new Error(label+'逾時，請檢查網路或 Firebase 規則。')),ms))
  ]);
}
async function ensureRealtimeConnected(timeoutMs=10000){
  if(!(await initCloud()))throw Error('Firebase 初始化失敗');
  return rtdbRestProbe(timeoutMs); // HTTPS reachability, not a socket.
}

async function rtdbRestProbe(timeoutMs=10000){
  if(!fbAuth?.currentUser)throw new Error('尚未登入 Firebase');
  const token=await fbAuth.currentUser.getIdToken(true);
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  if(!base)throw new Error('Firebase databaseURL 未設定');
  const ctrl=new AbortController();
  const timer=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{
    // 只讀一個不存在的輕量節點；即使規則拒絕，也代表資料庫端點有連到。
    const url=`${base}/__connection_probe__.json?auth=${encodeURIComponent(token)}`;
    const res=await fetch(url,{method:'GET',signal:ctrl.signal,cache:'no-store'});
    if(res.status===401||res.status===403){
      // 有 HTTP 回應就代表 RTDB 端點可達，真正權限由後續實際寫入判斷。
      return true;
    }
    if(!res.ok){
      const text=await res.text();
      throw new Error(`Realtime Database HTTP ${res.status}: ${text}`);
    }
    return true;
  }catch(e){
    if(e?.name==='AbortError')throw new Error('無法連到 Firebase Realtime Database（REST 連線逾時）');
    throw e;
  }finally{
    clearTimeout(timer);
  }
}

async function rtdbRestPut(path,value,timeoutMs=12000){
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  if(!base)throw new Error('Firebase databaseURL 未設定');

  const run=async(forceToken=false)=>{
    const token=await getRestIdToken(forceToken);
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),timeoutMs);

    try{
      const url=`${base}/${path}.json?auth=${encodeURIComponent(token)}`;
      const res=await fetch(url,{
        method:'PUT',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(value),
        signal:ctrl.signal,
        cache:'no-store'
      });
      const text=await res.text();

      if(!res.ok){
        let detail=text;
        try{detail=JSON.parse(text)?.error||text}catch{}
        const err=new Error(`Firebase REST ${res.status}: ${detail}`);
        err.code=`HTTP_${res.status}`;
        throw err;
      }

      return text?JSON.parse(text):null;
    }catch(e){
      if(e?.name==='AbortError')throw new Error('Firebase REST 寫入逾時');
      throw e;
    }finally{
      clearTimeout(timer);
    }
  };

  try{
    return await run(false);
  }catch(e){
    if(e?.code==='HTTP_401'){
      restTokenCache={token:null,ts:0};
      return await run(true);
    }
    throw e;
  }
}
async function rtdbRestDelete(path,timeoutMs=7000){
  if(!fbAuth?.currentUser)throw new Error('尚未登入 Firebase');

  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  if(!base)throw new Error('Firebase databaseURL 未設定');

  const run=async(forceToken=false)=>{
    const token=await getRestIdToken(forceToken);
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),timeoutMs);

    try{
      const url=`${base}/${path}.json?auth=${encodeURIComponent(token)}`;
      const res=await fetch(url,{
        method:'DELETE',
        signal:ctrl.signal,
        cache:'no-store'
      });

      const text=await res.text();

      if(!res.ok){
        let detail=text;
        try{detail=JSON.parse(text)?.error||text}catch{}
        const err=new Error(`Firebase REST ${res.status}: ${detail}`);
        err.code=`HTTP_${res.status}`;
        throw err;
      }

      return true;
    }catch(e){
      if(e?.name==='AbortError')throw new Error('Firebase REST DELETE 逾時');
      throw e;
    }finally{
      clearTimeout(timer);
    }
  };

  try{
    return await run(false);
  }catch(e){
    if(e?.code==='HTTP_401'){
      restTokenCache={token:null,ts:0};
      return await run(true);
    }
    throw e;
  }
}
async function rtdbRestPatchRoot(updates,timeoutMs=12000){
  if(!fbAuth?.currentUser)throw new Error('尚未登入 Firebase');

  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  if(!base)throw new Error('Firebase databaseURL 未設定');

  const run=async(forceToken=false)=>{
    const token=await getRestIdToken(forceToken);
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),timeoutMs);

    try{
      const url=`${base}/.json?auth=${encodeURIComponent(token)}`;
      const res=await fetch(url,{
        method:'PATCH',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(updates),
        signal:ctrl.signal,
        cache:'no-store'
      });

      const text=await res.text();

      if(!res.ok){
        let detail=text;
        try{detail=JSON.parse(text)?.error||text}catch{}
        const err=new Error(`Firebase REST ${res.status}: ${detail}`);
        err.code=`HTTP_${res.status}`;
        throw err;
      }

      return true;
    }catch(e){
      if(e?.name==='AbortError')throw new Error('Firebase REST PATCH 寫入逾時');
      throw e;
    }finally{
      clearTimeout(timer);
    }
  };

  try{
    return await run(false);
  }catch(e){
    if(e?.code==='HTTP_401'){
      restTokenCache={token:null,ts:0};
      return await run(true);
    }
    throw e;
  }
}

let restTokenCache={token:null,ts:0,uid:null};
// Token cache is UID-bound; late promises from another Google account cannot
// reinstall an old token into the new session.
async function getRestIdToken(force=false){
  const user=fbAuth?.currentUser;
  if(!user)throw new Error('尚未登入 Firebase');
  const ownerUid=user.uid;
  const now=Date.now();
  if(!force && restTokenCache.uid===ownerUid && restTokenCache.token &&
     (now-restTokenCache.ts)<45*60*1000)return restTokenCache.token;

  const token=await user.getIdToken(!!force);
  if(fbAuth?.currentUser?.uid!==ownerUid){
    const err=new Error('Firebase 登入身分已切換，請重新核對後再讀取');
    err.code='AUTH_CHANGED';throw err;
  }
  restTokenCache={token,ts:Date.now(),uid:ownerUid};
  return token;
}


const inFlightPublicReads=new Map();
function publicCloudGet(path,timeoutMs=10000){
  const key=(fbAuth?.currentUser?.uid||'public')+'|'+path;
  if(inFlightPublicReads.has(key))return inFlightPublicReads.get(key);
  const promise=fetchPublicCloudOnce(path,timeoutMs);
  inFlightPublicReads.set(key,promise);
  promise.finally(()=>{if(inFlightPublicReads.get(key)===promise)inFlightPublicReads.delete(key)}).catch(()=>{});
  return promise;
}
async function fetchPublicCloudOnce(path,timeoutMs=10000){
  if(!(await initCloud()))throw Error('Firebase 尚未初始化');
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  if(!base)throw Error('Firebase databaseURL 未設定');
  const run=async(forceToken=false)=>{
    const token=fbAuth?.currentUser?await getRestIdToken(forceToken):null;
    const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),timeoutMs);
    try{
      const url=`${base}/${path}.json`+(token?'?auth='+encodeURIComponent(token):'');
      const res=await fetch(url,{method:'GET',signal:ctrl.signal,cache:'no-store'});
      const body=await res.text();
      if(!res.ok){const e=new Error(`Firebase REST ${res.status}: ${body.slice(0,180)}`);e.code='HTTP_'+res.status;throw e;}
      return body?JSON.parse(body):null;
    }catch(e){if(e.name==='AbortError')throw Error('Firebase REST 讀取逾時');throw e;}
    finally{clearTimeout(timer)}
  };
  try{return await run(false)}catch(e){
    if(e?.code==='HTTP_401'&&fbAuth?.currentUser){restTokenCache={token:null,ts:0};return run(true)}
    throw e;
  }
}

const inFlightRestReads=new Map();
function rtdbRestGet(path,timeoutMs=12000){
  const uid=fbAuth?.currentUser?.uid||'public';
  const key=uid+'|'+path;
  const existing=inFlightRestReads.get(key);
  if(existing)return existing;
  const pending=fetchRestGetOnce(path,timeoutMs);
  inFlightRestReads.set(key,pending);
  pending.finally(()=>{if(inFlightRestReads.get(key)===pending)inFlightRestReads.delete(key)}).catch(()=>{});
  return pending;
}
async function fetchRestGetOnce(path,timeoutMs=12000){
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  if(!base)throw new Error('Firebase databaseURL 未設定');

  const run=async(forceToken=false)=>{
    const token=await getRestIdToken(forceToken);
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),timeoutMs);

    try{
      const url=`${base}/${path}.json?auth=${encodeURIComponent(token)}`;
      const res=await fetch(url,{
        method:'GET',
        signal:ctrl.signal,
        cache:'no-store'
      });
      const text=await res.text();

      if(!res.ok){
        let detail=text;
        try{detail=JSON.parse(text)?.error||text}catch{}
        const err=new Error(`Firebase REST ${res.status}: ${detail}`);
        err.code=`HTTP_${res.status}`;
        throw err;
      }

      return text?JSON.parse(text):null;
    }catch(e){
      if(e?.name==='AbortError')throw new Error('Firebase REST 讀取逾時');
      throw e;
    }finally{
      clearTimeout(timer);
    }
  };

  try{
    return await run(false);
  }catch(e){
    // 只有 token 真正失效時才強制刷新一次，不會每秒刷新。
    if(e?.code==='HTTP_401'){
      restTokenCache={token:null,ts:0};
      return await run(true);
    }
    throw e;
  }
}






async function reserveCloudEventSlot(eventId){
  if(!isGoogleUser())throw new Error('尚未登入 Google');
  if(!eventId)throw new Error('缺少 eventId');

  const uid=fbAuth.currentUser.uid;
  const token=await getRestIdToken(false);
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');

  for(let attempt=0;attempt<2;attempt++){
    for(let slot=0;slot<CLOUD_EVENT_LIMIT;slot++){
      const path=`userEvents/${uid}/${slot}`;
      const url=`${base}/${path}.json?auth=${encodeURIComponent(token)}`;

      const getCtrl=new AbortController();
      const getTimer=setTimeout(()=>getCtrl.abort(),4000);
      let current=null,etag='null_etag';

      try{
        const res=await fetch(url,{method:'GET',headers:{'X-Firebase-ETag':'true'},signal:getCtrl.signal,cache:'no-store'});
        if(!res.ok)throw new Error(`Firebase REST ${res.status}: ${await res.text()}`);
        etag=res.headers.get('ETag')||'null_etag';
        current=await res.json();
      }finally{
        clearTimeout(getTimer);
      }

      if(current===eventId){
        cloudEventSlots[eventId]=String(slot);
        return {ok:true,slot:String(slot),already:true};
      }
      if(current!==null)continue;

      const putCtrl=new AbortController();
      const putTimer=setTimeout(()=>putCtrl.abort(),4000);
      try{
        const res=await fetch(url,{
          method:'PUT',
          headers:{'Content-Type':'application/json','if-match':etag},
          body:JSON.stringify(eventId),
          signal:putCtrl.signal,
          cache:'no-store'
        });
        if(res.status===412)continue;
        if(!res.ok)throw new Error(`Firebase REST ${res.status}: ${await res.text()}`);
        cloudEventSlots[eventId]=String(slot);
        return {ok:true,slot:String(slot)};
      }finally{
        clearTimeout(putTimer);
      }
    }
  }

  return {ok:false,count:CLOUD_EVENT_LIMIT};
}

async function releaseCloudEventSlot(slot,eventId){
  if(!isGoogleUser())return;
  const uid=fbAuth.currentUser.uid;
  let targetSlot=slot;

  if(targetSlot===undefined || targetSlot===null){
    try{
      const slots=(await rtdbRestGet(`userEvents/${uid}`,5000))||{};
      targetSlot=Object.keys(slots).find(k=>slots[k]===eventId);
    }catch(e){}
  }

  if(targetSlot===undefined || targetSlot===null)return;

  try{
    await rtdbRestDelete(`userEvents/${uid}/${targetSlot}`,5000);
  }catch(e){
    console.warn('releaseCloudEventSlot failed',e);
  }

  if(eventId)delete cloudEventSlots[eventId];
}

async function createTournament(){
  const createBtn=document.querySelector('[data-create-tournament="1"]');
  const oldText=createBtn?.textContent||'建立賽程表';

  let reservedSlot=null;
  let createdEventId='';

  if(createBtn){
    createBtn.disabled=true;
    createBtn.textContent='建立中…';
  }

  try{
    let r=rosterFromText();
    if(r.length<2){
      alert('至少需要 2 位參賽者。');
      return;
    }

    if(demoExpectedCount!==null && r.length!==demoExpectedCount){
      alert(`目前選手名單是 ${r.length} 人，但你最後一次自動產生名單設定為 ${demoExpectedCount} 人。\n\n請先重新產生名單或確認名單人數後再建立賽事。`);
      return;
    }

    let autoPolicy=null;
    if(draftMode==='free'){
      let format;
      try{format=draftCreateFormat(r.length,$('byePolicy').value,$('noByeFinal').value)}
      catch(e){alert('賽制設定無效：'+e.message);return;}
      $('freeFinal').value=format.freeFinal;
      if(format.formatPolicy==='auto16')autoPolicy=format;
    }

    const testOnly=draftStorage==='test';
    let pairing=$('pairMode').value;
    if(pairing==='random')r=shuffle(r);

    if(testOnly){
      ev={
        id:'TEST-'+uid(),
        name:$('eventName').value.trim()||'Beyblade X Tournament',
        mode:draftMode,
        pairing,
        freeFinal:$('freeFinal').value,
        ...(autoPolicy?{formatPolicy:'auto16'}:{}),
        roster:r,
        rounds:[],
        finalRR:null,
        created:Date.now(),
        testOnly:true,
        cloudVersion:5
      };

      buildFirst();
      isAdmin=true;
      isReferee=false;
      localEventSave();

      $('create').classList.add('hidden');
      $('admin').classList.remove('hidden');
      history.replaceState(null,'',location.pathname);

      renderAdmin();
      showTab('referee');
      forcePageTopStable();
      return;
    }

    if(!(await initCloud())){
      alert('Firebase 尚未連線成功。');
      return;
    }
    if(!isGoogleUser()){
      alert('建立雲端賽事前，必須先使用 Google 帳號登入。');
      return;
    }

fbUser=fbAuth.currentUser;
// V0.6: ONE callable creates authoritative private board, management view,
// public projection and owner's index in ONE server-side atomic multipath update.
// No client writes /events or /publicEvents and no stage/activate saga.
if(createBtn)createBtn.textContent='建立雲端賽事…';
const createFn=firebase.app().functions('asia-southeast1').httpsCallable('bbxV011CreateAuthority');
const draftKey='BBX-V0.16:create:'+fbUser.uid+':'+JSON.stringify({name:$('eventName').value.trim(),r,mode:draftMode,pairing,freeFinal:$('freeFinal').value})+(draftMode==='free'&&$('byePolicy').value==='none'?':no-bye-v018':'');
let createOpId;
try{createOpId=sessionStorage.getItem('BBX-V0.11:pendingOp:'+draftKey)||makeV1OpId();sessionStorage.setItem('BBX-V0.11:pendingOp:'+draftKey,createOpId)}catch(e){createOpId=makeV1OpId()}
const created=(await createFn({clientVersion:V1_AUTH_CLIENT,opId:createOpId,
  name:$('eventName').value.trim()||'Beyblade X Tournament',
  roster:r,mode:draftMode,pairing,freeFinal:$('freeFinal').value,
  ...(autoPolicy?{formatPolicy:'auto16'}:{})})).data;
if(!created?.ok || !created?.eventId)throw new Error('建立操作未回傳完整確認資訊');
createdEventId=created.eventId;
const authoritative=await rtdbRestGet(`events/${created.eventId}`,10000);
if(!authoritative||authoritative.authorityBBX!=='active'||authoritative.releaseTag!=='BBX-V0.11')
  throw new Error('雲端資料尚未可讀；建立操作已送出，請返回首頁刷新賽事清單，不要重複建立');
ev=authoritative;
try{sessionStorage.removeItem('BBX-V0.11:pendingOp:'+draftKey)}catch(e){}
cloudEventSlots[ev.id]=String(created.slot);

    isAdmin=true;
    isReferee=false;
    cloudEventsCache[ev.id]=ev;
    cloudEventIds=[ev.id,...cloudEventIds.filter(x=>x!==ev.id)];
    cloudEventSlots[ev.id]=String(created.slot);


    listenCloudEvent(ev.id);
    history.replaceState(null,'',`${location.pathname}?event=${encodeURIComponent(ev.id)}`);

    $('create').classList.add('hidden');
    $('admin').classList.remove('hidden');

    renderAdmin();
    showTab('referee');
    forcePageTopStable();

  }catch(e){
    console.error('createTournament failed',e);

    // Server creation is atomic; do not destructively roll back from a client timeout.
    // A retry uses the same opId only within the in-flight callable; after ambiguity
    // the owner index on the homepage is the source of truth.

    const code=e?.code?`\n錯誤代碼：${e.code}`:'';
    const msg=e?.message||String(e);

    if(String(msg).includes('PERMISSION_DENIED')||String(msg).includes('Permission denied')||String(msg).includes('401')||String(msg).includes('403')){
      alert('建立雲端賽事失敗：Firebase Rules 與目前 V0.11 網頁版本不一致，請發布這一版附帶的完整 V0.11 Rules。');
    }else{
      alert('建立雲端賽事失敗：'+msg+code);
    }
  }finally{
    if(createBtn&&document.body.contains(createBtn)){
      createBtn.disabled=false;
      createBtn.textContent=oldText;
    }
  }
}
function nextPow2(n){let p=1;while(p<n)p*=2;return p}
function canFreeReachThree(n){
  n=Math.max(0,Math.floor(Number(n)||0));
  if(n===3)return true;
  while(n>3)n=Math.ceil(n/2);
  return n===3;
}
function buildFirst(){
 let r=[...ev.roster], slots=[];
 const auto=ev.mode==='free'&&ev.formatPolicy==='auto16';
 if(auto){
   ev.freeFinal=autoFormatPlan(r.length).freeFinal;
 }
 if(ev.mode==='free'&&ev.freeFinal==='rr3'&&r.length===3){
   ev.rounds=[];
   ev.finalRR={
     players:[...r],
     matches:[match(r[0],r[1]),match(r[1],r[2]),match(r[0],r[2])]
   };
   return;
 }

 if(auto){
   const p=autoFormatPlan(r.length).target;
   const byes=p-r.length,count=p/2;
   const byeSlots=new Set();
   for(let i=0;i<byes;i++)byeSlots.add(Math.floor((i+.5)*count/byes));
   let at=0;
   for(let i=0;i<count;i++)slots.push(byeSlots.has(i)?match(r[at++],'BYE'):match(r[at++],r[at++]));
 }else if(ev.mode==='single'){
   let p=nextPow2(r.length), byes=p-r.length;
   // distribute BYEs by pairing a player with BYE first, then normal pairs
   let idx=0; for(let i=0;i<byes;i++)slots.push(match(r[idx++],'BYE'));
   while(idx<r.length){slots.push(match(r[idx++],r[idx++]||'BYE'))}
 } else {
   for(let i=0;i<r.length;i+=2)slots.push(match(r[i],r[i+1]||'BYE'));
 }
 autoByes(slots);
 ev.rounds=[{name:'第 1 輪',matches:slots}];

 // 建立賽事時就先把後續淘汰樹架好，尚未出線的位置顯示「待定」。
 // 每一場一確定勝者，就會立即填入下一輪對應位置。
 ensureNext();
}
function match(a,b){return {a:a||'BYE',b:b||'BYE',sa:'',sb:'',winner:null,referee:'',refereeActive:false}}
function pendingMatch(){return match('待定','待定')}
function autoByes(ms){ms.forEach(m=>{if(m.a==='BYE'&&m.b!=='BYE'&&m.b!=='待定')m.winner=m.b;if(m.b==='BYE'&&m.a!=='BYE'&&m.a!=='待定')m.winner=m.a})}
function winners(r){return r.matches.map(m=>m.winner).filter(Boolean)}
function complete(r){return r.matches.every(m=>m.winner)}
function usesThreePlayerFinal(){
  return ev?.freeFinal==='rr3';
}
function usesChampionPlacementFinal(){
  // 真正依「最終目標」判斷，不用自由編排 / 單淘汰大類猜。
  // 標準單淘汰沒有此下拉欄位，因此自然視為淘汰至冠軍。
  return ev?.freeFinal==='champ' || ev?.mode==='single';
}
function loserOf(m){
  if(!m || !m.winner || m.a==='待定' || m.b==='待定')return '待定';
  if(m.winner===m.a)return m.b;
  if(m.winner===m.b)return m.a;
  return '待定';
}

function resetMatchForParticipants(m,a,b){
  const nextA=a||'待定';
  const nextB=b||'待定';
  const changed=m.a!==nextA || m.b!==nextB;

  if(changed){
    m.a=nextA;
    m.b=nextB;
    m.sa='';
    m.sb='';
    m.winner=null;
    m.referee='';
    m.refereeActive=false;
    delete m._previousWinner;
  }

  if(m.a==='BYE'&&m.b!=='BYE'&&m.b!=='待定'){
    m.winner=m.b;
  }else if(m.b==='BYE'&&m.a!=='BYE'&&m.a!=='待定'){
    m.winner=m.a;
  }

  return changed;
}

function ensureNext(){
  if(!ev?.rounds?.length)return false;
  let changed=false;
  let ri=0;
  while(ri<ev.rounds.length){
    const current=ev.rounds[ri];
    const currentCount=current?.matches?.length||0;
    if(!currentCount)break;

    // 這是一個已完成架構的「冠軍 / 季軍」最終輪，不再往下產生。
    if(current?.placementFinal===true)break;

    const rr3Stop=usesThreePlayerFinal() && currentCount<=3;
    if(rr3Stop){
      const w=winners(current);
      if(complete(current) && w.length===3){
        const samePlayers=ev.finalRR &&
          Array.isArray(ev.finalRR.players) &&
          ev.finalRR.players.length===3 &&
          ev.finalRR.players.every((p,i)=>p===w[i]);

        if(!samePlayers){
          ev.finalRR={
            players:[...w],
            matches:[
              match(w[0],w[1]),
              match(w[1],w[2]),
              match(w[0],w[2])
            ]
          };
          changed=true;
        }
      }else if(ev.finalRR){
        ev.finalRR=null;
        changed=true;
      }
      break;
    }

    // 「一路兩兩淘汰至冠軍」：四強打完後，同時產生冠軍賽與季軍賽。
    // 這裡判斷的是最終目標，不是自由編排/單淘汰的大分類。
    if(usesChampionPlacementFinal() && currentCount===2){
      let finalRound=ev.rounds[ri+1];

      if(!finalRound){
        finalRound={
          name:'最終名次',
          placementFinal:true,
          matches:[pendingMatch(),pendingMatch()]
        };
        ev.rounds.push(finalRound);
        changed=true;
      }else{
        finalRound.name='最終名次';
        if(finalRound.placementFinal!==true){
          finalRound.placementFinal=true;
          changed=true;
        }
        if(!Array.isArray(finalRound.matches))finalRound.matches=[];
        while(finalRound.matches.length<2){
          finalRound.matches.push(pendingMatch());
          changed=true;
        }
        if(finalRound.matches.length>2){
          finalRound.matches=finalRound.matches.slice(0,2);
          changed=true;
        }
      }

      const semiA=current.matches[0];
      const semiB=current.matches[1];

      const champA=semiA?.winner || '待定';
      const champB=semiB?.winner || '待定';
      const bronzeA=loserOf(semiA);
      const bronzeB=loserOf(semiB);

      if(resetMatchForParticipants(finalRound.matches[0],champA,champB))changed=true;
      if(resetMatchForParticipants(finalRound.matches[1],bronzeA,bronzeB))changed=true;

      // 冠軍 / 季軍就是終點。
      break;
    }

    // 舊資料相容：已經只剩一場冠軍賽時不再產生下一輪。
    if(currentCount<=1)break;

    const nextCount=Math.ceil(currentCount/2);
    let next=ev.rounds[ri+1];

    if(!next){
      next={
        name:`第 ${ri+2} 輪`,
        matches:Array.from({length:nextCount},()=>pendingMatch())
      };
      ev.rounds.push(next);
      changed=true;
    }else{
      if(!Array.isArray(next.matches))next.matches=[];
      while(next.matches.length<nextCount){
        next.matches.push(pendingMatch());
        changed=true;
      }
      if(next.matches.length>nextCount){
        next.matches=next.matches.slice(0,nextCount);
        changed=true;
      }
      next.name=`第 ${ri+2} 輪`;
    }

    for(let mi=0;mi<nextCount;mi++){
      const sourceA=current.matches[mi*2];
      const sourceB=current.matches[mi*2+1];

      const a=sourceA ? (sourceA.winner || '待定') : 'BYE';
      const b=sourceB ? (sourceB.winner || '待定') : 'BYE';

      if(resetMatchForParticipants(next.matches[mi],a,b))changed=true;
    }

    ri++;
  }

  return changed;
}
function pick(ri,mi,side){
 if(isV1Authority())return alert('雲端權威賽事請使用「開始執裁 → 計分 → 此場完成」決定晉級。');
 let m=ev.rounds[ri].matches[mi],v=side==='a'?m.a:m.b;
 if(v==='BYE'||v==='待定')return;
 m.winner=v;
 m.refereeActive=false;
 m.referee='';
 ensureNext();
 put();
}
async function score(ri,mi){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;

  if(isV1Authority())return v1FinishCloud('round',ri,mi);
  await cancelQueuedMatchCloud('round',ri,mi);

  let m=ev.rounds[ri].matches[mi];
  if(!canEditMatchScore(m)||!canCompleteMatch(m))return;

  const before=cloneJson(ev);

  const a=Number(m.sa??0);
  const b=Number(m.sb??0);
  const oldWinner=m._previousWinner||m.winner||null;
  const newWinner=a>b?m.a:m.b;

  m.sa=a;
  m.sb=b;
  m.winner=newWinner;
  delete m._previousWinner;
  m.refereeActive=false;
  m.referee='';

  const rebuilt=rebuildDownstreamIfWinnerChanged(ri,oldWinner,newWinner);
  if(!rebuilt)ensureNext();

  localEventSave();
  renderAdmin({bracketOnly:true});
  backToBracketFromMatch();

  if(!ev.testOnly)syncBracketDiff(before,ev);

  if(rebuilt){
    alert('比分已修改。因勝者改變，後續賽程已依新的勝者重新產生。');
  }
}

let resetChoiceTarget=null;

function openResetChoice(kind,ri,mi){
  syncAppVisualViewport();
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return alert('目前沒有重設權限。');
  resetChoiceTarget={kind,ri,mi};
  syncAppVisualViewport();
  $('resetChoiceModal').classList.remove('hidden');
}

function closeResetChoice(){
  $('resetChoiceModal').classList.add('hidden');
  resetChoiceTarget=null;
}

async function resetScoreOnly(){
  const t=resetChoiceTarget;
  if(!t)return;

  let m=t.kind==='rr'
    ? ev.finalRR?.matches?.[t.mi]
    : ev.rounds?.[t.ri]?.matches?.[t.mi];

  if(!m)return alert('找不到這場比賽資料。');

  await cancelQueuedMatchCloud(t.kind,t.ri,t.mi);
  if(isV1Authority()){
    try{await v1CloudMatchCommand('reset',t.kind,t.ri,t.mi);closeResetChoice();
      if(t.kind==='rr')openRRMatch(t.mi);else openMatchEditor(t.ri,t.mi);
    }catch(e){alert('雲端重設失敗：'+(e.message||e));}
    return;
  }

  if(m.winner&&!m._previousWinner)m._previousWinner=m.winner;

  m.winner=null;
  m.sa=0;
  m.sb=0;

  localEventSave();

  if(!ev.testOnly){
    try{
      await writeMatchCloudBoth(t.kind,t.ri,t.mi,cloneJson(m),4500);
    }catch(e){
      alert('比分重設沒有成功寫入 Firebase，將重新載入雲端資料。');
      await backgroundRefreshCurrentEvent(ev.id);
      return;
    }
  }

  closeResetChoice();
  if(t.kind==='rr')openRRMatch(t.mi);
  else openMatchEditor(t.ri,t.mi);
}

async function clearMatchAll(){
  const t=resetChoiceTarget;
  if(!t)return;

  let m=t.kind==='rr'
    ? ev.finalRR?.matches?.[t.mi]
    : ev.rounds?.[t.ri]?.matches?.[t.mi];

  if(!m)return alert('找不到這場比賽資料。');

  await cancelQueuedMatchCloud(t.kind,t.ri,t.mi);
  if(isV1Authority()){
    try{await v1CloudMatchCommand('clear',t.kind,t.ri,t.mi);closeResetChoice();
      closeMatchEditor();await backgroundRefreshCurrentEvent(ev.id);showTab('bracket');
    }catch(e){alert('雲端清除失敗：'+(e.message||e));}
    return;
  }

  const before=cloneJson(ev);
  const hadWinner=!!(m._previousWinner||m.winner);

  m.winner=null;
  m.sa=0;
  m.sb=0;
  delete m._previousWinner;
  m.refereeActive=false;
  m.referee='';

  if(t.kind!=='rr'&&hadWinner){
    clearDownstreamAfterMatchReset(t.ri);
  }

  localEventSave();

  if(!ev.testOnly){
    const ok=await syncBracketDiff(before,ev);
    if(!ok)return;
  }

  closeResetChoice();
  closeMatchEditor();
  showTab('bracket');

  requestAnimationFrame(()=>{
    setBracketScale(bracketScale);
    drawBracketLinks();
  });
}

function resetMatch(ri,mi){
  openResetChoice('round',ri,mi);
}
function swapPlayers(ri,i,j){
 if(i<0||j<0)return;
 if(isV1Authority())return v1OrganizerAction('swapPlayers',{ri,i,j});let r=ev.rounds[ri]; if(r.matches.some(m=>m.winner))return alert('本輪已有結果，請先重設再調整。');
 let flat=r.matches.flatMap(m=>[m.a,m.b]);[flat[i],flat[j]]=[flat[j],flat[i]];r.matches=Array.from({length:Math.ceil(flat.length/2)},(_,k)=>match(flat[k*2],flat[k*2+1]));autoByes(r.matches);put()
}

async function claimRRMatchAs(i){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return alert('目前沒有執裁權限。');

  const who=currentRefereeName();
  if(!who)return alert('請先到裁判頁選擇你的裁判名稱。');

  let m=ev.finalRR?.matches?.[i];
  if(!m)return alert('找不到這場循環賽資料。');

  const btn=document.querySelector('.startRefBtn');
  const context=matchSheetContext();
  const oldText=btn?.textContent||'⚖ 開始執裁';
  if(btn){btn.disabled=true;btn.textContent='接手中…'}

  try{
    if(ev.testOnly){
      releaseMyOtherMatches(who);
      m.referee=who;
      m.refereeActive=true;
      localEventSave();
      renderAdmin({bracketOnly:true});
      openRRMatch(i);
      return;
    }

    if(isV1Authority()){
      try{
        await v1CloudMatchCommand('claim','rr',0,i,{referee:who});
        if(ev?.id===context.eventId){localEventSave();renderAdmin({bracketOnly:true});if(matchSheetStillCurrent(context))openRRMatch(i);}
      }catch(e){alert('雲端接手失敗：'+(e?.message||e));}
      return;
    }
    await releaseMyOtherMatchesCloud(who,'rr',0,i);
    await cancelQueuedMatchCloud('rr',0,i);

    const result=await atomicClaimMatch('rr',0,i,who);

    if(!result.ok){
      if(result.busyBy){
        return alert(`這場目前由 ${result.busyBy} 執裁中。`);
      }
      return alert('開始執裁失敗：'+(result.error||'請再試一次'));
    }

    ev.finalRR.matches[i]=result.data;
    localEventSave();
    renderAdmin({bracketOnly:true});
    openRRMatch(i);
  }finally{
    if(btn&&document.body.contains(btn)){
      btn.disabled=false;
      btn.textContent=oldText;
    }
  }
}

async function rrScore(i){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;

  if(isV1Authority())return v1FinishCloud('rr',0,i);
  await cancelQueuedMatchCloud('rr',0,i);

  let m=ev.finalRR.matches[i];
  if(!canEditMatchScore(m)||!canCompleteMatch(m))return;

  const before=cloneJson(ev);
  const a=Number(m.sa??0);
  const b=Number(m.sb??0);

  m.sa=a;
  m.sb=b;
  m.winner=a>b?m.a:m.b;
  delete m._previousWinner;
  m.refereeActive=false;
  m.referee='';

  localEventSave();
  renderAdmin({bracketOnly:true});
  backToBracketFromMatch();

  if(!ev.testOnly)syncBracketDiff(before,ev);
}
function stageLabel(ri,r){
  if(r?.placementFinal===true)return '冠軍 / 季軍賽';
  if(usesThreePlayerFinal()){
    if(ri===0)return '第一輪（'+(ev.formatPolicy==='auto16'?ev.rounds?.[0]?.matches?.length*2:ev.roster.length)+'強）';
    let n=r.matches.length*2; return n+'強';
  }
  return r.name;
}
function renderBracketMatch(m,ri,mi){
  const pendingA=m.a==='待定', pendingB=m.b==='待定';
  const scoreA=pendingA?'':(m.sa===''?'–':m.sa);
  const scoreB=pendingB?'':(m.sb===''?'–':m.sb);
  const autoAdvance=m.a==='BYE'||m.b==='BYE';
  const canEdit=(isAdmin||isReferee||!!ev?.testOnly) && !pendingA && !pendingB && !autoAdvance;
  const round=ev?.rounds?.[ri];
  const matchTitle=round?.placementFinal===true
    ? (mi===0?'🏆 冠軍賽':'🥉 季軍賽')
    : `第 ${mi+1} 場`;
  return `<button type="button" class="bracketMatch ${m.winner?'done':''} ${m.refereeActive?'judging':''}" data-ri="${ri}" data-mi="${mi}" ${canEdit?`onclick="openMatchEditor(${ri},${mi})"`:'aria-disabled="true"'}><span class=tapEdit>${canEdit?'點擊編輯':(pendingA||pendingB?'等待出線':'觀看')}</span><div class=matchNo>${matchTitle}</div>
    <div class="bSide ${pendingA?'pending':''} ${m.winner===m.a?'winner':''}"><span class=bName>${m.winner===m.a?'<span class=winnerDot>●</span>':''}<span class=playerLabel>${esc(m.a)}</span></span><span class=bScore>${esc(scoreA)}</span></div>
    <div class="bSide ${pendingB?'pending':''} ${m.winner===m.b?'winner':''}"><span class=bName>${m.winner===m.b?'<span class=winnerDot>●</span>':''}<span class=playerLabel>${esc(m.b)}</span></span><span class=bScore>${esc(scoreB)}</span></div>${m.refereeActive?`<span class="refTag live">⚖ 執裁中：${esc(m.referee)}</span>`:''}</button>`;
}
function refereeIdentityKey(){return `bx_ref_identity_${ev?.id||'default'}`}
// Local storage remembers a preference only; it is NOT evidence of a current claim.
// A new event entry/UID must wait for an authoritative claims snapshot or REST read.
let confirmedRefereeClaimsContext='';
function refereeClaimsContext(){
  return ev && fbAuth?.currentUser?.uid ? `${ev.id}:${fbAuth.currentUser.uid}` : '';
}
function refereeClaimsConfirmed(){
  return !!(ev?.testOnly || (refereeClaimsContext() && confirmedRefereeClaimsContext===refereeClaimsContext()));
}
function confirmRefereeClaims(){
  confirmedRefereeClaimsContext=refereeClaimsContext();
  if(ev?.testOnly)return false;
  const uid=currentRefereeUid();
  const myClaim=Array.isArray(ev?.refereeNames)?ev.refereeNames.find((name,i)=>
    ev?.refereeClaims?.[String(i)]?.uid===uid):null;
  const stored=localStorage.getItem(refereeIdentityKey())||'';
  if(stored && stored!==myClaim){localStorage.removeItem(refereeIdentityKey());return true;}
  return false;
}
function getMyReferee(){
  const saved=localStorage.getItem(refereeIdentityKey())||'';
  if(ev?.testOnly)return saved;
  if(!refereeClaimsConfirmed() || !ev?.refereeNames)return '';
  const uid=currentRefereeUid();
  // Use only an actual cloud claim for this UID, never the remembered name.
  return ev.refereeNames.find((name,i)=>ev?.refereeClaims?.[String(i)]?.uid===uid)||'';
}

// Firebase RTDB represents dense numeric child keys ("0", "1", ...) as arrays.
// Referee slots use exactly those keys. Never discard a valid claim on read.
function normalizeRefereeClaimsData(raw){
  if(Array.isArray(raw)){
    const claims={};
    raw.forEach((claim,index)=>{
      if(claim && typeof claim==='object' && !Array.isArray(claim))claims[String(index)]=claim;
    });
    return claims;
  }
  return raw && typeof raw==='object'?raw:{};
}
// Private events/ snapshots do not contain the separately stored refereeClaims/
// tree. Match completion or a critical-action refresh must not turn a verified
// claim into an empty local claim just by replacing ev with a partial snapshot.
// Real claim/release updates still arrive from the independent claim listener.
function preserveLiveRefereeClaimsOnEventSnapshot(snapshot,current=ev){
  if(!snapshot || !current || snapshot.id!==current.id)return snapshot;
  snapshot.refereeClaims=normalizeRefereeClaimsData(current.refereeClaims);
  return snapshot;
}

function normalizeRefereeClaims(){
  if(!ev)return {};
  ev.refereeClaims=normalizeRefereeClaimsData(ev.refereeClaims);
  return ev.refereeClaims;
}

function refereeClaimKey(index){
  return String(index);
}

function currentRefereeUid(){
  return fbAuth?.currentUser?.uid || (ev?.testOnly?'TEST_LOCAL':'');
}

function getRefereeClaim(index){
  const claims=normalizeRefereeClaims();
  return claims[refereeClaimKey(index)]||null;
}

let refereeClaimsStreamRevision=0;
async function refreshRefereeClaimsNow(){
  // Entering the referee tab explicitly verifies claims from their own source.
  // A past claimsReady=true or an existing unsubscribe handle cannot prove freshness.
  if(!ev || ev.testOnly || (!isAdmin&&!isReferee))return normalizeRefereeClaims();
  const eventId=ev.id;
  const revision=refereeClaimsStreamRevision;
  try{
    const latest=(await rtdbRestGet(`refereeClaims/${eventId}`,5000))||{};
    // An older REST response must not replace a newer RTDB live snapshot.
    if(ev?.id!==eventId || revision!==refereeClaimsStreamRevision)return normalizeRefereeClaims();
    const normalized=normalizeRefereeClaimsData(latest);
    const changed=JSON.stringify(normalized)!==JSON.stringify(normalizeRefereeClaimsData(ev.refereeClaims));
    ev.refereeClaims=normalized;
    const first=!refereeClaimsConfirmed();
    const localFixed=confirmRefereeClaims();
    if(changed){
      refereeClaimsStreamRevision++;
      if(currentAdminTab==='referee' && $('refereeTab'))renderReferee({skipCloudRefresh:true});
    }else if((first||localFixed) && currentAdminTab==='referee' && $('refereeTab')){
      renderReferee({skipCloudRefresh:true});
    }
    if(typeof window!=='undefined' && window.__bbxSyncMetrics?.eventId===eventId){
      window.__bbxSyncMetrics.claimsRestCheckedAt=Date.now();
      window.__bbxSyncMetrics.claimsRestChanged=changed;
    }
    return ev.refereeClaims;
  }catch(e){
    console.warn('refreshRefereeClaimsNow failed',e);
    return normalizeRefereeClaims();
  }
}

function findRefereeIndexByName(name){
  return Array.isArray(ev?.refereeNames)?ev.refereeNames.indexOf(name):-1;
}

function isMyRefereeClaim(index){
  const claim=getRefereeClaim(index);
  const uid=currentRefereeUid();
  return !!(claim && uid && claim.uid===uid);
}

function refereeClaimLabel(index){
  const claim=getRefereeClaim(index);
  if(!claim)return '';
  if(isMyRefereeClaim(index))return '你已領取';
  return '已被領取';
}

async function claimRefereeSlot(index){
  if(!ev || (!isAdmin&&!isReferee&&!ev?.testOnly))return false;

  normalizeEvent();
  normalizeRefereeClaims();

  const name=ev.refereeNames[index];
  if(!name)return false;

  const uid=currentRefereeUid();
  if(!uid)return false;

  // 本機賽事：直接本機鎖定。
  if(ev.testOnly){
    const existing=getRefereeClaim(index);
    if(existing && existing.uid!==uid)return false;

    // 同一支手機一次只保留一個裁判身分。
    Object.keys(ev.refereeClaims).forEach(k=>{
      if(ev.refereeClaims[k]?.uid===uid)delete ev.refereeClaims[k];
    });

    ev.refereeClaims[refereeClaimKey(index)]={uid,name,claimedAt:Date.now()};
    localEventSave();
    return true;
  }

  // 先釋放自己先前領取的其他裁判名稱。
  for(const [k,claim] of Object.entries(ev.refereeClaims||{})){
    if(claim?.uid===uid && k!==refereeClaimKey(index)){
      try{
        await rtdbRestDelete(`refereeClaims/${ev.id}/${k}`,5000);
      }catch(e){
        console.warn('release previous referee claim failed',e);
      }
    }
  }

  // 用 Firebase REST ETag / If-Match 做真正的原子搶位。
  // 兩支手機同時選同一位時，只會有一支成功。
  const token=await getRestIdToken(false);
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  const path=`refereeClaims/${encodeURIComponent(ev.id)}/${encodeURIComponent(refereeClaimKey(index))}.json`;
  const url=`${base}/${path}?auth=${encodeURIComponent(token)}`;

  const ctrl1=new AbortController();
  const timer1=setTimeout(()=>ctrl1.abort(),5000);

  let etag='null_etag';
  let current=null;

  try{
    const res=await fetch(url,{
      method:'GET',
      headers:{'X-Firebase-ETag':'true'},
      signal:ctrl1.signal,
      cache:'no-store'
    });

    if(!res.ok)throw new Error(`Firebase REST ${res.status}`);

    etag=res.headers.get('ETag')||'null_etag';
    current=await res.json();
  }finally{
    clearTimeout(timer1);
  }

  if(current && current.uid && current.uid!==uid){
    return false;
  }

  const payload={uid,name,claimedAt:Date.now()};
  const ctrl2=new AbortController();
  const timer2=setTimeout(()=>ctrl2.abort(),5000);

  try{
    const res=await fetch(url,{
      method:'PUT',
      headers:{
        'Content-Type':'application/json',
        'if-match':etag
      },
      body:JSON.stringify(payload),
      signal:ctrl2.signal,
      cache:'no-store'
    });

    if(res.status===412)return false;
    if(!res.ok)throw new Error(`Firebase REST ${res.status}: ${await res.text()}`);
  }finally{
    clearTimeout(timer2);
  }

  ev.refereeClaims=ev.refereeClaims||{};
  ev.refereeClaims[refereeClaimKey(index)]=payload;
  confirmRefereeClaims();
  localEventSave();
  return true;
}

async function releaseRefereeSlot(index){
  if(!ev)return;

  normalizeRefereeClaims();

  let claim=getRefereeClaim(index);
  const uid=currentRefereeUid();
  const organizer=hasOrganizerAccess();

  // 雲端賽事有時 event 本體刷新會暫時不帶 refereeClaims；
  // 釋放前直接向專用節點讀一次，避免「已領取」框與釋放按鈕消失。
  if(!claim && !ev.testOnly && (organizer||isReferee)){
    await refreshRefereeClaimsNow();
    claim=getRefereeClaim(index);
  }

  // 主辦即使畫面暫時沒有 claim，也可以直接清掉指定裁判槽。
  if(!claim && organizer && !ev.testOnly){
    try{
      await rtdbRestDelete(`refereeClaims/${ev.id}/${refereeClaimKey(index)}`,5000);
      const name=ev.refereeNames?.[index]||'';
      if(getMyReferee()===name)localStorage.removeItem(refereeIdentityKey());
      if(ev.refereeClaims)delete ev.refereeClaims[refereeClaimKey(index)];
      renderAdmin({bracketOnly:true});
      showTab('referee');
      return;
    }catch(e){
      return alert('釋放裁判身分失敗：'+(e?.message||e));
    }
  }

  if(!claim){
    const localName=getMyReferee();
    const targetName=ev.refereeNames?.[index]||'';

    // 某些舊版本可能只留下本機裁判身分、雲端 claim 已不存在。
    // 這時「釋放」仍應該能清掉本機身分，不要讓使用者卡死。
    if(localName && localName===targetName){
      localStorage.removeItem(refereeIdentityKey());
      if(ev.refereeClaims)delete ev.refereeClaims[refereeClaimKey(index)];
      localEventSave();
      renderAdmin({bracketOnly:true});
      showTab('referee');
      return;
    }

    return alert('目前找不到這個裁判的領取資料，請按重新整理後再試一次。');
  }

  // 只有該裁判本人或主辦可以釋放。
  if(!organizer && (!uid || claim.uid!==uid)){
    return alert('只有這位裁判本人或主辦可以釋放這個裁判身分。');
  }

  const name=ev.refereeNames?.[index]||claim.name||'';

  if(ev.testOnly){
    delete ev.refereeClaims[refereeClaimKey(index)];
    if(getMyReferee()===name)localStorage.removeItem(refereeIdentityKey());
    localEventSave();
    renderAdmin({bracketOnly:true});
    showTab('referee');
    return;
  }

  try{
    await rtdbRestDelete(`refereeClaims/${ev.id}/${refereeClaimKey(index)}`,5000);

    if(ev.refereeClaims)delete ev.refereeClaims[refereeClaimKey(index)];
    if(getMyReferee()===name)localStorage.removeItem(refereeIdentityKey());

    localEventSave();
    renderAdmin({bracketOnly:true});
    showTab('referee');
  }catch(e){
    console.error('releaseRefereeSlot failed',e);
    alert('釋放裁判身分失敗：'+(e?.message||e));
  }
}

async function setMyReferee(name){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;
  if(!ev.testOnly&&!refereeClaimsConfirmed()){await refreshRefereeClaimsNow();}
  if(!ev.testOnly&&!refereeClaimsConfirmed())return alert('裁判領取狀態尚未核對完成，請檢查網路後重試。');

  normalizeEvent();

  const index=findRefereeIndexByName(name);
  if(index<0)return;

  const claim=getRefereeClaim(index);
  const uid=currentRefereeUid();

  if(claim && claim.uid!==uid){
    renderAdmin({bracketOnly:true});
    showTab('referee');
    return alert(`「${name}」已被其他裁判領取，請選擇其他裁判名稱。`);
  }

  const ok=await claimRefereeSlot(index);

  if(!ok){
    renderAdmin({bracketOnly:true});
    showTab('referee');
    return alert(`「${name}」剛剛已被其他裁判領取，請選擇其他裁判名稱。`);
  }

  localStorage.setItem(refereeIdentityKey(),name);

  renderAdmin({bracketOnly:true});

  if(isReferee&&!isAdmin&&!ev?.testOnly && name){
    showTab('bracket');
  }else{
    showTab('referee');
  }
}
async function saveRefereeNames(){
  if(!isAdmin&&!ev?.testOnly)return;

  normalizeEvent();
  normalizeRefereeClaims();

  const nextNames=Array.from({length:ev.refereeCount},(_,i)=>{
    const current=ev.refereeNames[i]||`裁判 ${i+1}`;
    const claim=getRefereeClaim(i);

    // 使用中的名稱鎖定，不允許改名。
    if(claim)return current;

    const v=$(`refName${i}`)?.value.trim();
    return v||`裁判 ${i+1}`;
  });

  if(nextNames.every((name,i)=>name===ev.refereeNames[i]))return; // No-op; avoid redundant cloud mutation.
  if(isV1Authority())return v1OrganizerAction('setReferees',{refereeNames:nextNames});
  ev.refereeNames=nextNames;
  localEventSave();

  if(!ev.testOnly){
    try{
      await cloudUpdate({
        [`events/${ev.id}/refereeNames`]:ev.refereeNames,
        [`events/${ev.id}/refereeCount`]:ev.refereeCount
      });
    }catch(e){
      return alert('儲存裁判名稱失敗：'+(e?.message||e));
    }
  }

  renderAdmin({bracketOnly:true});
  showTab('referee');
}
function refereeOptionsHtml(kind,ri,mi){
  normalizeEvent();
  const me=getMyReferee();
  if(!me)return `<div class=pickTitle>尚未設定本機裁判身分</div><button type=button class=secondary onclick="closeMatchEditor();showTab('referee')">先到裁判設定選擇我是誰</button>`;
  const action=kind==='rr'?`claimRRMatchAs(${mi},${JSON.stringify(me)})`:`claimMatchAs(${ri},${mi},${JSON.stringify(me)})`;
  return `<div class=pickTitle>本機身分：<b>${esc(me)}</b></div><button type=button onclick='${action}'>⚖ 開始執裁</button>`;
}

function currentRefereeName(){
  return getMyReferee()||'';
}
function canEditMatchScore(m){
  const me=currentRefereeName();
  return !!(me && m.refereeActive && !m.winner && m.referee===me && (ev?.testOnly || !cloudResyncBlocked) && (!m.claimUid || m.claimUid===fbAuth?.currentUser?.uid));
}

async function refreshEventBeforeCriticalAction(){
  if(ev?.testOnly)return ev;
  if(!cloudReady||!ev?.id)return ev;

  try{
    const latest=await rtdbRestGet(`events/${ev.id}`,8000);
    if(latest && ev?.id===latest.id){
      ev=preserveLiveRefereeClaimsOnEventSnapshot(latest);
      localEventSave();
      return ev;
    }
  }catch(e){
    // 即時 listener 仍是主要來源；這個 REST 只是操作前的單次保險。
    console.warn('critical preflight refresh failed',e);
  }

  return ev;
}


async function cloudSet(path,value,timeoutMs=5000){
  if(!(await initCloud()))throw new Error('Firebase 尚未初始化');
  if(!fbAuth?.currentUser)throw new Error('目前沒有寫入權限登入身分');

  // 所有雲端寫入固定走 REST。
  // 不再同時啟動 Firebase SDK set/update + timeout fallback，
  // 避免 SDK 延遲完成後把較新的比分/裁判狀態覆蓋回舊資料。
  await rtdbRestPut(path,value,Math.max(3000,timeoutMs));
  return true;
}

async function cloudUpdate(updates,timeoutMs=8000){
  if(ev?.authorityBBX==='active' && !['BBX-V0.9','BBX-V0.10','BBX-V0.11'].includes(ev.releaseTag))throw new Error('舊版權威賽事不可使用本頁面寫入');
  if(!(await initCloud()))throw new Error('Firebase 尚未初始化');
  if(!fbAuth?.currentUser)throw new Error('目前沒有寫入權限登入身分');

  await rtdbRestPatchRoot(updates,Math.max(5000,timeoutMs));
  return true;
}

function matchCloudPath(kind,ri,mi){
  return kind==='rr'
    ? `events/${ev.id}/finalRR/matches/${mi}`
    : `events/${ev.id}/rounds/${ri}/matches/${mi}`;
}


const matchSyncTimers=new Map();
const matchSyncRetry=new Map();
const matchSyncInFlight=new Map();
const matchSyncGeneration=new Map();
let eventSyncTimer=null;
let lastBackgroundSyncAlert=0;

async function cancelQueuedMatchCloud(kind,ri,mi){
  const key=`${kind}:${ri}:${mi}`;
  if(isV1Authority()){
   const state=v05ScoreState(kind,ri,mi);
   if(state?.timer){clearTimeout(state.timer);state.timer=null;state.desired=null;}
   if(state?.run){try{await state.run}catch(e){}}
   if(state){state.desired=null;v05ScoreQueues.delete(v05ScoreKey(ev.id,kind,ri,mi));}
  }
  matchSyncGeneration.set(key,(matchSyncGeneration.get(key)||0)+1);

  const timer=matchSyncTimers.get(key);
  if(timer){
    clearTimeout(timer);
    matchSyncTimers.delete(key);
  }
  matchSyncRetry.delete(key);

  // 如果舊的快速比分已經送出 HTTP 請求，就等它結束後再做
  // 「完成 / 重設 / 釋放」的最終寫入，確保最後一筆一定是新狀態。
  const inFlight=matchSyncInFlight.get(key);
  if(inFlight){
    try{await inFlight}catch(e){}
  }
}

function cloneJson(v){
  return JSON.parse(JSON.stringify(v));
}

function backgroundSyncAlert(message){
  const now=Date.now();
  if(now-lastBackgroundSyncAlert<8000)return;
  lastBackgroundSyncAlert=now;
  alert(message);
}

const pendingPublications=new Map();
function updatePendingPublicationStatus(){
  const pending=ev&&pendingPublications.get(ev.id);
  if(pending&&Number(ev.publishedSeq||0)>=pending.seq){
    if(pending.timer)clearTimeout(pending.timer);
    pendingPublications.delete(ev.id);
  }
  const waiting=!!(ev&&pendingPublications.has(ev.id));
  const el=$('bbxPublicationNotice');
  if(el){el.classList.toggle('hidden',!waiting);el.textContent=waiting?'已儲存，正在核對其他裝置與觀眾畫面的同步進度。請勿重複送出。':'';}
  if(currentAdminTab==='roster')updateRosterControls();
}
function notePendingPublication(id,seq){
  if(ev?.id!==id||!Number.isSafeInteger(seq)||seq<=Number(ev.publishedSeq||0))return;
  let pending=pendingPublications.get(id);
  if(pending){pending.seq=Math.max(pending.seq,seq);updatePendingPublicationStatus();return;}
  pending={seq,timer:null};pendingPublications.set(id,pending);
  updatePendingPublicationStatus();
  const delays=[300,900,1800,3000];
  const check=async()=>{
    if(pendingPublications.get(id)!==pending||ev?.id!==id||document.visibilityState==='hidden'){pending.timer=null;return;}
    try{
      const published=Number(await rtdbRestGet(`events/${id}/publishedSeq`,5000))||0;
      if(ev?.id===id&&pendingPublications.get(id)===pending&&published>=pending.seq)await backgroundRefreshCurrentEvent(id);
    }catch(e){console.warn('Publication check deferred',e);}
    if(pendingPublications.get(id)===pending&&ev?.id===id&&document.visibilityState!=='hidden'&&delays.length)
      pending.timer=setTimeout(check,delays.shift());
    else pending.timer=null;
  };
  pending.timer=setTimeout(check,delays.shift());
}

function queueSingleMatchCloud(kind,ri,mi,delay=100){
  if(!ev)return;

  localEventSave();
  if(ev.testOnly)return;

  const m=kind==='rr'
    ? ev.finalRR?.matches?.[mi]
    : ev.rounds?.[ri]?.matches?.[mi];

  if(!m)return;
  if(isV1Authority()){v05QueueScore(kind,ri,mi,delay);return;}

  const key=`${kind}:${ri}:${mi}`;
  const path=matchCloudPath(kind,ri,mi);
  const snapshot=cloneJson(m);
  const generation=matchSyncGeneration.get(key)||0;

  if(matchSyncTimers.has(key))clearTimeout(matchSyncTimers.get(key));

  matchSyncTimers.set(key,setTimeout(async()=>{
    matchSyncTimers.delete(key);

    // 如果這筆在等待期間已被「完成 / 重設 / 釋放」取消，就不要再送。
    if((matchSyncGeneration.get(key)||0)!==generation)return;

    const writePromise=writeMatchCloudBoth(kind,ri,mi,snapshot,4000);
    matchSyncInFlight.set(key,writePromise);

    try{
      await writePromise;
      if((matchSyncGeneration.get(key)||0)===generation){
        matchSyncRetry.delete(key);
      }
    }catch(e){
      console.warn('background match sync failed',key,e);
      if(isV1Authority()){
        // A rejected / ambiguous command must not be resubmitted with a NEW operation id.
        matchSyncRetry.delete(key);
        backgroundSyncAlert('雲端版本已改變或操作尚未確認，已停止重試並讀取最新比分。');
        return;
      }

      // 已被新的最終操作取消，不准舊資料再重試。
      if((matchSyncGeneration.get(key)||0)!==generation)return;

      const retry=(matchSyncRetry.get(key)||0)+1;
      matchSyncRetry.set(key,retry);

      if(retry<=1){
        setTimeout(()=>{
          if((matchSyncGeneration.get(key)||0)===generation){
            queueSingleMatchCloud(kind,ri,mi,0);
          }
        },350);
      }else{
        matchSyncRetry.delete(key);
        backgroundSyncAlert('這次比分沒有成功寫入 Firebase，將重新讀取雲端資料避免衝突。');
        backgroundRefreshCurrentEvent(ev.id);
      }
    }finally{
      if(matchSyncInFlight.get(key)===writePromise){
        matchSyncInFlight.delete(key);
      }
    }
  },delay));
}


async function saveSingleMatchCloud(kind,ri,mi){
  if(ev?.testOnly){
    localEventSave();
    return true;
  }

  const m=kind==='rr'
    ? ev.finalRR?.matches?.[mi]
    : ev.rounds?.[ri]?.matches?.[mi];

  if(!m)return false;

  localEventSave();

  try{
    await writeMatchCloudBoth(kind,ri,mi,cloneJson(m),4500);
    return true;
  }catch(e){
    console.error('single match sync failed',e);
    return false;
  }
}

async function saveEventCloudNow(){
  if(!ev)return false;
  if(isV1Authority()){
    alert('此賽事由雲端權威管理，不允許整場資料從手機寫回。');
    await backgroundRefreshCurrentEvent(ev.id);
    return false;
  }

  localEventSave();
  renderAdmin();

  if(ev.testOnly)return true;

  if(!hasOrganizerAccess()){
    alert('這個操作需要主辦權限；裁判只能同步被授權的比賽資料。');
    return false;
  }

  try{
    await cloudUpdate(cloudOrganizerUpdatesFromEvent(),5000);
    return true;
  }catch(e){
    console.error('organizer event sync failed',e);
    alert('主辦雲端同步失敗：'+(e?.message||e));
    return false;
  }
}

function refereeStatusHtml(m,kind,ri,mi){
  const me=currentRefereeName();

  if(m.refereeActive){
    const mine=!!me && m.referee===me;
    const rel=kind==='rr'?`releaseRRMatchAny(${mi})`:`releaseMatchAny(${ri},${mi})`;

    if(mine || isAdmin || ev?.testOnly){
      return `<div class=sheetRefRow>
        <div class=status>⚖ ${esc(m.referee)} 執裁中</div>
        <button type=button class="danger releaseBtn" onclick="${rel}">釋放</button>
      </div>`;
    }

    return `<div class=sheetRefRow>
      <div class=status>⚖ ${esc(m.referee)} 執裁中</div>
      <button type=button class="secondary releaseBtn" disabled>此場已有人執裁</button>
    </div>`;
  }

  if(!me){
    return `<div class=sheetRefRow>
      <div>${m.winner?'此場已完成':'尚未有人執裁'}</div>
      <button type=button class=secondary disabled>請先選擇裁判身分</button>
    </div>`;
  }

  const start=kind==='rr'
    ?`claimRRMatchAs(${mi})`
    :`claimMatchAs(${ri},${mi})`;

  return `<div class=sheetRefRow>
    <div>${m.winner?'此場已完成':'尚未有人執裁'}</div>
    <button type=button class=startRefBtn onclick="${start}">
      ${m.winner?'✏️ 修改比分':'⚖ 開始執裁'}
    </button>
  </div>`;
}
let activeScoreTarget=null;
function openScorePicker(inputId,buttonId){
  syncAppVisualViewport();
  let m=null;
  let side=null;

  let mm=inputId.match(/^s(\d+)-(\d+)([ab])$/);
  if(mm){
    m=ev?.rounds?.[+mm[1]]?.matches?.[+mm[2]];
    side=mm[3];
  }

  mm=inputId.match(/^rr(\d+)([ab])$/);
  if(mm){
    m=ev?.finalRR?.matches?.[+mm[1]];
    side=mm[2];
  }

  // 比分規則：同一時間最多只能有一方 >= 4 分。
  // 如果對手已經 >= 4，這一方只能選 0～3。
  const opponentScore=m
    ? +(side==='a' ? (m.sb||0) : (m.sa||0))
    : 0;
  const maxAllowed=opponentScore>=4?3:6;

  activeScoreTarget={inputId,buttonId,maxAllowed};

  // 直接把不合法的 4～6 隱藏，裁判不會誤按。
  document.querySelectorAll('#scorePicker .scoreGrid button').forEach(btn=>{
    const n=+btn.textContent.trim();
    btn.style.display=n<=maxAllowed?'':'none';
    btn.disabled=n>maxAllowed;
  });

  syncAppVisualViewport();
  $('scorePicker').classList.remove('hidden');
}
function closeScorePicker(){
  $('scorePicker').classList.add('hidden');
  activeScoreTarget=null;
}
function chooseScore(v){
  if(!activeScoreTarget)return;

  const scoreValue=(v===''?0:+v);
  if(scoreValue>(activeScoreTarget.maxAllowed??6))return;

  const id=activeScoreTarget.inputId;
  let matchInfo=null;

  let mm=id.match(/^s(\d+)-(\d+)([ab])$/);
  if(mm&&ev?.rounds?.[+mm[1]]?.matches?.[+mm[2]]){
    const ri=+mm[1],mi=+mm[2],side=mm[3];
    const m=ev.rounds[ri].matches[mi];
    m[side==='a'?'sa':'sb']=scoreValue;
    matchInfo={kind:'round',ri,mi};
  }

  mm=id.match(/^rr(\d+)([ab])$/);
  if(mm&&ev?.finalRR?.matches?.[+mm[1]]){
    const mi=+mm[1],side=mm[2];
    const m=ev.finalRR.matches[mi];
    m[side==='a'?'sa':'sb']=scoreValue;
    matchInfo={kind:'rr',ri:0,mi};
  }

  closeScorePicker();

  if(matchInfo){
    localEventSave();
    queueSingleMatchCloud(matchInfo.kind,matchInfo.ri,matchInfo.mi,80);

    if(matchInfo.kind==='rr')openRRMatch(matchInfo.mi);
    else openMatchEditor(matchInfo.ri,matchInfo.mi);
  }
}

function scoreEventButtons(handler){
  return `
    <button type=button onclick="${handler}(1,'對方違規')">對方違規</button>
    <button type=button onclick="${handler}(1,'轉停')">轉停</button>
    <button type=button onclick="${handler}(2,'爆裂')">爆裂</button>
    <button type=button onclick="${handler}(2,'擊飛')">擊飛</button>
    <button type=button onclick="${handler}(3,'極限')">極限</button>`;
}

function quickScoreHtml(m,kind,ri,mi,quickEnabled,scoreEditEnabled=quickEnabled){
  const aScore=m.sa===''?0:+m.sa;
  const bScore=m.sb===''?0:+m.sb;

  const aInputId=kind==='rr'?`rr${mi}a`:`s${ri}-${mi}a`;
  const bInputId=kind==='rr'?`rr${mi}b`:`s${ri}-${mi}b`;
  const aScoreId=kind==='rr'?`qrr-0-${mi}-a`:`qm-${ri}-${mi}-a`;
  const bScoreId=kind==='rr'?`qrr-0-${mi}-b`:`qm-${ri}-${mi}-b`;
  const quickDisabled=quickEnabled?'':'disabled';
  const scoreDisabled=scoreEditEnabled?'':'disabled';

  const aButtons=kind==='rr'
    ? `
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'a',1,'對方違規')">對方違規</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'a',1,'轉停')">轉停</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'a',2,'爆裂')">爆裂</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'a',2,'擊飛')">擊飛</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'a',3,'極限')">極限</button>`
    : `
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'a',1,'對方違規')">對方違規</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'a',1,'轉停')">轉停</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'a',2,'爆裂')">爆裂</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'a',2,'擊飛')">擊飛</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'a',3,'極限')">極限</button>`;

  const bButtons=kind==='rr'
    ? `
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'b',1,'對方違規')">對方違規</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'b',1,'轉停')">轉停</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'b',2,'爆裂')">爆裂</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'b',2,'擊飛')">擊飛</button>
      <button type=button ${quickDisabled} onclick="quickAddRRScore(${mi},'b',3,'極限')">極限</button>`
    : `
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'b',1,'對方違規')">對方違規</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'b',1,'轉停')">轉停</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'b',2,'爆裂')">爆裂</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'b',2,'擊飛')">擊飛</button>
      <button type=button ${quickDisabled} onclick="quickAddMatchScore(${ri},${mi},'b',3,'極限')">極限</button>`;

  return `<div class=quickScoreBox>
    <div class=quickScoreTitle>⚡ 快速加分</div>

    <div class=quickScorePlayers>
      <div class=quickScoreSide>
        <input type=hidden id="${aInputId}" value="${m.sa}">
        <div class=quickScoreHead>
          <div class=quickScoreName>${esc(m.a)}</div>
          <button type=button
            class=quickScoreTotal
            id="${aScoreId}"
            ${scoreDisabled}
            onclick="openScorePicker('${aInputId}','${aScoreId}')"
          >${aScore}</button>
        </div>
        ${quickEnabled?`<div class=quickScoreBtns>${aButtons}</div>`:''}
      </div>

      <div class=quickScoreSide>
        <input type=hidden id="${bInputId}" value="${m.sb}">
        <div class=quickScoreHead>
          <div class=quickScoreName>${esc(m.b)}</div>
          <button type=button
            class=quickScoreTotal
            id="${bScoreId}"
            ${scoreDisabled}
            onclick="openScorePicker('${bInputId}','${bScoreId}')"
          >${bScore}</button>
        </div>
        ${quickEnabled?`<div class=quickScoreBtns>${bButtons}</div>`:''}
      </div>
    </div>

    <div class=quickScoreHint>
      ${isV1Authority()&&v05ScorePending(kind,ri,mi)?'⏳ 比分正在送往雲端，完成比賽前會先確認。':''}
      點右側數字可隨時修改比分。若一方已達 4 分以上，另一方只能選 0～3 分；確認無誤後再按「此場完成」。
    </div>
  </div>`;
}

function syncQuickScoreDisplay(kind,ri,mi,m){
  const prefix=kind==='rr'?'qrr':'qm';
  const a=$( `${prefix}-${ri}-${mi}-a` );
  const b=$( `${prefix}-${ri}-${mi}-b` );
  if(a)a.textContent=m.sa===''?0:m.sa;
  if(b)b.textContent=m.sb===''?0:m.sb;
}

function quickAddMatchScore(ri,mi,side,points,reason){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;

  let m=ev.rounds?.[ri]?.matches?.[mi];
  if(!m)return alert('找不到這場比賽資料。');
  if(!canEditMatchScore(m))return alert('請先按「開始執裁／修改比分」。');
  if(matchReachedFinishThreshold(m))return;

  if(m.winner){
    m._previousWinner=m.winner;
    m.winner=null;
  }

  const key=side==='a'?'sa':'sb';
  const other=side==='a'?'sb':'sa';
  const current=m[key]===''?0:+m[key];

  if(m[other]==='')m[other]=0;
  m[key]=current+points;

  localEventSave();
  syncQuickScoreDisplay('round',ri,mi,m);

  // UI 立即更新；雲端在背景合併同步。
  queueSingleMatchCloud('round',ri,mi,120);

  // 立刻重畫編輯器；達 4 分後停止快速加分，但數字比分仍可直接修正。
  openMatchEditor(ri,mi);
}

function quickAddRRScore(i,side,points,reason){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;

  let m=ev.finalRR?.matches?.[i];
  if(!m)return alert('找不到這場循環賽資料。');
  if(!canEditMatchScore(m))return alert('請先按「開始執裁／修改比分」。');
  if(matchReachedFinishThreshold(m))return;

  if(m.winner){
    m._previousWinner=m.winner;
    m.winner=null;
  }

  const key=side==='a'?'sa':'sb';
  const other=side==='a'?'sb':'sa';
  const current=m[key]===''?0:+m[key];

  if(m[other]==='')m[other]=0;
  m[key]=current+points;

  localEventSave();
  syncQuickScoreDisplay('rr',0,i,m);

  queueSingleMatchCloud('rr',0,i,120);
  openRRMatch(i);
}



function matchReachedFinishThreshold(m){
  const a=Number(m?.sa ?? 0);
  const b=Number(m?.sb ?? 0);
  return Math.max(a,b)>=4;
}

function canCompleteMatch(m){
  const a=Number(m?.sa ?? 0);
  const b=Number(m?.sb ?? 0);

  // 必須有明確勝者，而且至少一方已達 4 分。
  // 0:0、未滿 4 分、同分都不能按「此場完成」。
  return Math.max(a,b)>=4 && a!==b;
}

function backToBracketFromMatch(){
  closeMatchEditor();
  // A judge continues at the same round/match, even after completing it.
  // The rendered board and its scroll position are preserved by V0.16.
  showTab('bracket');
}

// V0.45: A match-sheet locator contains NO players, results, tokens, or authority.
// iOS may suspend or discard Safari when Camera starts. A locator is never
// trusted as permission; every restored sheet is checked against cloud state.
const ACTIVE_MATCH_SHEET_KEY='bx_v045_active_match_sheet';
function clearActiveMatchSheet(){
  try{sessionStorage.removeItem(ACTIVE_MATCH_SHEET_KEY)}catch(e){}
  try{localStorage.removeItem(ACTIVE_MATCH_SHEET_KEY)}catch(e){}
}
function readActiveMatchSheet(){
  let record=null;
  try{record=JSON.parse(sessionStorage.getItem(ACTIVE_MATCH_SHEET_KEY)||'null')}catch(e){}
  if(!record){try{record=JSON.parse(localStorage.getItem(ACTIVE_MATCH_SHEET_KEY)||'null')}catch(e){}}
  if(!record || !ev || record.eventId!==ev.id || record.uid!==fbAuth?.currentUser?.uid ||
     !['round','rr'].includes(record.kind) || !Number.isInteger(record.ri) || !Number.isInteger(record.mi) ||
     record.ri<0 || record.mi<0 || record.ri>127 || record.mi>127 ||
     Date.now()-Number(record.ts)>2*3600000 || Number(record.ts)>Date.now()+60000)return null;
  return record;
}
function rememberActiveMatchSheet(kind,ri,mi,m){
  if(!ev || !m || !m.refereeActive || m.winner || !canEditMatchScore(m) || !fbAuth?.currentUser?.uid)return;
  const record={eventId:ev.id,uid:fbAuth.currentUser.uid,kind,ri,mi,
    structureVersion:Number(ev.publishedStructureVersion??ev.structureVersion)||0,ts:Date.now()};
  try{sessionStorage.setItem(ACTIVE_MATCH_SHEET_KEY,JSON.stringify(record))}catch(e){}
  // The UID-bound locator survives Safari WebKit tab eviction; not a score cache.
  try{localStorage.setItem(ACTIVE_MATCH_SHEET_KEY,JSON.stringify(record))}catch(e){}
}
function pauseActiveMatchSheetForResync(){
  if($('matchModal')?.classList.contains('hidden'))return;
  const sheet=$('matchSheet');if(!sheet)return;
  for(const button of sheet.querySelectorAll('button:not(.sheetClose)'))button.disabled=true;
  if(!sheet.querySelector('#matchSyncPending')){
    const info=document.createElement('div');info.id='matchSyncPending';info.className='refHint';
    info.setAttribute('role','status');info.textContent='正在核對雲端最新比分及裁判身分，核對完成後恢復此場執裁。';
    sheet.insertBefore(info,sheet.firstChild);
  }
}
function restoreActiveMatchSheetIfSafe(){
  if(!ev || currentAdminTab!=='bracket' || cloudResyncBlocked || !refereeClaimsConfirmed())return false;
  const ref=readActiveMatchSheet();if(!ref)return false;
  const epoch=projectedStructureOf(ev);
  const currentEpoch=Number(ev.publishedStructureVersion??ev.structureVersion)||0;
  if(epoch===null)return false; // Don't use an unconfirmed structure.
  const m=ref.kind==='rr'?ev.finalRR?.matches?.[ref.mi]:ev.rounds?.[ref.ri]?.matches?.[ref.mi];
  if(currentEpoch!==ref.structureVersion || !m || m.winner || !canEditMatchScore(m)){
    clearActiveMatchSheet();
    if(!$('matchModal')?.classList.contains('hidden')){
      $('matchModal').classList.add('hidden');closeScorePicker();closeResetChoice();
    }
    return false;
  }
  if(ref.kind==='rr')openRRMatch(ref.mi);else openMatchEditor(ref.ri,ref.mi);
  return true;
}
function matchSheetContext(){return {eventId:ev?.id,head:$('matchSheet')?.firstElementChild};}
function matchSheetStillCurrent(context){
 return ev?.id===context.eventId&&currentAdminTab==='bracket'&&!!context.head&&
  $('matchSheet')?.firstElementChild===context.head&&!$('matchModal')?.classList.contains('hidden');
}

function openMatchEditor(ri,mi){
  syncAppVisualViewport();
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;

  let m=ev.rounds?.[ri]?.matches?.[mi];
  if(!m)return;
  if(m.a==='待定'||m.b==='待定')return alert('這場尚未確定出線選手。');
  if(m.a==='BYE'||m.b==='BYE')return alert('這是自動晉級場，不需要執裁。');

  const scoreEnabled=canEditMatchScore(m);
  const finishLocked=scoreEnabled && matchReachedFinishThreshold(m);
  const quickEnabled=scoreEnabled && !finishLocked;

  const completeEnabled=scoreEnabled && canCompleteMatch(m);
  const completeDisabled=completeEnabled?'':'disabled';
  const backDisabled=finishLocked?'disabled':'';

  $('matchSheet').innerHTML=`<div class=sheetHandle></div><div class=sheetTitle><div><div class=muted>${stageLabel(ri,ev.rounds[ri])}・第 ${mi+1} 場</div><h3>編輯比賽</h3></div><button class=sheetClose onclick=closeMatchEditor()>✕</button></div>
    <div class=sheetRef><b>裁判狀態</b>${refereeStatusHtml(m,'round',ri,mi)}</div>
    ${quickScoreHtml(m,'round',ri,mi,quickEnabled,scoreEnabled)}
    ${!scoreEnabled?`<div class=refHint style="margin:10px 0">必須先按「開始執裁」，才能修改比分。</div>`:''}
    ${finishLocked?`<div class=refHint style="margin:7px 0">已有人達到 4 分以上。另一方仍可修正比分，但只能選 0～3；若要改判另一方獲勝，請先把目前 4 分以上的一方調回 0～3。</div>`:''}

    <div class=sheetFooter style="grid-template-columns:1fr 1fr 1fr">
      <button class=secondary ${backDisabled} onclick="backToBracketFromMatch()">回到對戰表</button>
      <button class=secondary ${completeDisabled} onclick="score(${ri},${mi})">此場完成</button>
      <button class=danger onclick="resetMatch(${ri},${mi})">重設比分</button>
    </div>`;

  $('matchModal').classList.remove('hidden');
  rememberActiveMatchSheet('round',ri,mi,m);
}
function closeMatchEditor(){
  clearActiveMatchSheet();
  $('matchModal').classList.add('hidden');closeScorePicker();
  // Reconcile changes received while the overlay was open without resetting the viewport.
  if(ev && !$('admin').classList.contains('hidden'))renderAdmin({bracketOnly:true});
}
let bracketScale=1;
function setBracketScale(v){
  bracketScale=Math.max(.32,Math.min(1.25,v));
  const c=document.querySelector('.bracketCanvas'),st=document.querySelector('.bracketStage');
  if(!c||!st)return;
  c.style.transform=`scale(${bracketScale})`;
  st.style.width=Math.ceil(c.scrollWidth*bracketScale)+'px';
  st.style.height=Math.ceil(c.scrollHeight*bracketScale)+'px';
  const lab=document.querySelector('.zoomLabel');if(lab)lab.textContent=Math.round(bracketScale*100)+'%';
}
function zoomBracket(d){setBracketScale(bracketScale+d);requestAnimationFrame(drawBracketLinks)}
function fitBracket(){
  const sc=document.querySelector('.bracketScroll'),c=document.querySelector('.bracketCanvas');if(!sc||!c)return;
  const scale=Math.min(.92,(sc.clientWidth-16)/c.scrollWidth);
  setBracketScale(Math.max(.32,scale));sc.scrollTo({left:0,top:0,behavior:'smooth'});requestAnimationFrame(drawBracketLinks);
}
// V0.22: align every round to the actual rendered centers of its two feeder matches.
// CSS owns card heights; measuring the DOM avoids mobile/compact/zoom pixel drift.
function alignBracketRounds(canvas){
  if(!canvas)return;
  const columns=[...canvas.querySelectorAll('.roundCol[data-round]')];
  const scaleNow=canvas.getBoundingClientRect().width/Math.max(1,canvas.offsetWidth);
  if(!Number.isFinite(scaleNow)||scaleNow<=0)return;
  const centerY=el=>{const r=el.getBoundingClientRect();return r.top+r.height/2;};
  for(let i=0;i<columns.length;i++){
    const col=columns[i],container=col.querySelector('.roundMatches');
    const cards=[...col.querySelectorAll('.bracketMatch')];
    if(!container||!cards.length)continue;
    // Recompute from scratch on every re-render/resize, never stack offsets.
    container.style.paddingTop='0px';
    container.style.removeProperty('gap');
    if(i===0)continue;
    const previous=[...columns[i-1].querySelectorAll('.bracketMatch')];
    const targets=[];
    for(let j=0;j<cards.length;j++){
      if(previous[j*2]&&previous[j*2+1])targets.push((centerY(previous[j*2])+centerY(previous[j*2+1]))/2);
      else if(previous[j*2])targets.push(centerY(previous[j*2]));
      else break; // e.g. separate third-place match, not a feeder pair
    }
    if(!targets.length)continue;
    const h=cards[0].getBoundingClientRect().height/scaleNow;
    const origin=container.getBoundingClientRect().top;
    container.style.paddingTop=Math.max(0,(targets[0]-origin)/scaleNow-h/2)+'px';
    if(targets.length>1){
      // Every pair midpoint must match the center of its destination card.
      const delta=(targets[1]-targets[0])/scaleNow;
      container.style.gap=Math.max(0,delta-h)+'px';
    }else if(cards.length>1){
      // Champion and third-place matches share a column, not the same feeder pairs.
      container.style.gap='16px';
    }
  }
}

function drawBracketLinks(){
  const canvas=document.querySelector('.bracketCanvas');
  const svg=document.querySelector('.bracketLinks');
  if(!canvas||!svg||!ev?.rounds)return;
  alignBracketRounds(canvas);
  // A corrected layout changes canvas height: keep the scaled scroll extent in sync.
  const stage=document.querySelector('.bracketStage');
  if(stage)stage.style.height=Math.ceil(canvas.scrollHeight*bracketScale)+'px';

  const cr=canvas.getBoundingClientRect();
  const inv=1/(bracketScale||1);
  const width=canvas.scrollWidth;
  const height=canvas.scrollHeight;

  svg.setAttribute('width',width);
  svg.setAttribute('height',height);
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  svg.style.width=width+'px';
  svg.style.height=height+'px';

  const point=(el,side='center')=>{
    const r=el.getBoundingClientRect();
    const x=side==='right'?r.right:(side==='left'?r.left:(r.left+r.width/2));
    return {
      x:(x-cr.left)*inv,
      y:(r.top+r.height/2-cr.top)*inv
    };
  };

  const paths=[];

  // 每兩場上一輪對戰，匯入下一輪同一場。
  for(let ri=0;ri<ev.rounds.length-1;ri++){
    const src=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${ri}"]`)];
    const dst=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${ri+1}"]`)];

    dst.forEach((target,j)=>{
      const t=point(target,'left');
      const pair=[src[j*2],src[j*2+1]].filter(Boolean);
      if(!pair.length)return;

      const sourcePoints=pair.map(el=>({el,...point(el,'right')}));
      const maxSourceX=Math.max(...sourcePoints.map(p=>p.x));
      const elbowX=maxSourceX+Math.max(16,(t.x-maxSourceX)*0.52);

      sourcePoints.forEach(p=>{
        const live=p.el.classList.contains('done')?'live':'';
        paths.push(
          `<path class="${live}" d="M ${p.x.toFixed(1)} ${p.y.toFixed(1)} H ${elbowX.toFixed(1)} V ${t.y.toFixed(1)} H ${t.x.toFixed(1)}"/>`
        );
      });
    });
  }

  // 淘汰至三人後接最後三人循環。
  if(ev.finalRR){
    const last=ev.rounds.length-1;
    const src=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${last}"]`)];
    const target=canvas.querySelector('.rrPanel');
    if(target&&src.length){
      const t=point(target,'left');
      const sourcePoints=src.map(el=>({el,...point(el,'right')}));
      const maxSourceX=Math.max(...sourcePoints.map(p=>p.x));
      const elbowX=maxSourceX+Math.max(16,(t.x-maxSourceX)*0.52);

      sourcePoints.forEach((p,k)=>{
        const live=p.el.classList.contains('done')?'live':'';
        const ty=t.y+(k-(sourcePoints.length-1)/2)*12;
        paths.push(
          `<path class="${live}" d="M ${p.x.toFixed(1)} ${p.y.toFixed(1)} H ${elbowX.toFixed(1)} V ${ty.toFixed(1)} H ${t.x.toFixed(1)}"/>`
        );
      });
    }
  }

  svg.innerHTML=paths.join('');
}
function normalizeEvent(){
  // RTDB omits empty arrays. Direct 3-player RR has ZERO knockout rounds,
  // so after a cloud read the rounds key can legitimately be absent.
  if(!ev || typeof ev!=='object')return;
  if(!Array.isArray(ev.rounds)) ev.rounds=[];
  if(ev.finalRR && !Array.isArray(ev.finalRR.matches)) ev.finalRR.matches=[];
  if(!Number.isInteger(ev.refereeCount)||ev.refereeCount<1){
    ev.refereeCount=Array.isArray(ev.refereeNames)&&ev.refereeNames.length
      ? ev.refereeNames.length
      : (Array.isArray(ev.referees)&&ev.referees.length?ev.referees.length:1);
  }

  if(!Array.isArray(ev.refereeNames))ev.refereeNames=[];
  ev.refereeClaims=normalizeRefereeClaimsData(ev.refereeClaims);

  ev.refereeNames=Array.from({length:ev.refereeCount},(_,i)=>{
    const v=String(ev.refereeNames[i]??ev.referees?.[i]??`裁判 ${i+1}`).trim();
    return v||`裁判 ${i+1}`;
  });

  (ev.rounds||[]).forEach(r=>(r.matches||[]).forEach(m=>{
    if(typeof m.referee!=='string')m.referee='';
    if(typeof m.refereeActive!=='boolean')m.refereeActive=false;
  }));

  if(ev.finalRR)ev.finalRR.matches.forEach(m=>{
    if(typeof m.referee!=='string')m.referee='';
    if(typeof m.refereeActive!=='boolean')m.refereeActive=false;
  });
}

function freeFlowLabel(n){
  n=Number(n)||0;
  if(ev?.formatPolicy==='auto16'){
    const p=autoFormatPlan(n);
    n=p.target;
  }
  if(n<=3)return `${n} → 3・最後三人循環`;

  const steps=[n];
  let cur=n;

  // 顯示「一路兩兩淘汰到剩 3 人」的流程。
  // 例如 6 → 3、12 → 6 → 3、24 → 12 → 6 → 3。
  while(cur>6){
    cur=Math.ceil(cur/2);
    steps.push(cur);
  }

  if(steps[steps.length-1]!==3)steps.push(3);
  return `${steps.join(' → ')}・最後三人循環`;
}



let raffleTimer=null;
let raffleSpinning=false;

function raffleStorageKey(){
  return `bx_live_raffle_round_${ev?.id||'default'}`;
}

function defaultRaffleState(){
  const roster=[...(ev?.roster||[])].filter(Boolean);
  const checked={};
  roster.forEach(name=>checked[name]=true);
  return {winners:[],checked};
}

function getRaffleState(){
  const roster=[...(ev?.roster||[])].filter(Boolean);
  let state=null;

  if(ev?.testOnly){
    try{
      const raw=localStorage.getItem(raffleStorageKey());
      if(raw)state=JSON.parse(raw);
    }catch(e){}
  }else{
    state=ev?.raffleState?cloneJson(ev.raffleState):null;
  }

  // RTDB does not retain an empty list child: winners:[] may arrive as
  // missing/null even while checked contains confirmed false selections.
  // Never discard valid checkbox exclusions merely because nobody has won yet.
  if(!state||!state.checked||typeof state.checked!=='object'||Array.isArray(state.checked)){
    state=defaultRaffleState();
  }else if(state.winners==null){
    state.winners=[];
  }else if(!Array.isArray(state.winners)){
    // Reject malformed historical winner data without changing the saved
    // exclusions; a non-list is not an instruction to select everyone.
    state.winners=[];
  }

  state.winners=state.winners.filter(name=>roster.includes(name));

  const nextChecked={};
  roster.forEach(name=>{
    if(state.winners.includes(name))nextChecked[name]=false;
    else nextChecked[name]=state.checked[name]!==false;
  });
  state.checked=nextChecked;
  // Keep unsent/ongoing scoped checkbox intentions visible while an unrelated
  // match snapshot or SSE notification refreshes ev.raffleState.
  if(!ev?.testOnly && v1RaffleChecksEventId===ev?.id){
    const overlay=[...(v1RaffleChecksInflightEventId===ev.id?v1RaffleChecksInflight:[]),...v1RaffleChecksPending];
    for(const [name,enabled] of overlay){
      if(roster.includes(name)&&!state.winners.includes(name))state.checked[name]=enabled;
    }
  }
  return state;
}

// V0.43: A scoped patch is only visually confirmed after BOTH the command
// receipt and its private projection are verified. This closes V0.41's
// success -> stale event refresh -> checkbox rebounds after ~2 seconds race.
// Never submit a whole raffleState for an individual checkbox edit.
let v1RaffleChecksEventId=null;
let v1RaffleChecksPending=new Map(),v1RaffleChecksInflight=new Map();
let v1RaffleChecksInflightEventId=null;
let v1RaffleChecksTimer=null,v1RaffleChecksBusy=false;
let v1RaffleSaveStatus='';
const v1RaffleConfirmedSeqByEvent=new Map();
function v1RaffleHasUnconfirmedChanges(id=ev?.id){
  return !!id && v1RaffleChecksEventId===id &&
    (v1RaffleChecksPending.size>0 ||
     (v1RaffleChecksInflightEventId===id && v1RaffleChecksInflight.size>0));
}
// A delayed in-flight whole-event read must not replace a newer, verified
// raffleState. The server can legitimately update it again on a later seq.
function preserveVerifiedRaffleOnOldEventSnapshot(next,previous,id){
  const verified=Number(v1RaffleConfirmedSeqByEvent.get(id)||0);
  if(verified>Number(next?.publishedSeq||0) && previous?.raffleState){
    next.raffleState=cloneJson(previous.raffleState);
  }
  return next;
}
function enqueueV1RaffleCheck(name,enabled){
  const id=ev?.id;
  if(!id)return;
  if(v1RaffleChecksEventId!==id){
    // An in-progress command is scoped to its original event. Never move its
    // pending names to a different tournament or re-use their event ID.
    if(v1RaffleChecksTimer)clearTimeout(v1RaffleChecksTimer);
    v1RaffleChecksPending=new Map();
    v1RaffleChecksEventId=id;
  }
  v1RaffleChecksPending.set(name,!!enabled);
  v1RaffleSaveStatus='勾選變更等待雲端確認…';
  if(v1RaffleChecksTimer)clearTimeout(v1RaffleChecksTimer);
  v1RaffleChecksTimer=setTimeout(flushV1RaffleChecks,300);
}
function v1RafflePatchMatches(state,changes){
  if(!state||typeof state!=='object'||!state.checked||typeof state.checked!=='object')return false;
  return changes.every(({name,checked})=>state.checked[name]===checked);
}
async function verifyV1RafflePublished(id,receipt,changes){
  const wanted=Number(receipt?.seq)||0;
  if(!wanted)throw Error('雲端沒有回傳可驗證的抽獎版本，無法確認已儲存');
  let lastReason='';
  // Normal inline publication: only two tiny reads, no full-board polling.
  // A delayed publisher gets a small, bounded retry sequence (not a timer).
  for(const delay of [0,450,1000,1800,3000,4200]){
    if(delay)await new Promise(resolve=>setTimeout(resolve,delay));
    try{
      const published=Number(await rtdbRestGet(`events/${id}/publishedSeq`,5000))||0;
      if(published<wanted){lastReason=`已提交版本 ${wanted}，尚待發布（目前 ${published}）`;continue;}
      const state=await rtdbRestGet(`events/${id}/raffleState`,5000);
      if(v1RafflePatchMatches(state,changes))return {state,seq:published};
      // Newer organizer commands may have legitimately changed the selection.
      // Report the conflict; never overwrite that authority with stale UI.
      lastReason='伺服器已發布，但目前抽獎勾選與本次操作不一致';
      if(published>wanted)break;
    }catch(e){lastReason=String(e?.message||e)}
  }
  throw Error(`抽獎勾選尚未確認：${lastReason||'雲端讀取失敗'}`);
}
async function flushV1RaffleChecks(){
  if(v1RaffleChecksBusy||!v1RaffleChecksPending.size)return;
  const id=v1RaffleChecksEventId;
  v1RaffleChecksBusy=true;
  try{
    while(v1RaffleChecksPending.size && v1RaffleChecksEventId===id){
      const changes=[...v1RaffleChecksPending].map(([name,checked])=>({name,checked}));
      v1RaffleChecksPending.clear();
      v1RaffleChecksInflight=new Map(changes.map(x=>[x.name,x.checked]));
      v1RaffleChecksInflightEventId=id;
      try{
        const receipt=await v1CloudOrganizerCommand('setRaffleChecks',{checks:changes},id,{deferEventRefresh:true});
        const verified=await verifyV1RafflePublished(id,receipt,changes);
        if(ev?.id===id){
          // Only the verified raffle subdocument is replaced. Scores, claims,
          // referee lock and currently open match editor remain untouched.
          ev.raffleState=cloneJson(verified.state);
          cloudEventsCache[id]=ev;
          v1RaffleConfirmedSeqByEvent.set(id,Math.max(Number(v1RaffleConfirmedSeqByEvent.get(id)||0),verified.seq));
          v1RaffleSaveStatus='勾選已儲存到雲端';
        }
      }catch(e){
        // The command may have committed even when publication was delayed.
        // Do not blindly retry with another opId or write a whole stale state.
        console.error('Raffle checkbox authority confirmation failed',e);
        v1RaffleChecksPending.clear();
        if(ev?.id===id){
          await backgroundRefreshCurrentEvent(id).catch(()=>{});
          v1RaffleSaveStatus='未確認儲存，請核對名單';
          alert('抽獎勾選未確認儲存：'+(e?.message||e)+'。已停止重試，請核對雲端最新勾選。');
        }
        break;
      }finally{
        v1RaffleChecksInflight.clear();
        v1RaffleChecksInflightEventId=null;
        if(ev?.id===id && currentAdminTab==='draw')renderDraw();
      }
    }
  }finally{
    v1RaffleChecksBusy=false;
    if(v1RaffleChecksPending.size)
      v1RaffleChecksTimer=setTimeout(flushV1RaffleChecks,100);
  }
}
let v1RafflePending=null,v1RaffleTimer=null,v1RaffleBusy=false;
async function flushV1Raffle(){
 if(v1RaffleBusy||!v1RafflePending)return;
 v1RaffleBusy=true;
 try{
  while(v1RafflePending){
   const current=v1RafflePending;v1RafflePending=null;
   await v1CloudOrganizerCommand('setRaffle',{raffleState:current});
  }
 }catch(e){
  v1RafflePending=null;
  console.error('Cloud raffle update failed',e);
  backgroundSyncAlert('抽獎狀態沒有成功同步，已停止舊資料寫回，請重新開啟賽事。');
 }finally{v1RaffleBusy=false;}
}
function saveRaffleState(state){
  if(!ev)return;

  if(ev.testOnly){
    try{localStorage.setItem(raffleStorageKey(),JSON.stringify(state))}catch(e){}
    return;
  }

  ev.raffleState=cloneJson(state);
  cloudEventsCache[ev.id]=ev;

  if(hasOrganizerAccess()){
    if(isV1Authority()){
      v1RafflePending=cloneJson(state);
      if(v1RaffleTimer)clearTimeout(v1RaffleTimer);
      v1RaffleTimer=setTimeout(flushV1Raffle,300);
    }else{
      rtdbRestPut(`events/${ev.id}/raffleState`,cloneJson(state),3500).catch(e=>{
        console.warn('raffle cloud sync failed',e);
        backgroundSyncAlert('抽獎狀態沒有成功同步到 Firebase，請檢查網路。');
      });
    }
  }
}

function setRaffleChecked(name,checked){
  if(!hasOrganizerAccess()||raffleSpinning)return;

  const state=getRaffleState();
  if(state.winners.includes(name))return;

  state.checked[name]=!!checked;
  if(!ev.testOnly && isV1Authority()){
    // Never send a stale whole raffleState on a live match. The server checks
    // ownership and applies just this person's selection atomically.
    ev.raffleState=cloneJson(state);
    cloudEventsCache[ev.id]=ev;
    enqueueV1RaffleCheck(name,!!checked);
  }else{
    saveRaffleState(state);
  }
  renderDraw();
}

function resetPrizeRaffleRound(){
  if(!hasOrganizerAccess()||raffleSpinning)return;
  if(v1RaffleHasUnconfirmedChanges()){
    v1RaffleSaveStatus='請先等待勾選儲存完成';renderDraw();return;
  }
  clearInterval(raffleTimer);
  raffleTimer=null;
  raffleSpinning=false;
  saveRaffleState(defaultRaffleState());
  renderDraw();
}

function secureRandomIndex(max){
  if(max<=1)return 0;

  if(window.crypto?.getRandomValues){
    const maxUint=0x100000000;
    const limit=maxUint-(maxUint%max);
    const a=new Uint32Array(1);
    let x;
    do{
      crypto.getRandomValues(a);
      x=a[0];
    }while(x>=limit);
    return x%max;
  }

  return Math.floor(Math.random()*max);
}

function renderDraw(){
  const tab=$('drawTab');
  if(!tab||!ev)return;

  if(!Array.isArray(ev.roster))ev.roster=[];

  const editable=hasOrganizerAccess();
  const roster=[...ev.roster].filter(Boolean);
  const state=getRaffleState();
  const winners=state.winners||[];
  const lastWinner=winners.length?winners[winners.length-1]:'';

  const available=roster.filter(name=>!winners.includes(name) && state.checked[name]!==false);
  const raffleSaving=v1RaffleHasUnconfirmedChanges();

  const participantHtml=roster.map((name,i)=>{
    const won=winners.includes(name);
    const checked=!won && state.checked[name]!==false;

    return `
      <label class="drawChip rafflePerson ${won?'raffleWon':''}">
        <input
          class=raffleCheck
          type=checkbox
          ${checked?'checked':''}
          ${won||!editable?'disabled':''}
          onchange='setRaffleChecked(${JSON.stringify(name)},this.checked)'
        >
        <span class=drawNo>${won?'✓':i+1}</span>
        <span class=drawName>${esc(name)}</span>
        ${won?'<span class=raffleWonTag>已中籤</span>':''}
      </label>
    `;
  }).join('');

  const historyHtml=winners.length
    ? winners.map((name,i)=>`<span class=raffleHistoryItem>第 ${i+1} 位：${esc(name)}</span>`).join('')
    : '<span class=muted>本輪尚未有人中籤</span>';

  tab.innerHTML=`
    <div class="card drawCard raffleCard">
      <div class=drawHead>
        <div>
          <div class=muted>🎁 參賽者獎品抽籤</div>
          <h3 style="margin:4px 0 0">抽一位幸運得主</h3>
        </div>
        <span class=refCountBadge>${roster.length} 人</span>
      </div>

      <div class=drawNotice>
        每次只抽出 1 位。<b>同一輪已中籤的人不會再次被抽到</b>；
        中籤後會在下方名單變成灰色。勾選框預設全部開啟，也可以先取消不參加本次抽獎的人。
        這個功能不會修改對戰順序或比賽結果。
      </div>

      <div class=raffleStage>
        <div class=raffleLabel>本次中獎者</div>
        <div id=raffleWinner class="raffleWinner ${lastWinner?'hasWinner':''}">
          ${lastWinner?`🎉 ${esc(lastWinner)}`:'等待抽籤'}
        </div>
        <div id=raffleRolling class=raffleRolling>
          ${roster.length?`本輪可抽 ${available.length} 人・已中籤 ${winners.length} 人`:'目前沒有參賽者'}
        </div>
      </div>

      <div class=drawActions>
        <button id=raffleStartBtn type=button ${editable&&available.length&&!raffleSaving?'':'disabled'} onclick=startPrizeRaffle()>
          ${winners.length?'🎁 抽下一位':'🎁 開始抽籤'}
        </button>
        <button type=button class=secondary ${editable&&(winners.length||roster.length)&&!raffleSaving?'':'disabled'} onclick=resetPrizeRaffleRound()>開始新一輪</button>
      </div>

      ${!editable?`<div class=refHint style="margin-top:10px">只有主辦可以操作抽獎。</div>`:''}

      <div class=drawSectionTitle>本輪中籤紀錄</div>
      <div class=raffleHistory>${historyHtml}</div>

      <div class=drawSectionTitle>本次抽籤名單</div>
      <div class=muted role=status aria-live=polite style="margin:5px 0 9px">${esc(v1RaffleSaveStatus||'勾選變更會以雲端確認結果為準')}</div>
      <div class=raffleSelectAll>
        <span>✅ 預設全部勾選</span>
        <span class=muted>已中籤者會自動取消並鎖定</span>
      </div>
      <div class=drawGrid>${participantHtml || '<div class=muted>目前沒有參賽者。</div>'}</div>
    </div>
  `;
}

function shuffleDraw(){
  startPrizeRaffle();
}

function applyDrawResult(){
  startPrizeRaffle();
}


let currentAdminTab='bracket';

function isEventOwner(){
  return !!(
    ev &&
    !ev.testOnly &&
    isGoogleUser() &&
    ev.ownerUid &&
    fbAuth?.currentUser?.uid===ev.ownerUid
  );
}

function hasOrganizerAccess(){
  return !!(isAdmin || ev?.testOnly || isEventOwner());
}

function syncTabButtons(t=currentAdminTab){
  document.querySelectorAll('[data-tab-btn]').forEach(btn=>{
    const active=btn.dataset.tabBtn===t;
    btn.classList.toggle('secondary',!active);
    btn.classList.toggle('tabActive',active);
    btn.setAttribute('aria-current',active?'page':'false');
  });
}


function renderPublicBracketOnly(){
  normalizeEvent();
  ensureNext();

  const flow=usesThreePlayerFinal()?freeFlowLabel(ev.roster.length):'兩兩淘汰至冠軍＋季軍賽';
  const top=`<div class=adminHero>
    <div class=adminHeroTop>
      <div><div class=muted>🏆 賽程表</div><h2>${esc(ev.name)}</h2></div>
    </div>
    <div class=metaChips>
      <span class=metaChip>👤 ${ev.roster.length} 人</span>
      <span class=metaChip>${ev.mode==='free'?'↝ 自由編排':'🏆 單淘汰'}</span>
      <span class=metaChip>⌘ ${flow}</span>
    </div>
  </div>`;

  let cols=ev.rounds.map((r,ri)=>{
    return `<section class="roundCol ${r?.placementFinal===true?'placementFinalCol':''}" data-round="${ri}">
      <div class=roundHead><h3>${stageLabel(ri,r)}</h3><div class=roundSub>${r.matches.length} 場對戰</div></div>
      <div class=roundMatches >${r.matches.map((m,mi)=>renderBracketMatch(m,ri,mi)).join('')}</div>
    </section>`;
  }).join('');

  if(ev.finalRR)cols+=renderRR();

  $('bracketTab').innerHTML=top+`<div class=bracketShell>
    <div class=bracketTools>
      <div class=zoomGroup><button onclick="zoomBracket(-.1)">−</button><span class=zoomLabel>100%</span><button onclick="zoomBracket(.1)">＋</button><button onclick=fitBracket()>全覽</button></div>
      <div class=bracketHint>拖曳查看即時賽程</div>
      <button class=viewToggle onclick=toggleBracketFull()>⛶</button>
    </div>
    <div class=bracketScroll><div class=bracketStage><div class="bracketCanvas ${ev.roster.length>=64?'compact64':ev.roster.length>=32?'compact32':''}">
      <svg class=bracketLinks></svg>${cols}
    </div></div></div>
  </div>${renderFinalPlacings()}`;

  currentAdminTab='bracket';
  ['draw','roster','referee','organizer','share'].forEach(x=>$(x+'Tab')?.classList.add('hidden'));
  $('bracketTab')?.classList.remove('hidden');

  requestAnimationFrame(()=>{
    const n=ev?.roster?.length||0;
    bracketScale=window.innerWidth<=640
      ? (n>=64?.52:n>=32?.60:.72)
      : (n>=64?.68:n>=32?.78:.9);
    setBracketScale(bracketScale);
    requestAnimationFrame(drawBracketLinks);
  });
}


// V0.16: A single source of truth for the on-screen bracket viewport.
// A Firebase score delta must not recreate the scroll container or reset fit/zoom.
let bracketViewEventId=null;
let bracketViewInitialized=false;
// The private match stream owns the SAME live card DOM until bracket STRUCTURE
// changes. Never recreate the bracket scroller for a score/claim push.
let renderedPrivateBracket=null;
function privateBracketShape(){
  return JSON.stringify({rounds:(ev?.rounds||[]).map(r=>[r?.name,r?.placementFinal===true,(r?.matches||[]).length]),
    rr:!!ev?.finalRR, rosterSize:ev?.roster?.length||0, mode:ev?.mode, freeFinal:ev?.freeFinal});
}
function privateHeroHtml(){
  let flow=usesThreePlayerFinal()?freeFlowLabel(ev.roster.length):'兩兩淘汰至冠軍＋季軍賽';
  // V0.39: Permission-aware HTML must be authoritative on every SSE patch and full render.
  // Styling an unauthorized button with .hidden after construction is not sufficient:
  // patchPrivateBracket replaces .adminHero without invoking the normal access pass.
  const organizerAccess=hasOrganizerAccess();
  const heroActions=`${organizerAccess?`<button id=organizerHeroBtn class=secondary data-tab-btn="organizer" onclick="showTab('organizer')">🛡 主辦</button>`:''}${organizerAccess||isReferee?`<button class=secondary data-tab-btn="referee" onclick="showTab('referee')">⚖ 裁判</button>`:''}`;
  return `<div class=adminHero><div class=adminHeroTop><div><div class=muted>🏆 賽程表</div><h2>${esc(ev.name)}</h2>${isReferee&&!isAdmin?`<div class="cloudBadge on" style="margin-top:8px">⚖ 裁判模式：${esc(getMyReferee()||'尚未選擇')}</div>`:''}</div></div><div class=adminActions>${heroActions}</div><div class=metaChips><span class=metaChip>👤 ${ev.roster.length} 人</span><span class=metaChip>${ev.mode==='free'?'↝ 自由編排':'🏆 單淘汰'}</span><span class=metaChip>⌘ ${flow}</span></div></div>`;
}
function capturePrivateBracket(htmlHero){
  const matches=new Map();
  (ev?.rounds||[]).forEach((r,ri)=>(r.matches||[]).forEach((m,mi)=>matches.set(`${ri}:${mi}`,renderBracketMatch(m,ri,mi))));
  renderedPrivateBracket={id:ev?.id,shape:privateBracketShape(),hero:htmlHero,
    matches,rr:ev?.finalRR?renderRR():'',final:renderFinalPlacings()};
}
function patchPrivateBracket(){
  const cache=renderedPrivateBracket;
  const tab=$('bracketTab');
  if(!cache||!tab||cache.id!==ev?.id||cache.shape!==privateBracketShape()||!tab.querySelector('.bracketCanvas'))return false;
  // A changed hero doesn't require replacing any live match, zoom, or scroll.
  const hero=privateHeroHtml();
  if(hero!==cache.hero){const node=tab.querySelector('.adminHero');if(!node)return false;node.outerHTML=hero;cache.hero=hero;}
  let dirty=false;
  for(let ri=0;ri<(ev.rounds||[]).length;ri++){
    for(let mi=0;mi<(ev.rounds[ri]?.matches||[]).length;mi++){
      const key=`${ri}:${mi}`;
      const html=renderBracketMatch(ev.rounds[ri].matches[mi],ri,mi);
      if(html===cache.matches.get(key))continue;
      const node=tab.querySelector(`.bracketMatch[data-ri="${ri}"][data-mi="${mi}"]`);
      if(!node)return false;
      node.outerHTML=html;cache.matches.set(key,html);dirty=true;
    }
  }
  const rr=ev.finalRR?renderRR():'';
  if(rr!==cache.rr){
    const canvas=tab.querySelector('.bracketCanvas');if(!canvas)return false;
    const original=canvas.querySelector('.rrPanel');
    if(rr && original){
      const draft=document.createElement('template');draft.innerHTML=rr;
      const next=draft.content.querySelector('.rrPanel');if(!next)return false;
      const patchRows=selector=>{
        const a=[...original.querySelectorAll(selector)],b=[...next.querySelectorAll(selector)];
        if(a.length!==b.length)return false;
        for(let i=0;i<a.length;i++)if(a[i].outerHTML!==b[i].outerHTML)a[i].outerHTML=b[i].outerHTML;
        return true;
      };
      if(!patchRows('.rrMini')||!patchRows('.rrRankRow')||!patchRows('.rrStatRow'))return false;
    }else if(rr){
      canvas.insertAdjacentHTML('beforeend',rr);
    }else if(original){original.remove();}
    cache.rr=rr;dirty=true;
  }
  const final=renderFinalPlacings();
  if(final!==cache.final){
    const old=tab.querySelector('.finalPlacingsPanel');if(old)old.remove();
    if(final)tab.querySelector('.bracketShell')?.insertAdjacentHTML('afterend',final);
    cache.final=final;
  }
  // Geometry (and gold advancement paths) is recomputed, not the DOM tree.
  if(dirty)requestAnimationFrame(()=>{if(ev?.id===cache.id)drawBracketLinks()});
  return true;
}
function bracketDefaultScale(){
  const n=ev?.roster?.length||0;
  return window.innerWidth<=640 ? (n>=64?.52:n>=32?.60:.72) : (n>=64?.68:n>=32?.78:.9);
}
function bracketViewBeforeRender(){
  const sc=document.querySelector('#bracketTab .bracketScroll');
  return sc && bracketViewInitialized && bracketViewEventId===ev?.id
    ? {left:sc.scrollLeft,top:sc.scrollTop,scale:bracketScale,pageX:window.scrollX,pageY:window.scrollY}
    : null;
}
function bracketViewAfterRender(old){
  const id=ev?.id;
  const same=!!old && bracketViewEventId===id;
  if(!same){bracketScale=bracketDefaultScale();bracketViewEventId=id;}
  else bracketScale=old.scale;
  bracketViewInitialized=true;
  requestAnimationFrame(()=>{
    if(ev?.id!==id)return;
    setBracketScale(bracketScale);
    const sc=document.querySelector('#bracketTab .bracketScroll');
    if(same&&sc){
      sc.scrollLeft=old.left;sc.scrollTop=old.top;
      if(document.body.classList.contains('bracketFullscreen')){
        // Inside full view only the bracket scroller should move.
      }else if(document.querySelector('#bracketTab')?.classList.contains('hidden')===false){
        window.scrollTo(old.pageX,old.pageY);
      }
    }
    requestAnimationFrame(drawBracketLinks);
  });
}
function renderAdmin({bracketOnly=false}={}){
  if(!ev){$('admin').classList.add('hidden');$('home').classList.remove('hidden');return;}
  if(ev.publicViewOnly){
    renderPublicBracketOnly();
    return;
  }
  const bracketView=bracketViewBeforeRender();
  normalizeEvent();
  ensureNext();
  // Revoked or expired administrator access must never leave a privileged tab visible.
  if(!hasOrganizerAccess() && ['organizer','draw','roster'].includes(currentAdminTab)){
    currentAdminTab='bracket';
    // A successful SSE patch can return before the normal tab visibility pass.
    // Explicitly close a formerly privileged panel when access is no longer valid.
    ['bracket','draw','roster','referee','organizer','share'].forEach(x=>{
      const panel=$(x+'Tab');
      if(panel)panel.classList.toggle('hidden',x!=='bracket');
    });
  }
  if(bracketOnly && patchPrivateBracket()){
    applyAccessUI();
    return;
  }
  let top=privateHeroHtml();
  let cols=ev.rounds.map((r,ri)=>{return `<section class="roundCol ${r?.placementFinal===true?'placementFinalCol':''}" data-round="${ri}"><div class=roundHead><h3>${stageLabel(ri,r)}</h3><div class=roundSub>${r.matches.length} 場對戰</div></div><div class=roundMatches >${r.matches.map((m,mi)=>renderBracketMatch(m,ri,mi)).join('')}</div></section>`}).join('');
  if(ev.finalRR)cols+=renderRR();
  $('bracketTab').innerHTML=top+`<div class=bracketShell><div class=bracketTools><div class=zoomGroup><button onclick="zoomBracket(-.1)">−</button><span class=zoomLabel>100%</span><button onclick="zoomBracket(.1)">＋</button><button onclick=fitBracket()>全覽</button></div><div class=bracketHint>${isReferee&&!isAdmin?'點比賽卡開始執裁':'拖曳查看・點比賽卡編輯'}</div><button class=viewToggle onclick=toggleBracketFull()>⛶</button></div><div class=bracketScroll><div class=bracketStage><div class="bracketCanvas ${ev.roster.length>=64?'compact64':ev.roster.length>=32?'compact32':''}"><svg class=bracketLinks></svg>${cols}</div></div></div></div>${renderFinalPlacings()}`;
  // Incremental score echoes must never restart hidden-tab auth-code rotations.
  // Organizer/referee pages are rebuilt lazily by showTab() when opened.
  if(!bracketOnly){
    renderDraw();renderRoster();renderShare();
  }
  // This includes bracketOnly fallback full renders, not just initial load.
  applyAccessUI();

  // Firebase listener 或公開時間更新造成重繪時，保留使用者目前所在分頁。
  const tab=currentAdminTab||'bracket';
  ['bracket','draw','roster','referee','organizer','share'].forEach(x=>{
    const el=$(x+'Tab');
    if(el)el.classList.toggle('hidden',x!==tab);
  });
  syncTabButtons(tab);

  capturePrivateBracket(top);
  bracketViewAfterRender(bracketView);
}

function renderFinalPlacings(){
  if(!usesChampionPlacementFinal())return '';
  const finalRound=(ev.rounds||[]).find(r=>r?.placementFinal===true);
  if(!finalRound || !Array.isArray(finalRound.matches) || finalRound.matches.length<2)return '';

  const champ=finalRound.matches[0];
  const bronze=finalRound.matches[1];

  const loser=nameMatch=>{
    if(!nameMatch?.winner)return '';
    return nameMatch.winner===nameMatch.a?nameMatch.b:
      nameMatch.winner===nameMatch.b?nameMatch.a:'';
  };

  const rows=[
    ['🥇','第一名',champ?.winner||'待定'],
    ['🥈','第二名',loser(champ)||'待定'],
    ['🥉','第三名',bronze?.winner||'待定'],
    ['4️⃣','第四名',loser(bronze)||'待定']
  ];

  return `<div class="rrPanel finalPlacingsPanel" style="margin-top:14px">
    <div class=rrHead><div><b>🏆 最終名次</b><div class=muted>冠軍賽＋季軍賽完成後自動產生 1～4 名</div></div></div>
    <div class=rrRanks>${rows.map(([icon,label,name],i)=>`
      <div class=rrRankRow>
        <span class=rrPos>${icon}</span>
        <b>${label}</b>
        <span>${esc(name)}</span>
      </div>`).join('')}
    </div>
  </div>`;
}

function renderRR(){
  const f=ev.finalRR;
  if(!f)return '';

  const players=f.players||[];
  const stat={};
  players.forEach(p=>stat[p]={w:0,l:0,pf:0,pa:0});

  (f.matches||[]).forEach(m=>{
    if(!stat[m.a])stat[m.a]={w:0,l:0,pf:0,pa:0};
    if(!stat[m.b])stat[m.b]={w:0,l:0,pf:0,pa:0};

    const a=Number(m.sa),b=Number(m.sb);
    const hasA=m.sa!==''&&m.sa!=null;
    const hasB=m.sb!==''&&m.sb!=null;

    if(hasA&&hasB){
      stat[m.a].pf+=a; stat[m.a].pa+=b;
      stat[m.b].pf+=b; stat[m.b].pa+=a;
      if(a>b){stat[m.a].w++;stat[m.b].l++}
      else if(b>a){stat[m.b].w++;stat[m.a].l++}
    }
  });

  const ranked=[...players].sort((a,b)=>{
    const sa=stat[a],sb=stat[b];
    if(sb.w!==sa.w)return sb.w-sa.w;
    const da=sa.pf-sa.pa,db=sb.pf-sb.pa;
    if(db!==da)return db-da;
    return sb.pf-sa.pf;
  });

  const rows=ranked.map((p,i)=>{
    const s=stat[p];
    return `<div class=rrRankRow><span class=rrPos>${i+1}</span><b>${esc(p)}</b><span>${s.w}-${s.l}</span></div>`;
  }).join('');

  const canEdit=isAdmin||isReferee||!!ev?.testOnly;
  const games=(f.matches||[]).map((m,i)=>`<div class="rrMini ${m.refereeActive?'judging':''}" ${canEdit?`onclick="openRRMatch(${i})"`:''}><b>${esc(m.a)} vs ${esc(m.b)}</b><span>${m.sa===''?'–':m.sa} : ${m.sb===''?'–':m.sb}</span></div>`).join('');

  const statRows=ranked.map(p=>{
    const s=stat[p],diff=s.pf-s.pa;
    return `<div class=rrStatRow>
      <b>${esc(p)}</b>
      <span>得分 ${s.pf}</span>
      <span>失分 ${s.pa}</span>
      <span class="${diff>0?'plus':diff<0?'minus':''}">淨勝 ${diff>0?'+':''}${diff}</span>
    </div>`;
  }).join('');

  return `<div class=rrPanel>
    <div class=rrHead><div><b>👑 最後三人循環</b><div class=muted>決定最終名次</div></div></div>
    <div class=rrRanks>${rows}</div>
    <div class=rrGames>${games}</div>
    <div class=rrStatBox>
      <div class=rrStatTitle>📊 循環賽得失分</div>
      ${statRows}
    </div>
  </div>`;
}

function resetRRMatch(i){
  openResetChoice('rr',0,i);
}

function openRRMatch(i){
  syncAppVisualViewport();
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;

  let m=ev.finalRR.matches[i];

  const scoreEnabled=canEditMatchScore(m);
  const finishLocked=scoreEnabled && matchReachedFinishThreshold(m);
  const quickEnabled=scoreEnabled && !finishLocked;

  const completeEnabled=scoreEnabled && canCompleteMatch(m);
  const completeDisabled=completeEnabled?'':'disabled';
  const backDisabled=finishLocked?'disabled':'';

  $('matchSheet').innerHTML=`
    <div class=sheetHandle></div>

    <div class=sheetTitle>
      <div>
        <div class=muted>最後三人循環・第 ${i+1} 場</div>
        <h3>${esc(m.a)} vs ${esc(m.b)}</h3>
      </div>
      <button class=sheetClose onclick=closeMatchEditor()>✕</button>
    </div>

    <div class=sheetRef>
      <b>裁判狀態</b>
      ${refereeStatusHtml(m,'rr',0,i)}
    </div>

    ${quickScoreHtml(m,'rr',0,i,quickEnabled,scoreEnabled)}

    ${!scoreEnabled?`
      <div class=refHint style="margin:10px 0">
        必須先按「開始執裁」，才能修改比分。
      </div>
    `:''}

    ${finishLocked?`
      <div class=refHint style="margin:7px 0">
        已有人達到 4 分以上。另一方仍可修正比分，但只能選 0～3；若要改判另一方獲勝，請先把目前 4 分以上的一方調回 0～3。
      </div>
    `:''}

    <div class=sheetFooter style="grid-template-columns:1fr 1fr 1fr">
      <button class=secondary ${backDisabled} onclick="backToBracketFromMatch()">回到對戰表</button>
      <button class=secondary ${completeDisabled} onclick="rrScore(${i})">此場完成</button>
      <button class=danger onclick="resetRRMatch(${i})">重設比分</button>
    </div>`;

  $('matchModal').classList.remove('hidden');
  rememberActiveMatchSheet('rr',0,i,m);
}
function toggleBracketFull(){
  syncAppVisualViewport();document.body.classList.toggle('bracketFullscreen');setTimeout(()=>{setBracketScale(bracketScale);drawBracketLinks()},80)}

async function addReferee(){
  if(!isAdmin&&!ev?.testOnly)return;

  normalizeEvent();

  if(ev.refereeCount>=12){
    return alert('裁判最多 12 位。');
  }

  // V0.36: server appends the new slot without renumbering claimed judges.
  if(isV1Authority())return v1OrganizerAction('appendReferee');
  ev.refereeCount+=1;
  ev.refereeNames.push(`裁判 ${ev.refereeCount}`);
  localEventSave();

  if(!ev.testOnly){
    try{
      await cloudUpdate({
        [`events/${ev.id}/refereeNames`]:ev.refereeNames,
        [`events/${ev.id}/refereeCount`]:ev.refereeCount
      });
    }catch(e){
      return alert('增加裁判失敗：'+(e?.message||e));
    }
  }

  renderAdmin();
  showTab('referee');
}

async function removeReferee(index){
  if(!isAdmin&&!ev?.testOnly)return;

  normalizeEvent();
  normalizeRefereeClaims();

  if(ev.refereeCount<=1){
    return alert('至少要保留 1 位裁判。');
  }

  if(index<0 || index>=ev.refereeCount)return;

  const claim=getRefereeClaim(index);
  if(claim){
    return alert('這位裁判目前已被領取，請先按「釋放」後再刪除。');
  }

  const removedName=ev.refereeNames[index]||`裁判 ${index+1}`;
  const nextNames=ev.refereeNames.filter((_,i)=>i!==index);
  if(isV1Authority()){
    if(Object.keys(ev.refereeClaims||{}).length)return alert('請先釋放全部裁判身分，才能調整裁判名單。');
    return v1OrganizerAction('setReferees',{refereeNames:nextNames});
  }

  // 刪除中間某位時，claim 的 index 也要跟著往前移，避免身份對錯人。
  const oldClaims={...(ev.refereeClaims||{})};
  const nextClaims={};

  for(const [k,v] of Object.entries(oldClaims)){
    const oldIndex=Number(k);
    if(!Number.isInteger(oldIndex))continue;
    if(oldIndex===index)continue;
    const newIndex=oldIndex>index?oldIndex-1:oldIndex;
    nextClaims[String(newIndex)]=v;
  }

  ev.refereeCount-=1;
  ev.refereeNames=nextNames;
  ev.refereeClaims=nextClaims;

  if(getMyReferee()===removedName){
    localStorage.removeItem(refereeIdentityKey());
  }

  localEventSave();

  if(!ev.testOnly){
    try{
      const updates={
        [`events/${ev.id}/refereeNames`]:ev.refereeNames,
        [`events/${ev.id}/refereeCount`]:ev.refereeCount
      };

      // claims 已搬到獨立節點，因此需要同步整個 claims 物件。
      updates[`refereeClaims/${ev.id}`]=Object.keys(nextClaims).length?nextClaims:null;

      await cloudUpdate(updates,5000);
    }catch(e){
      return alert('刪除裁判失敗：'+(e?.message||e));
    }
  }

  renderAdmin();
  showTab('referee');
}


function releaseMyOtherMatches(who){
  if(!ev||!who)return;

  // 一位裁判同一時間只允許執裁一場。
  // 接新場次時，自動釋放自己先前尚未完成的其他場次。
  (ev.rounds||[]).forEach(round=>{
    (round.matches||[]).forEach(m=>{
      if(m && m.refereeActive && m.referee===who && !m.winner){
        m.refereeActive=false;
        m.referee='';
      }
    });
  });

  if(ev.finalRR?.matches){
    ev.finalRR.matches.forEach(m=>{
      if(m && m.refereeActive && m.referee===who && !m.winner){
        m.refereeActive=false;
        m.referee='';
      }
    });
  }
}



function clearDownstreamAfterMatchReset(ri){
  // 這一場如果原本已經有勝者，後續賽程可能已經帶入該選手。
  // 因此只保留到目前這一輪，清掉後續輪次與最後三人循環，
  // 待這輪重新完成後再由 ensureNext() 重新產生。
  if(!ev?.rounds)return;
  ev.rounds=ev.rounds.slice(0,ri+1);
  ev.finalRR=null;
}

function rebuildDownstreamIfWinnerChanged(ri,oldWinner,newWinner){
  if(!oldWinner || oldWinner===newWinner)return false;

  // 勝者改變時，後續對戰配對已不再可信。
  // 保留目前這一輪所有已完成結果，清掉後續輪次並重新依目前勝者產生。
  ev.rounds=ev.rounds.slice(0,ri+1);
  ev.finalRR=null;
  ensureNext();
  return true;
}



async function releaseMyOtherMatchesCloud(who,exceptKind,exceptRi,exceptMi){
  if(!who||!ev)return;

  const jobs=[];

  (ev.rounds||[]).forEach((round,ri)=>{
    (round.matches||[]).forEach((m,mi)=>{
      if(
        m &&
        m.refereeActive &&
        m.referee===who &&
        !m.winner &&
        !(exceptKind==='round' && ri===exceptRi && mi===exceptMi)
      ){
        m.referee='';
        m.refereeActive=false;

        if(!ev.testOnly){
          jobs.push(cloudSet(`events/${ev.id}/rounds/${ri}/matches/${mi}`,m));
        }
      }
    });
  });

  if(ev.finalRR?.matches){
    ev.finalRR.matches.forEach((m,mi)=>{
      if(
        m &&
        m.refereeActive &&
        m.referee===who &&
        !m.winner &&
        !(exceptKind==='rr' && mi===exceptMi)
      ){
        m.referee='';
        m.refereeActive=false;

        if(!ev.testOnly){
          jobs.push(cloudSet(`events/${ev.id}/finalRR/matches/${mi}`,m));
        }
      }
    });
  }

  if(jobs.length){
    await Promise.allSettled(jobs);
  }
}

async function atomicClaimMatch(kind,ri,mi,who){
  if(ev?.testOnly)return {ok:true,data:null};

  if(!(await initCloud()))return {ok:false,error:'Firebase 尚未連線'};
  if(!fbAuth?.currentUser)return {ok:false,error:'尚未取得裁判/主辦寫入權限'};

  const localMatch=kind==='rr'
    ? ev.finalRR?.matches?.[mi]
    : ev.rounds?.[ri]?.matches?.[mi];

  if(!localMatch)return {ok:false,error:'找不到這場比賽資料'};

  const token=await getRestIdToken(false);
  const base=String(FIREBASE_CONFIG.databaseURL||'').replace(/\/+$/,'');
  const rawPath=matchCloudPath(kind,ri,mi);
  const url=`${base}/${rawPath}.json?auth=${encodeURIComponent(token)}`;

  // 先讀取伺服器最新狀態與 ETag。
  const ctrl1=new AbortController();
  const timer1=setTimeout(()=>ctrl1.abort(),5000);

  let current=null;
  let etag='null_etag';

  try{
    const res=await fetch(url,{
      method:'GET',
      headers:{'X-Firebase-ETag':'true'},
      signal:ctrl1.signal,
      cache:'no-store'
    });

    if(!res.ok){
      const text=await res.text();
      throw new Error(`Firebase REST ${res.status}: ${text}`);
    }

    etag=res.headers.get('ETag')||'null_etag';
    current=await res.json();
  }catch(e){
    if(e?.name==='AbortError')return {ok:false,error:'讀取此場裁判狀態逾時，請再試一次'};
    return {ok:false,error:e?.message||String(e)};
  }finally{
    clearTimeout(timer1);
  }

  // 如果雲端這一場尚未存在，直接以本機賽程資料為底。
  if(!current)current={...localMatch};

  // 只有「真的有裁判名稱 + active=true」才算被占用。
  // refereeActive=true 但 referee 空白視為舊資料殘留，不擋人。
  if(current.refereeActive===true && current.referee && current.referee!==who){
    return {ok:false,busyBy:current.referee};
  }

  current.referee=who;
  current.refereeActive=true;

  // 用 If-Match 確保兩支手機同時搶同一場時只會一支成功。
  const ctrl2=new AbortController();
  const timer2=setTimeout(()=>ctrl2.abort(),5000);

  try{
    const res=await fetch(url,{
      method:'PUT',
      headers:{
        'Content-Type':'application/json',
        'if-match':etag
      },
      body:JSON.stringify(current),
      signal:ctrl2.signal,
      cache:'no-store'
    });

    if(res.status===412){
      // 代表剛剛有人在你按下之後先搶到；重新讀一次真正是誰。
      try{
        const latest=await rtdbRestGet(rawPath,5000);
        const busy=(latest?.refereeActive && latest?.referee)?latest.referee:'其他裁判';
        return {ok:false,busyBy:busy};
      }catch(e){
        return {ok:false,busyBy:'其他裁判'};
      }
    }

    if(!res.ok){
      const text=await res.text();
      return {ok:false,error:`Firebase REST ${res.status}: ${text}`};
    }

    const saved=await res.json();
    return {ok:true,data:saved||current};

  }catch(e){
    if(e?.name==='AbortError')return {ok:false,error:'鎖定此場逾時，請再試一次'};
    return {ok:false,error:e?.message||String(e)};
  }finally{
    clearTimeout(timer2);
  }
}

async function claimMatchAs(ri,mi){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return alert('目前沒有執裁權限。');

  const target=ev?.rounds?.[ri]?.matches?.[mi];
  if(!target)return alert('找不到這場比賽資料。');
  if(target.a==='待定'||target.b==='待定')return alert('這場尚未確定出線選手。');
  if(target.a==='BYE'||target.b==='BYE')return alert('這是自動晉級場，不需要執裁。');

  const who=currentRefereeName();
  if(!who)return alert('請先到裁判頁選擇你的裁判名稱。');

  let m=ev.rounds?.[ri]?.matches?.[mi];
  if(!m)return alert('找不到這場比賽資料。');

  const btn=document.querySelector('.startRefBtn');
  const context=matchSheetContext();
  const oldText=btn?.textContent||'⚖ 開始執裁';
  if(btn){btn.disabled=true;btn.textContent='接手中…'}

  try{
    if(ev.testOnly){
      releaseMyOtherMatches(who);
      m.referee=who;
      m.refereeActive=true;
      localEventSave();
      renderAdmin({bracketOnly:true});
      openMatchEditor(ri,mi);
      return;
    }

    if(isV1Authority()){
      try{
        await v1CloudMatchCommand('claim','round',ri,mi,{referee:who});
        if(ev?.id===context.eventId){localEventSave();renderAdmin({bracketOnly:true});if(matchSheetStillCurrent(context))openMatchEditor(ri,mi);}
      }catch(e){alert('雲端接手失敗：'+(e?.message||e));}
      return;
    }
    await releaseMyOtherMatchesCloud(who,'round',ri,mi);
    await cancelQueuedMatchCloud('round',ri,mi);

    const result=await atomicClaimMatch('round',ri,mi,who);

    if(!result.ok){
      if(result.busyBy){
        return alert(`這場目前由 ${result.busyBy} 執裁中。`);
      }
      return alert('開始執裁失敗：'+(result.error||'請再試一次'));
    }

    ev.rounds[ri].matches[mi]=result.data;
    localEventSave();
    renderAdmin({bracketOnly:true});
    openMatchEditor(ri,mi);
  }finally{
    if(btn&&document.body.contains(btn)){
      btn.disabled=false;
      btn.textContent=oldText;
    }
  }
}
async function releaseMatchAny(ri,mi){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;
  const context=matchSheetContext();

  await cancelQueuedMatchCloud('round',ri,mi);

  const m=ev.rounds?.[ri]?.matches?.[mi];
  if(!m)return alert('找不到這場比賽資料。');

  const me=currentRefereeName();

  if(!isAdmin&&!ev?.testOnly&&m.referee!==me){
    return alert(`這場目前由 ${m.referee||'其他裁判'} 執裁中，你不能釋放別人的場次。`);
  }

  if(isV1Authority()){
    try{await v1CloudMatchCommand('release','round',ri,mi);if(ev?.id===context.eventId){renderAdmin({bracketOnly:true});if(matchSheetStillCurrent(context))openMatchEditor(ri,mi);}}
    catch(e){alert('雲端釋放失敗：'+(e.message||e));}
    return;
  }

  m.referee='';
  m.refereeActive=false;

  // 先立即更新本機畫面，讓對戰表的「執裁中」標籤當場消失。
  localEventSave();
  renderAdmin({bracketOnly:true});
  openMatchEditor(ri,mi);

  // 雲端直接等待寫入完成，不再丟到背景 queue，
  // 避免畫面已釋放但 Firebase 還保留 refereeActive=true。
  if(!ev.testOnly){
    try{
      await rtdbRestPut(matchCloudPath('round',ri,mi),cloneJson(m),5000);
    }catch(e){
      console.error('release match cloud sync failed',e);
      alert('釋放場次已更新在本機，但雲端同步失敗，請再按一次釋放或重新整理。');
    }
  }
}
async function releaseRRMatchAny(i){
  if(!isAdmin&&!isReferee&&!ev?.testOnly)return;
  const context=matchSheetContext();

  await cancelQueuedMatchCloud('rr',0,i);

  const m=ev.finalRR?.matches?.[i];
  if(!m)return alert('找不到這場循環賽資料。');

  const me=currentRefereeName();

  if(!isAdmin&&!ev?.testOnly&&m.referee!==me){
    return alert(`這場目前由 ${m.referee||'其他裁判'} 執裁中，你不能釋放別人的場次。`);
  }

  if(isV1Authority()){
    try{await v1CloudMatchCommand('release','rr',0,i);if(ev?.id===context.eventId){renderAdmin({bracketOnly:true});if(matchSheetStillCurrent(context))openRRMatch(i);}}
    catch(e){alert('雲端釋放失敗：'+(e.message||e));}
    return;
  }

  m.referee='';
  m.refereeActive=false;

  localEventSave();
  renderAdmin({bracketOnly:true});
  openRRMatch(i);

  if(!ev.testOnly){
    try{
      await rtdbRestPut(matchCloudPath('rr',0,i),cloneJson(m),5000);
    }catch(e){
      console.error('release RR match cloud sync failed',e);
      alert('釋放場次已更新在本機，但雲端同步失敗，請再按一次釋放或重新整理。');
    }
  }
}


function applyAccessUI(){
  const r=$('rosterTopBtn');
  const o=$('organizerHeroBtn');
  const d=$('drawTopBtn');

  const p=new URLSearchParams(location.search);
  const adminInvite=p.get('admin')==='1';
  const organizerAccess=hasOrganizerAccess();

  if(r)r.classList.toggle('hidden',!organizerAccess);
  if(d)d.classList.toggle('hidden',!organizerAccess);
  if(o)o.classList.toggle('hidden',!(organizerAccess||adminInvite));

  document.querySelectorAll('.adminActions button').forEach(b=>{
    const isRefBtn=(b.textContent||'').includes('裁判');

    if(isRefBtn){
      b.classList.toggle('hidden',!(organizerAccess||isReferee));
    }else{
      b.classList.toggle('hidden',!organizerAccess);
    }
  });

  syncTabButtons(currentAdminTab);
}

function stopAdminCodeRotation(){
  if(adminCodeTimer){clearInterval(adminCodeTimer);adminCodeTimer=null}
  if(adminCodeCountdownTimer){clearInterval(adminCodeCountdownTimer);adminCodeCountdownTimer=null}
}
async function rotateAdminCode(force=false){
  if(!ev||ev.testOnly||!hasOrganizerAccess()||!fbAuth?.currentUser)return false;

  if(isEventOwner())isAdmin=true;

  try{
    const cur=(await rtdbRestGet(`secrets/${ev.id}`,8000))||{};
    const now=Date.now();

    if(!force && cur.adminCode && Number(cur.expiresAt||0)>now+2500){
      return true;
    }

    const code=String(Math.floor(100000+Math.random()*900000));
    const expiresAt=now+60000;
    await rtdbRestPut(`secrets/${ev.id}`,{adminCode:code,expiresAt},10000);
    return true;
  }catch(e){
    console.error('rotateAdminCode failed',e);
    return false;
  }
}
async function startAdminCodeRotation(){
  stopAdminCodeRotation();
  if(!hasOrganizerAccess()||ev?.testOnly)return;

  if(isEventOwner())isAdmin=true;

  const refreshCodeUI=async(force=false)=>{
    const ok=await rotateAdminCode(force);
    if(!ok){
      const box=$('organizerCodeBox');
      if(box)box.textContent='取得失敗';
      const cd=$('adminCodeCountdown');
      if(cd)cd.textContent='請重新整理後再試';
      return;
    }
    const latest=(await getCurrentAdminSecret())||{};
    const code=String(latest.adminCode||'------');
    const expiresAt=Number(latest.expiresAt||0);
    const box=$('organizerCodeBox');
    if(box)box.textContent=code;
    const cd=$('adminCodeCountdown');
    if(cd){cd.dataset.expiresAt=String(expiresAt);updateAdminCodeCountdown()}
  };

  await refreshCodeUI(false);

  adminCodeTimer=setInterval(()=>refreshCodeUI(true),60000);
  adminCodeCountdownTimer=setInterval(updateAdminCodeCountdown,1000);
}
async function getCurrentAdminSecret(){
  if(!ev||ev.testOnly||!fbAuth?.currentUser)return null;
  try{
    return await rtdbRestGet(`secrets/${ev.id}`,8000);
  }catch(e){
    console.warn('getCurrentAdminSecret failed',e);
    return null;
  }
}
function updateAdminCodeCountdown(){
  const el=$('adminCodeCountdown');
  if(!el)return;
  const expiresAt=Number(el.dataset.expiresAt||0);
  const left=Math.max(0,Math.ceil((expiresAt-Date.now())/1000));
  el.textContent=`${left} 秒後更換`;
}


function refereeUrl(){
  return location.origin+location.pathname+`?event=${encodeURIComponent(ev.publicCode||ev.id)}&ref=1`;
}
let refereeInviteRotation=null;
function stopRefereeCodeRotation(){
 const state=refereeInviteRotation;if(!state)return;
 refereeInviteRotation=null;
 clearTimeout(state.timer);
}
function refereeInviteVisible(){
 return !!(ev&&!ev.testOnly&&hasOrganizerAccess()&&fbAuth?.currentUser&&
  currentAdminTab==='referee'&&document.visibilityState!=='hidden'&&
  $('admin')&&!$('admin').classList.contains('hidden')&&$('refereeInviteCode')&&$('refereeCodeCountdown'));
}
function startRefereeCodeRotation(){
 if(!refereeInviteVisible()){stopRefereeCodeRotation();return;}
 const id=ev.id,uid=fbAuth.currentUser.uid;
 if(refereeInviteRotation?.id===id&&refereeInviteRotation.uid===uid){refereeInviteRotation.paint();return;}
 stopRefereeCodeRotation();
 const state={id,uid,code:'',deadline:0,retryAt:0,failures:0,timer:null,inFlight:false,paint:null};
 refereeInviteRotation=state;
 const active=()=>refereeInviteRotation===state&&ev?.id===id&&fbAuth?.currentUser?.uid===uid&&refereeInviteVisible();
 const schedule=(ms)=>{clearTimeout(state.timer);state.timer=setTimeout(state.paint,ms);};
 const fetchCode=async()=>{
  state.inFlight=true;
  try{
   const result=(await firebase.app().functions('asia-southeast1').httpsCallable('bbxV011OrganizerAuthority')({
    clientVersion:V1_AUTH_CLIENT,eventId:id,action:'getRefereeInviteCode'})).data;
   if(!active())return;
   const remaining=Number(result?.expiresAt)-Number(result?.serverNow);
   if(!result?.ok||!/^\d{6}$/.test(result.code)||!(remaining>0&&remaining<=60000))throw Error('Invalid referee invite response');
   state.code=result.code;state.deadline=performance.now()+remaining;
   state.failures=0;state.retryAt=0;
  }catch(e){
   if(!active())return;
   console.warn('Referee invite refresh deferred',String(e?.code||'unavailable'));
   state.failures++;
   state.retryAt=performance.now()+Math.min(15000,1500*2**Math.min(state.failures-1,4));
  }finally{
   state.inFlight=false;
   if(active())state.paint();
  }
 };
 state.paint=()=>{
  if(!active())return;
  clearTimeout(state.timer);state.timer=null;
  const box=$('refereeInviteCode'),countdown=$('refereeCodeCountdown');
  const now=performance.now(),left=state.deadline-now;
  if(state.code&&left>0){
   box.textContent=state.code;countdown.textContent=`${Math.ceil(left/1000)} 秒後更換`;
   schedule(Math.min(left,1000));return;
  }
  box.textContent='------';
  if(state.retryAt>now){countdown.textContent='暫時無法取得驗證碼，將自動重試';schedule(state.retryAt-now);return;}
  countdown.textContent='正在取得新驗證碼…';
  if(!state.inFlight)void fetchCode();
 };
 state.paint();
}
async function refreshRefereeState(id){
  isReferee=false;
  if(!fbAuth?.currentUser)return false;

  // Owner 本身已有最高權限，不需要再等 refereeUsers 查詢。
  if(ev?.id===id && ev?.ownerUid===fbAuth.currentUser.uid){
    isReferee=false;
    return false;
  }

  try{
    const v=await rtdbRestGet(`refereeUsers/${id}/${fbAuth.currentUser.uid}`,4000);
    isReferee=v!==null && v!==undefined && v!==false;
  }catch(e){
    console.warn('refreshRefereeState failed',e);
    isReferee=false;
  }

  return isReferee;
}
async function claimRefereeAccess(){
  if(!(await ensureRefereeAuth()))return;

  const code=$('joinRefereeCode')?.value.trim();
  if(!/^\d{6}$/.test(code))return alert('請輸入 6 位數裁判驗證碼。');

  try{
    // 沿用同一個 LOCAL Firebase user，不會每次加分/切頁重新匿名登入。
    await cloudSet(`refereeUsers/${ev.id}/${fbAuth.currentUser.uid}`,code);
    await refreshRefereeState(ev.id);

    if(!isReferee)return alert('驗證碼不正確或已過期。');

    renderAdmin();
    showTab('referee');
  }catch(e){
    console.error(e);
    alert('取得裁判權限失敗：'+(e?.message||e));
  }
}
async function assignFiveCode(){
 if(!ev?.id||!isEventOwner()||!isGoogleUser())return alert('僅原建立者能配置五碼活動 ID');
 try{
   const call=firebase.app().functions('asia-southeast1').httpsCallable('bbxV011AssignPublicCode');
   const result=(await call({clientVersion:V1_AUTH_CLIENT,eventId:ev.id})).data;
   if(!result?.ok||!/^[A-HJ-NP-Z2-9]{5}$/.test(result.publicCode||''))throw Error('伺服器未確認五碼 ID');
   ev.publicCode=result.publicCode;
   renderShare();
 }catch(error){alert('活動 ID 配置失敗：'+(error.message||error))}
}
function organizerUrl(){return location.origin+location.pathname+`?event=${encodeURIComponent(ev.publicCode||ev.id)}&admin=1`}
function publicUrl(){
  const code=String(ev?.publicCode||'');
  if(/^[A-HJ-NP-Z2-9]{5}$/.test(code))return `https://bbxs-tamsui.web.app/v/${encodeURIComponent(code)}`;
  // Legacy event without 5-character alias remains accessible on Hosting.
  return `https://bbxs-tamsui.web.app/viewer.html?event=${encodeURIComponent(ev?.id||'')}`;
}
async function claimAdmin(){
  if(!(await initCloud()))return;
  const code=$('joinAdminCode')?.value.trim();
  if(!/^\d{6}$/.test(code))return alert('請輸入 6 位數驗證碼。');
  try{
    await rtdbRestPut(`admins/${ev.id}/${fbUser.uid}`,code,7000);
    await refreshAdminState(ev.id);
    if(!isAdmin)return alert('驗證碼不正確或已過期，請向主辦取得目前顯示的新驗證碼。');
    await startAdminCodeRotation();
    renderAdmin();showTab('organizer');alert('這支手機已取得管理權。');
  }catch(e){
    console.error(e);
    alert('加入管理失敗：驗證碼不正確或已過期。');
  }
}
async function renderOrganizer(){
  const tab=$('organizerTab');
  if(!tab)return;

  if(ev?.testOnly){
    stopAdminCodeRotation();
    tab.innerHTML=`<div class=card><h3>📱 本機賽事</h3><div class=notice>這場賽事使用本機模式，不會上傳 Firebase，也無法讓第二支手機共同管理。</div><div class=cloudNote style="margin-top:12px">如果需要多人同步，請回首頁建立一場雲端賽事。</div></div>`;
    return;
  }

  if(!hasOrganizerAccess()){
    stopAdminCodeRotation();
    tab.innerHTML=`<div class=card><h3>🛡 加入主辦管理</h3><div class=cloudNote>這支手機目前是觀看模式。若要一起修改同一份賽程，請掃描主辦 QR 後輸入目前顯示的 6 位驗證碼。驗證碼每 60 秒失效。</div><label>6 位管理驗證碼</label><input id=joinAdminCode inputmode=numeric maxlength=6 placeholder="例如 583921"><button style="width:100%;margin-top:10px" onclick=claimAdmin()>驗證並成為管理員</button></div>`;
    return;
  }

  // owner 直接視為主辦，避免背景權限刷新時掉回觀看模式。
  if(isEventOwner())isAdmin=true;

  tab.innerHTML=`<div class=card><h3>🛡 主辦管理</h3>
    <div class="cloudBadge on">● 雲端同步中</div>
    <div class=organizerGrid style="margin-top:14px">
      <div>
        <div class=muted>動態管理驗證碼</div>
        <div id=organizerCodeBox class=organizerCode>讀取中…</div>
        <div id=adminCodeCountdown class=cloudNote data-expires-at="0" style="text-align:center;margin-top:6px">正在取得驗證碼</div>
        <div class=cloudNote>驗證碼每 60 秒自動更換，舊碼到期後即無法加入管理。第二支手機：掃右側 QR → 輸入目前顯示的驗證碼。</div>
      </div>
      <div>
        <div class=muted>管理 QR</div>
        <div id=adminQr class=adminQr></div>
      </div>
    </div>
    <label>管理連結</label>
    <input readonly value="${esc(organizerUrl())}">
    <div class=notice style="margin-top:12px">管理 QR 不要公開貼在群組；一般觀眾請使用「QR／分享」裡的公開觀看連結。</div>
  </div>`;

  setTimeout(()=>{
    const q=$('adminQr');
    if(q&&window.QRCode){
      q.innerHTML='';
      new QRCode(q,{text:organizerUrl(),width:180,height:180});
    }
  },0);

  await startAdminCodeRotation();
}

function renderRoster(){
 const panel=$('rosterTab');if(!panel)return;
 if(!hasOrganizerAccess()){panel.replaceChildren();delete panel.dataset.roster;return;}
 const signature=JSON.stringify([ev.id,ev.roster]);
 if(panel.dataset.eventId && panel.dataset.eventId!==ev.id)rosterRebuildMessage='';
  if(panel.dataset.roster!==signature){
  const draft=panel.dataset.eventId===ev.id?$('newPlayer')?.value||'':'';
  panel.dataset.eventId=ev.id;panel.dataset.roster=signature;
  panel.innerHTML=`<div class=card><h3>編輯參賽名單</h3><div class=notice>修改姓名會同步到對戰表。尚未開始執裁、記分或產生賽果時，才能新增、刪除選手或重新抽籤比賽順序。這不會動到獎品抽籤。</div><div id=editRoster>${ev.roster.map((n,i)=>`<div class=player><span class=num>${i+1}</span><input data-roster-edit value="${esc(n)}" onchange="rename(${i},this.value,this)"><button type=button data-roster-rebuild class="mini danger" onclick="delPlayer(${i})">刪</button></div>`).join('')}</div><div class=row><input id=newPlayer data-roster-rebuild placeholder="新增選手"><button type=button data-roster-rebuild onclick=addPlayer()>＋新增</button></div><div class=toolbar style="margin-top:10px"><button id=rosterRandomBtn type=button class=secondary onclick=randomRebuild()>依目前名單重新抽籤比賽順序</button></div><div id=rosterRebuildStatus class="rosterRebuildStatus" role=status aria-live=polite></div></div>`;
  $('newPlayer').value=draft;
 }
 updateRosterControls();
}
let rosterRebuildMessage='';
function showRosterRebuildMessage(message){
 rosterRebuildMessage=message;
 const area=$('rosterRebuildStatus');if(area)area.textContent=message;
}
function updateRosterControls(){
 const panel=$('rosterTab');if(!ev||!panel)return;
 const busy=rosterWrites.has(ev.id)||pendingPublications.has(ev.id)||(!ev.testOnly&&(cloudResyncBlocked||projectedStructureOf(ev)===null));
 const locked=!noResults();
 for(const el of panel.querySelectorAll('[data-roster-edit],[data-roster-rebuild]'))el.disabled=busy||(locked&&el.hasAttribute('data-roster-rebuild'));
 // Keep the redraw action clickable even when blocked; show the precise reason.
 const btn=$('rosterRandomBtn');if(btn){btn.disabled=false;btn.setAttribute('aria-describedby','rosterRebuildStatus');}
 const explanation=locked?'此賽事已有執裁、比分或賽果，為保護進行中的比賽，不能重新抽籤。':
   busy?'名單或籤表正在同步中；可按此按鈕核對進度，請勿重複寫入。':rosterRebuildMessage;
 const note=$('rosterRebuildStatus');if(note)note.textContent=explanation;
}
function noResults(){
 const started=m=>m?.refereeActive||m?.claimUid||Number(m?.sa||0)>0||Number(m?.sb||0)>0||(m?.winner&&m.a!=='BYE'&&m.b!=='BYE');
 return !(ev?.rounds||[]).some(r=>(r.matches||[]).some(started))&&!(ev?.finalRR?.matches||[]).some(started);
}
async function rename(i,v,field){if(!ev||!hasOrganizerAccess())return;if(isV1Authority()){
 const id=ev.id,previous=ev.roster[i];if(v.trim()===previous){if(field)field.value=previous;return;}
 const ok=await v1OrganizerAction('rename',{index:i,value:v});
 if(!ok&&field?.isConnected&&ev?.id===id)field.value=ev.roster[i]??previous;
 return;
 }let old=ev.roster[i],nv=v.trim()||old;if(ev.roster.some((x,j)=>j!==i&&x===nv)){if(field)field.value=old;return alert('選手名稱不可重複');}ev.roster[i]=nv;(ev.rounds||[]).forEach(r=>(r.matches||[]).forEach(m=>{if(m.a===old)m.a=nv;if(m.b===old)m.b=nv;if(m.winner===old)m.winner=nv}));if(ev.finalRR){ev.finalRR.players=ev.finalRR.players.map(x=>x===old?nv:x);ev.finalRR.matches.forEach(m=>{if(m.a===old)m.a=nv;if(m.b===old)m.b=nv;if(m.winner===old)m.winner=nv})}put()}
function delPlayer(i){if(!ev||!hasOrganizerAccess())return;if(isV1Authority())return v1OrganizerAction('delPlayer',{index:i});if(!noResults())return alert('已有執裁或比分，不能刪除選手。');if(ev.roster.length<=2)return alert('參賽人數至少 2 位。');ev.roster.splice(i,1);rebuild()}
async function addPlayer(){
 if(!ev||!hasOrganizerAccess())return;
 const id=ev.id,v=$('newPlayer')?.value.trim();if(!v)return;
 if(isV1Authority()){
  if(await v1OrganizerAction('addPlayer',{value:v})&&ev?.id===id&&$('newPlayer')?.value.trim()===v)$('newPlayer').value='';
  return;
 }
 if(!noResults())return alert('已有執裁或比分，不能新增選手。');
 if(ev.roster.includes(v))return alert('選手名稱不可重複');
 ev.roster.push(v);rebuild();if($('newPlayer'))$('newPlayer').value='';
}
function rebuild(){if(!ev||!hasOrganizerAccess())return;if(isV1Authority())return v1OrganizerAction('rebuild');ev.rounds=[];ev.finalRR=null;buildFirst();put()}
async function randomRebuild(){
 if(!ev||!hasOrganizerAccess())return;
 const id=ev.id;
 if(!noResults())return showRosterRebuildMessage('此賽事已有執裁、比分或賽果，為避免破壞成績，不能重新抽籤。');
 if(rosterWrites.has(id))return showRosterRebuildMessage('正在處理上一筆名單操作，請等候雲端確認。');
 if(!ev.testOnly && (cloudResyncBlocked || projectedStructureOf(ev)===null)){
   showRosterRebuildMessage('籤表正在核對雲端版本，請稍候再按；尚未送出重抽操作。');
   return;
 }
 if(pendingPublications.has(id)){
   showRosterRebuildMessage('上一筆操作已寫入，正在確認觀眾同步，請稍候再按。');
   backgroundRefreshCurrentEvent(id).catch(()=>{});
   return;
 }
 if(isV1Authority()){
   showRosterRebuildMessage('正在向雲端提交重新抽籤…');
   const ok=await v1OrganizerAction('randomRebuild');
   if(ev?.id===id){
     showRosterRebuildMessage(ok?'已提交重新抽籤，正核對最新版籤表。':'重抽未完成；請核對雲端訊息後再試。');
     updateRosterControls();
   }
   return;
 }
 // Local-only tournaments use the original deterministic pairing builder.
 let next;
 do{next=shuffle([...ev.roster]);}while(next.length>1&&new Set(next).size>1&&next.every((n,i)=>n===ev.roster[i]));
 ev.roster=next;ev.pairing='random';rebuild();
 showRosterRebuildMessage('已重新抽籤並更新比賽順序。');
}


function closeRaffleWinnerModal(){
  const el=document.getElementById('raffleWinnerModal');
  if(el)el.remove();
}

function showRaffleWinnerModal(winner){
  syncAppVisualViewport();
  closeRaffleWinnerModal();

  const overlay=document.createElement('div');
  overlay.id='raffleWinnerModal';
  overlay.className='raffleWinnerModal';

  const card=document.createElement('div');
  card.className='raffleWinnerModalCard';

  const icon=document.createElement('div');
  icon.className='raffleWinnerModalIcon';
  icon.textContent='🎉';

  const label=document.createElement('div');
  label.className='raffleWinnerModalLabel';
  label.textContent='本次中獎者';

  const name=document.createElement('div');
  name.className='raffleWinnerModalName';
  name.textContent=winner;

  const congrats=document.createElement('div');
  congrats.className='raffleWinnerModalCongrats';
  congrats.textContent='恭喜中獎！';

  const btn=document.createElement('button');
  btn.type='button';
  btn.className='raffleWinnerModalClose';
  btn.textContent='關閉';
  btn.addEventListener('click',closeRaffleWinnerModal);

  card.append(icon,label,name,congrats,btn);
  overlay.appendChild(card);

  overlay.addEventListener('click',e=>{
    if(e.target===overlay)closeRaffleWinnerModal();
  });

  document.body.appendChild(overlay);
}

function startPrizeRaffle(){
  if(!hasOrganizerAccess()||raffleSpinning||!ev)return;
  if(v1RaffleHasUnconfirmedChanges()){
    v1RaffleSaveStatus='請先等待勾選儲存完成';renderDraw();return;
  }

  const roster=[...(ev.roster||[])].filter(Boolean);
  const state=getRaffleState();
  const winners=state.winners||[];

  // 同一輪只從「有勾選 + 尚未中籤」的人裡抽。
  const pool=roster.filter(name=>!winners.includes(name) && state.checked[name]!==false);

  if(!pool.length){
    return alert('本輪已沒有可抽的人。請重新勾選名單，或按「開始新一輪」。');
  }

  raffleSpinning=true;

  const winnerEl=$('raffleWinner');
  const rollingEl=$('raffleRolling');
  const btn=$('raffleStartBtn');

  if(btn){
    btn.disabled=true;
    btn.textContent='抽籤中…';
  }

  if(winnerEl){
    winnerEl.classList.remove('hasWinner');
    winnerEl.textContent='抽籤中…';
  }

  let ticks=0;
  const totalTicks=24;

  clearInterval(raffleTimer);
  raffleTimer=setInterval(()=>{
    ticks++;
    const preview=pool[secureRandomIndex(pool.length)];

    if(winnerEl)winnerEl.textContent=preview;
    if(rollingEl)rollingEl.textContent=`抽籤中 ${'•'.repeat((ticks%3)+1)}`;

    if(ticks>=totalTicks){
      clearInterval(raffleTimer);
      raffleTimer=null;

      const winner=pool[secureRandomIndex(pool.length)];

      const latest=getRaffleState();
      if(!latest.winners.includes(winner)){
        latest.winners.push(winner);
      }
      latest.checked[winner]=false;
      saveRaffleState(latest);

      if(winnerEl){
        winnerEl.textContent=`🎉 ${winner}`;
        winnerEl.classList.add('hasWinner');
      }
      if(rollingEl)rollingEl.textContent='恭喜中獎！';

      raffleSpinning=false;

      // 額外跳出大型中獎視窗，方便現場所有人看到。
      showRaffleWinnerModal(winner);

      // 背景名單同步重畫：中籤者變灰、取消勾選並鎖定。
      setTimeout(renderDraw,180);
    }
  },70);
}

function clearPrizeRaffle(){
  resetPrizeRaffleRound();
}


function scrollPageTop(){
  // 外層頁面
  try{window.scrollTo({top:0,left:0,behavior:'auto'})}catch(e){window.scrollTo(0,0)}
  document.documentElement.scrollTop=0;
  document.documentElement.scrollLeft=0;
  document.body.scrollTop=0;
  document.body.scrollLeft=0;

  // 對戰表自己也是 overflow:auto；iPhone Safari 會記住這個內層 scrollTop。
  const sc=document.querySelector('.bracketScroll');
  if(sc){
    try{sc.scrollTo({top:0,left:0,behavior:'auto'})}catch(e){
      sc.scrollTop=0;
      sc.scrollLeft=0;
    }
    sc.scrollTop=0;
    sc.scrollLeft=0;
  }
}

function forcePageTopStable(){
  // iPhone Safari 切換建立頁 -> 裁判頁時，會沿用表單原本的 scroll 位置。
  // 立即 + 多個 frame + 短延遲全部歸零，確保真正落在頁面最上方。
  scrollPageTop();
  requestAnimationFrame(()=>{
    scrollPageTop();
    requestAnimationFrame(()=>{
      scrollPageTop();
      requestAnimationFrame(scrollPageTop);
    });
  });
  setTimeout(scrollPageTop,80);
  setTimeout(scrollPageTop,220);
}



const ACTIVE_VIEW_KEY='bx_live_active_view';
const CLOUD_VIEW_POINTER_KEY='bx_cloud_last_view_pointer';
// Store ONLY a reference and account identity, never scores/roster/authority.
// This survives Safari discarding a tab without ever restoring stale cloud data.
function readCloudViewPointer(requireCurrentUser=true){
  try{
    const hint=JSON.parse(localStorage.getItem(CLOUD_VIEW_POINTER_KEY)||'null');
    if(!hint || typeof hint.eventId!=='string' || typeof hint.ownerUid!=='string' ||
       Date.now()-Number(hint.ts)>7*86400000)return null;
    if(requireCurrentUser && (!isGoogleUser() || fbAuth.currentUser.uid!==hint.ownerUid))return null;
    return {eventId:hint.eventId,tab:hint.tab||'bracket',testOnly:false};
  }catch(e){return null}
}

function persistActiveView(tab){
  if(!ev)return;

  const payload={
    eventId:ev.id,
    tab:tab||'bracket',
    testOnly:!!ev.testOnly,
    ts:Date.now()
  };

  // 同一個分頁內的 reload 可以回到原頁籤。
  try{sessionStorage.setItem(ACTIVE_VIEW_KEY,JSON.stringify(payload))}catch(e){}

  if(ev.testOnly){
    // 只有本機賽事允許跨關窗持久保存 active view。
    try{localStorage.setItem(ACTIVE_VIEW_KEY,JSON.stringify(payload))}catch(e){}
  }else{
    // Cloud data is never stored locally; only a version-independent pointer
    // to the currently viewed organizer event survives iOS Safari tab eviction.
    try{localStorage.removeItem(ACTIVE_VIEW_KEY)}catch(e){}
    if(isGoogleUser()&&ev.ownerUid===fbAuth.currentUser.uid){
      try{localStorage.setItem(CLOUD_VIEW_POINTER_KEY,JSON.stringify({
        eventId:ev.id,ownerUid:ev.ownerUid,tab:tab||'bracket',ts:Date.now()
      }))}catch(e){}
    }

    // 目前正在看的雲端賽事由 URL 記住；真正資料仍全部來自 Firebase。
    try{
      const u=new URL(location.href);
      u.searchParams.set('event',ev.publicCode||ev.id);
      u.searchParams.set('tab',tab||'bracket');
      history.replaceState(null,'',u.pathname+u.search);
    }catch(e){}
  }
}

function clearActiveView(){
  try{sessionStorage.removeItem(ACTIVE_VIEW_KEY)}catch(e){}
  try{localStorage.removeItem(ACTIVE_VIEW_KEY)}catch(e){}
  try{localStorage.removeItem(CLOUD_VIEW_POINTER_KEY)}catch(e){}
}

function readActiveView(){
  const parse=raw=>{
    try{return raw?JSON.parse(raw):null}catch(e){return null}
  };

  // sessionStorage 可以包含雲端 / 測試，僅供「同一分頁 reload」使用。
  let v=null;
  try{v=parse(sessionStorage.getItem(ACTIVE_VIEW_KEY))}catch(e){}
  if(v?.eventId)return v;

  // localStorage 只接受 testOnly=true。
  try{v=parse(localStorage.getItem(ACTIVE_VIEW_KEY))}catch(e){}
  if(v?.eventId && v.testOnly===true)return v;

  // 清理舊版本留下的雲端 active view；新格式只有 pointer。
  try{localStorage.removeItem(ACTIVE_VIEW_KEY)}catch(e){}
  return readCloudViewPointer(true);
}

function showTab(t){
  if(!ev)return;
  const previousTab=currentAdminTab;

  const organizerAccess=hasOrganizerAccess();

  if(isReferee&&!organizerAccess&&t==='roster')t='bracket';
  if(isReferee&&!organizerAccess&&t==='organizer')t='bracket';
  if(isReferee&&!organizerAccess&&t==='draw')t='bracket';

  if(!organizerAccess && (t==='draw'||t==='roster'||t==='organizer')){
    t='bracket';
  }
  if(t!=='bracket'){
    if($('matchModal')&&!$('matchModal').classList.contains('hidden'))closeMatchEditor();
    else clearActiveMatchSheet();
  }

  currentAdminTab=t;
  persistActiveView(t);

  ['bracket','draw','roster','referee','organizer','share'].forEach(x=>{
    const el=$(x+'Tab');
    if(el)el.classList.toggle('hidden',x!==t);
  });

  syncTabButtons(t);
  updatePendingPublicationStatus();
  if(t==='roster')renderRoster();

  // A hidden bracket has zero/invalid geometry in some iOS WebViews.
  // Recompute SVG only after the bracket is visible and has been laid out.
  if(t==='bracket' && previousTab!=='bracket'){
    const eventId=ev.id;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(ev?.id===eventId && currentAdminTab==='bracket' && !$('bracketTab')?.classList.contains('hidden')){
        setBracketScale(bracketScale);
        drawBracketLinks();
      }
    }));
  }

  if(t==='draw'){
    try{
      renderDraw();
    }catch(e){
      console.error('renderDraw failed',e);
      const tab=$('drawTab');
      if(tab){
        tab.innerHTML=`<div class=card><h3>🎲 抽籤</h3><div class=notice>抽籤頁載入失敗，請回到對戰表後再重新進入。</div></div>`;
      }
    }
  }

  if(t==='organizer')renderOrganizer();
  else stopAdminCodeRotation();

  if(t==='referee')renderReferee();
  else stopRefereeCodeRotation();
}
// V0.37: Claim/claim-release updates must not rebuild the whole referee page.
// In particular, do not tear down the rotating QR, unsubmitted text inputs,
// or the scroll anchor underneath an iPhone Safari finger tap.
function updateRefereePanelHtml(nextHtml){
  const panel=$('refereeTab');if(!panel)return false;
  const temp=document.createElement('template');temp.innerHTML=nextHtml;
  const fresh=temp.content.querySelector('.refCard');
  const current=panel.querySelector('.refCard');
  const sameMode=!!current&&!!fresh&&
    !!current.querySelector('.refereeListHead')===!!fresh.querySelector('.refereeListHead');
  const sameSlots=sameMode&&
    current.querySelectorAll('.refIdentityRow').length===fresh.querySelectorAll('.refIdentityRow').length&&
    current.querySelectorAll('.refereeNameEdit').length===fresh.querySelectorAll('.refereeNameEdit').length;
  const visible=currentAdminTab==='referee'&&!panel.classList.contains('hidden');
  const oldPage=visible&&current?{x:window.scrollX,y:window.scrollY,
    left:panel.scrollLeft,top:panel.scrollTop}:null;
  if(sameSlots){
    // Reconcile just the changing rows; other controls and the QR stay mounted.
    for(const selector of ['#refereeClaimsSummary','.refereeNameEdit','.refIdentityRow','.judgePick + .refHint']){
      const before=[...current.querySelectorAll(selector)];
      const after=[...fresh.querySelectorAll(selector)];
      if(before.length!==after.length){panel.innerHTML=nextHtml;return false;}
      for(let i=0;i<before.length;i++){
        if(before[i].outerHTML!==after[i].outerHTML)before[i].replaceWith(after[i].cloneNode(true));
      }
    }
  }else{
    // A genuine roster/permission layout change still needs a full rebuild.
    panel.innerHTML=nextHtml;
  }
  if(oldPage){
    const restore=()=>{
      if(currentAdminTab!=='referee'||panel.classList.contains('hidden'))return;
      panel.scrollLeft=oldPage.left;panel.scrollTop=oldPage.top;
      window.scrollTo(oldPage.x,oldPage.y);
    };
    // Restore synchronously and after iOS layout/scroll anchoring settles.
    restore();requestAnimationFrame(restore);
  }
  return !!sameSlots;
}
async function renderReferee({skipCloudRefresh=false}={}){
  normalizeEvent();
  normalizeRefereeClaims();

  if(!skipCloudRefresh && !ev.testOnly && (isAdmin||isReferee)){
    // Do not block showing the existing referee panel on a REST round trip.
    // A changed server claim will repaint this tab after the response arrives.
    void refreshRefereeClaimsNow().catch(e=>console.warn('referee claims verify deferred',e));
  }

  const invite=new URLSearchParams(location.search).get('ref')==='1';
  const myUid=currentRefereeUid();
  const claimedCount=ev.refereeNames.reduce((n,_,i)=>n+Number(!!getRefereeClaim(i)),0);
  const claimSummary=`<div class="refHint" id="refereeClaimsSummary"><b>${!ev.testOnly&&!refereeClaimsConfirmed()?'正在核對雲端裁判領取狀態…':`全場裁判領取狀態：${claimedCount}/${ev.refereeNames.length} 已領取`}</b><div style="margin-top:6px">${ev.refereeNames.map((name,i)=>`${esc(name)}：${getRefereeClaim(i)?'已領取':'未領取'}`).join('・')}</div></div>`;

  const makeIdentityButton=(name,index)=>{
    const claim=getRefereeClaim(index);
    const mine=!!(claim && myUid && claim.uid===myUid);
    const taken=!!claim && !mine;
    const me=getMyReferee();
    const localSelected=!!ev.testOnly && me===name;
    const selected=mine || localSelected;
    const organizer=hasOrganizerAccess();

    return `<div class="refIdentityRow ${(taken||claim)?'claimed':''}">
      <button
        type=button
        class="${selected?'':'secondary'} refIdentityBtn"
        ${taken||(!ev.testOnly&&!refereeClaimsConfirmed())?'disabled':''}
        onclick='setMyReferee(${JSON.stringify(name)})'
      >
        ${selected?'✓ ':''}⚖ ${esc(name)}
        ${taken?'・已被領取':mine?'・你已領取':localSelected?'・本機已選':''}
      </button>
      ${(organizer || mine || localSelected)
        ? `<button type=button class="danger refReleaseBtn" onclick="releaseRefereeSlot(${index})">釋放</button>`
        : ''
      }
    </div>`;
  };

  if(hasOrganizerAccess()){
    const n=ev.refereeCount||1,me=getMyReferee();
    const names=ev.refereeNames.map((name,i)=>{
      const claim=getRefereeClaim(i);
      const claimed=!!claim;
      return `<div class="player refereeNameEdit ${claimed?'claimed':''}">
        <span class=num>${i+1}</span>
        <input id="refName${i}" value="${esc(name)}" placeholder="裁判 ${i+1}" ${claimed?'disabled':''}>
        <span class=refClaimState>${claimed?(isMyRefereeClaim(i)?'你已領取':'已被領取'):'未領取'}</span>
        ${(claimed || getMyReferee()===name)
          ? `<button type=button class="danger mini" onclick="releaseRefereeSlot(${i})">釋放</button>`
          : (n>1?`<button type=button class="danger mini" onclick="removeReferee(${i})">刪除</button>`:'')
        }
      </div>`;
    }).join('');

    const identityButtons=ev.refereeNames.map((name,i)=>makeIdentityButton(name,i)).join('');

    const inviteBlock=ev.testOnly?'':`
      <div class=refInviteBox style="margin-top:18px">
        <label>裁判加入</label>
        <div class=cloudNote>把這個 QR 給現場裁判掃描。裁判輸入目前 6 位驗證碼後，只能取得執裁權限，不會取得主辦權限。</div>
        <div class=organizerGrid style="margin-top:12px">
          <div>
            <div class=muted>動態裁判驗證碼</div>
            <div id=refereeInviteCode class=organizerCode>讀取中…</div>
            <div id=refereeCodeCountdown class=cloudNote data-expires-at="0" style="text-align:center;margin-top:6px">正在取得驗證碼</div>
          </div>
          <div>
            <div class=muted>裁判 QR</div>
            <div id=refereeInviteQr class=adminQr></div>
          </div>
        </div>
      </div>`;

    const wasPatched=updateRefereePanelHtml(`<div class="refCard refSimple"><h3 style="margin-top:0">⚖ 裁判設定</h3>
      <div class=muted>
        預設 1 位裁判，需要時可按「增加裁判」逐位新增。
        未被領取的裁判可以刪除；已被領取的裁判要先按「釋放」才能刪除。
        裁判名稱一旦被某支手機領取，其他手機不能再選同一個名稱。
      </div>
      ${claimSummary}

      <div class=refereeListHead style="margin-top:14px">
        <div>
          <label style="margin:0">裁判名單</label>
          <span class=refCountBadge>目前 ${n} 位</span>
        </div>
        <button type=button onclick=addReferee()>＋ 增加裁判</button>
      </div>

      <div style="margin-top:10px">
        ${names}
        <button style="width:100%;margin-top:8px" onclick=saveRefereeNames()>儲存裁判名稱</button>
      </div>

      ${inviteBlock}

      <div style="margin-top:18px">
        <label>主辦這支手機的裁判身分（與其他裁判領取狀態分開）</label>
        <div class=judgePick>${identityButtons}</div>
        ${me?`<div class=refHint>目前本機：<b>${esc(me)}</b></div>`:`<div class=refHint>這支主辦手機尚未選擇裁判身分；不代表其他裁判尚未領取。</div>`}
      </div>

      <div style="margin-top:12px"><button class=secondary onclick="showTab('bracket')">返回對戰表</button></div>
    </div>`);

    if(!ev.testOnly&&!wasPatched){
      setTimeout(()=>{
        const q=$('refereeInviteQr');
        if(q&&window.QRCode){q.innerHTML='';new QRCode(q,{text:refereeUrl(),width:180,height:180})}
      },0);
    }
    if(!ev.testOnly)startRefereeCodeRotation();
    return;
  }

  if(isReferee){
    const me=getMyReferee();
    const buttons=ev.refereeNames.map((name,i)=>makeIdentityButton(name,i)).join('');

    updateRefereePanelHtml(`<div class="refCard refSimple"><h3 style="margin-top:0">⚖ 選擇裁判身分</h3>
      <div class=muted>
        灰色代表這個裁判名稱已經被其他手機領取，不能重複選擇。
        你領取的名稱會顯示「你已領取」，需要更換時請先按「釋放」。
      </div>

      <div class=judgePick style="margin-top:16px">${buttons}</div>

      ${me
        ? `<div class=refHint>目前身分：<b>${esc(me)}</b>。現在可以直接回對戰表執裁。</div>`
        : `<div class=refHint>尚未選擇裁判身分。</div>`
      }

      <button style="width:100%;margin-top:14px" onclick="showTab('bracket')">返回對戰表</button>
    </div>`);
    return;
  }

  if(invite){
    $('refereeTab').innerHTML=`<div class="refCard refSimple"><h3 style="margin-top:0">⚖ 加入裁判</h3>
      <div class=muted>輸入主辦方目前顯示的 6 位裁判驗證碼。通過後只會取得執裁權限，不會取得主辦管理權。</div>
      <label style="margin-top:16px">6 位裁判驗證碼</label>
      <input id=joinRefereeCode inputmode=numeric maxlength=6 placeholder="例如 583921">
      <button style="width:100%;margin-top:10px" onclick=claimRefereeAccess()>驗證並加入裁判</button>
    </div>`;
    return;
  }

  $('refereeTab').innerHTML='';
}
function renderShare(){
  if(ev?.testOnly){
    $('shareTab').innerHTML=`<div class=card><h3>QR／分享</h3><div class=notice>這場是本機賽事，沒有雲端網址，因此不提供 QR 分享或跨手機同步。</div></div>`;
    return;
  }

  const ownerControls=isGoogleUser() && ev?.ownerUid===fbAuth.currentUser.uid;
  const expired=ev?.publicOpen===false || Number(ev?.publicUntil||0)<=Date.now();
  const statusText=publicStatusText(ev);

  $('shareTab').innerHTML=`
    <div class=card>
      <h3>QR／分享</h3>
      <div class=cloudNote>活動 ID：<strong>${esc(ev.publicCode||'尚未配置')}</strong> ${ev.publicCode?'（五碼）':(ownerControls?'<button type=button onclick=assignFiveCode()>為舊賽事配置五碼 ID</button>':'（舊版長 ID 仍可使用）')}</div>

      <div class=notice>
        這是公開觀看連結。觀眾只能查看即時比分與晉級，以及分享連結；不能修改賽程、比分或裁判狀態。
      </div>

      <div class="sharePublicControl ${expired?'off':'on'}">
        <div>
          <div class=sharePublicLabel>公開狀態</div>
          <div class=sharePublicTime>${esc(statusText)}</div>
          <div class=cloudNote>公開時間最多維持到現在起 4 小時；按「增加 4 小時」後，公開期限最多仍只會到現在起 4 小時，不會疊加成 8 小時以上。</div>
        </div>

        ${ownerControls?`
          <div class=sharePublicActions>
            <button type=button data-extend-id="${ev.id}">增加 4 小時</button>
            <button type=button class="secondary" data-close-public-id="${ev.id}" ${ev.publicOpen===false?'disabled':''}>關閉公開連結</button>
          </div>
        `:''}
      </div>

      <label>公開觀看網址</label>
      <input id=pubUrl readonly value="${esc(publicUrl())}">

      <div id=qr class=qrbox></div>

      <div class=toolbar>
        <button onclick=copyPublic()>複製連結</button>
        <button class=secondary onclick=nativeShare()>分享到 LINE／其他 App</button>
      </div>
    </div>`;

  const extendBtn=$('shareTab').querySelector(`[data-extend-id="${CSS.escape(ev.id)}"]`);
  if(extendBtn)extendBtn.addEventListener('click',()=>extendPublicEvent(ev.id));

  const closeBtn=$('shareTab').querySelector(`[data-close-public-id="${CSS.escape(ev.id)}"]`);
  if(closeBtn)closeBtn.addEventListener('click',()=>closePublicEvent(ev.id));

  setTimeout(()=>{
    const q=$('qr');
    if(q&&window.QRCode){
      q.innerHTML='';
      new QRCode(q,{text:publicUrl(),width:180,height:180});
    }
  },0);
}
async function copyPublic(){await navigator.clipboard.writeText(publicUrl());alert('已複製連結')}
async function nativeShare(){if(navigator.share)await navigator.share({title:ev.name,text:'查看即時對戰表',url:publicUrl()});else copyPublic()}


function currentTheme(){
  const attr=document.documentElement.getAttribute('data-theme');
  if(attr==='light'||attr==='dark')return attr;

  try{
    const saved=localStorage.getItem(THEME_KEY);
    if(saved==='light'||saved==='dark')return saved;
  }catch(e){}

  return 'dark';
}

function updateThemeButton(){
  const btn=$('themeToggleBtn');
  if(!btn)return;

  const isLight=currentTheme()==='light';

  // 顯示目前模式的圖示：
  // 深色 = 月亮，淺色 = 太陽
  if(isLight){
    btn.textContent='☀️';
    btn.setAttribute('aria-label','目前為淺色模式，點擊切換深色');
    btn.title='淺色模式';
  }else{
    btn.textContent='🌙';
    btn.setAttribute('aria-label','目前為深色模式，點擊切換淺色');
    btn.title='深色模式';
  }
}

function applyTheme(theme,save=true){
  const next=theme==='light'?'light':'dark';

  document.documentElement.setAttribute('data-theme',next);

  if(save){
    try{localStorage.setItem(THEME_KEY,next)}catch(e){}
  }

  const meta=document.querySelector('meta[name="theme-color"]');
  if(meta)meta.setAttribute('content',next==='light'?'#f5f7fa':'#0b0d12');

  updateThemeButton();

  // 重新畫對戰表只做為附加動作，任何錯誤都不能影響主題切換本身。
  requestAnimationFrame(()=>{
    try{
      if(typeof setBracketScale==='function' && typeof bracketScale!=='undefined'){
        setBracketScale(bracketScale);
      }
      if(typeof drawBracketLinks==='function'){
        drawBracketLinks();
      }
    }catch(e){
      console.warn('theme redraw skipped',e);
    }
  });
}

function toggleTheme(){
  try{
    const now=currentTheme();
    const next=now==='light'?'dark':'light';
    applyTheme(next,true);
  }catch(e){
    console.error('toggleTheme failed',e);

    // 最後保險：即使 localStorage 或其他 UI 發生問題，
    // 仍直接切換 html[data-theme]。
    const root=document.documentElement;
    const next=root.getAttribute('data-theme')==='light'?'dark':'light';
    root.setAttribute('data-theme',next);

    try{localStorage.setItem('bx_live_theme',next)}catch(_){}

    const btn=document.getElementById('themeToggleBtn');
    if(btn)btn.textContent=next==='light'?'☀️':'🌙';
  }
}



document.addEventListener('DOMContentLoaded',()=>{
  const btn=$('homeNextBtn');
  if(btn && !btn.dataset.boundNext){
    btn.dataset.boundNext='1';
    btn.addEventListener('click',e=>{
      if(btn.disabled)return;
      // inline onclick 已存在時不重複執行；這裡只作 Safari fallback。
    });
  }
});


function initThemeUI(){
  let saved='dark';

  try{
    const v=localStorage.getItem(THEME_KEY);
    if(v==='light'||v==='dark')saved=v;
    else saved=currentTheme();
  }catch(e){
    saved=currentTheme();
  }

  applyTheme(saved,false);
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',initThemeUI,{once:true});
}else{
  initThemeUI();
}



const liveRetryAttempts=new Map();
let cloudResyncBlocked=false;
let foregroundCloudResyncBusy=false;
let foregroundCloudResyncLastAt=0;

async function resyncCurrentCloudEventOnForeground(reason='foreground'){
  // 只有「目前正在看的雲端主辦/裁判賽事」需要這層保險。
  // 本機測試賽事不碰 Firebase；公開觀眾已由 viewer.html 的 SSE-resync 處理。
  if(!ev || ev.testOnly || ev.publicViewOnly)return false;
  if(!$('admin') || $('admin').classList.contains('hidden'))return false;

  const id=ev.id;
  if(!id)return false;

  // pageshow + visibilitychange 在 iOS 可能前後一起觸發。
  // 避免同一秒重複向 Firebase 抓兩次完整賽事。
  const now=Date.now();
  if(foregroundCloudResyncBusy)return false;
  if(now-foregroundCloudResyncLastAt<1500)return false;

  foregroundCloudResyncBusy=true;
  foregroundCloudResyncLastAt=now;

  const keepTab=currentAdminTab||'bracket';

  try{
    // Score commands sent before backgrounding are not cancelled. Wait for their
    // receipts before reloading, so the fresh snapshot cannot erase a pending tap.
    const inflight=[...v05ScoreQueues.values()].filter(q=>q.eventId===id&&(q.run||q.timer||q.desired));
    for(const q of inflight){
      try{await v05FlushScores(q.kind,q.ri,q.mi)}
      catch(e){console.warn('foreground score reconciliation failed',e)}
    }
    if(document.visibilityState==='hidden'||ev?.id!==id)return false;
    // 若 Safari / PWA 從背景恢復時 Auth 還沒回來，最多等 5 秒。
    if(!fbAuth?.currentUser){
      await waitForAuthRestore(5000);
      fbUser=fbAuth?.currentUser||fbUser;
      renderHeaderAuth();
    }

    if(!fbAuth?.currentUser){
      console.warn('foreground cloud resync deferred until auth restored',reason);
      cloudResyncBlocked=true;
      pauseActiveMatchSheetForResync();
      return false;
    }

    // V0.45: Keep the referee's match sheet through a Camera/app switch.
    // Lock stale controls until the authoritative snapshot + referee claim
    // have both been verified; never close the overlay simply for backgrounding.
    cloudResyncBlocked=true;
    pauseActiveMatchSheetForResync();

    // Keep an active subscription alive until the fresh snapshot succeeds.
    // If iOS already detached it while hidden, the failure branch reattaches.

    let latest=null;
    try{
      latest=await rtdbRestGet(`events/${id}`,8000);
    }catch(firstErr){
      console.warn('foreground resync first read failed, refresh token and retry',firstErr);

      // iOS 背景回前景時 token 可能剛好過期，強制刷新後再讀一次。
      try{
        await getRestIdToken(true);
        latest=await rtdbRestGet(`events/${id}`,8000);
      }catch(secondErr){
        console.warn('foreground resync retry failed',secondErr);

        // 讀取失敗時不能用舊 RAM 資料繼續寫。
        // 保留畫面但不重新綁 listener，讓使用者重新整理/等待 Auth 恢復。
        // Keep the last rendered scores and the organizer route. The server
        // rejects stale versions, but edits are paused until a successful GET.
        cloudResyncBlocked=true;
        if(!cloudUnsub)listenCloudEvent(id); // only reattach if background actually detached it
        console.warn('BBX_V023_FOREGROUND_DEFERRED',reason);
        return false;
      }
    }

    if(!latest){
      cloudResyncBlocked=true;
      // A null read alone cannot prove removal: never clear the organizer
      // route or event list. An explicit deletion has a different receipt.
      console.warn('Foreground event returned null; retaining organizer session',id);
      // A failed REST lookup must not leave live observers permanently detached.
      // Restore read-only subscriptions; no local state or event is deleted.
      if(!cloudUnsub)listenCloudEvent(id);
      console.warn('BBX_V027_FOREGROUND_NULL_SNAPSHOT',reason);
      return false;
    }

    if(document.visibilityState==='hidden'||ev?.id!==id)return false;
    if(Number(latest.publishedSeq||0)<Number(ev?.publishedSeq||0)){
      console.warn('BBX_V027_FOREGROUND_STALE_SNAPSHOT_SKIPPED',id);
      cloudResyncBlocked=true;
      return false;
    }
    // Firebase is authoritative, but an older GET must not regress a match
    // accepted from the live stream during the network round trip.
    if(isV1Authority()&&sameProjectedStructure(ev,latest)){
      for(const [kind,rounds] of [['round',ev.rounds],['rr',ev.finalRR?.matches?[{matches:ev.finalRR.matches}]:[]]]){
        (rounds||[]).forEach((round,ri)=>(round.matches||[]).forEach((old,mi)=>{
          const next=kind==='rr'?latest.finalRR?.matches?.[mi]:latest.rounds?.[ri]?.matches?.[mi];
          if(next&&old.a===next.a&&old.b===next.b&&(v05ScorePending(kind,kind==='rr'?0:ri,mi)||Number(old.matchVersion||0)>Number(next.matchVersion||0)))Object.assign(next,old);
        }));
      }
    }
    cloudResyncBlocked=false;
    const previousClaims=normalizeRefereeClaimsData(ev?.refereeClaims);
    ev=preserveVerifiedRaffleOnOldEventSnapshot(latest,ev,id);
    ev.refereeClaims=previousClaims;
    cloudEventsCache[id]=ev;

    if(latest.ownerUid===fbAuth.currentUser.uid){
      isAdmin=true;
      isReferee=false;
    }else{
      await Promise.all([
        refreshAdminState(id),
        refreshRefereeState(id)
      ]);
    }

    // 重新取得當下裁判 claim，避免背景期間場次被其他裁判接走。
    const claimsAtRequest=refereeClaimsStreamRevision;
    let claimsVerified=false;
    // A previous claim is not proof that this UID still controls this match.
    confirmedRefereeClaimsContext='';
    try{
      const claims=await rtdbRestGet(`refereeClaims/${id}`,5000);
      if(claimsAtRequest===refereeClaimsStreamRevision){
        ev.refereeClaims=normalizeRefereeClaimsData(claims);
        confirmRefereeClaims();
      }
      claimsVerified=refereeClaimsConfirmed();
    }catch(e){
      console.warn('foreground referee claims refresh skipped',e);
      ev.refereeClaims=ev.refereeClaims||{};
    }

    cloudResyncBlocked=!claimsVerified;
    renderAdmin();
    showTab(keepTab);
    if(claimsVerified)restoreActiveMatchSheetIfSafe();
    else pauseActiveMatchSheetForResync();

    // 用最新完整資料重新綁 listener。
    listenCloudEvent(id);

    // 重新畫樹狀線，避免 Safari 從背景回來後 geometry 是舊的。
    requestAnimationFrame(()=>{
      try{
        setBracketScale(bracketScale);
        requestAnimationFrame(drawBracketLinks);
      }catch(e){}
    });

    console.info('foreground cloud resync complete',reason,id);
    return true;
  }finally{
    foregroundCloudResyncBusy=false;
  }
}

window.addEventListener('pageshow',e=>{
  if(e.persisted && ev?.publicViewOnly && ev.id){loadPublicProjectionEvent(ev.id);return;}
  if(bbxCanRunOwnerIndex()){
    listenMyCloudEventIndex();
    return;
  }

  // iOS BFCache / 回到前景：主辦與裁判賽事強制以 Firebase 最新完整資料校正。
  if(e.persisted || (ev && !ev.testOnly && !ev.publicViewOnly)){
    if(currentAdminTab==='referee')startRefereeCodeRotation();
    resyncCurrentCloudEventOnForeground(e.persisted?'pageshow-bfcache':'pageshow');
  }
});

document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='hidden'){
    // Detach SSE streams while backgrounded, not any in-flight Cloud Function
    // scoring request. Their original opIds and receipts remain intact.
    if(cloudUnsub){try{cloudUnsub()}catch(e){} cloudUnsub=null;}
    stopMyCloudEventIndexListener();
    stopAdminCodeRotation();
    stopRefereeCodeRotation();
    return;
  }
  if(bbxCanRunOwnerIndex()){
    listenMyCloudEventIndex();
    return;
  }
  if(ev?.publicViewOnly && ev.id){loadPublicProjectionEvent(ev.id);return;}
  if(currentAdminTab==='referee')startRefereeCodeRotation();


  // Safari / PWA 背景期間賽程可能已被其他裁判更新。
  // 回前景後不相信舊 RAM，完整抓 Firebase 最新資料再重綁 listener。
  resyncCurrentCloudEventOnForeground('visibility');
});

window.addEventListener('pagehide',()=>{
  if(cloudUnsub){try{cloudUnsub()}catch(e){} cloudUnsub=null;}
  stopMyCloudEventIndexListener();
  stopAdminCodeRotation();
  stopRefereeCodeRotation();
});

window.addEventListener('online',()=>{
  if($('home') && !$('home').classList.contains('hidden') && isGoogleUser())listenMyCloudEventIndex();
  // 網路從離線恢復時也做同一層校正。
  if(ev && !ev.testOnly && !ev.publicViewOnly){
    if(currentAdminTab==='referee')startRefereeCodeRotation();
    resyncCurrentCloudEventOnForeground('online');
  }
});

window.addEventListener('resize',()=>{clearTimeout(window.__bxResize);window.__bxResize=setTimeout(()=>{setBracketScale(bracketScale);drawBracketLinks()},120)});


$('deleteCancelBtn')?.addEventListener('click',closeDeleteConfirm);
$('deleteOkBtn')?.addEventListener('click',async()=>{
  if(!pendingDeleteId)return closeDeleteConfirm();
  await deleteSavedEvent(pendingDeleteId);
});
$('deleteConfirmModal')?.addEventListener('click',e=>{
  if(e.target===$('deleteConfirmModal'))closeDeleteConfirm();
});

function restoreCachedEventImmediately(id,tab){
  const cached=events()[id];
  if(!cached?.testOnly)return false;

  ev=cached;
  isAdmin=true;
  isReferee=false;

  $('home').classList.add('hidden');
  $('create').classList.add('hidden');
  $('admin').classList.remove('hidden');

  currentAdminTab=tab||'bracket';
  renderAdmin();

  const allowed=['bracket','draw','roster','referee','organizer','share'];
  showTab(allowed.includes(currentAdminTab)?currentAdminTab:'bracket');
  return true;
}

async function backgroundRefreshCurrentEvent(id){
  try{
    let data=null;

    if(fbAuth?.currentUser){
      try{
        data=await rtdbRestGet(`events/${id}`,5000);
      }catch(e){
        console.warn('background private refresh skipped; auth/token may still be restoring',e);
        return;
      }
    }else{
      return;
    }

    if(!data){
      // No snapshot is not an authenticated deletion receipt. Keep the page,
      // URL, roster and index; only a fresh confirmed snapshot unblocks edits.
      cloudResyncBlocked=true;
      console.warn('Background event returned null; preserving organizer view',id);
      return;
    }

    if(!ev||ev.id!==id||Number(data.publishedSeq||0)<Number(ev.publishedSeq||0))return;

    const keepTab=currentAdminTab||'bracket';
    // Public projection can lag the private authority. Never let an older
    // events/ snapshot roll a confirmed or still-pending score backwards.
    if(isV1Authority()&&sameProjectedStructure(ev,data)&&['BBX-V0.9','BBX-V0.10','BBX-V0.11'].includes(data.releaseTag)){
      for(const [kind,rounds] of [['round',ev.rounds],['rr',ev.finalRR?.matches?[{matches:ev.finalRR.matches}]:[]]]){
       (rounds||[]).forEach((r,ri)=>(r.matches||[]).forEach((old,mi)=>{
        const dest=kind==='rr'?data.finalRR?.matches?.[mi]:data.rounds?.[ri]?.matches?.[mi];
        if(!dest||old.a!==dest.a||old.b!==dest.b)return;
        const stale=Number(old.matchVersion||0)>Number(dest.matchVersion||0);
        if(stale||v05ScorePending(kind,kind==='rr'?0:ri,mi))Object.assign(dest,old);
       }));
      }
    }
    // A full event REST GET never includes refereeClaims/<eventId>. Keep
    // the independently confirmed claim rather than clearing identity on
    // every match completion and forcing a referee-tab round trip.
    if(!sameProjectedStructure(ev,data))closeStaleMatchSheet(ev,data);
    ev=preserveLiveRefereeClaimsOnEventSnapshot(
      preserveVerifiedRaffleOnOldEventSnapshot(data,ev,id));
    cloudEventsCache[id]=ev;

    if(fbAuth?.currentUser){
      if(data.ownerUid===fbAuth.currentUser.uid){
        isAdmin=true;
        isReferee=false;
      }else{
        await Promise.all([
          refreshAdminState(id),
          refreshRefereeState(id)
        ]);
      }
    }

    if(ev?.id!==id)return;
    renderAdmin({bracketOnly:true});
    showTab(currentAdminTab||keepTab);
    updatePendingPublicationStatus();
  }catch(e){
    console.warn('backgroundRefreshCurrentEvent failed',e);
  }
}


function stopMyCloudEventIndexListener(){
  if(ownerIndexUnsub)bbxLifecycleNote('home-index','stop');
  ownerIndexBoundUid=null;
  ownerIndexGeneration++;
  clearOwnerRetryTimers();
  ownerIndexPendingSnapshot=null;
  if(ownerIndexUnsub){
    try{ownerIndexUnsub()}catch(e){}
    ownerIndexUnsub=null;
  }
}
function listenMyCloudEventIndex(){
  if(!bbxCanRunOwnerIndex())return;
  const uid=fbAuth.currentUser.uid;
  if(ownerIndexUnsub&&ownerIndexBoundUid===uid)return;
  stopMyCloudEventIndexListener();
  bbxLifecycleNote('home-index','start');
  const generation=ownerIndexGeneration;
  const active=()=>generation===ownerIndexGeneration&&bbxCanRunOwnerIndex()&&fbAuth?.currentUser?.uid===uid;
  ownerIndexBoundUid=uid;
  cloudEventsCache=Object.fromEntries(Object.entries(cloudEventsCache).map(([id,item])=>
    [id,item?.ownerUid===uid?{...item,pendingSync:true}:item]));
  setOwnerIndexState({phase:'loading',uid,provider:'google.com',restSlots:null,
    verified:false,indexMismatch:false,source:null,error:null,checkedAt:null});
  let timer=null,busy=false,again=false,retries=0;
  const refresh=async()=>{
    if(!active())return;
    if(busy){again=true;return;}busy=true;ownerIndexSyncBusy=true;
    try{
      const result=await rtdbRestGet(`userEvents/${uid}`,7000);
      if(!active())return;
      const slots=indexedOwnerSlots(result);
      await syncMyCloudEvents(result,active);
      if(!active())return;
      setOwnerIndexState({phase:'verified',uid,verified:true,source:'REST+SSE',
        restSlots:Object.keys(slots).length,restFingerprint:ownerIndexSlotFingerprint(result),
        error:null,indexMismatch:false,checkedAt:Date.now()});
      retries=0;
      renderHomeSelections();renderSavedEvents();
    }catch(e){if(active()){
      setOwnerIndexState({phase:'error',verified:false,error:ownerIndexErrorLabel(e),source:'REST',checkedAt:Date.now()});
      if(retries++<5)schedule(Math.min(30000,2000*2**Math.min(retries,4)));
    }}finally{busy=false;ownerIndexSyncBusy=false;if(again&&active()){again=false;schedule(160)}}
  };
  const schedule=(delay=130)=>{if(!active()||timer!==null)return;timer=setTimeout(()=>{timer=null;refresh()},delay)};
  let indexFirstMessage=true;
  const off=bbxOpenRestStream(`userEvents/${uid}`,(msg)=>{
    if(indexFirstMessage&&msg.path==='/'){indexFirstMessage=false;return;}
    indexFirstMessage=false;schedule(130);
  },()=>{
    if(active()){setOwnerIndexState({phase:'degraded',verified:false,error:'sse_disconnected'});schedule(1700)}
  },active,true);
  ownerIndexUnsub=()=>{if(timer!==null)clearTimeout(timer);off();};
  // Initial REST verification is mandatory even if the socket has not sent its first put.
  schedule(100);
}

async function refreshCloudListOnHome(){
  if(!isGoogleUser()||document.visibilityState==='hidden')return;
  if(ownerIndexUnsub)return;
  listenMyCloudEventIndex();
}

// V0.15: Referee links must never require a successful private-event GET
// before the judge can submit the six-digit claim. A five-character code
// reveals only the event ID; all roster, scores and permissions remain private.
let refereeJoinEventId=null;
let refereeJoinBusy=false;
function setRefereeJoinStatus(message,failed=false){
  const el=$('refereeJoinStatus');
  if(!el)return;
  el.textContent=message;
  el.dataset.state=failed?'error':'info';
}
function displayRefereeJoin(message){
  ['home','create','admin'].forEach(id=>$(id)?.classList.add('hidden'));
  $('refereeJoin')?.classList.remove('hidden');
  setRefereeJoinStatus(message);
  const button=$('refereeJoinSubmit');
  if(button)button.disabled=!refereeJoinEventId || refereeJoinBusy;
}
async function resolveRefereeInviteId(locator){
  const raw=String(locator||'');
  if(/^[A-HJ-NP-Z2-9]{5}$/.test(raw)){
    // The alias is public; private data remains unreadable until claim.
    const id=await publicCloudGet(`bbxPublicCodeLookup/${raw}`,8000);
    if(typeof id!=='string' || !/^[A-Za-z0-9_-]{6,100}$/.test(id))
      throw new Error('找不到這個活動代碼，請主辦確認裁判 QR Code');
    return id;
  }
  if(!/^[A-Za-z0-9_-]{6,100}$/.test(raw))
    throw new Error('裁判網址的賽事代碼格式錯誤');
  return raw;
}
async function bootstrapRefereeEntry(locator){
  refereeJoinEventId=null;
  displayRefereeJoin('正在確認裁判邀請連結…');
  let id;
  try{
    id=await resolveRefereeInviteId(locator);
    refereeJoinEventId=id;
  }catch(error){
    console.warn('referee invite alias resolution failed',error);
    setRefereeJoinStatus('活動代碼暫時無法核對：'+(error?.message||error)+'。請確認網路或重新整理，不會改動賽事。',true);
    return;
  }
  displayRefereeJoin('請輸入主辦提供的六位數裁判驗證碼；不需要 Google 登入。');

  // A returning signed-in referee can re-enter directly. Read only the tiny
  // per-UID authorization leaf, NEVER the entire private event before a grant.
  const current=fbAuth?.currentUser;
  if(!current)return;
  try{
    const granted=await rtdbRestGet(`refereeUsers/${id}/${current.uid}`,5000);
    if(granted){
      const result=await loadCloudEvent(id);
      if(result==='ok'){showTab('referee');return;}
      setRefereeJoinStatus('裁判身分已保留，但賽事尚未成功載入。可以重新整理再試，不必重複領取權限。',true);
      return;
    }
    // Organizer/admin already authorized may open the same invite.
    if(isGoogleUser()){
      try{
        await rtdbRestGet(`events/${id}/ownerUid`,5000);
        const result=await loadCloudEvent(id);
        if(result==='ok'){showTab('referee');return;}
      }catch(e){ /* Not yet authorized; use the normal six-digit claim form. */ }
    }
  }catch(error){
    console.warn('referee membership lookup pending',error);
    setRefereeJoinStatus('登入身分尚未能完成核對；若有驗證碼，仍可按下方按鈕加入。');
  }
}
async function claimRefereeFromLink(){
  if(refereeJoinBusy)return;
  if(!refereeJoinEventId){
    setRefereeJoinStatus('活動代碼尚未核對成功，請先重新整理裁判網址。',true);
    return;
  }
  const code=String($('refereeJoinCode')?.value||'').trim();
  if(!/^\d{6}$/.test(code)){
    setRefereeJoinStatus('請輸入主辦目前顯示的六位數裁判驗證碼。',true);
    return;
  }
  refereeJoinBusy=true;
  const button=$('refereeJoinSubmit');
  if(button){button.disabled=true;button.textContent='驗證裁判身分中…';}
  try{
    if(!(await ensureRefereeAuth())){
      setRefereeJoinStatus('Firebase 登入未完成，請確認網路後重試。',true);
      return;
    }
    const uid=fbAuth?.currentUser?.uid;
    if(!uid)throw new Error('Firebase 匿名身分尚未建立');
    const id=refereeJoinEventId;
    // This exact scoped RTDB rule checks the code and expiry on the server.
    await cloudSet(`refereeUsers/${id}/${uid}`,code,8000);
    const granted=await rtdbRestGet(`refereeUsers/${id}/${uid}`,6000);
    if(!granted)throw new Error('尚未取得裁判權限，請重試');
    const result=await loadCloudEvent(id);
    if(result==='ok'){
      $('refereeJoinCode').value='';
      showTab('referee');
      return;
    }
    // Never write/delete authority due to a post-claim read failure.
    setRefereeJoinStatus('裁判身分已驗證，但完整賽事暫時載入失敗；重新整理此連結即可重試。',true);
  }catch(error){
    console.warn('referee invited claim failed',error);
    const msg=String(error?.message||error);
    const rejected=String(error?.code||'').includes('403') || /403|permission.denied|permission denied/i.test(msg);
    setRefereeJoinStatus(rejected?'驗證碼不正確或已過期，請向主辦取得目前的六位數驗證碼。':'暫時無法完成裁判驗證：'+msg+'。請確認連線後重試。',true);
  }finally{
    refereeJoinBusy=false;
    if(button){button.disabled=!refereeJoinEventId;button.textContent='驗證並進入裁判頁';}
  }
}

async function bootstrapCloud(){
  try{return await bootstrapCloudOnce();}
  finally{
    bbxBootstrapping=false;
    bbxLifecycleNote('bootstrap','finished');
    if(bbxCanRunOwnerIndex())listenMyCloudEventIndex();
  }
}
async function bootstrapCloudOnce(){
  migrateLegacyTestEvents();
  cleanupLegacyCloudLocalData();

  draftMode=null;
  draftStorage=null;

  const params=new URLSearchParams(location.search);
  await initCloud();

  let saved=readActiveView();
  const rememberedCloudView=readCloudViewPointer(false);
  const urlEvent=params.get('event');

  // 主辦把 Safari / Web App 視窗關掉再開時，Firebase Auth 在 iOS
  // 可能比網頁啟動慢。若這支手機有「剛剛正在看這場」的紀錄，
  // 最多等 5 秒讓 Google 登入身分恢復，再去讀 Firebase。
  const reopeningActiveEvent=!!(
    (saved?.eventId && (!urlEvent || saved.eventId===urlEvent)) ||
    !!rememberedCloudView?.eventId ||
    // A five-character organizer/referee link does not equal the saved long ID.
    !!urlEvent
  );

  if(fbAuth && !fbAuth.currentUser && reopeningActiveEvent){
    await waitForAuthRestore(5000);
  }else if(fbAuth && !fbAuth.currentUser){
    // 普通首頁 / 公開觀眾不要被登入恢復拖慢。
    await waitForAuthRestore(700);
  }

  fbUser=fbAuth?.currentUser||fbUser;
  renderHeaderAuth();
  // Firebase Auth can finish AFTER the first readActiveView() call on iOS.
  // Recheck only the owner-bound locator, not any cached event contents.
  saved=saved||readCloudViewPointer(true);

  if(urlEvent && params.get('ref')==='1'){
    // Referee must claim a scoped identity before any private board read.
    // This also works when the public viewer has been closed or expired.
    await bootstrapRefereeEntry(urlEvent);
    return;
  }

  if(urlEvent){
    const result=await loadCloudEvent(urlEvent);

    if(result==='missing'){
      // Keep the URL's immutable event/code locator; failure to resolve on
      // this request is not an organizer deletion instruction.
      alert('暫時找不到此賽事，網址已保留。請確認登入和網路狀態後重新整理。');
    }else if(result==='expired'){
      alert('目前無法確認這場賽事的存取權限或公開期限；網址已保留，請先確認登入狀態。');
    }else if(result==='error'){
      if(saved?.eventId===urlEvent){
        alert('主辦登入狀態尚未成功恢復，暫時無法讀取這場賽事。\n\n請先確認右上角仍顯示「已登入」，再按重新整理；系統會保留這場賽事，不會刪除。');
      }else{
        alert('目前暫時無法從 Firebase 載入這場賽事，請稍後再試。');
      }
    }
    return;
  }

  if(saved?.eventId){
    const wanted=saved.tab||'bracket';

    if(saved.testOnly){
      if(restoreCachedEventImmediately(saved.eventId,wanted))return;
    }else if(isGoogleUser()){
      // A UID-bound local pointer may survive an iOS tab eviction. It contains
      // no scores/roster and must re-fetch the authoritative event from RTDB.
      const result=await loadCloudEvent(saved.eventId);
      if(result==='ok')return;
      console.warn('session cloud event restore skipped',result);
    }
  }

  renderHomeSelections();

  if(isGoogleUser()){
    listenMyCloudEventIndex();
  }else{
    stopMyCloudEventIndexListener();
  }

  renderSavedEvents();
}


/* V0.14: one viewport-to-document coordinate transform for every interactive
 * overlay, independent of browser or OS. No UA branching, CSS override stack,
 * fixed-position offset adjustments or repeated delayed positioning patches.
 * All popups are direct <body> children and share these root CSS variables.
 */
function bbxOverlayViewportGeometry(vv=window.visualViewport,scrollX=window.scrollX,scrollY=window.scrollY,innerWidth=window.innerWidth,innerHeight=window.innerHeight){
  const safe=(value,fallback)=>Number.isFinite(value)?value:fallback;
  return {
    top:Math.max(0,safe(vv?.pageTop,scrollY+safe(vv?.offsetTop,0))),
    left:Math.max(0,safe(vv?.pageLeft,scrollX+safe(vv?.offsetLeft,0))),
    width:Math.max(1,safe(vv?.width,innerWidth)),
    height:Math.max(1,safe(vv?.height,innerHeight))
  };
}
function syncAppVisualViewport(){
  const g=bbxOverlayViewportGeometry();
  const r=document.documentElement.style;
  r.setProperty('--bbx-overlay-top',`${g.top}px`);
  r.setProperty('--bbx-overlay-left',`${g.left}px`);
  r.setProperty('--bbx-overlay-width',`${g.width}px`);
  r.setProperty('--bbx-overlay-height',`${g.height}px`);
}
let bbxViewportSyncPending=false;
function queueAppVisualViewportSync(){
  if(bbxViewportSyncPending)return;
  bbxViewportSyncPending=true;
  requestAnimationFrame(()=>{
    bbxViewportSyncPending=false;
    syncAppVisualViewport();
  });
}
syncAppVisualViewport();
if(window.visualViewport){
  window.visualViewport.addEventListener('scroll',queueAppVisualViewportSync,{passive:true});
  window.visualViewport.addEventListener('resize',queueAppVisualViewportSync,{passive:true});
}
window.addEventListener('scroll',queueAppVisualViewportSync,{passive:true});
window.addEventListener('resize',queueAppVisualViewportSync,{passive:true});
window.addEventListener('orientationchange',queueAppVisualViewportSync,{passive:true});
window.addEventListener('pageshow',syncAppVisualViewport,{passive:true});
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='visible')syncAppVisualViewport();
},{passive:true});

bootstrapCloud();
