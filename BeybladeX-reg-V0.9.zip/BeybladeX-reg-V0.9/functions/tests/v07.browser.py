"""Local mocked-browser regression. Network never reaches Firebase/Google."""
import ast,re
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_support import html_assets,browser_options
ROOT=Path(__file__).resolve().parents[2]
tree=ast.parse((Path(__file__).with_name('frontend.offline.py')).read_text())
SEED=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SEED' for t in n.targets))
EXTRA=r'''window.__version='V0.10';window.__versionCalls=0;window.__post=null;
const originalFetch=window.fetch;
window.fetch=async(input,opt={})=>{if(String(input)==='/version.json'){window.__versionCalls++;return new Response(JSON.stringify({version:window.__version}),{status:200})}if(opt.method==='POST')window.__post=JSON.parse(opt.body);return originalFetch(input,opt)};
Object.defineProperty(navigator,'standalone',{value:true,configurable:true});'''
def html(name):
 s=html_assets(ROOT/'reg',name)
 return re.sub(r'^import .*?;\s*','',s,flags=re.M).replace('<script type="module">','<script>')
with sync_playwright() as pw:
 browser=pw.chromium.launch(**browser_options())
 for width in [320,390,430]:
  context=browser.new_context(viewport={'width':width,'height':760},is_mobile=True,has_touch=True)
  context.add_init_script(SEED+'\n'+EXTRA)
  context.route('**/*',lambda route:route.fulfill(content_type='text/html',body=html('signup.html' if '/s/' in route.request.url else 'status.html' if '/q/' in route.request.url else 'index.html')))
  p=context.new_page();p.goto('https://mock.local/#manage=ABCDE');p.wait_for_selector('[data-review]')
  for height in [760,480,640]:
   p.set_viewport_size({'width':width,'height':height})
   p.locator('[data-review]').first.click();p.wait_for_selector('#modalContent [data-to]')
   for b in p.locator('#modalContent button').all():
    b.scroll_into_view_if_needed();box=b.bounding_box();assert box['height']>=44,box
    assert box['y']>=-1 and box['y']+box['height']<=height+1,(width,height,box)
    assert b.evaluate('(b)=>{const r=b.getBoundingClientRect();return b.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
   p.locator('#close').click();assert p.evaluate("document.body.style.position!=='fixed'")
  assert p.locator('.versionIndex').inner_text()=='V0.9 測試版'
  p.evaluate("__version='V0.10';versionLast=0;checkVersion()")
  p.wait_for_selector('#versionUpdate');assert 'V0.10' in p.locator('#versionUpdate').inner_text()
  p.evaluate('BBX.beginWrite()');assert p.locator('#versionUpdate button').is_disabled()
  p.evaluate('BBX.endWrite()');assert p.locator('#versionUpdate button').is_enabled()
  p.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,value:'hidden'});document.dispatchEvent(new Event('visibilitychange'));versionLast=0")
  old=p.evaluate('__versionCalls');p.evaluate('BBX.checkVersion()');assert p.evaluate('__versionCalls')==old
  p.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,value:'visible'});document.dispatchEvent(new Event('visibilitychange'))")
  p.locator('#openSignup').click();p.wait_for_url('**/s/ABCDE?from=organizer');p.wait_for_selector('#returnOrganizer')
  assert p.locator('#returnOrganizer').get_attribute('href')=='/#manage=ABCDE'
  assert 'from=organizer' in p.locator('#statusLink').get_attribute('href')
  p.locator('#playerName').fill('測試暫存');p.locator('#phone3').fill('123');p.locator('#lineName').fill('暫存LINE')
  p.reload();p.wait_for_selector('#playerName');assert p.locator('#playerName').input_value()=='測試暫存'
  dialogs=[]
  p.on('dialog',lambda d:(dialogs.append(d.message),d.dismiss()));assert p.locator('#returnOrganizer').inner_text()=='返回';p.locator('#returnOrganizer').click();p.wait_for_url('**/#manage=ABCDE');p.wait_for_selector('#openStatus')
  p.locator('#openStatus').click();p.wait_for_url('**/q/ABCDE?from=organizer');p.wait_for_selector('#returnOrganizer');p.locator('#returnOrganizer').click();p.wait_for_url('**/#manage=ABCDE')
  assert dialogs==[],dialogs
  p.goto('https://mock.local/s/ABCDE');p.wait_for_selector('#playerName');assert p.locator('#returnOrganizer').count()==0
  p.locator('#playerName').fill('選手');p.locator('#phone3').fill('123');p.locator('#lineName').fill('LINE');p.locator('#submit').click();p.wait_for_function('window.__post!==null');assert p.evaluate('__post.data.clientVersion')=='V0.7'
  print(f'PASS V07 Chromium {width}px: modal hit targets at 3 viewport heights; version update/writes/hidden; PWA same-event return for both pages; public link unchanged; draft survives reload; client version sent')
  context.close()
 browser.close()
