const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const js=fs.readFileSync(path.join(root,'assets/index-v038.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const viewer=fs.readFileSync(path.join(root,'assets/viewer-v038.js'),'utf8');
const stream=js.slice(js.indexOf('function listenCloudEvent(id){'),js.indexOf('async function waitForAuthRestore('));
const part=(a,b)=>js.slice(js.indexOf(a),js.indexOf(b,js.indexOf(a)+a.length));

test('RTDB Database SDK has no bootstrap script or transport, Auth and callable remain',()=>{
 assert.ok(!html.includes('firebase-database-compat.js'));
 for(const pattern of [/firebase\.database\s*\(/,/\bfbDb\b/,/\.info\/connected/,/forceLongPolling\s*\(/,/forceWebSockets\s*\(/])assert.doesNotMatch(js,pattern);
 assert.match(html,/firebase-auth-compat\.js/);assert.match(html,/firebase-functions-compat\.js/);
 assert.match(js,/httpsCallable\(authorityFnName\('CommandAuthority'\)\)/);
});
test('privileged subscription begins SSE immediately; two protected paths',()=>{
 assert.match(stream,/startPrivateSse\('primary'\)/);
 assert.match(stream,/publishedMatchHints/);assert.match(stream,/refereeClaims\/\$\{id\}/);
 assert.doesNotMatch(stream,/\.ref\s*\(/);
});
test('SSE is not trusted on HTTP open alone; both streams need initial data',()=>{
 assert.match(stream,/sseOpen\.hints&&sseOpen\.claims&&sseInitialized\.hints&&sseInitialized\.claims/);
 assert.match(stream,/refreshSseClaims\(\)/);
 assert.match(stream,/sseHintReceipt\(payload\.data\)/);
});
test('SSE failure stops sensitive writes and bounded reconnect',()=>{
 assert.match(stream,/unsafe\('私人即時通知中斷/);
 assert.match(stream,/Math\.min\(16000,750\*2/);
 assert.match(stream,/cloudResyncBlocked=true/);
});
test('SSE scores use version-specific single-match GET and never poll whole event',()=>{
 assert.match(stream,/receiptMatches\(privateMatch\(p\),h\)/);
 assert.match(stream,/rtdbRestGet\(`events\/\$\{id\}\/\$\{p\}`/);
 assert.match(stream,/setInterval\(watchdog,12000\)/);
});
test('organizer index is SSE and REST, not an RTDB SDK listener',()=>{
 assert.match(js,/bbxOpenRestStream\(`userEvents\/\$\{uid\}`/);
 assert.match(js,/rtdbRestGet\(`userEvents\/\$\{uid\}`/);
 assert.match(js,/function stopMyCloudEventIndexListener\(\)/);
});
test('claim, release, completion, RR and older score paths patch bracket',()=>{
 for(const fn of ['claimMatchAs','claimRRMatchAs','releaseMatchAny','releaseRRMatchAny']){
  const start=js.indexOf('async function '+fn+'(');
  assert.ok(start>=0,fn);
  assert.match(js.slice(start,start+3000),/renderAdmin\(\{bracketOnly:true\}\)/,fn);
 }
 const finish=part('async function v1FinishCloud','async function v1CloudOrganizerCommand');
 assert.match(finish,/backToBracketFromMatch\(\)/);assert.match(finish,/backgroundRefreshCurrentEvent/);
 const refresh=part('async function backgroundRefreshCurrentEvent','function stopMyCloudEventIndexListener');
 assert.match(refresh,/renderAdmin\(\{bracketOnly:true\}\)/);
});
test('RR DOM updates are row-granular; unrelated nodes and viewport remain',()=>{
 const patch=part('function patchPrivateBracket(){','function bracketDefaultScale(){');
 assert.match(patch,/patchRows\('\.rrMini'\)/);
 assert.match(patch,/patchRows\('\.rrRankRow'\)/);
 assert.match(patch,/a\[i\]\.outerHTML=b\[i\]\.outerHTML/);
 assert.doesNotMatch(patch,/original\.remove\(\);[\s\S]*canvas\.insertAdjacentHTML\('beforeend',rr\)/);
});
test('backend and public viewer remain byte-identical to validated V0.36 baselines',()=>{
 const crypto=require('node:crypto');const hash=fn=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,fn))).digest('hex');
 const expected={
  'functions/bbx-v011-cleanup.js':'888397ccf9aa05278b2fbfae001a33b9c2c5ffa8a5b0015ed001d0e1b4569124',
  'functions/bbx-v011-core.js':'747d0c4472c43077dedb53f86348ecd238112c216be64ab7dd6cf394a9e4b17b',
  'functions/bbx-v011-lifecycle.js':'b2a47ad3f7253654272a5f728434f6f332d569fa450e7d892830482978a585e9',
  'functions/bbx-v011-publication.js':'459bcc7d8b8c69fc63724f0cca99095d0f9ee83253dc778752b6812376664d31',
  'functions/index.js':'84547503791c45400ff75ac653d3d1cd6aaeca5bea4831d028bd5ddf100aaf1c',
  'functions/package.json':'93a45fb35f3b0adca23f323d827072350265eb217e776fab0c7f301f744a940d',
  'database.rules.json':'ead2bd91a9eb35816140cb4565e428a55c4ad2c1ed20b2502f718527a351ef06',
  'firebase.json':'3688733ad2023a832b1ae9375e4b8b8ebbf57afca21eaca0599adf9ad7f44404',
  'firebase.hosting.json':'162dbd677cfcefcda44dea5aee817bd71e37b818dc081f05603c1bee20fb9c04'
 };
 for(const [f,h] of Object.entries(expected))assert.equal(hash(f),h,f);
 assert.equal(crypto.createHash('sha256').update(viewer.replaceAll('BBX-V0.38','BBX-V0.36')).digest('hex'),'6d00521dcf9e8e9870186fa8140c4e57501a1c90b17443459a7b192ac41bb24a');
});
