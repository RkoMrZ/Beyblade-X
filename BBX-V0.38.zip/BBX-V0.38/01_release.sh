#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.38 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: V0.38 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.38 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v038.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v038-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight mismatch';exit 3; }
bash deploy/functions-v038.sh
bash deploy/hosting-v038.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.38 OrganizerAuthority + Hosting deployed; Rules, scoring functions and existing events untouched.\n'
