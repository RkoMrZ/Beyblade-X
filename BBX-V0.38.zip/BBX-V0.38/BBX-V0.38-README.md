# BBX-V0.38 — 裁判名單完成賽事後可修改／精簡 SSE 請求稽核

修改基準：已測試 BBX-V0.37。只更新主辦雲端命令（OrganizerAuthority 及其 reducer）與 Hosting，不觸碰比分／晉級 Functions、Rules、歷史資料與獨立報名系統。

1. `setReferees` 將「是否曾經計分」與「是否仍有有效執裁鎖」分開：完成的賽事不再阻止改名或移除已釋放裁判；正在執裁、或未完成且仍持有 claimUid 的場次繼續禁止。雲端仍要求所有裁判身分領取已釋放，保護索引一致性。
2. 只更動 `refereeNames`/`refereeCount` 的雲端權威資料。完成的比分、勝負、裁判歷史、matchVersion、晉級、三人循環及公共資料不重建。
3. 主辦名字沒有變化時不發出 Function，雲端主辦操作已完成權威刷新就不再額外重繪；SSE 同時收到多筆發布提示時合併 `syncVersion` 讀取。
4. 刪除舊版 README 重複文件及三個已無呼叫的舊前端函式。保留清理登記表、歷史 Rules 測試素材、裁判鎖及 12 秒輕量保底核對。
5. 部署改正 V0.36 發現的 Functions 依賴安裝問題：必須先通過 Node/Emulator 測試，再 `npm install --prefix functions --omit=dev`，驗證 firebase-functions 存在才部署單一 callable 與 Hosting。

請注意：Chromium/Node 本地測試不等於 Safari/Chrome 現場多人驗收；本版維持 V0.x 測試狀態。
