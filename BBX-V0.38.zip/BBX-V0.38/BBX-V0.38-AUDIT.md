# V0.38 全檔稽核與去重記錄

## 檢查範圍
- 前端：`assets/index-v038.js`、`assets/viewer-v038.js`、對應 HTML/CSS。
- 雲端：全部 `functions/*.js`、Functions 套件宣告、Database Rules、跨版本清理資料。
- 發布：Node／Chromium／Emulator 測試與含內容指紋的 Hosting 資產。

## 找到並修正
1. 雲端 `anyStarted()` 把已完成比分/勝負當作目前執裁：拆出 `anyActiveReferee()` 專供裁判名單；原 `anyStarted()` 仍保護重建籤表。
2. 儲存未變的裁判名稱仍送出 Function 並補讀賽事：加入本機無變更即返回。
3. 雲端命令成功時，`v1CloudOrganizerCommand()` 已做 REST 刷新／必要重繪，外層 `v1OrganizerAction()` 重複呼叫 render：移除第二次渲染。
4. SSE 一串分數發布可能每筆都立即觸發 `syncVersion` REST GET：改成 200ms 合併與同時間只有一筆 in-flight，仍保留版本變更的結構補讀和失敗保護。
5. 移除前端無呼叫 stub `backfillMyCloudEventIndex`、`queueWholeEventCloud` 與舊隱藏欄位用 `setRefereeCount`。共移除 18 份舊版重複 README；舊 ZIP 不動。

## 有意保留，不可當成冗餘
- `events/{id}` 首次與重大結構變更時的權威全量讀取：確保資料完整，避免舊回覆覆寫新畫面。
- 個別場次 REST 版本修補：只有 SSE 提示不同時才讀取。
- 每 12 秒一筆 `publishedSeq` 小型水位保底：處理 iPhone/WebView SSE 無聲停止，並非整場輪詢。
- `refereeClaims/{id}` 專用私人 SSE／必要 REST 核對：裁判領取不等於場次比分，不能合併成公開資料。
- 目前未執裁但仍有人領取裁判身份時的雲端攔截：重排索引會破壞已領取身份。
- 保留歷史版本清理登記、規則測試素材、Firebase Auth、Functions、雲端交易鎖和版本檢查。

## 限制
未連接 Firebase 正式資料庫進行壓力測試；程式靜態呼叫檢查不能證明所有環境都不會重複請求。手機實機延遲、成本與 60 人並行仍待驗收。
