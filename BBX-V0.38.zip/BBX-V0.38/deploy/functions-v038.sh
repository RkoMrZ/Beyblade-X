#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.38 ]] || { echo 'STOP: wrong version';exit 2; }
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: wrong project';exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v038-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight not complete';exit 3; }
# V0.36 deployment failed when the Functions dependencies had not been installed.
npm install --prefix functions --omit=dev --no-audit --no-fund
node -e "require('./functions/node_modules/firebase-functions/v2/https'); require('./functions/node_modules/firebase-admin');console.log('PASS: Cloud Functions dependencies installed')"
# Update one callable only: not scoring, cleanup, publication, Rules, or stored data.
firebase deploy --only functions:bbxV011OrganizerAuthority --config firebase.json --project ljt-beyblade-x --non-interactive
printf 'PASS: only bbxV011OrganizerAuthority deployed\n'
