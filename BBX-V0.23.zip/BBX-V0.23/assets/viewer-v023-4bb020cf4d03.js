const DB='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const params=new URLSearchParams(location.search);
const pathCode=location.pathname.match(/^\/v\/([A-HJ-NP-Z2-9]{5})(?:\/)?$/)?.[1]||'';
const eventId=params.get('event')||pathCode;
let data=null, stream=null, renderTimer=null, scale=1, gotFirst=false, failureCheckBusy=false;
let streamKind='',streamId='',streamGeneration=0,streamOpenedOnce=false;
let reconnectResyncTimer=null,resyncPromise=null,lastResyncAt=0;
let reconnectCount=0,lastStreamOpenAt=0;
let receivedEventSerial=0;
let lastSseUpdateAt=Date.now();
let viewerSeqCheckInFlight=false;
// No snapshot polling: one tiny monotonic counter is checked infrequently to
// detect a stuck WebView EventSource which never emits onerror.
async function verifyViewerStreamHealth(){
  if(document.visibilityState==='hidden'||!streamKind||!streamId||!gotFirst||viewerSeqCheckInFlight)return;
  if(Date.now()-lastSseUpdateAt<12000)return;
  viewerSeqCheckInFlight=true;
  const kind=streamKind,id=streamId,generation=streamGeneration;
  try{
    const r=await fetch(`${DB}/${kind}/${encodeURIComponent(id)}/meta/authoritySeq.json`,{cache:'no-store'});
    if(!r.ok||generation!==streamGeneration)return;
    const seq=Number(await r.json())||0;
    if(generation!==streamGeneration)return;
    const localSeq=Number(data?.meta?.authoritySeq)||0;
    if(seq>localSeq){
      setStatus('偵測到漏訊，正在校正最新比分…');
      scheduleReconnectResync(kind,id,'viewer-missed-sequence');
    }
  }catch(error){console.warn('viewer stream watchdog deferred',error)}
  finally{viewerSeqCheckInFlight=false;}
}
setInterval(verifyViewerStreamHealth,30000);

function goBack(){
  try{stream?.close()}catch{}
  stream=null;
  streamGeneration++;
  clearTimeout(reconnectResyncTimer);

  // viewer 是純觀看頁，返回一律完整載入管理首頁，
  // 不依賴 iOS Safari 的 bfcache。
  location.replace('index.html');
}
function setStatus(text,kind=''){
  const el=$('status'); el.textContent=text; el.className='status'+(kind?' '+kind:'');
}
function pathParts(path){return String(path||'/').split('/').filter(Boolean)}
function setAtPath(root,path,value){
  const parts=pathParts(path);
  if(!parts.length)return value;
  if(root==null||typeof root!=='object')root={};
  let cur=root;
  for(let i=0;i<parts.length-1;i++){
    const k=parts[i];
    if(cur[k]==null||typeof cur[k]!=='object')cur[k]={};
    cur=cur[k];
  }
  const key=parts[parts.length-1];
  if(value===null){
    if(Array.isArray(cur) && /^\d+$/.test(key))cur[Number(key)]=null;
    else delete cur[key];
  }else cur[key]=value;
  return root;
}
function patchAtPath(root,path,patch){
  if(patch==null)return setAtPath(root,path,null);
  if(typeof patch!=='object'||Array.isArray(patch))return setAtPath(root,path,patch);
  for(const [k,v] of Object.entries(patch)){
    const p=(path==='/'?'':path.replace(/\/$/,''))+'/'+k;
    root=setAtPath(root,p,v);
  }
  return root;
}
function applyServerEvent(type,payload){
  receivedEventSerial++;
  lastSseUpdateAt=Date.now();
  if(!payload||typeof payload.path!=='string')return;
  // A single null root event during a flaky reconnection is not an
  // authenticated deletion receipt. Keep the last published tournament.
  if(payload.path==='/'&&payload.data===null&&data){
    setStatus('公開賽程暫時無法確認，保留上次畫面…');
    scheduleReconnectResync(streamKind,streamId,'null-sse-root');
    return;
  }
  if(type==='put')data=setAtPath(data,payload.path,payload.data);
  else data=patchAtPath(data,payload.path,payload.data);
  gotFirst=true;
  scheduleRender();
}
function scheduleRender(){
  if(renderTimer)return;
  renderTimer=setTimeout(()=>{renderTimer=null;render()},90);
}
function streamUrl(kind,id){
  return `${DB}/${kind}/${encodeURIComponent(id)}.json`;
}

function publicReadErrorText(){
  return '公開連結已關閉或過期。';
}

async function fetchFreshSnapshot(kind,id,{quiet=false}={}){
  const generation=streamGeneration;
  const requestSerial=receivedEventSerial;

  try{
    const r=await fetch(streamUrl(kind,id),{
      cache:'no-store',
      headers:{'Accept':'application/json'}
    });

    if(generation!==streamGeneration)return false;

    if(r.status===401||r.status===403){
      setStatus(publicReadErrorText(),'error');
      try{stream?.close()}catch{}
      return false;
    }

    if(!r.ok){
      if(!quiet)setStatus('目前無法重新同步資料，正在保留即時連線…');
      return false;
    }

    const fresh=await r.json();
    if(generation!==streamGeneration)return false;
    // 若 GET 期間已收到更新的 SSE 事件，不能用較早快照蓋掉它。
    if(receivedEventSerial!==requestSerial)return false;

    if(!fresh){
      setStatus('找不到資料。','error');
      return false;
    }

    // SSE 斷線後，以 Firebase 最新完整快照校正本機狀態。
    // 快照寫入後，後續 SSE patch 會繼續套用在這份最新資料上。
    data=fresh;
    gotFirst=true;
    lastResyncAt=Date.now();
    scheduleRender();
    setStatus('已重新同步・即時連線中','ok');
    return true;
  }catch(e){
    if(generation!==streamGeneration)return false;
    if(!quiet)setStatus('重新同步暫時失敗，正在等待連線恢復…');
    return false;
  }
}

function scheduleReconnectResync(kind,id,reason='reconnect'){
  clearTimeout(reconnectResyncTimer);

  // 多台手機同時恢復連線時加入少量 jitter，
  // 避免 200+ viewer 在同一毫秒全部 GET Firebase。
  const jitter=250+Math.floor(Math.random()*1250);

  reconnectResyncTimer=setTimeout(()=>{
    reconnectResyncTimer=null;

    if(resyncPromise)return;

    resyncPromise=fetchFreshSnapshot(kind,id,{quiet:false})
      .finally(()=>{resyncPromise=null});
  },jitter);
}

function hardReconnect(reason='manual'){
  if(!streamKind||!streamId)return;

  const kind=streamKind,id=streamId;
  try{stream?.close()}catch{}
  stream=null;

  setStatus('正在重新建立即時連線…');
  startStream(kind,id,{isRestart:true,reason});
}

function startStream(kind,id,{isRestart=false,reason='initial'}={}){
  streamKind=kind;
  streamId=id;
  streamGeneration++;
  const generation=streamGeneration;

  clearTimeout(reconnectResyncTimer);
  try{stream?.close()}catch{}
  stream=null;

  if(!isRestart){
    gotFirst=false;
    streamOpenedOnce=false;
    reconnectCount=0;
    setStatus('正在連線即時資料…');
  }

  const es=new EventSource(streamUrl(kind,id));
  stream=es;

  es.addEventListener('open',()=>{
    if(generation!==streamGeneration || stream!==es)return;

    lastStreamOpenAt=Date.now();

    if(streamOpenedOnce || isRestart){
      reconnectCount++;
      setStatus('連線已恢復，正在校正最新資料…');
      // 新 SSE 連線會自行送出初始 put 快照。只有逾時未收到快照才 GET。
      const serialOnOpen=receivedEventSerial;
      reconnectResyncTimer=setTimeout(()=>{
        reconnectResyncTimer=null;
        if(generation!==streamGeneration||stream!==es)return;
        if(receivedEventSerial===serialOnOpen) scheduleReconnectResync(kind,id,'missing-resume-snapshot');
      },4000+Math.floor(Math.random()*2000));
    }else{
      streamOpenedOnce=true;
      setStatus('即時連線已建立，正在載入資料…');
    }
  });

  es.addEventListener('put',e=>{
    if(generation!==streamGeneration || stream!==es)return;
    try{
      applyServerEvent('put',JSON.parse(e.data));
      setStatus('即時同步中','ok');
    }catch(err){
      console.error(err);
      scheduleReconnectResync(kind,id,'bad-put');
    }
  });

  es.addEventListener('patch',e=>{
    if(generation!==streamGeneration || stream!==es)return;
    try{
      applyServerEvent('patch',JSON.parse(e.data));
      setStatus('即時同步中','ok');
    }catch(err){
      console.error(err);
      scheduleReconnectResync(kind,id,'bad-patch');
    }
  });

  es.addEventListener('cancel',()=>{
    if(generation!==streamGeneration || stream!==es)return;
    setStatus(publicReadErrorText(),'error');
    try{es.close()}catch{}
  });

  es.addEventListener('auth_revoked',()=>{
    if(generation!==streamGeneration || stream!==es)return;
    setStatus('公開讀取權限已失效。','error');
    try{es.close()}catch{}
  });

  es.onerror=()=>{
    if(generation!==streamGeneration || stream!==es)return;

    if(gotFirst){
      setStatus('連線中斷，Firebase 正在自動重連…');
      // EventSource 本身會自動重連。
      // 真正重新 open 時，再做完整 GET 校正，避免漏掉背景期間的更新。
      return;
    }

    checkFailure(kind,id);
  };
}

async function checkFailure(kind,id){
  if(failureCheckBusy)return;
  failureCheckBusy=true;
  const generation=streamGeneration, serial=receivedEventSerial;
  const current=()=>generation===streamGeneration && kind===streamKind && id===streamId && document.visibilityState!=='hidden';
  try{
    const r=await fetch(streamUrl(kind,id),{
      cache:'no-store',
      headers:{'Accept':'application/json'}
    });

    if(!current()||receivedEventSerial!==serial)return;
    if(r.status===401||r.status===403){
      setStatus(publicReadErrorText(),'error');
      try{stream?.close()}catch{}
    }else if(r.ok){
      const j=await r.json();
      if(!current()||receivedEventSerial!==serial)return;
      if(j){
        data=j;
        gotFirst=true;
        lastResyncAt=Date.now();
        scheduleRender();
        setStatus('已重新同步・即時連線中','ok');
      }else{
        setStatus('找不到資料。','error');
      }
    }else{
      setStatus('目前無法讀取資料，請稍後重試。','error');
    }
  }catch(e){
    if(!current()||receivedEventSerial!==serial)return;
    setStatus('網路連線異常，Firebase 正在自動重連…');
  }finally{
    failureCheckBusy=false;
  }
}

// iOS Safari / Web App 從背景回前景時，SSE 有可能看似存在但其實已停住。
// 回前景直接「重建 SSE + GET 最新快照」，不相信舊連線狀態。
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='hidden'){
    // 背景觀看不維持 RTDB 連線；返回前景再同步最新快照。
    clearTimeout(reconnectResyncTimer);
    try{stream?.close()}catch(e){}
    stream=null;streamGeneration++;
  } else if(streamKind&&streamId) hardReconnect('visibility');
});

window.addEventListener('pageshow',e=>{
  if(e.persisted && streamKind && streamId){
    hardReconnect('bfcache');
  }
});

window.addEventListener('online',()=>{
  if(streamKind && streamId){
    hardReconnect('online');
  }
});

// BBX-V0.11: SSE 長連線即時接收變更，不做固定完整快照輪詢；
// 只有斷線重連 / 回前景時，才依需要重新同步。

function eventCount(){
  const m=data?.meta||{};
  if(Array.isArray(m.roster))return m.roster.length;
  const rs=rounds();
  return Number(m.rosterCount)||((rs[0]?.matches?.length||0)*2);
}
function rounds(){
  const r=data?.rounds;
  if(Array.isArray(r))return r.filter(Boolean);
  if(r&&typeof r==='object')return Object.keys(r).sort((a,b)=>Number(a)-Number(b)).map(k=>r[k]).filter(Boolean);
  return [];
}
function matchesOf(r){
  if(Array.isArray(r?.matches))return r.matches.filter(Boolean);
  const m=r?.matches;
  if(m&&typeof m==='object')return Object.keys(m).sort((a,b)=>Number(a)-Number(b)).map(k=>m[k]).filter(Boolean);
  return [];
}
function usesRR(){return data?.meta?.freeFinal==='rr3'}
function flowLabel(){
  const n=eventCount();
  if(!usesRR())return '兩兩淘汰至冠軍＋季軍賽';
  if(n<=3)return `${n} → 3・最後三人循環`;
  const steps=[n];let cur=n;
  while(cur>6){cur=Math.ceil(cur/2);steps.push(cur)}
  if(steps[steps.length-1]!==3)steps.push(3);
  return `${steps.join(' → ')}・最後三人循環`;
}
function stageLabel(ri,r){
  if(r?.placementFinal===true)return '冠軍 / 季軍賽';
  if(usesRR()){
    if(ri===0)return `第一輪（${eventCount()}強）`;
    return `${matchesOf(r).length*2}強`;
  }
  return r?.name||`第 ${ri+1} 輪`;
}
function matchHtml(m,ri,mi,r){
  const a=m?.a??'待定',b=m?.b??'待定';
  const pa=a==='待定',pb=b==='待定';
  const sa=pa?'':(m?.sa===''||m?.sa==null?'–':m.sa);
  const sb=pb?'':(m?.sb===''||m?.sb==null?'–':m.sb);
  const title=r?.placementFinal===true?(mi===0?'🏆 冠軍賽':'🥉 季軍賽'):`第 ${mi+1} 場`;
  return `<div class="bracketMatch ${m?.winner?'done':''}" data-ri="${ri}" data-mi="${mi}">
    <div class="matchNo">${title}</div>
    <div class="bSide ${pa?'pending':''} ${m?.winner===a?'winner':''}">
      <span class="bName">${m?.winner===a?'<span class="winnerDot">●</span>':''}<span class="playerLabel">${esc(a)}</span></span><span class="bScore">${esc(sa)}</span>
    </div>
    <div class="bSide ${pb?'pending':''} ${m?.winner===b?'winner':''}">
      <span class="bName">${m?.winner===b?'<span class="winnerDot">●</span>':''}<span class="playerLabel">${esc(b)}</span></span><span class="bScore">${esc(sb)}</span>
    </div>
  </div>`;
}
function rrHtml(){
  const f=data?.finalRR;if(!f)return '';
  const players=Array.isArray(f.players)?f.players:Object.values(f.players||{});
  const games=Array.isArray(f.matches)?f.matches.filter(Boolean):Object.values(f.matches||{}).filter(Boolean);
  const stat={};players.forEach(p=>stat[p]={w:0,l:0,pf:0,pa:0});
  games.forEach(m=>{
    if(!stat[m.a])stat[m.a]={w:0,l:0,pf:0,pa:0};
    if(!stat[m.b])stat[m.b]={w:0,l:0,pf:0,pa:0};
    const hasA=m.sa!==''&&m.sa!=null,hasB=m.sb!==''&&m.sb!=null;
    if(hasA&&hasB){
      const a=Number(m.sa)||0,b=Number(m.sb)||0;
      stat[m.a].pf+=a;stat[m.a].pa+=b;stat[m.b].pf+=b;stat[m.b].pa+=a;
      if(a>b){stat[m.a].w++;stat[m.b].l++}else if(b>a){stat[m.b].w++;stat[m.a].l++}
    }
  });
  const ranked=[...players].sort((a,b)=>{
    const sa=stat[a],sb=stat[b];if(sb.w!==sa.w)return sb.w-sa.w;
    const da=sa.pf-sa.pa,db=sb.pf-sb.pa;if(db!==da)return db-da;return sb.pf-sa.pf;
  });
  return `<section class="rrPanel">
    <div class="rrHead"><b>👑 最後三人循環</b><div class="muted">決定最終名次</div></div>
    <div class="rrRanks">${ranked.map((p,i)=>`<div class="rrRankRow"><span class="rrPos">${i+1}</span><b>${esc(p)}</b><span>${stat[p].w}-${stat[p].l}</span></div>`).join('')}</div>
    <div class="rrGames">${games.map(m=>`<div class="rrMini"><b>${esc(m.a)} vs ${esc(m.b)}</b><span>${m.sa===''?'–':esc(m.sa)} : ${m.sb===''?'–':esc(m.sb)}</span></div>`).join('')}</div>
    <div class="rrStatBox"><div class="rrStatTitle">📊 循環賽得失分</div>${ranked.map(p=>{const s=stat[p],d=s.pf-s.pa;return `<div class="rrStatRow"><b>${esc(p)}</b><span>得 ${s.pf}</span><span>失 ${s.pa}</span><span>淨 ${d>0?'+':''}${d}</span></div>`}).join('')}</div>
  </section>`;
}
function finalHtml(rs){
  const fr=rs.find(r=>r?.placementFinal===true),ms=matchesOf(fr);
  if(!fr||ms.length<2)return '';
  const champ=ms[0],bronze=ms[1];
  const loser=m=>!m?.winner?'':m.winner===m.a?m.b:m.winner===m.b?m.a:'';
  const rows=[
    ['🥇','第一名',champ?.winner||'待定'],['🥈','第二名',loser(champ)||'待定'],
    ['🥉','第三名',bronze?.winner||'待定'],['4️⃣','第四名',loser(bronze)||'待定']
  ];
  return `<section class="rrPanel finalPlacings"><div class="rrHead"><b>🏆 最終名次</b><div class="muted">冠軍賽＋季軍賽完成後自動產生 1～4 名</div></div>
  <div class="rrRanks">${rows.map(([i,l,n])=>`<div class="rrRankRow"><span class="rrPos">${i}</span><b>${l}</b><span>${esc(n)}</span></div>`).join('')}</div></section>`;
}
function renderEvent(){
  const meta=data?.meta;if(!meta)return;
  $('eventView').classList.remove('hidden');
  $('pageSub').textContent='公開即時賽程';
  const count=eventCount();
  $('hero').innerHTML=`<div class="muted">🏆 賽程表</div><h1>${esc(meta.name||'Beyblade X Tournament')}</h1>
    <div class="chips"><span class="chip">👤 ${count} 人</span><span class="chip">${meta.mode==='free'?'↝ 自由編排':'🏆 單淘汰'}</span><span class="chip">⌘ ${esc(flowLabel())}</span></div>`;
  const rs=rounds();
  const cols=rs.map((r,ri)=>{const ms=matchesOf(r);return `<section class="roundCol" data-round="${ri}">
    <div class="roundHead"><h3>${esc(stageLabel(ri,r))}</h3><div class="sub">${ms.length} 場對戰</div></div>
    <div class="roundMatches" >${ms.map((m,mi)=>matchHtml(m,ri,mi,r)).join('')}</div></section>`}).join('')+(data.finalRR?rrHtml():'');
  const canvas=document.querySelector('.bracketCanvas');
  canvas.classList.toggle('compact32',count>=32&&count<64);canvas.classList.toggle('compact64',count>=64);
  $('bracketCols').innerHTML=cols;
  $('finalBox').innerHTML=finalHtml(rs);
  requestAnimationFrame(()=>{autoScale();requestAnimationFrame(drawLinks)});
}

function render(){
  if(!data)return;
  renderEvent();
}
// V0.22: align every round to the actual rendered centers of its two feeder matches.
// CSS owns card heights; measuring the DOM avoids mobile/compact/zoom pixel drift.
function alignBracketRounds(canvas){
  if(!canvas)return;
  const columns=[...canvas.querySelectorAll('.roundCol[data-round]')];
  const scaleNow=canvas.getBoundingClientRect().width/Math.max(1,canvas.offsetWidth);
  if(!Number.isFinite(scaleNow)||scaleNow<=0)return;
  const centerY=el=>{const r=el.getBoundingClientRect();return r.top+r.height/2;};
  for(let i=0;i<columns.length;i++){
    const col=columns[i],container=col.querySelector('.roundMatches');
    const cards=[...col.querySelectorAll('.bracketMatch')];
    if(!container||!cards.length)continue;
    // Recompute from scratch on every re-render/resize, never stack offsets.
    container.style.paddingTop='0px';
    container.style.removeProperty('gap');
    if(i===0)continue;
    const previous=[...columns[i-1].querySelectorAll('.bracketMatch')];
    const targets=[];
    for(let j=0;j<cards.length;j++){
      if(previous[j*2]&&previous[j*2+1])targets.push((centerY(previous[j*2])+centerY(previous[j*2+1]))/2);
      else if(previous[j*2])targets.push(centerY(previous[j*2]));
      else break; // e.g. separate third-place match, not a feeder pair
    }
    if(!targets.length)continue;
    const h=cards[0].getBoundingClientRect().height/scaleNow;
    const origin=container.getBoundingClientRect().top;
    container.style.paddingTop=Math.max(0,(targets[0]-origin)/scaleNow-h/2)+'px';
    if(targets.length>1){
      // Every pair midpoint must match the center of its destination card.
      const delta=(targets[1]-targets[0])/scaleNow;
      container.style.gap=Math.max(0,delta-h)+'px';
    }else if(cards.length>1){
      // Champion and third-place matches share a column, not the same feeder pairs.
      container.style.gap='16px';
    }
  }
}

function drawLinks(){
  if(!eventId)return;

  const canvas=document.querySelector('.bracketCanvas');
  const svg=document.querySelector('.bracketLinks');
  if(!canvas||!svg)return;
  alignBracketRounds(canvas);
  const stage=document.querySelector('.bracketStage');
  if(stage)stage.style.height=Math.ceil(canvas.scrollHeight*scale)+'px';

  const rs=rounds();
  const cr=canvas.getBoundingClientRect();
  const inv=1/(scale||1);
  const width=canvas.scrollWidth;
  const height=canvas.scrollHeight;

  svg.setAttribute('width',width);
  svg.setAttribute('height',height);
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  svg.style.width=width+'px';
  svg.style.height=height+'px';

  const point=(el,side='center')=>{
    const r=el.getBoundingClientRect();
    const x=side==='right'?r.right:(side==='left'?r.left:(r.left+r.width/2));
    return {
      x:(x-cr.left)*inv,
      y:(r.top+r.height/2-cr.top)*inv
    };
  };

  const paths=[];

  for(let ri=0;ri<rs.length-1;ri++){
    const src=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${ri}"]`)];
    const dst=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${ri+1}"]`)];

    dst.forEach((target,j)=>{
      const t=point(target,'left');
      const pair=[src[j*2],src[j*2+1]].filter(Boolean);
      if(!pair.length)return;

      const sourcePoints=pair.map(el=>({el,...point(el,'right')}));
      const maxSourceX=Math.max(...sourcePoints.map(p=>p.x));
      const elbowX=maxSourceX+Math.max(16,(t.x-maxSourceX)*0.52);

      sourcePoints.forEach(p=>{
        const live=p.el.classList.contains('done')?'live':'';
        paths.push(
          `<path class="${live}" d="M ${p.x.toFixed(1)} ${p.y.toFixed(1)} H ${elbowX.toFixed(1)} V ${t.y.toFixed(1)} H ${t.x.toFixed(1)}"/>`
        );
      });
    });
  }

  if(data.finalRR){
    const last=rs.length-1;
    const src=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${last}"]`)];
    const target=canvas.querySelector('.rrPanel');

    if(target&&src.length){
      const t=point(target,'left');
      const sourcePoints=src.map(el=>({el,...point(el,'right')}));
      const maxSourceX=Math.max(...sourcePoints.map(p=>p.x));
      const elbowX=maxSourceX+Math.max(16,(t.x-maxSourceX)*0.52);

      sourcePoints.forEach((p,k)=>{
        const live=p.el.classList.contains('done')?'live':'';
        const ty=t.y+(k-(sourcePoints.length-1)/2)*12;
        paths.push(
          `<path class="${live}" d="M ${p.x.toFixed(1)} ${p.y.toFixed(1)} H ${elbowX.toFixed(1)} V ${ty.toFixed(1)} H ${t.x.toFixed(1)}"/>`
        );
      });
    }
  }

  svg.innerHTML=paths.join('');
}
function setScale(v){
  scale=Math.max(.30,Math.min(1.2,v));
  const c=document.querySelector('.bracketCanvas'),st=document.querySelector('.bracketStage');if(!c||!st)return;
  c.style.transform=`scale(${scale})`;st.style.width=Math.ceil(c.scrollWidth*scale)+'px';st.style.height=Math.ceil(c.scrollHeight*scale)+'px';
  const z=document.querySelector('.zoomLabel');if(z)z.textContent=Math.round(scale*100)+'%';
}
function zoom(d){setScale(scale+d);requestAnimationFrame(drawLinks)}
function fit(){
  const sc=document.querySelector('.bracketScroll'),c=document.querySelector('.bracketCanvas');if(!sc||!c)return;
  setScale(Math.max(.30,Math.min(.92,(sc.clientWidth-14)/c.scrollWidth)));sc.scrollTo({left:0,top:0,behavior:'smooth'});requestAnimationFrame(drawLinks)
}
function autoScale(){
  const n=eventCount();
  setScale(innerWidth<=640?(n>=64?.52:n>=32?.60:.72):(n>=64?.68:n>=32?.78:.9))
}
function toggleFull(){document.body.classList.toggle('fullscreen');setTimeout(()=>{autoScale();drawLinks()},80)}
addEventListener('resize',()=>{if(eventId){clearTimeout(window.__rz);window.__rz=setTimeout(()=>{autoScale();drawLinks()},120)}});

window.addEventListener('pagehide',()=>{
  clearTimeout(reconnectResyncTimer);
  try{stream?.close()}catch{}
  stream=null;
  streamGeneration++;
});

if(!DB.startsWith('https://'))setStatus('Firebase 資料庫網址設定錯誤。','error');
else if(eventId){
  // Public alias lookup is one GET on first load, never listened to.
  // Match ID in Firebase always remains the immutable internal event ID.
  if(/^[A-HJ-NP-Z2-9]{5}$/.test(eventId)){
    fetch(`${DB}/bbxPublicCodeLookup/${encodeURIComponent(eventId)}.json`,{cache:'no-store'})
      .then(r=>{if(!r.ok)throw Error('lookup HTTP '+r.status);return r.json()})
      .then(real=>{
        if(typeof real!=='string'||!/^[A-Za-z0-9_-]{6,100}$/.test(real)){
          setStatus('活動 ID 不存在、已刪除或不可使用。','error');return;
        }
        startStream('publicEvents',real);
      })
      .catch(()=>setStatus('活動 ID 查詢失敗，請稍後再試。','error'));
  }else startStream('publicEvents',eventId);
}
else setStatus('網址缺少 event 參數。','error');
