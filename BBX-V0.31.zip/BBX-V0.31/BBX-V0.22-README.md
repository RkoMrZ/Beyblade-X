# BBX-V0.22 — 淘汰樹逐輪錯位修復

- 修正 V0.21 手機卡片實際高度 104px、JS 卻使用 112px 所造成的逐輪垂直位移。
- 由實際 DOM 卡片中心決定各輪對戰格位置，並讓連接線使用相同座標。
- 修正公開觀眾對戰表相同的佈局風險；涵蓋手機、平板、PC 及縮放／全覽。
- 移除被取代的 `roundLayout/layout` 固定高度公式、CSS 位移和季軍賽手動 `translateY` 補丁。
- 不改動賽事資料、晉級規則、比分權威、Firebase Functions／Rules 或既有賽事。
- 僅部署 Hosting。此版仍需 iPhone Safari／Android Chrome／桌面瀏覽器實機驗收。
