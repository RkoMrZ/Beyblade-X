# BBX-V0.31 — iOS Firebase RTDB transport recovery candidate

- Per-iOS WebKit privileged RTDB transport initialized to Firebase long-polling BEFORE attaching listeners. Desktop remains default transport. `?bbxTransport=auto` disables the override for a controlled comparison; `?bbxTransport=longpoll` tests it on other browsers. This uses the supported Firebase compat Database.INTERNAL API.
- No second Firebase Database instance, no new polling loop, no change to spectator SSE, Functions, RTDB Rules, scoring locks, tournament formatting or existing events.
- Synchronization diagnosis distinguishes SDK connectivity, live stream readiness, REST publishedSeq success and the selected transport; no token or private UID exposed.
- This is a candidate. A live iPhone organizer test with 5+ minutes page-open and referee operations is essential; local tests cannot prove the exact reason the previous WebSocket was disconnected.
