'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v031.js'),'utf8');
const start=src.indexOf('function listenCloudEvent(id){');
const end=src.indexOf('async function waitForAuthRestore(',start);
assert.ok(start>=0&&end>start);
const listener=src.slice(start,end);
function testClient({seq=1}={}){
 const paths=new Map();let watchdog,claimReads=0;
 const handlers=()=>({on(){},off(){}});
 const ctx={console,Date,JSON,Number,Map,Set,window:{},setTimeout,clearTimeout,
  setInterval:fn=>{watchdog=fn;return 9},clearInterval:()=>{},
  document:{visibilityState:'visible'},
  ev:{id:'EVENT42',rounds:[{matches:[{a:'A',b:'B',sa:0,sb:0,matchVersion:1,refereeActive:false}]}],refereeClaims:{},refereeNames:['裁判 1','裁判 2'],publishedSeq:1},
  cloudReady:true,isAdmin:true,isReferee:false,cloudUnsub:null,cloudListenerEpoch:0,cloudResyncBlocked:false,cloudEventsCache:{},
  liveRetryAttempts:new Map(),liveTransportRecoveryAt:new Map(),refereeClaimsStreamRevision:0,currentAdminTab:'bracket',
  fbDb:{ref(p){if(!paths.has(p))paths.set(p,new Map());return {on(t,fn){paths.get(p).set(t,fn)},off(t,fn){if(paths.get(p).get(t)===fn)paths.get(p).delete(t)}}}},
  $:()=>null,normalizeRefereeClaimsData:d=>d||{},confirmRefereeClaims:()=>false,refereeClaimsConfirmed:()=>false,
  rtdbRestGet:async p=>{if(p.includes('refereeClaims/')){claimReads++;return {}};if(p.endsWith('/publishedSeq'))return seq;return null},
  renderAdmin(){},renderReferee(){},v05ScorePending:()=>false, firebase:{database:()=>({goOnline(){}})}
 };
 vm.createContext(ctx);vm.runInContext(listener,ctx);ctx.listenCloudEvent('EVENT42');
 return {ctx,paths,tick:()=>watchdog(),get claimReads(){return claimReads},close:()=>ctx.cloudUnsub()};
}
test('five-minute-open organizer with disconnected SDK is classified as stalled and schedules ONE recovery',async()=>{
 const h=testClient({seq:2});
 try{
  h.ctx.window.__bbxSyncMetrics.startedAt=Date.now()-5*60*1000;
  h.paths.get('.info/connected').get('value')({val:()=>false});
  const metric=h.ctx.window.__bbxSyncMetrics;
  assert.equal(metric.connectionObserved,true);
  assert.equal(metric.connected,false);
  assert.equal(metric.lastLiveAt,null,'false connection notices are not score updates');
  await h.tick();
  assert.equal(metric.bootstrapIssue,'SDK offline');
  assert.ok(metric.trace.some(t=>t.stage==='bootstrap-stalled'));
  assert.equal(metric.trace.filter(t=>t.stage==='resubscribe').length,1,'missed watermark and offline SDK must not schedule two recoveries');
  assert.ok(h.claimReads>0,'claims must be checked separately when SDK is offline');
 }finally{h.close()}
});
test('healthy existing SDK stream does not get marked stalled merely because the page stayed open five minutes',async()=>{
 const h=testClient();
 try{
  h.ctx.window.__bbxSyncMetrics.startedAt=Date.now()-5*60*1000;
  h.paths.get('.info/connected').get('value')({val:()=>true});
  h.paths.get('events/EVENT42/publishedSeq').get('value')({val:()=>1});
  h.paths.get('refereeClaims/EVENT42').get('value')({val:()=>({})});
  await h.tick();
  const metric=h.ctx.window.__bbxSyncMetrics;
  assert.equal(metric.connected,true);
  assert.equal(metric.ready,true);
  assert.equal(metric.claimsReady,true);
  assert.equal(metric.bootstrapIssue,null);
  assert.equal(metric.trace.filter(t=>t.stage==='resubscribe').length,0);
  assert.equal(h.claimReads,0);
 }finally{h.close()}
});
