# Beyblade X 賽程表 — BBX-V0.16（賽前穩定更新）

本版 **不支援敗部復活**，請勿部署或使用任何先前含有敗部復活程式碼的 V0.16 候選版本。

## 本次修復範圍
- 裁判完成單場後保持對戰表捲動位置，不再強制回頁首
- 對戰表 Firebase 增量更新比分，不重建整張籤表；全覽模式保留縮放／捲動與場次點擊
- 自由編排新增「自動補位」：雲端伺服器依實際報名數配到 2、3、4、6、8、12、16、24、32、48、64、96、128 人的最近合法結構
- 40 人：48 格，8 人 BYE 自動晉級，16 場首輪比賽，進入 24→12→6→3→循環
- 保留原本「標準單淘汰」模式的演算法；歷史賽事不重排
- 草稿名單新增清除按鈕，不會修改既有雲端賽事

## 安全與相容性
- Functions 僅部署 `bbxV011CreateAuthority` 與 `bbxV011OrganizerAuthority`
- **不部署**記分 Command、公開 SSE、刪除 Function、Realtime Database Rules
- 不會自動新增、刪除或重排已存在的雲端賽事
- 雲端裁判權限、順序記分及賽事完成均以現有伺服器權威協定為準
- V0.11 是內部協定版本，不代表這份 ZIP 的發行號錯誤；本次 ZIP 仍為 V0.16

## 部署
上傳 `BBX-V0.16.zip` 至 GitHub main 根目錄後，使用交付的一行 Cloud Shell 指令（含新的 SHA-256）。
腳本會先執行測試和 Emulator，再安裝 Functions 依賴，最後先部署 Create/Organizer Functions、再部署 Hosting。

## 尚待實機驗收
- iPhone Safari/Chrome、Android Chrome、PC：裁判 2 支手機多場並行、同場互斥
- 全覽時比分修改／重新執裁以及返回頁面位置
- 40 人雲端建賽、BYE 晉級、三人循環和 QR 觀眾同步
