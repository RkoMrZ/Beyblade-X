#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.4 ]] || exit 2
python3 - <<'PY'
import json
m=json.load(open('MANIFEST.json'))
assert m['firebase_project']=='ljt-beyblade-x' and m['previous_release']=='BBX-V0.3'
assert len(m['previous_function_exports'])==8
assert all(n.startswith('bbxV03') for n in m['previous_function_exports'])
PY
gcloud functions list --v2 --regions=asia-southeast1 --project ljt-beyblade-x --format=json > /tmp/bbx-v04-before-clean.json
python3 - <<'PY' >/tmp/bbx-v04-remove.txt
import json
m=json.load(open('MANIFEST.json'))
active={i['name'].split('/')[-1] for i in json.load(open('/tmp/bbx-v04-before-clean.json'))}
for n in m['previous_function_exports']:
 if n in active:print(n)
PY
while read -r fn; do
 [[ -n "$fn" ]] || continue
 echo "Delete OLD BBX function only: $fn"
 firebase functions:delete "$fn" --region asia-southeast1 --project ljt-beyblade-x --force
done </tmp/bbx-v04-remove.txt
gcloud functions list --v2 --regions=asia-southeast1 --project ljt-beyblade-x --format=json > /tmp/bbx-v04-after-clean.json
python3 - <<'PY'
import json
m=json.load(open('MANIFEST.json'))
names={i['name'].split('/')[-1] for i in json.load(open('/tmp/bbx-v04-after-clean.json'))}
assert not (set(m['previous_function_exports']) & names)
assert set(m['functions_exports']) <= names
print('PASS V0.3 exact Functions deleted; all V0.4 Functions remain')
PY
rm -rf -- "$HOME/BBX-V0.3"
rm -f -- "$HOME/BBX-V0.3.zip"
echo 'Previous test archive on GitHub must be removed using authorized GitHub account; no shared resources or database records deleted.'
