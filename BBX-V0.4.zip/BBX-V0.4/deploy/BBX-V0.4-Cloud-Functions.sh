#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == 'BBX-V0.4' ]] || exit 2
python3 - <<'PY'
import json
m=json.load(open('MANIFEST.json'))
assert m['project_id']=='BBX-V0.4' and m['firebase_project']=='ljt-beyblade-x'
assert m['previous_release']=='BBX-V0.3'
assert m['release_status']=='PREDEPLOY_TEST_REQUIRED'
assert len(m['functions_exports'])==7 and all(x.startswith('bbxV04') for x in m['functions_exports'])
assert len(m['previous_function_exports'])==8 and all(x.startswith('bbxV03') for x in m['previous_function_exports'])
PY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == '22' ]] || { echo 'Node 22 required'; exit 3; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v04-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: full preflight test not passed for this exact package'; exit 3; }
for c in firebase gcloud curl python3 npm; do command -v "$c" >/dev/null || exit 3; done
if ! gcloud auth print-access-token >/dev/null 2>&1; then
 mapfile -t ACCOUNTS < <(gcloud auth list --format='value(account)' | sed '/^$/d')
 [[ ${#ACCOUNTS[@]} == 1 ]] || { echo 'STOP: gcloud account not selected'; exit 3; }
 gcloud config set account "${ACCOUNTS[0]}" --quiet
fi
gcloud auth print-access-token >/dev/null
PROJECT=ljt-beyblade-x
INSTANCE=ljt-beyblade-x-default-rtdb
gcloud config set project "$PROJECT" --quiet >/dev/null
[[ "$(gcloud config get-value project 2>/dev/null)" == "$PROJECT" ]] || exit 3
[[ "$(python3 -c 'import json;print(json.load(open(".firebaserc"))["projects"]["default"])')" == "$PROJECT" ]] || exit 3
RULES_URL="https://${INSTANCE}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS --retry 3 --connect-timeout 10 --max-time 45 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v04-live-rules.json
python3 deploy/merge-rules.py /tmp/bbx-v04-live-rules.json /tmp/bbx-v04-merged-rules.json
# Runtime temporary config only; verified package JSON is restored after deployment.
TMP_CFG="$(mktemp)"
TMP_FIREBASERC="$(mktemp)"
cp firebase.json "$TMP_CFG"
cp .firebaserc "$TMP_FIREBASERC"
trap 'cp "$TMP_CFG" "$ROOT/firebase.json"; cp "$TMP_FIREBASERC" "$ROOT/.firebaserc"; rm -f "$TMP_CFG" "$TMP_FIREBASERC" "$ROOT/deploy/.bbx-v04-runtime-rules.json"' EXIT
cp /tmp/bbx-v04-merged-rules.json deploy/.bbx-v04-runtime-rules.json
firebase target:apply database bbxv04-main "$INSTANCE" --project "$PROJECT"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('firebase.json');x=json.loads(p.read_text());x['database']={'target':'bbxv04-main','rules':'deploy/.bbx-v04-runtime-rules.json'};p.write_text(json.dumps(x,indent=2)+'\n')
PY
npm --prefix functions install --no-audit --no-fund
FN='functions:bbxV04CreateAuthority,functions:bbxV04CommandAuthority,functions:bbxV04GetOperation,functions:bbxV04RepairPublication,functions:bbxV04PublishAuthority,functions:bbxV04OrganizerAuthority,functions:bbxV04DeleteAuthority'
echo '=== Deploy BBX-V0.4 only (7 Functions), then merged RTDB Rules ==='
firebase deploy --only "$FN" --project "$PROJECT" --non-interactive --force
firebase deploy --only database:bbxv04-main --project "$PROJECT" --non-interactive
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS --retry 3 --connect-timeout 10 --max-time 45 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v04-post-rules.json
python3 - <<'PY'
import json
from pathlib import Path
def load(p):
 x=json.loads(Path(p).read_text());return json.loads(x) if isinstance(x,str) else x
assert load('/tmp/bbx-v04-post-rules.json')==load('/tmp/bbx-v04-merged-rules.json'),'online Rules mismatch'
print('PASS online Rules verified; unrelated branches preserved')
PY
gcloud functions list --v2 --regions=asia-southeast1 --project "$PROJECT" --format=json > /tmp/bbx-v04-functions.json
python3 - <<'PY'
import json
m=json.load(open('MANIFEST.json'))
l=json.load(open('/tmp/bbx-v04-functions.json'))
names={str(i['name']).split('/')[-1] for i in l}
assert set(m['functions_exports']) <= names,'missing V0.4 Functions'
print('PASS all 7 BBX-V0.4 Functions confirmed in asia-southeast1')
PY
# Only after online verification, delete exact previous V0.3 BBX function names.
bash deploy/BBX-V0.4-清理舊測試版.sh
printf '\nPASS: BBX-V0.4 Cloud Functions and Rules deployed. Update index.html/viewer.html from the SAME ZIP in GitHub Pages.\n'
