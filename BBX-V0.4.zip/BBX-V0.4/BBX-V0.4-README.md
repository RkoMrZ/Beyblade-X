# BBX-V0.4｜戰鬥陀螺賽程表（測試版）

**唯一開發母版**：`baseline/index.v1.html`、`baseline/viewer.v1.html`、`baseline/rules.v1.json`（使用者 2026-10-17 上傳的正式 V1.0 原始三檔）。沒有重做原本介面或 CSS。

**目標 Firebase 專案**：`ljt-beyblade-x`（非獨立報名系統）。

**本版解決的重點**：此前 V0.1–V0.3 建立賽事採用「手機直接寫 events、公開牌，再由另一支 Function 暫存／啟用」多階段流程；手機在某一步收到 aborted / not-found，留下狀態不一致風險。V0.4 改成**單一 `bbxV04CreateAuthority` Callable**，只接受賽事設定與選手名稱，**由伺服器**依原版編排邏輯建立完整初始賽程，並以**一次原子多路徑 RTDB 更新**一併寫入：

- `events/{eventId}`：主辦、裁判讀取的管理投影（保留原 V1 UI 可讀結構）
- `publicEvents/{eventId}`：公開觀眾投影（**不含私密憑證、UID 或操作紀錄**）
- `authorityBBXV04/{eventId}/board`：唯一可信權威狀態（禁止前端直接讀寫）
- `userEvents/{uid}/{slot}`：主辦帳號的三場名額索引
- `secrets/{eventId}`、`admins/{eventId}/{uid}`：原版管理碼及原有管理權限相容

採用由 UID + 隨機操作碼決定的賽事 ID；同一操作重試只會返回原賽事，不會再建立第二場。Cloud Functions 不相信手機送來的整張淘汰樹或最終晉級結果。

## 主辦、裁判、觀眾資料讀寫

| 身分 | 即時讀取 | 操作寫入 | 完整同步的觸發 |
|---|---|---|---|
| 主辦 | 帳號索引、賽事基本資料、每輪場次 child 變動 | `bbxV04OrganizerAuthority`（名單、重排、裁判設定、抽獎、開關公開連結）、`bbxV04DeleteAuthority` | 首次開啟、賽程結構變更、失去連線後校正 |
| 裁判 | 已授權的賽事、負責場次及裁判鎖 | `bbxV04CommandAuthority`（接手、比分、完成、重設、釋放）；原有裁判身分加入節點保留 | 首次開啟、改判後依賴輪次變更、明確版本衝突 |
| 觀眾 | `publicEvents/{eventId}` 一條 SSE（第一次完整快照，之後只接收 Firebase patch） | **零寫入** | 首次開啟、斷線且未收到 SSE 恢復快照時，按需 GET；不做每四分鐘整表 GET |

**核心原則**：雲端是唯一真實賽事狀態。手機只提出操作、暫時顯示 UI；操作帶唯一碼、場次 `matchVersion` 或結構 `seq`；不符即拒絕、重新讀雲端。比分完成與晉級由伺服器取得短期賽事鎖、驗證最新權威資料後計算，且**只將變動的私人節點（比分、版本、序號、操作紀錄）寫回**；再將受影響場次增量發布至管理與公開投影。伺服器為判斷下一輪，仍會讀取一次私人權威狀態，觀眾不會讀取此狀態。已完成的比賽改判期間，會保留已確認的公開結果直到新結果完成。

## 7 支 Functions

`bbxV04CreateAuthority`、`bbxV04CommandAuthority`、`bbxV04GetOperation`、`bbxV04OrganizerAuthority`、`bbxV04DeleteAuthority`、`bbxV04RepairPublication`、`bbxV04PublishAuthority`。

## 測試與版本安全

- 已在本地執行 Node 純邏輯及模擬整合測試、原始 HTML/CSS 完整比對、JS 語法、Rules 安全合併測試。
- Firebase Emulator 依賴 Cloud Shell，**本地未能確認真實 Emulator 結果**；`deploy/BBX-V0.4-檢查.sh` 會強制執行，未通過不允許第二段部署。
- 真正 Firebase Callable + iPhone Safari、以及 200 人同時觀看，仍須線上測試；**本包不是正式 V1.0**。
- V0.3 已建立的測試場不會自動遷移為 V0.4。請使用新版建立新測試場；避免舊版本資料衝突。
- 不修改 `ljtreg-39954` 等報名專案，不刪正式 V1.0 賽事或報名資料，也不建立額外備份。
- 只有 V0.4 的 7 支 Functions 和合併 Rules 都確認部署成功後，才刪除 V0.3 的 8 支 Functions；不執行全專案刪除。

## Cloud Shell 用法（手機）

將 `BBX-V0.4.zip` 上傳 GitHub `rkomrz/Beyblade-X` 的 `main` 根目錄，然後依 `BBX-V0.4-CloudShell-指令.txt` 的兩段指令操作。第一段下載 + 完整檢查，第二段部署並只刪除前版 BBX 函數。網站請使用**同一份 ZIP** 裡的 `index.html` 與 `viewer.html` 覆蓋 Pages 根目錄原檔，不另建測試目錄。
