#!/usr/bin/env python3
import re,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(p):return (root/p).read_text()
def nonscript(html):
 s=re.sub(r'<script\b[^>]*>[\s\S]*?</script>','<script></script>',html,flags=re.I)
 return re.sub(r'(?:<script></script>\s*)+','<script></script>\n',s)
for n,original in [('index','baseline/index.v1.html'),('viewer','baseline/viewer.v1.html')]:
 a=read(original);b=read(n+'.html')
 # Exact markup and styling (outside script tags) is preserved.
 assert nonscript(a)==nonscript(b),n+' ORIGINAL HTML/CSS structural mismatch'
 assert re.findall(r'<style[^>]*>([\s\S]*?)</style>',a)==re.findall(r'<style[^>]*>([\s\S]*?)</style>',b)
 print('PASS original',n,'HTML/CSS preserved byte for byte outside scripts')
frontend=read('index.html');fn=read('functions/index.js');viewer=read('viewer.html')
assert 'bbxV04CreateAuthority' in frontend and 'bbxV04CreateAuthority' in fn
assert 'bbxV04ActivateAuthority' not in frontend+fn
assert "const created=(await createFn" in frontend
assert "createdEventId=created.eventId" in frontend
assert "const authoritative=await rtdbRestGet" in frontend
assert "projectGuard()" in fn and "DB_URL=" in fn
assert "authorityBBXV04/${eventId}" in fn
assert "ref:'authorityBBXV04/{eventId}/board/seq'" in fn
assert 'await db.ref().update(updates);  // one atomic server commit' in fn
assert "const isV1Authority=()=>!!ev&&!ev.testOnly&&ev.authorityBBX==='active'&&ev.releaseTag==='BBX-V0.4'" in frontend
assert '每 4 分鐘做一次' not in viewer
assert "document.visibilityState==='hidden'" in viewer
assert 'bbxV03' not in fn+frontend
assert 'ljtreg' not in fn+frontend+read('.firebaserc')
base=json.loads(read('baseline/rules.v1.json'))['rules']; rules=json.loads(read('database.rules.json'))['rules']
assert all(rules[k]==base[k] for k in base if k not in {'events','publicEvents'})
assert rules['events']['$eventId']['.read']==base['events']['$eventId']['.read']
assert rules['publicEvents']['$eventId']['.read']==base['publicEvents']['$eventId']['.read']
assert rules['authorityBBXV04']=={'.read':False,'.write':False}
assert 'authorityBBX' in rules['events']['$eventId']['rounds']['.write']
assert "BBX-V0.4" in rules['events']['$eventId']['.write']
print('PASS scoped create, version gate, SSE, private authority and Rules guards')
