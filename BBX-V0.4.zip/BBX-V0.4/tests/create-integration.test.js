'use strict';
const assert=require('node:assert/strict');
const test=require('node:test');
const Module=require('node:module');
const originalLoad=Module._load;
process.env.GCLOUD_PROJECT='ljt-beyblade-x';
const COPY=v=>v===undefined?undefined:JSON.parse(JSON.stringify(v));
const store={};
const transactions=[];const writes=[];
function parts(p){return String(p||'').split('/').filter(Boolean)}
function getAt(path){let n=store;for(const k of parts(path)){if(!n||typeof n!=='object'||!(k in n))return null;n=n[k]}return COPY(n)}
function setAt(path,v){let a=parts(path),o=store;for(let i=0;i<a.length-1;i++){o[a[i]]??={};o=o[a[i]]}if(v===null)delete o[a.at(-1)];else o[a.at(-1)]=COPY(v)}
class Ref{
 constructor(p=''){this.p=p}
 child(n){return new Ref(this.p+'/'+n)}
 async get(){return new Snap(getAt(this.p))}
 async once(){return this.get()}
 async set(v){setAt(this.p,v)}
 async update(up){for(const [k,v] of Object.entries(up)){writes.push(this.p+'/'+k);setAt(this.p+'/'+k,v)}}
 async transaction(change){transactions.push(this.p);const current=getAt(this.p);const res=change(COPY(current));if(res===undefined)return {committed:false,snapshot:new Snap(current)};setAt(this.p,res);return {committed:true,snapshot:new Snap(getAt(this.p))}}
}
class Snap{constructor(v){this.v=v}val(){return COPY(this.v)}exists(){return this.v!==null&&this.v!==undefined}}
const fakeDb={ref:p=>new Ref(p)};
class HttpsError extends Error{constructor(code,message){super(message);this.code=code}}
Module._load=function(request,parent,isMain){
 if(parent?.filename?.endsWith('/functions/index.js')){
  if(request==='firebase-admin')return {initializeApp(){},database:()=>fakeDb};
  if(request==='firebase-functions/v2/https')return {onCall:(_opt,fn)=>fn,HttpsError};
  if(request==='firebase-functions/v2/database')return {onValueWritten:(_opt,fn)=>fn};
 }
 return originalLoad.apply(this,arguments);
};
const f=require('../functions/index.js');Module._load=originalLoad;
function op(){return Date.now().toString(16).padStart(12,'0')+'d'.repeat(36)}
function request(data,uid='owner',google=true){return {data:{clientVersion:'bbx-v0.4-authority-1',...data},auth:uid?{uid,token:{firebase:{sign_in_provider:google?'google.com':'anonymous'}}}:null}}
const roster=['A','B','C','D'];const make=opId=>request({opId,name:'Test Event',roster,mode:'single',pairing:'ordered',freeFinal:'champ'});
let eventId;
test('atomic server CREATE writes owner index / private / public / board together',async()=>{
 const result=await f.bbxV04CreateAuthority(make(op()));assert.equal(result.ok,true);eventId=result.eventId;
 assert.equal(result.slot,'0');assert.equal(result.eventId.startsWith('B4_'),true);
 assert.equal(getAt('events/'+eventId+'/releaseTag'),'BBX-V0.4');
 assert.equal(getAt('events/'+eventId+'/authorityBBX'),'active');
 assert.equal(getAt('publicEvents/'+eventId+'/meta/id'),eventId);
 assert.equal(getAt('userEvents/owner/0'),eventId);
 assert.equal(getAt('authorityBBXV04/'+eventId+'/board/seq'),0);
 assert.equal(getAt('authorityBBXV04/'+eventId+'/board/rounds/0/matches/0/a'),'A');
 assert.equal(getAt('admins/'+eventId+'/owner')!==null,true);
 assert.equal(getAt('bbxV04CreateLocks/owner'),null);
});
test('same create operation is idempotent and does not allocate another slot',async()=>{
 const id='d'.repeat(36),o=Date.now().toString(16).padStart(12,'0')+id;
 const a=await f.bbxV04CreateAuthority(make(o));const b=await f.bbxV04CreateAuthority(make(o));
 assert.equal(a.eventId,b.eventId);assert.equal(b.existing,true);assert.equal(b.slot,'1');
});
test('new request increments owner slot, but fourth create is refused',async()=>{
 await f.bbxV04CreateAuthority(make(op().slice(0,12)+'e'.repeat(36)));
 await assert.rejects(()=>f.bbxV04CreateAuthority(make(op().slice(0,12)+'f'.repeat(36))),e=>e.code==='resource-exhausted');
 assert.equal(Object.keys(getAt('userEvents/owner')).length,3);
});
test('anonymous and non-Google cannot create authoritative event',async()=>{
 await assert.rejects(()=>f.bbxV04CreateAuthority(request(make(op()).data,null)),e=>e.code==='unauthenticated');
 await assert.rejects(()=>f.bbxV04CreateAuthority(request(make(op()).data,'bad',false)),e=>e.code==='permission-denied');
});
test('server score/claim advances one match and rejects old matchVersion',async()=>{
 const a=await f.bbxV04CommandAuthority(request({eventId,opId:op(),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'}));
 assert.equal(a.ok,true);
 assert.equal(a.matchVersion,1);
 assert.equal(getAt(`events/${eventId}/rounds/0/matches/0/referee`),'裁判 1');
 await assert.rejects(()=>f.bbxV04CommandAuthority(request({eventId,opId:op().slice(0,12)+'b'.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,sa:4,sb:1})),e=>e.code==='aborted');
 const s=await f.bbxV04CommandAuthority(request({eventId,opId:op().slice(0,12)+'c'.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:1,sa:4,sb:1}));assert.equal(s.ok,true);
 assert.equal(getAt(`publicEvents/${eventId}/rounds/0/matches/0/sa`),4);
 assert.equal(transactions.some(p=>p.endsWith('/board')),false,'the private board must never be transacted wholesale');
 assert.equal(writes.includes(`authorityBBXV04/${eventId}/board/rounds`),false,'score must not write the entire rounds tree');
 assert.ok(writes.some(p=>p.endsWith('/board/rounds/0/matches/0/sa')),'score writes its match leaf');
});
test('old release client version cannot operate V0.4 event',async()=>{
 await assert.rejects(()=>f.bbxV04CommandAuthority({data:{clientVersion:'bbx-v0.3-authority-1',eventId,action:'claim'},auth:request({}).auth}),e=>e.code==='failed-precondition');
});
test('orphaned slot from prior failed release can be reclaimed without deleting existing events',async()=>{
 setAt('userEvents/newowner/0','ORPHAN_OLD_A');
 const made=await f.bbxV04CreateAuthority(request({opId:op().slice(0,12)+'a'.repeat(36),name:'Clean old orphan',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'newowner'));
 assert.equal(made.slot,'0');assert.equal(getAt('userEvents/newowner/0'),made.eventId);
 assert.equal(getAt('userEvents/owner/0'),eventId);
});
test('server deletion is scoped, serialized against publisher and removes private/public/index together',async()=>{
 const removed=await f.bbxV04DeleteAuthority(request({eventId}));
 assert.deepEqual(removed,{ok:true,deleted:true});
 for(const p of [`events/${eventId}`,`publicEvents/${eventId}`,`authorityBBXV04/${eventId}`,'userEvents/owner/0'])assert.equal(getAt(p),null,p);
 assert.ok(getAt('userEvents/owner/1'),'other existing event untouched');
 assert.ok(getAt('events/'+getAt('userEvents/owner/1')),'other event still exists');
});
test('simultaneous stale score commands cannot both commit',async()=>{
 const r=await f.bbxV04CreateAuthority(request({opId:op().slice(0,12)+'8'.repeat(36),name:'Racing scoreboard',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'newowner'));
 const eid=r.eventId;
 await f.bbxV04CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+'1'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},'newowner'));
 const score=(ending,tail)=>f.bbxV04CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+tail.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:1,sa:ending,sb:1},'newowner'));
 const results=await Promise.allSettled([score(3,'2'),score(4,'3')]);
 assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
 assert.ok(['aborted','resource-exhausted'].includes(results.find(x=>x.status==='rejected').reason.code));
 assert.equal(getAt(`events/${eid}/rounds/0/matches/0/matchVersion`),2);
});
