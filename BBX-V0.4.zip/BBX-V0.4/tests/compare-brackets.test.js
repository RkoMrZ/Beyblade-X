const fs=require('fs'),vm=require('vm');
const test=require('node:test'),assert=require('node:assert/strict');
const Org=require('../functions/bbx-v04-organizer');
const src=fs.readFileSync(__dirname+'/../baseline/index.v1.html','utf8');
const body=src.slice(src.indexOf('function nextPow2('),src.indexOf('function pick(ri,mi,side)'));
const context=vm.createContext({ev:null});vm.runInContext(body,context);
function norm(a){return JSON.parse(JSON.stringify(a,(k,v)=>['matchVersion','referee','refereeActive','claimUid'].includes(k)?undefined:v))}
for(const mode of ['single','free'])for(const freeFinal of ['champ','rr3']){
 test(`generated bracket matches every original V1.0 roster (${mode}/${freeFinal})`,()=>{
  let count=0;
  for(let n=2;n<=64;n++){
   const roster=Array.from({length:n},(_,i)=>'P'+(i+1));
   if(mode==='free'&&freeFinal==='rr3'){let k=n;while(k>3)k=Math.ceil(k/2);if(k!==3)continue;}
   context.ev={roster,mode,freeFinal,rounds:[],finalRR:null};context.buildFirst();
   const actual=Org.build(roster,mode,freeFinal);
   assert.deepEqual(norm(actual),norm({rounds:context.ev.rounds,finalRR:context.ev.finalRR}),`mode=${mode} final=${freeFinal} n=${n}`);
   count++;
  }
  assert(count>=1);
 });
}
