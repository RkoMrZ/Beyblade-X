'use strict';
// BBX V0.3 server-authoritative match and organizer commands.
const admin=require('firebase-admin');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onValueWritten}=require('firebase-functions/v2/database');
const C=require('./bbx-v04-core');
const O=require('./bbx-v04-organizer');
const PROJECT='ljt-beyblade-x';
const DB_URL='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app';
const VERSION='bbx-v0.4-authority-1';
admin.initializeApp({projectId:PROJECT,databaseURL:DB_URL});
const db=admin.database();
const OPT={region:'asia-southeast1',timeoutSeconds:60,maxInstances:4};
const ID=/^[A-Za-z0-9_-]{6,100}$/;
const id=x=>{if(!ID.test(x||''))throw new HttpsError('invalid-argument','賽事代碼格式錯誤');return x};
function auth(req,google=false){
 if(req.data?.clientVersion!==VERSION)throw new HttpsError('failed-precondition','舊版網頁無法修改此賽事，請更新網頁');
 if(!req.auth?.uid)throw new HttpsError('unauthenticated','請先登入');
 if(google&&req.auth.token?.firebase?.sign_in_provider!=='google.com')throw new HttpsError('permission-denied','主辦需 Google 身分');
 return req.auth.uid;
}
function catchError(e){
 if(e instanceof HttpsError)throw e;
 if(e instanceof C.CommandError)throw new HttpsError(e.code,e.message);
 console.error('V1 authority error',e);
 throw new HttpsError('internal','伺服器尚未確認結果；請使用相同操作代碼查詢，不要重複點擊');
}
const base=eventId=>`authorityBBXV04/${eventId}`;
// RTDB transaction callbacks can receive null on a cold SDK cache even when the
// server node exists. Warm the same SDK reference with an actual value listener
// BEFORE a read-modify-write transaction. Never insert an assumed client snapshot.
async function compareAndSwap(ref,change){
 await ref.once('value');
 return ref.transaction(change,undefined,false);
}

// A small per-event mutex serializes commands; unlike a board transaction, a
// command only WRITES changed private leaves (match, seq, receipt, outbox).
// It may read the authoritative private board for deterministic progression.
function changedLeaves(before,after){
 const writes={};
 const walk=(a,b,path)=>{
  if(JSON.stringify(a)===JSON.stringify(b))return;
  if(path&&(a==null||b==null||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b)||
      (Array.isArray(a)&&a.length!==b.length))){writes[path]=b===undefined?null:b;return;}
  if(a==null||b==null||typeof a!=='object'||typeof b!=='object')throw Error('invalid root board diff');
  const keys=new Set([...Object.keys(a),...Object.keys(b)]);
  for(const key of keys)walk(a[key],b[key],path?`${path}/${key}`:key);
 };
 walk(before,after,'');return writes;
}
async function withEventLock(eventId,task){
 const path=db.ref(`${base(eventId)}/operationLock`);
 const token=require('node:crypto').randomBytes(12).toString('hex');let held=false;
 for(let i=0;i<8;i++){
  const result=await compareAndSwap(path,cur=>!cur||Number(cur.until)<Date.now()?{token,until:Date.now()+90000}:undefined);
  if(result.committed){held=true;break;}
  await new Promise(resolve=>setTimeout(resolve,150+i*75));
 }
 if(!held)throw new HttpsError('resource-exhausted','另一個裝置正在處理賽事操作，請稍候重試');
 try{return await task()}
 finally{
  try{await compareAndSwap(path,cur=>cur?.token===token?null:undefined)}
  catch(e){console.error('operation lock cleanup failure:',eventId,e)}
 }
}
async function applyToPrivateBoard(eventId,operation){
 return withEventLock(eventId,async()=>{
  const ref=db.ref(`${base(eventId)}/board`);
  const original=(await ref.get()).val();
  if(!original||original.deleted===true)throw new HttpsError('not-found','賽事權威狀態不存在或已刪除');
  const result=operation(original);
  if(result.replay)return {...result.receipt,replayed:true};
  if(result.unchanged)return {...result,ok:true};
  const writes=changedLeaves(original,result.board);
  if(!Object.keys(writes).length)throw new HttpsError('internal','此次操作沒有產生可確認的資料變更');
  await ref.update(writes);
  return result.result;
 });
}

function projectGuard(){
 const project=process.env.GCLOUD_PROJECT||process.env.GCP_PROJECT||JSON.parse(process.env.FIREBASE_CONFIG||'{}').projectId;
 if(project!==PROJECT)throw new HttpsError('failed-precondition','Firebase 專案不符');
}
async function authz(uid,eventId){
 const [e,claims,ref,adminFlag]=await Promise.all([
   db.ref(`events/${eventId}/ownerUid`).get(),
   db.ref(`refereeClaims/${eventId}`).get(),
   db.ref(`refereeUsers/${eventId}/${uid}`).get(),
   db.ref(`admins/${eventId}/${uid}`).get()
 ]);
 const owner=e.val()===uid;
 let refereeName=null;
 if(ref.exists())for(const x of Object.values(claims.val()||{}))if(x?.uid===uid){refereeName=String(x.name||'');break;}
 return {owner,admin:adminFlag.exists(),referee:ref.exists()&&!!refereeName,refereeName};
}
async function publish(eventId){
 return withEventLock(eventId,async()=>{
 const ref=db.ref(base(eventId));const ownerToken=require('node:crypto').randomBytes(16).toString('hex');
 let claimed=false;
 const lock=ref.child('publishing');const now=Date.now();
 const taken=await lock.transaction(x=>!x||x.expiresAt<now?{token:ownerToken,expiresAt:now+45000}:undefined,undefined,false);
 if(!taken.committed)return {busy:true};claimed=true;
 try{
  const liveGate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(liveGate!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.4'||(await ref.child('board/deleted').get()).val()===true)return {ok:false,disabled:true};
  let cursor=Number((await ref.child('publishedSeq').get()).val()||0);
  for(let batch=0;batch<24;batch++){
   const item=(await ref.child(`board/outbox/${String(cursor+1).padStart(12,'0')}`).get()).val();
   if(!item)break;
   const stillLive=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
   if(stillLive!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.4'||(await ref.child('board/deleted').get()).val()===true)return {ok:false,disabled:true};
   const changes={};let structure=false;
   for(const ch of item.changes||[]){
     changes[`events/${eventId}/${ch.path}`]=ch.value;
     if(ch.publicChanged!==false)changes[`publicEvents/${eventId}/${ch.publicPath||ch.path}`]=ch.publicValue;
     if(ch.structure===true||ch.path==='finalRR/players')structure=true;
   }
   if(structure){
     const t=Date.now();changes[`events/${eventId}/syncVersion`]=t;changes[`publicEvents/${eventId}/meta/syncVersion`]=t;
   }
   changes[`events/${eventId}/authoritySeq`]=cursor+1;
   if(Object.keys(changes).length)await db.ref().update(changes);
   // Idempotent updates above can safely be retried if this bookkeeping write fails.
   await ref.update({publishedSeq:cursor+1,[`board/outbox/${String(cursor+1).padStart(12,'0')}`]:null});
   cursor++;
  }
  return {ok:true,publishedSeq:cursor};
 }finally{
   if(claimed)await compareAndSwap(lock,x=>x?.token===ownerToken?null:undefined);
 }
 });
}
// BBX-V0.4: one single authoritative CREATE operation, not stage + activate.
// The client sends configuration ONLY. Server constructs the bracket and index.
// All authoritative nodes become visible in the SAME atomic RTDB multipath update.
const crypto=require('node:crypto');
const CREATE_OP=/^[a-f0-9]{48}$/;
const cleanName=s=>typeof s==='string'?s.trim():'';
const publicMatch=m=>C.sanitizedMatch(m);
function projectPublic(ev){
 return {meta:{id:ev.id,name:ev.name,mode:ev.mode,pairing:ev.pairing,
    freeFinal:ev.freeFinal,roster:ev.roster,created:ev.created,cloudVersion:5,
    syncVersion:ev.syncVersion,publicOpen:ev.publicOpen,publicUntil:ev.publicUntil},
    rounds:ev.rounds.map(r=>({name:r.name,...(r.placementFinal?{placementFinal:true}:{}),matches:(r.matches||[]).map(publicMatch)})),
    finalRR:ev.finalRR?{players:ev.finalRR.players,matches:ev.finalRR.matches.map(publicMatch)}:null};
}
function validateCreate(d){
 const name=cleanName(d.name)||'Beyblade X Tournament';
 if(name.length>100)throw new HttpsError('invalid-argument','賽事名稱過長');
 if(!Array.isArray(d.roster)||d.roster.length<2||d.roster.length>64)throw new HttpsError('invalid-argument','選手人數須介於2至64');
 const roster=d.roster.map(x=>cleanName(x));
 if(roster.some(x=>!x||x.length>60||x==='BYE'||x==='待定'||/[\u0000-\u001f]/.test(x))||new Set(roster).size!==roster.length)
   throw new HttpsError('invalid-argument','選手名稱不可為空、重複或保留字');
 if(!['free','single'].includes(d.mode)||!['ordered','random','manual'].includes(d.pairing)||!['champ','rr3'].includes(d.freeFinal))
   throw new HttpsError('invalid-argument','賽制參數無效');
 if(d.mode==='free'&&d.freeFinal==='rr3'){
   let n=roster.length;while(n>3)n=Math.ceil(n/2);
   if(n!==3)throw new HttpsError('invalid-argument','人數無法自然晉級至三人循環');
 }
 return {name,roster,mode:d.mode,pairing:d.pairing,freeFinal:d.freeFinal};
}
exports.bbxV04CreateAuthority=onCall(OPT,async req=>{
 let lockHeld=false,lockPath=null,token=null;
 try{
  projectGuard(); const uid=auth(req,true), opId=req.data?.opId;
  if(!CREATE_OP.test(opId||''))throw new HttpsError('invalid-argument','建立操作代碼無效');
  const d=validateCreate(req.data), now=Date.now();
  const eventId='B4_'+crypto.createHash('sha256').update(uid+':'+opId).digest('hex').slice(0,26);
  const eventRef=db.ref(`events/${eventId}`);
  const existing=(await eventRef.get()).val();
  if(existing){
    if(existing.ownerUid===uid&&existing.releaseTag==='BBX-V0.4'&&existing.authorityBBX==='active'){
      const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
      const slot=Object.keys(slots).find(k=>slots[k]===eventId);
      return {ok:true,eventId,slot,existing:true};
    }
    throw new HttpsError('already-exists','代碼已建立但狀態不完整，請聯絡管理者');
  }
  token=crypto.randomBytes(12).toString('hex');lockPath=db.ref(`bbxV04CreateLocks/${uid}`);
  const claim=await compareAndSwap(lockPath,cur=>!cur||Number(cur.until)<Date.now()?{token,until:Date.now()+90000}:undefined);
  if(!claim.committed)throw new HttpsError('resource-exhausted','此帳號正在建立另一場賽事，請稍候');
  lockHeld=true;
  // Re-check inside account lock, including idempotent retries.
  const again=(await eventRef.get()).val();
  if(again?.authorityBBX==='active'&&again.ownerUid===uid){
    const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
    return {ok:true,eventId,slot:Object.keys(slots).find(k=>slots[k]===eventId),existing:true};
  }
  const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
  // A previously failed test release may leave an owner slot without its event.
  // Only reclaim truly missing events; never remove an existing V1 or V0.x event.
  let free;
  for(const k of ['0','1','2']){
    if(!slots[k]){free=k;break;}
    const referenced=await db.ref(`events/${String(slots[k])}`).get();
    if(!referenced.exists()){free=k;break;}
  }
  if(free===undefined)throw new HttpsError('resource-exhausted','雲端賽事已達三場上限');
  const built=O.build(d.roster,d.mode,d.freeFinal),adminCode=String(crypto.randomInt(100000,1000000));
  const ev={id:eventId,ownerUid:uid,created:now,testOnly:false,releaseTag:'BBX-V0.4',
    authorityBBX:'active',authoritySeq:0,cloudVersion:5,syncVersion:now,
    ...d,rounds:built.rounds,finalRR:built.finalRR,refereeCount:1,
    refereeNames:['裁判 1'],publicOpen:true,publicUntil:now+4*3600000,
    raffleState:null};
  const board=C.bootstrap(ev);
  const updates={
    [`events/${eventId}`]:ev,
    [`publicEvents/${eventId}`]:projectPublic(ev),
    [`authorityBBXV04/${eventId}/board`]:board,
    [`authorityBBXV04/${eventId}/publishedSeq`]:0,
    [`userEvents/${uid}/${free}`]:eventId,
    [`secrets/${eventId}`]:{adminCode,expiresAt:now+60000},
    [`admins/${eventId}/${uid}`]:adminCode
  };
  await db.ref().update(updates);  // one atomic server commit across all nodes
  return {ok:true,eventId,slot:free,created:true};
 }catch(e){catchError(e)}
 finally{
  if(lockHeld&&lockPath){try{await compareAndSwap(lockPath,cur=>cur?.token===token?null:undefined)}catch(e){console.error('create lock release failure',e)}}
 }
});

exports.bbxV04CommandAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.4')throw new HttpsError('failed-precondition','尚未切換為雲端權威版本');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin&&!permission.referee)throw new HttpsError('permission-denied','未取得主辦或裁判授權');
  const result=await applyToPrivateBoard(eventId,cur=>C.apply(cur,uid,req.data,Date.now(),permission));
  if(result.replayed)return result;
  const published=await publish(eventId);
  return {...result,published:published.publishedSeq>=result.seq};
 }catch(e){catchError(e)}
});
exports.bbxV04GetOperation=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId),opId=req.data?.opId;
  if(typeof opId!=='string'||!/^[a-f0-9]{48}$/.test(opId))throw new HttpsError('invalid-argument','操作代碼無效');
  if((await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.4')throw new HttpsError('failed-precondition','只能查詢 V0.4 操作');
  const r=(await db.ref(`${base(eventId)}/board/receipts/${opId}`).get()).val();
  if(!r)return {found:false};
  if(r.uid!==uid)throw new HttpsError('permission-denied','不能讀取別人的操作結果');
  return {found:true,...r.result};
 }catch(e){catchError(e)}
});
exports.bbxV04RepairPublication=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const owner=(await db.ref(`events/${eventId}/ownerUid`).get()).val();
  if(owner!==uid||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.4')throw new HttpsError('permission-denied','只有 V0.4 主辦能要求修復');
  return publish(eventId);
 }catch(e){catchError(e)}
});
exports.bbxV04PublishAuthority=onValueWritten({ref:'authorityBBXV04/{eventId}/board/seq',region:'asia-southeast1',instance:'ljt-beyblade-x-default-rtdb',retry:true},async e=>{
 projectGuard();if(!e.data.after.exists())return;
 const n=id(e.params.eventId),target=Number(e.data.after.val());
 const r=await publish(n);
 if(r.busy||r.disabled)return;
 if(r.publishedSeq<target)throw Error('Incremental publication pending');
});

// Organizer mutations use the same atomic event authority as match commands.
// Never accepts a client-provided roster, rounds, or complete event snapshot.
exports.bbxV04OrganizerAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.4')throw new HttpsError('failed-precondition','尚未啟用雲端權威');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin)throw new HttpsError('permission-denied','需要主辦權限');
  if(req.data?.action==='setReferees') {
   const claims=(await db.ref(`refereeClaims/${eventId}`).get()).val()||{};
   if(Object.values(claims).some(Boolean))throw new HttpsError('failed-precondition','仍有已領取的裁判身分，請先釋放全部裁判再修改名單');
  }
  const result=await applyToPrivateBoard(eventId,cur=>O.apply(cur,uid,req.data,Date.now(),permission));
  if(result.replayed||result.unchanged)return result;
  const published=await publish(eventId);
  return {...result,published:published.publishedSeq>=result.seq};
 }catch(e){catchError(e)}
});


// Delete is scoped to a single verified, active BBX test tournament.
// In-flight operations see the tombstone and will not recreate removed data.
exports.bbxV04DeleteAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const ev=(await db.ref(`events/${eventId}`).get()).val();
  if(!ev||ev.ownerUid!==uid||ev.releaseTag!=='BBX-V0.4')
   throw new HttpsError('permission-denied','只允許建立者刪除本測試版的賽事');
  if(ev.authorityBBX !== 'active')
   throw new HttpsError('failed-precondition','尚未啟用的測試賽事只允許執行失敗後清理');
  await withEventLock(eventId,async()=>{
    // Tombstone prevents any pending publication from creating an orphan.
    const boardRef=db.ref(`${base(eventId)}/board`);
    await boardRef.child('deleted').set(true);
    const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
    const updates={};
    for(const path of ['events','publicEvents','refereeClaims','refereeUsers','refereeSecrets','secrets','admins','authorityBBXV04'])
      updates[`${path}/${eventId}`]=null;
    for(const [slot,value] of Object.entries(slots))if(value===eventId)updates[`userEvents/${uid}/${slot}`]=null;
    await db.ref().update(updates);
  });
  return {ok:true,deleted:true};
 }catch(e){catchError(e)}
});
