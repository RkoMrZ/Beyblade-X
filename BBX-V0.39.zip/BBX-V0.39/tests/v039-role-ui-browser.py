"""v0.39 role UI patch regression at iPhone and desktop widths."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil
src=(Path(__file__).resolve().parents[1]/'assets/index-v039.js').read_text()
fragment=src[src.index('let bracketViewEventId=null;'):src.index('function bracketDefaultScale(){')]
render_fn=src[src.index('function renderAdmin({bracketOnly=false}={}){'):src.index('function renderFinalPlacings(){')]
fixture="""
window.ev={name:'Test',id:'E1',testOnly:false,roster:['A','B','C'],mode:'free',rounds:[],refereeNames:['裁判 1']};
window.isReferee=true;window.isAdmin=false;window.canOwner=false;window.myName='裁判 1';
window.hasOrganizerAccess=()=>canOwner;window.usesThreePlayerFinal=()=>false;
window.getMyReferee=()=>myName;window.esc=s=>String(s);
window.$=id=>document.getElementById(id);window.renderRR=()=>'';window.renderFinalPlacings=()=>'';window.renderBracketMatch=()=>'';window.drawBracketLinks=()=>{};
"""
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 for width in (375,390,768,1366):
  pg=browser.new_page(viewport={'width':width,'height':720})
  pg.set_content('<style>body{height:2600px}</style><div id="bracketTab"></div><div id="organizerTab" class=hidden></div>')
  pg.add_script_tag(content=fixture+'\n'+fragment+'\n'+render_fn+'\nwindow.normalizeEvent=()=>{};window.ensureNext=()=>{};window.applyAccessUI=()=>{};window.bracketViewBeforeRender=()=>null;')
  pg.evaluate("document.getElementById('bracketTab').innerHTML=privateHeroHtml()+'<div class=bracketCanvas></div>';capturePrivateBracket(privateHeroHtml())")
  assert pg.locator('#organizerHeroBtn').count()==0
  assert pg.get_by_text('裁判模式：裁判 1').count()==1
  assert pg.locator('[data-tab-btn="referee"]').count()==1
  pg.evaluate('window.scrollTo(0,500)')
  pg.evaluate("""()=>{canOwner=true;isAdmin=true;patchPrivateBracket()}""")
  assert pg.locator('#organizerHeroBtn').count()==1
  pg.evaluate("""()=>{canOwner=false;isAdmin=false;patchPrivateBracket()}""")
  assert pg.locator('#organizerHeroBtn').count()==0
  assert pg.evaluate('window.scrollY')==500
  # Revoked access while viewing organizer panel must switch back to bracket,
  # even when renderAdmin takes the successful SSE patch early return.
  pg.evaluate("currentAdminTab='organizer';document.getElementById('organizerTab').classList.remove('hidden');document.getElementById('bracketTab').classList.add('hidden');")
  pg.evaluate('renderAdmin({bracketOnly:true})')
  assert pg.evaluate("currentAdminTab==='bracket'")
  assert pg.locator('#organizerTab').evaluate('(el)=>el.classList.contains("hidden")')
  assert not pg.locator('#bracketTab').evaluate('(el)=>el.classList.contains("hidden")')
  print('PASS',width,'referee-only UI; organizer visible only with privilege; scroll preserved')
  pg.close()
 browser.close()
