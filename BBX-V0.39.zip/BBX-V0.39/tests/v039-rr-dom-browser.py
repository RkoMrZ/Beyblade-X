from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil
src=(Path(__file__).resolve().parents[1]/'assets/index-v039.js').read_text()
block=src[src.index('let bracketViewEventId=null;'):src.index('function bracketDefaultScale(){')]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 for w in [375,390,768,1366]:
  page=b.new_page(viewport={'width':w,'height':800})
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content('''<div id="bracketTab"><div class="adminHero">INIT</div><div class="bracketShell"><div class="bracketScroll" style="overflow:auto;width:290px;height:170px"><div class="bracketCanvas"><section class="roundCol"><div class="roundMatches"></div></section><div class="rrPanel"><div class="rrRanks"><div class="rrRankRow">A</div></div><div class="rrGames"><div class="rrMini">0</div><div class="rrMini">0</div><div class="rrMini">0</div></div><div class="rrStatBox"><div class="rrStatRow">A</div></div></div></div></div></div></div>''')
  page.evaluate('''()=>{
   window.$=id=>document.getElementById(id);window.esc=String;
   window.ev={id:'DEMO',name:'Demo',mode:'free',freeFinal:'rr3',roster:['A','B','C'],rounds:[{name:'ROUND',matches:[]}],finalRR:{matches:[{sa:0,sb:0},{sa:0,sb:0},{sa:0,sb:0}]}};
   window.isReferee=false;window.isAdmin=true;window.hasOrganizerAccess=()=>window.isAdmin;window.getMyReferee=()=>'';window.usesThreePlayerFinal=()=>true;window.freeFlowLabel=()=>'';
   window.renderBracketMatch=()=>'';window.renderFinalPlacings=()=>'';window.drawBracketLinks=()=>{};
   window.renderRR=()=>`<div class="rrPanel"><div class="rrRanks"><div class="rrRankRow">A</div></div><div class="rrGames">${ev.finalRR.matches.map(m=>`<div class="rrMini">${m.sa}</div>`).join('')}</div><div class="rrStatBox"><div class="rrStatRow">A</div></div></div>`;
  }''')
  page.add_script_tag(content=block)
  page.evaluate('''()=>{const tab=document.getElementById('bracketTab');tab.querySelector('.adminHero').outerHTML=privateHeroHtml();capturePrivateBracket(privateHeroHtml());
   window.oldCanvas=tab.querySelector('.bracketCanvas');window.oldRr=tab.querySelector('.rrPanel');window.oldGame=tab.querySelectorAll('.rrMini')[1];window.oldScroll=tab.querySelector('.bracketScroll');oldScroll.scrollTop=64;ev.finalRR.matches[0].sa=6;}''')
  assert page.evaluate('patchPrivateBracket()') is True
  assert page.evaluate('document.querySelector(".bracketCanvas")===oldCanvas')
  assert page.evaluate('document.querySelector(".rrPanel")===oldRr')
  assert page.evaluate('document.querySelectorAll(".rrMini")[1]===oldGame')
  assert page.evaluate('document.querySelectorAll(".rrMini")[0].textContent')=='6'
  assert page.evaluate('document.querySelector(".bracketScroll")===oldScroll')
  assert not errs,(w,errs)
  print('PASS',w,'RR score updates only changed row, preserves panel and viewport')
  page.close()
 b.close()
