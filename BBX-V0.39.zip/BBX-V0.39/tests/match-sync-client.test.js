'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync(require('node:path').join(__dirname,'../assets/index-v039.js'),'utf8');
const from=html.indexOf('const v05ScoreQueues=new Map();');
const to=html.indexOf('async function v1CloudMatchCommand(',from);
assert.ok(from>0&&to>from);
const source=html.slice(from,to)+'\n globalThis.scoring={queue:v05QueueScore,flush:v05FlushScores,pending:v05ScorePending,state:v05ScoreState,accept:v05AcceptServerMatch};';
function scenario({fail=false,ackLost=false}={}){
 const match={sa:0,sb:0,matchVersion:1,a:'A',b:'B',refereeActive:true,referee:'裁判 1'};
 const event={id:'B6_test',releaseTag:'BBX-V0.11',rounds:[{matches:[match]}]};
 const persisted={...match};
 const calls=[];let active=0,maxActive=0;
 const scope={Map,Number,Error,console,setTimeout,clearTimeout,ev:event,
  isV1Authority:()=>true,initCloud:async()=>true,V1_AUTH_CLIENT:'bbx-v0.11-authority-1',authorityFnName:(x)=>'bbxV011'+x,authorityClientVersion:()=> 'bbx-v0.11-authority-1',
  makeV1OpId:()=>`test-operation-${calls.length+1}`,
  firebase:{app:()=>({functions:()=>({httpsCallable:()=>async(arg)=>({data:arg.readMatch?
   {found:true,match:{...persisted}}:{found:ackLost,ok:ackLost,matchVersion:persisted.matchVersion}})})})},
  v1Match:()=>match,
  localEventSave:()=>{},renderAdmin:()=>{},backgroundSyncAlert:()=>{},
  v1CloudMatchCommand:async(action,_k,_r,_m,options)=>{
   active++;maxActive=Math.max(maxActive,active);
   await new Promise(resolve=>setTimeout(resolve,30));
   calls.push(options);
   active--;
   if(ackLost){Object.assign(persisted,{sa:options.sa,sb:options.sb,matchVersion:options.expectedMatchVersion+1});throw Error('network response lost');}
   if(fail)throw Error('aborted');
   return {matchVersion:options.expectedMatchVersion+1};
  },
  }; 
 vm.createContext(scope);vm.runInContext(source,scope);
 return {match,calls,scope,scoring:scope.scoring,maxActive:()=>maxActive};
}
test('five points from rapid taps serialize to latest score without concurrent writes',async()=>{
 const c=scenario();
 c.match.sb=1;c.scoring.queue('round',0,0,0);
 await new Promise(resolve=>setTimeout(resolve,8));
 c.match.sb=3;c.scoring.queue('round',0,0,0);
 c.match.sb=5;c.scoring.queue('round',0,0,0);
 await c.scoring.flush('round',0,0);
 assert.equal(c.maxActive(),1);
 assert.equal(c.match.sb,5);
 assert.equal(c.match.matchVersion,3);
 assert.equal(c.calls.length,2);
 assert.deepEqual(c.calls.map(x=>x.expectedMatchVersion),[1,2]);
 assert.equal(c.calls.at(-1).sb,5);
 assert.equal(c.scoring.pending('round',0,0),false);
});
test('completion flushes debounce without discarding unsent fifth point',async()=>{
 const c=scenario();
 c.match.sb=5;c.scoring.queue('round',0,0,250);
 await c.scoring.flush('round',0,0);
 assert.equal(c.calls.length,1);
 assert.equal(c.calls[0].sb,5);
 assert.equal(c.match.matchVersion,2);
});
test('failed score does not become confirmed or silently restart',async()=>{
 const c=scenario({fail:true});
 c.match.sb=5;c.scoring.queue('round',0,0,0);
 await assert.rejects(()=>c.scoring.flush('round',0,0));
 assert.equal(c.calls.length,1);
 assert.equal(c.match.matchVersion,1);
 assert.equal(c.match.sb,0);
 assert.equal(c.scoring.pending('round',0,0),false);
});
test('lost acknowledgement is reconciled using private committed score, not retried',async()=>{
 const c=scenario({ackLost:true});
 c.match.sb=5;c.scoring.queue('round',0,0,0);
 await c.scoring.flush('round',0,0);
 assert.equal(c.calls.length,1,'never repeat a committed score with a new opId');
 assert.equal(c.match.sb,5);
 assert.equal(c.match.matchVersion,2);
 assert.equal(c.scoring.pending('round',0,0),false);
});

test('stale event projection cannot overwrite a newer privately confirmed match',()=>{
 const c=scenario();
 c.match.matchVersion=4;c.match.sb=5;
 assert.equal(c.scoring.accept('round',0,0,{sa:0,sb:0,matchVersion:3}),false);
 assert.equal(c.match.sb,5);
 assert.equal(c.scoring.accept('round',0,0,{sa:0,sb:5,matchVersion:5}),true);
});
test('successful completion avoids unnecessary private GET and drains score first',()=>{
 const start=html.indexOf('async function v1FinishCloud(');
 const end=html.indexOf('async function v1CloudOrganizerCommand(',start);
 assert.ok(start>0&&end>start);
 const body=html.slice(start,end);
 assert.match(body,/await v05FlushScores\(kind,ri,mi\)/);
 assert.match(body,/await v1CloudMatchCommand\('complete'/);
 assert.doesNotMatch(body,/await v05ReadAuthoritativeMatch\(/);
});

test('authoritative refresh advances idle queue version',async()=>{
 const c=scenario();c.match.sb=1;c.scoring.queue('round',0,0,250);await c.scoring.flush('round',0,0);
 c.scoring.accept('round',0,0,{sa:0,sb:2,matchVersion:5});
 c.match.sb=3;c.scoring.queue('round',0,0,250);await c.scoring.flush('round',0,0);
 assert.equal(c.calls.at(-1).expectedMatchVersion,5);
});
test('failed score discards later optimistic taps and restores cloud value',async()=>{
 const c=scenario({fail:true});c.match.sb=1;c.scoring.queue('round',0,0,0);
 await new Promise(r=>setTimeout(r,8));c.match.sb=6;c.scoring.queue('round',0,0,0);
 await assert.rejects(()=>c.scoring.flush('round',0,0));assert.equal(c.match.sb,0);
});
