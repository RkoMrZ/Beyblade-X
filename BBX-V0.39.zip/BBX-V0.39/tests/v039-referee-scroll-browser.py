"""V0.37 iPhone viewport regression: claiming/releasing identity must not jump."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil
js=(Path(__file__).resolve().parents[1]/'assets/index-v039.js').read_text()
start=js.index('function updateRefereePanelHtml(')
end=js.index('function renderShare(){',start)
part=js[start:end]
fixture='''
window.$=id=>document.getElementById(id);
window.ev={id:'E',testOnly:false,refereeCount:2,refereeNames:['裁判 1','裁判 2']};
window.currentAdminTab='referee';window.isAdmin=true;window.isReferee=false;
window.claims={};window.myName='';
window.getRefereeClaim=i=>claims[i]||null;
window.getMyReferee=()=>myName;
window.currentRefereeUid=()=> 'OWNER';window.isMyRefereeClaim=i=>claims[i]?.uid==='OWNER';
window.hasOrganizerAccess=()=>true;window.refereeClaimsConfirmed=()=>true;
window.normalizeEvent=()=>{};window.normalizeRefereeClaims=()=>{};window.esc=s=>String(s);
window.startRefereeCodeRotation=()=>{};window.refereeUrl=()=>'/ref';
window.refreshRefereeClaimsNow=async()=>({});
window.refereeClaimKey=i=>String(i);
'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 for width in (375,390,768,1366):
  page=browser.new_page(viewport={'width':width,'height':700})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content('<style>body{margin:0}.spacer{height:500px}#refereeTab{min-height:1000px}.refCard{padding:8px}.refIdentityRow{margin:20px 0}</style><div class="spacer"></div><main><div id="refereeTab"></div></main><div class="spacer"></div>')
  page.add_script_tag(content=fixture+'\n'+part)
  page.evaluate('renderReferee({skipCloudRefresh:true})')
  page.evaluate('window.scrollTo(0,620)')
  page.wait_for_timeout(50)
  assert page.evaluate('window.scrollY')==620
  page.evaluate('''()=>{
    document.getElementById('refName1').value='未儲存的名稱';
    const qr=document.getElementById('refereeInviteQr');window.originalQr=qr;
    qr.textContent='QR_MUST_REMAIN';
    claims[0]={uid:'OWNER',name:'裁判 1'};myName='裁判 1';
    renderReferee({skipCloudRefresh:true});
  }''')
  page.wait_for_timeout(100)
  assert abs(page.evaluate('window.scrollY')-620)<=1,(width,page.evaluate('window.scrollY'))
  assert page.evaluate('document.getElementById("refName1").value')=='未儲存的名稱'
  assert page.evaluate('document.getElementById("refereeInviteQr")===window.originalQr')
  assert page.evaluate('document.getElementById("refereeInviteQr").textContent')=='QR_MUST_REMAIN'
  assert page.get_by_text('你已領取').count()>=1
  page.evaluate('''()=>{delete claims[0];myName='';renderReferee({skipCloudRefresh:true});}''')
  page.wait_for_timeout(100)
  assert abs(page.evaluate('window.scrollY')-620)<=1
  assert page.evaluate('document.getElementById("refereeInviteQr")===window.originalQr')
  assert page.evaluate('document.getElementById("refName1").value')=='未儲存的名稱'
  assert not errors,(width,errors)
  print('PASS',width,'organizer claim/release preserved viewport, edited input, QR node')
  page.close()
 browser.close()
