# Beyblade X Tournament — BBX-V0.39

基準：BBX-V0.38（使用者實測）。只改 Hosting 前端的角色 UI 呈現與 SSE 局部更新時的權限顯示回歸。

## 問題
裁判模式（通常匿名 Auth）透過 SSE 收到賽事更新後，`patchPrivateBracket()` 直接取代 `.adminHero`，但未套用 `applyAccessUI()`；此外 `renderAdmin({bracketOnly:true})` 在局部更新回退為整表重繪時也會跳過 `applyAccessUI()`。因此畫面會錯誤顯示「主辦」按鈕，雖然 `showTab()` 和雲端命令仍有權限判斷。

## 修正
1. 主辦按鈕在 `privateHeroHtml()` 內依 `hasOrganizerAccess()` 決定是否存在，不再依賴事後 `hidden` CSS；裁判專用畫面仍保留裁判按鈕。
2. SSE 局部 patch 和 bracketOnly 完整重建都重新執行 `applyAccessUI()`。
3. 如果主辦權限消失，退回對戰表，不讓舊主辦分頁殘留。
4. 追加 Node.js 及 Chromium 角色畫面專項測試（裁判、主辦、再撤權四種寬度）。

**部署僅 Firebase Hosting；不更新 Functions、Rules、舊賽事、比賽權限，也不碰報名系統。** Firebase Auth / Functions SDK 仍用於身份與雲端命令，RTDB SDK 長連線依舊不載入。Cloud Shell 部署前仍須經 Rules Emulator 回歸；Safari/Chrome 多手機現場驗收尚需執行。
