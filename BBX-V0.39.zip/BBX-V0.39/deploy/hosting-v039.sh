#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.39 ]] || { echo 'STOP: wrong version';exit 2; }
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: wrong project';exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v039-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight not complete';exit 3; }
P=ljt-beyblade-x;SITE=bbxs-tamsui
firebase hosting:sites:get "$SITE" --project "$P" >/dev/null
# hosting-public is generated; clear only this release's staging directory.
rm -rf hosting-public;mkdir -p hosting-public/assets
cp -f index.html viewer.html hosting-public/
cp -f assets/index-v039-????????????.css assets/index-v039-????????????.js assets/viewer-v039-????????????.css assets/viewer-v039-????????????.js hosting-public/assets/
python3 - <<'PY_H'
from pathlib import Path
import hashlib,re
for page in ('index','viewer'):
 s=Path(page+'.html').read_text()
 refs=re.findall(r'assets/'+page+r'-v039-[0-9a-f]{12}\.(?:js|css)',s)
 assert len(refs)==2,(page,refs)
 for asset in refs:
  target=Path('hosting-public')/asset
  assert target.is_file() and target.read_bytes()==Path(asset).read_bytes(),asset
print('PASS: clean Hosting stage and exact assets')
PY_H
firebase deploy --only hosting --config firebase.hosting.json --project "$P" --non-interactive
for attempt in 1 2 3 4 5 6; do
 f=$(mktemp)
 if curl --fail --location --silent --show-error --max-time 15 -H 'Cache-Control: no-cache' "https://${SITE}.web.app/" -o "$f" && cmp -s index.html "$f";then rm -f "$f";break;fi
 rm -f "$f"
 if [[ "$attempt" == 6 ]];then echo 'STOP: live HTML mismatch';exit 4;fi
 sleep 3
done
asset=$(grep -o 'assets/index-v039-[0-9a-f]\{12\}\.js' index.html | head -1)
[[ -n "$asset" ]] || { echo 'STOP: JS asset not found';exit 4; }
f=$(mktemp);curl --fail --location --silent --show-error --max-time 20 "https://${SITE}.web.app/$asset" -o "$f"
cmp -s "$asset" "$f" || { rm -f "$f";echo 'STOP: live JS mismatch';exit 4; }
rm -f "$f"
echo 'PASS: BBX-V0.39 live HTML and version-fingerprinted JS verified'
