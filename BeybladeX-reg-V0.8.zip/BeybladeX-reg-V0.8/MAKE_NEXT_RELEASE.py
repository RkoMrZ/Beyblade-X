#!/usr/bin/env python3
raise SystemExit('SAFE STOP: Live registrations must be preserved. Do not automatically rename API/data namespaces. Keep V06 compatibility, cleanup history and old-client refresh handling; validate a separate future release before deployment.')
