#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
bash 06_source_guard.sh
firebase deploy --only hosting --project ljtreg-39954 --non-interactive
