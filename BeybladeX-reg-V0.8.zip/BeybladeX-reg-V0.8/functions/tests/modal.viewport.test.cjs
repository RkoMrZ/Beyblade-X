const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const code=fs.readFileSync(__dirname+'/../../web/js/common.js','utf8');
function harness(withViewport=true){
 const target=()=>{const handlers=new Map();return {handlers,addEventListener:(n,f)=>{if(!handlers.has(n))handlers.set(n,new Set());handlers.get(n).add(f)},removeEventListener:(n,f)=>handlers.get(n)?.delete(f),emit(n){for(const f of handlers.get(n)||[])f()}}};
 const style=()=>({getPropertyValue(p){return this[p]||''},getPropertyPriority(){return ''},setProperty(p,v){this[p]=v},removeProperty(p){delete this[p]}});
 const classes=new Set(['hide']),overlay={style:style(),tagName:'DIV',classList:{add:x=>classes.add(x),remove:x=>classes.delete(x)}};
 const main={tagName:'MAIN',inert:false},header={tagName:'HEADER',inert:false},panel={focus(){},innerHTML:'',scrollTop:0};
 const body={style:style(),children:[main,header,overlay]},raf=new Map();let next=0;
 const win=Object.assign(target(),{visualViewport:Object.assign(target(),{offsetTop:0,offsetLeft:0,width:390,height:700}),innerWidth:390,innerHeight:800,scrollX:0,scrollY:1280,scrollTo(v){this.restored=v}});
 if(!withViewport)delete win.visualViewport;
 const ctx={AbortController,fetch:async()=>({ok:true,json:async()=>null}),setTimeout,clearTimeout,window:win,document:{readyState:'loading',addEventListener(){},body,documentElement:{dataset:{}},activeElement:{matches:()=>false,isConnected:true,focus(){}}},localStorage:{getItem:()=>null},requestAnimationFrame:f=>{raf.set(++next,f);return next},cancelAnimationFrame:k=>raf.delete(k)};
 vm.createContext(ctx);vm.runInContext(code,ctx);
 return {win,body,overlay,main,header,panel,controller:win.BBX.createModalViewport(overlay,panel),flush(){const work=[...raf.values()];raf.clear();work.forEach(f=>f())},listeners(){return [...win.handlers.values(),...(win.visualViewport?.handlers.values()||[])].reduce((n,s)=>n+s.size,0)-3}};
}
test('scroll is locked, visual viewport offsets/resizes applied, and close restores original position',()=>{
 const h=harness();h.controller.open('狀態');h.flush();assert.equal(h.body.style.top,'-1280px');assert.equal(h.main.inert,true);
 Object.assign(h.win.visualViewport,{offsetTop:78,offsetLeft:12,height:380,width:350});h.win.visualViewport.emit('resize');h.win.visualViewport.emit('scroll');h.flush();
 assert.equal(h.overlay.style.top,'78px');assert.equal(h.overlay.style.left,'12px');assert.equal(h.overlay.style.height,'380px');
 h.controller.close();assert.equal(h.main.inert,false);assert.equal(h.body.style.position,undefined);assert.equal(h.win.restored.top,1280);assert.equal(h.listeners(),0);
});
test('repeated open/close does not leak listeners or overwrite original scroll/styles',()=>{
 const h=harness();h.body.style.position='relative';h.header.inert=true;
 for(let i=0;i<30;i++){h.controller.open('A');h.flush();const n=h.listeners();h.controller.open('B');assert.equal(h.listeners(),n);h.controller.close();h.flush();assert.equal(h.listeners(),0);assert.equal(h.body.style.position,'relative');assert.equal(h.header.inert,true);assert.equal(h.win.restored.top,1280)}
});
test('fallback without VisualViewport stays usable and closing cancels pending resize frame',()=>{
 const h=harness(false); // separate context with no VisualViewport
 h.controller.close();h.controller.open('A');assert.equal(h.overlay.style.height,'800px');h.controller.close();h.flush();assert.equal(h.overlay.style.top,undefined);
});
