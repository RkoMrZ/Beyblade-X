#!/usr/bin/env python3
from browser_support import html_assets,browser_options
"""Offline browser test of Firebase Hosting short routes (without network access)."""
import re
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
host='https://bbxr-tamsui.web.app'
seed=r'''(() => {
 window.__hits=[];window.__streams=[];
 window.__backend={meta:{title:'短碼測試盃',eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'體育館',fee:0,capacity:2,open:true,version:1},rows:{p00000001:{signupNo:1,playerName:'示例選手',phone3:'093',status:'approved',recordVersion:1}}};
 window.initializeApp=()=>({});window.getAuth=()=>({});window.GoogleAuthProvider=class{};
 window.onAuthStateChanged=(_,cb)=>setTimeout(()=>cb({uid:'host-test',getIdToken:async()=> 'mock-token'}),0);
 window.signInWithPopup=async()=>{};window.signOut=async()=>{};
 window.EventSource=class{constructor(url){this.url=url;window.__streams.push(this)}close(){}addEventListener(){}};
 window.fetch=async (input,options={})=>{
   const u=new URL(String(input));const path=u.pathname.replace(/^\//,'').replace(/\.json$/,'');window.__hits.push(path);
   let body=null;if(path==='eventsV06/ABCDE/meta')body=__backend.meta;
   else if(path==='publicRowsV06/ABCDE')body=__backend.rows;
   else if(path==='syncV06/ABCDE')body={token:'one',lastChange:''};
   else if(path==='ownerEventsV06/host-test')body={ABCDE:{title:'短碼測試盃',eventDate:'2026-11-01',capacity:2}};
   else if(path==='managerRowsV06/ABCDE')body={p00000001:{lineName:'私密資料'}};
   else if(/^ownerEventsV0[345]\//.test(path)||path==='registrationServiceState')body=null;else throw Error('Unexpected offline request: '+path);
   return new Response(JSON.stringify(body),{status:200});
 }
})()'''
def content(filename,virtual_path):
 body=html_assets(root/'reg',filename)
 if filename=='index.html':body=re.sub(r'^import .*?;\s*','',body,flags=re.M).replace('<script type="module">','<script>')
 # The sandbox browser blocks real HTTP navigations. Replace pathname just in the test
 # representation, preserving the real production source unchanged.
 body=body.replace('location.pathname.match(', 'window.__mockPath.match(')
 return '<script>window.__mockPath='+repr(virtual_path)+';</script>'+body
with sync_playwright() as pw:
 browser=pw.chromium.launch(**browser_options())
 context=browser.new_context(viewport={'width':390,'height':800});context.add_init_script(seed)
 p=context.new_page();p.set_content(content('signup.html','/s/ABCDE'))
 p.wait_for_function("document.querySelector('#title').textContent.includes('短碼測試盃')")
 assert p.evaluate('eid')=='ABCDE'
 assert p.locator('#statusLink').get_attribute('href')==host+'/q/ABCDE'
 print('PASS /s/ABCDE: signup parses 5-char path, renders event, provides /q/ query URL')
 p=context.new_page();p.set_content(content('status.html','/q/ABCDE'))
 p.wait_for_function("document.querySelector('#rows').textContent.includes('示例選手')")
 assert p.evaluate('eid')=='ABCDE'
 print('PASS /q/ABCDE: public query parses 5-char path, loads matching roster')
 p=context.new_page();p.set_content(content('index.html','/'))
 p.wait_for_function("document.querySelector('#events').textContent.includes('短碼測試盃')")
 p.locator('[data-manage]').click();p.wait_for_function("document.querySelector('#copyLink')!==null")
 assert p.evaluate('eid')=='ABCDE'
 print('PASS /: manager accepts 5-char event code and renders management controls')
 context.close();browser.close()
