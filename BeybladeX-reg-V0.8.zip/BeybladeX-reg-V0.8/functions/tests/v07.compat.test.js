'use strict';
// In-memory deterministic simulation, NOT real Firebase Emulator or pressure testing.
const assert=require('node:assert/strict'),Module=require('node:module'),path=require('node:path');
const state={},clone=x=>x===undefined?undefined:structuredClone(x);let q=Promise.resolve(),pushNo=0,failRootUpdate=null,nullOnlyTransactions=0;const activeListeners=new Map();
const keys=p=>String(p).split('/').filter(Boolean);
const get=p=>clone(keys(p).reduce((c,k)=>c?.[k],state));
function set(p,v){const a=keys(p);if(!a.length)throw Error('root');let cur=state;for(const k of a.slice(0,-1))cur=cur[k]??={};if(v===null||v===undefined)delete cur[a.at(-1)];else cur[a.at(-1)]=clone(v)}
function snap(v){return {val:()=>clone(v),exists:()=>v!==null&&v!==undefined,hasChild:k=>v!=null&&Object.hasOwn(v,k),numChildren:()=>Object.keys(v||{}).length}}
function ref(p=''){return {
 orderByKey(){const rows=()=>Object.entries(get(p)||{}).sort(([a],[b])=>a.localeCompare(b));return {
  limitToFirst:n=>({get:async()=>snap(Object.fromEntries(rows().slice(0,n)))}),
  limitToLast:n=>({get:async()=>snap(Object.fromEntries(rows().slice(-n)))}),
  endAt:k=>({get:async()=>snap(Object.fromEntries(rows().filter(([key])=>key<=k)))})
 }},
 child:k=>ref(p+'/'+k),push(){return {key:'-chg'+String(++pushNo).padStart(16,'0')}},async get(){return snap(get(p))},
 on(type,callback){assert.equal(type,'value');const listeners=activeListeners.get(p)||new Set();listeners.add(callback);activeListeners.set(p,listeners);queueMicrotask(()=>callback(snap(get(p))));return callback},
 off(type,callback){const listeners=activeListeners.get(p);if(listeners){listeners.delete(callback);if(!listeners.size)activeListeners.delete(p)}},
 async update(up){
 const failure=p===''?failRootUpdate:null;
 if(failure){failRootUpdate=null;if(failure==='before')throw Error('injected: server rejected before commit')}
 // RTDB multi-location update is atomic; the fake must preserve that property.
 const backup=clone(state);
 try{for(const [k,v] of Object.entries(up))set(p?(p+'/'+k):k,v)}catch(e){for(const k of Object.keys(state))delete state[k];Object.assign(state,backup);throw e}
 if(failure==='after')throw Error('injected: response lost after server commit');
 },transaction(fn){const job=q.then(()=>{const cur=get(p)??null;
 if(cur!==null&&!activeListeners.has(p)){
  // Model RTDB cold cache: aborting the speculative null means no server retry.
  const guess=fn(null);if(guess===undefined)return {committed:false,snapshot:snap(cur)};
 }
 const output=fn(clone(cur));if(output===undefined)return {committed:false,snapshot:snap(cur)};set(p,output);return {committed:true,snapshot:snap(output)}});q=job.catch(()=>{});return job}}}

class HttpsError extends Error{constructor(code,message){super(message);this.code=code}}
const load=Module._load;
Module._load=function(id,parent,main){if(id==='firebase-functions/v2/https')return {onCall:(_,f)=>f,HttpsError};if(id==='firebase-admin/app')return {initializeApp:()=>{},getApps:()=>[{}]};if(id==='firebase-admin/database')return {getDatabase:()=>({ref})};return load.apply(this,arguments)};
const previous=require('../compat_v06_baseline.cjs');
const api=require(path.join(__dirname,'../index.js'));Module._load=load;
const owner={auth:{uid:'owner',token:{firebase:{sign_in_provider:'google.com'}}}},other={auth:{uid:'other',token:{firebase:{sign_in_provider:'google.com'}}}},guest={auth:null};
let cid=0;const call=(n,data,as=owner)=>api[n]({...as,data:{...data,...(n==='regV06CreateEvent'&&!data.createId?{createId:(++cid).toString(16).padStart(48,'0')}:{}),clientVersion:'V0.7'}});
(async()=>{
 const event={title:'既有真實活動樣本',eventDate:'2020-01-01',checkinTime:'09:00',startTime:'10:00',venue:'原場地',fee:300,capacity:1,createId:'a'.repeat(48)};
 const {eid}=await previous.regV06CreateEvent({...owner,data:event});
 const person={eid,rid:'b'.repeat(48),playerName:'舊版選手',phone3:'123',lineName:'原LINE'};
 await previous.regV06Submit({...guest,data:person});
 const before=structuredClone(state);
 assert.equal(get(`eventsV06/${eid}/meta/signupClosesAt`),undefined);
 assert.equal((await call('regV06CreateEvent',event)).eid,eid,'old createId replays same URL');
 assert.deepEqual(get(`publicRowsV06/${eid}`),before.publicRowsV06[eid]);
 assert.deepEqual(get(`privateRowsV06/${eid}`),before.privateRowsV06[eid]);
 assert.deepEqual(get(`eventsV06/${eid}`),before.eventsV06[eid]);
 assert.equal((await call('regV06Submit',{...person,rid:'c'.repeat(48),playerName:'新版繼續報名'},guest)).signupNo,2);
 await call('regV06Review',{eid,key:'p00000001',status:'rejected',expectedVersion:1});
 assert.equal((await call('regV06MyRank',{eid,rid:'c'.repeat(48)},guest)).rankLabel,'正選#1');
 const surviving=await previous.regV06CreateEvent({...other,data:{...event,createId:'d'.repeat(48)}});
 const sibling=structuredClone(get(`eventsV06/${surviving.eid}`));
 await assert.rejects(call('regV06DeleteEvent',{eid},other),{code:'permission-denied'});
 // Seed redundant historical lifecycle entries for this V06 event, not another schema.
 const manifest=require('../cleanup_manifest');
 for(const root of manifest.registry.lifecycleRoots)set(`${root}/V06/${eid}`,get(`eventLifecycleV06/V06/${eid}`));
 for(const root of manifest.registry.cleanupReceiptRoots)set(`${root}/V06/${eid}`,{ownerUid:'owner'});
 failRootUpdate='before';await assert.rejects(call('regV06DeleteEvent',{eid}),/injected/);
 await call('regV06DeleteEvent',{eid});
 const all=manifest.completeCleanupPaths('V06',eid,'owner');
 for(const p of Object.keys(all))if(!p.startsWith('eventsV06/')&&!p.startsWith('allocV06/'))assert.equal(get(p),undefined,p);
 assert.deepEqual(get(`eventsV06/${surviving.eid}`),sibling);
 assert.deepEqual(get(`allocV06/${eid}`),{deleted:true,open:false});
 assert.equal(Object.keys(get(`eventsV06/${eid}`)).length,4);
 await call('regV06DeleteEvent',{eid});
 await assert.rejects(call('regV06CreateEvent',event),/已刪除/);
 await assert.rejects(call('regV06Submit',{...person,rid:'e'.repeat(48),playerName:'刪後報名'},guest));
 assert.equal(get(`nameClaimsV06/${eid}`),undefined,'deleted form cannot leave a late name claim');
 console.log('PASS V06 -> V07: existing event/code/rows/contacts/createId preserved; legacy form still accepts; owner-only cleanup all business and lifecycle paths; sibling untouched; late submit cannot leave name claim');
 const future={...event,eventDate:'2099-11-01',createId:'f'.repeat(48)};
 const fresh=(await call('regV06CreateEvent',future)).eid;
 assert.equal(get(`allocV06/${fresh}/signupClosesAt`),Date.parse('2099-11-01T10:00:00+08:00'));
 const closing=Date.parse('2099-11-01T09:30:00+08:00');
 await call('regV06UpdateEvent',{...future,eid:fresh,signupDeadline:'2099-11-01T09:30',expectedVersion:1});
 assert.equal(get(`allocV06/${fresh}/signupClosesAt`),closing);
 await assert.rejects(call('regV06UpdateEvent',{...future,eid:fresh,signupDeadline:'2099-02-30T09:30',expectedVersion:2}),/截止/);
 await assert.rejects(call('regV06UpdateEvent',{...future,eid:fresh,signupDeadline:'2099-11-01T11:30',expectedVersion:2}),/截止/);
 const oldNow=Date.now;
 Date.now=()=>closing-1;
 const replay={...person,eid:fresh,rid:'1'.repeat(48),playerName:'截止前'};
 await call('regV06Submit',replay,guest);
 Date.now=()=>closing;
 await assert.rejects(call('regV06Submit',{...replay,rid:'2'.repeat(48),playerName:'截止後'},guest),/截止/);
 assert.equal((await call('regV06Submit',replay,guest)).replayed,true,'confirmed retry must not create another slot');
 await call('regV06Review',{eid:fresh,key:'p00000001',status:'approved',expectedVersion:1});
 Date.now=oldNow;
 console.log('PASS deadline: default start time, exact boundary, timezone, malformed date rejected, confirmed retry works, check-in after close works');
 const quotaOwner={auth:{uid:'quota-owner',token:{firebase:{sign_in_provider:'google.com'}}}};
 const attempts=await Promise.allSettled(Array.from({length:8},(_,i)=>call('regV06CreateEvent',{...future,createId:(100+i).toString(16).padStart(48,'0')},quotaOwner)));
 const accepted=attempts.filter(x=>x.status==='fulfilled');
 assert.equal(accepted.length,5,'8 concurrent creates must admit exactly 5');
 assert.equal(attempts.filter(x=>x.status==='rejected'&&x.reason.code==='resource-exhausted').length,3);
 assert.equal(Object.keys(get('ownerEventsV06/quota-owner')).length,5);
 assert.equal(get('registrationCreateGates/quota-owner'),undefined,'successful gate is removed');
 const first=attempts.findIndex(x=>x.status==='fulfilled');
 assert.equal((await call('regV06CreateEvent',{...future,createId:(100+first).toString(16).padStart(48,'0')},quotaOwner)).eid,attempts[first].value.eid,'idempotent retry at cap succeeds');
 await call('regV06SetOpen',{eid:accepted[0].value.eid,open:false,expectedVersion:1},quotaOwner);
 await assert.rejects(call('regV06CreateEvent',{...future,createId:'7'.repeat(48)},quotaOwner),{code:'resource-exhausted'});
 await call('regV06DeleteEvent',{eid:accepted[0].value.eid},quotaOwner);
 await call('regV06CreateEvent',{...future,createId:'7'.repeat(48)},quotaOwner);
 // Pre-upgrade accounts above five keep every form. No retrospective deletion.
 const grandfather={auth:{uid:'existing-six',token:{firebase:{sign_in_provider:'google.com'}}}};
 const existingSix=[];
 for(let i=0;i<6;i++)existingSix.push(await previous.regV06CreateEvent({...grandfather,data:{...future,createId:(200+i).toString(16).padStart(48,'0')}}));
 const preserved=structuredClone(get('ownerEventsV06/existing-six'));
 await assert.rejects(call('regV06CreateEvent',{...future,createId:'8'.repeat(48)},grandfather),{code:'resource-exhausted'});
 assert.deepEqual(get('ownerEventsV06/existing-six'),preserved);
 assert.equal((await call('regV06CreateEvent',{...future,createId:(200).toString(16).padStart(48,'0')},grandfather)).eid,existingSix[0].eid);
 const legacyOwner={auth:{uid:'legacy-quota',token:{firebase:{sign_in_provider:'google.com'}}}};
 set('ownerEventsV05/legacy-quota',{AAAAA:{title:'old1'},AAAAB:{title:'old2'},AAAAC:{title:'old3'},AAAAD:{title:'old4'},AAAAE:{title:'old5'}});
 await assert.rejects(call('regV06CreateEvent',{...future,createId:'9'.repeat(48)},legacyOwner),{code:'resource-exhausted'});
 assert.equal(get('ownerEventsV06/legacy-quota'),undefined);
 console.log('PASS quota: 8 parallel creates -> 5 accepted; same-request retry at cap; closed counts; deletion frees slot; existing six preserved; legacy forms counted; account gate released');
 const beforeOldClient=structuredClone(state);
 await assert.rejects(api.regV06CreateEvent({...owner,data:future}),/重新整理/);
 assert.deepEqual(state,beforeOldClient,'old client rejects before writes');
 console.log('PASS old client: refresh message without modifying data');
 set('registrationServiceState/active',true);
 const frozen=structuredClone(state);
 for(const name of Object.keys(api))await assert.rejects(call(name,{eid:fresh}),{code:'unavailable'});
 assert.deepEqual(state,frozen,'maintenance: every endpoint rejects without any write');
 set('registrationServiceState/active',false);
 await call('regV06Review',{eid:fresh,key:'p00000001',status:'approved',expectedVersion:2});
 console.log('PASS maintenance: all ten existing V06 endpoints blocked; no mutation; recovery works');
})().catch(e=>{console.error(e);process.exitCode=1});
