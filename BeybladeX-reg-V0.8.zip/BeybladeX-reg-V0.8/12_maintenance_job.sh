#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
umask 077
exec > >(tee maintenance-operation.log) 2>&1
exec 9>.maintenance-job.lock
flock -n 9 || exit 3
rm -f .maintenance-job-ok
source "$HOME/.nvm/nvm.sh" && nvm use 22 && bash 09_maintenance.sh "$1"
rc=$?
[ "$rc" -ne 0 ] || date -u > .maintenance-job-ok
printf 'MAINTENANCE_JOB_EXIT_CODE=%s\n' "$rc"
exit "$rc"
