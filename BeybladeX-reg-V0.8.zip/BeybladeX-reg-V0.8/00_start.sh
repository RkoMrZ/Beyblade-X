#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
SESSION=reg-v08-release
if ! tmux has-session -t "$SESSION" 2>/dev/null; then
 tmux new-session -d -s "$SESSION" -c "$PWD" 'bash 10_run_release.sh'
fi
if [ -n "${TMUX:-}" ]; then tmux switch-client -t "$SESSION"; else tmux attach-session -t "$SESSION"; fi
