#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
MODE=${1:-status}
case "$MODE" in on|off) ;; status) exec bash 09_maintenance.sh status;; *) echo 'Use on|off|status';exit 2;; esac
SESSION=reg-v08-maintenance
if tmux has-session -t "$SESSION" 2>/dev/null; then
 dead=$(tmux display-message -p -t "$SESSION" '#{pane_dead}')
 prior=$(cat .maintenance-last-mode 2>/dev/null || true)
 if [ "$dead" = 1 ] && { [ "$prior" != "$MODE" ] || [ ! -f .maintenance-job-ok ]; }; then
  printf '%s' "$MODE" > .maintenance-last-mode
  tmux respawn-pane -k -t "$SESSION" "bash 12_maintenance_job.sh $MODE"
 fi
else
 printf '%s' "$MODE" > .maintenance-last-mode
 tmux new-session -d -s "$SESSION" -c "$PWD"
 tmux set-option -w -t "$SESSION" remain-on-exit on
 tmux respawn-pane -k -t "$SESSION" "bash 12_maintenance_job.sh $MODE"
fi
if [ -n "${TMUX:-}" ]; then tmux switch-client -t "$SESSION"; else tmux attach-session -t "$SESSION"; fi
