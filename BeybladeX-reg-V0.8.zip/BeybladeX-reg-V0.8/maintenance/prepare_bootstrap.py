from pathlib import Path
import shutil,json
r=Path(__file__).resolve().parents[1]
d=r/'.bootstrap-functions'
d.mkdir(exist_ok=True)
for name in ['package.json','package-lock.json','cleanup_manifest.js','cleanup_registry.json']:
 shutil.copy2(r/'functions'/name,d/name)
s=(r/'functions/compat_v06_baseline.cjs').read_text()
s=s.replace('const api=handler=>onCall(settings,handler);', """const api=handler=>onCall(settings,async req=>{
 if((await db.ref('registrationServiceState/active').get()).val()===true)
  throw new HttpsError('unavailable','系統維修中，請稍後再試',{maintenance:true});
 return handler(req);
});""")
assert "registrationServiceState/active" in s
(d/'index.js').write_text(s)
c=json.loads((r/'firebase.json').read_text());c['functions'][0]['source']='.bootstrap-functions'
(r/'.firebase-bootstrap.json').write_text(json.dumps(c))
