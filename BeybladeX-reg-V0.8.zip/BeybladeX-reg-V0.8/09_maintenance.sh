#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
INSTANCE=ljtreg-39954-default-rtdb
case "${1:-status}" in
 on)
  [ -f .release-completed ] || { echo 'STOP: complete V0.8 Hosting deployment first'; exit 2; }
  # Successful V0.8 release already verified the V0.7 completion evidence.
  sha256sum -c FILE_SHA256.txt >/dev/null
  tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
  printf 'true\n' > "$tmp"
  firebase database:set /registrationServiceState/active "$tmp" --force --project "$PROJECT" --instance "$INSTANCE"
  firebase deploy --only hosting --config firebase.maintenance.json --project "$PROJECT" --non-interactive
  echo 'MAINTENANCE_ON: new operations blocked; already accepted operations may finish.'
  ;;
 off)
  [ -f .release-completed ] || { echo "STOP: complete V0.8 08_release.sh before reopening"; exit 2; }
  # Resume only after the actual app assets are live and verified.
  bash 07_deploy_hosting.sh
  python3 maintenance/verify_hosting.py
  tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
  printf 'false\n' > "$tmp"
  firebase database:set /registrationServiceState/active "$tmp" --force --project "$PROJECT" --instance "$INSTANCE"
  echo MAINTENANCE_OFF
  ;;
 status) firebase database:get /registrationServiceState --project "$PROJECT" --instance "$INSTANCE";;
 *) echo 'Usage: bash 09_maintenance.sh on|off|status'; exit 2;;
esac
