#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
source "$HOME/.nvm/nvm.sh" && nvm use 22 && bash 08_release.sh
rc=$?
printf 'SESSION_EXIT_CODE=%s\n' "$rc"
exec bash
