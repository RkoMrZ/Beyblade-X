#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.14 ]] || { echo 'STOP: wrong V0.14 directory'; exit 2; }
[[ "$(gcloud config get-value project 2>/dev/null)" == 'ljt-beyblade-x' ]] || { echo 'STOP: wrong Firebase project'; exit 2; }
python3 - <<'PY_VERIFY'
import json,hashlib,re
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.14' and m['firebase_project']=='ljt-beyblade-x'
assert m['hosting_site']=='bbxs-tamsui' and len(m['functions_exports'])==9
for f in m['files']:
 raw=Path(f['path']).read_bytes()
 assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256'],f['path']
# Rules and all other back-end source must be byte-identical to V0.13.
for file,digest in m['untouched_backend_hashes'].items():
 assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==digest,file
idx=Path('functions/index.js').read_text()
assert 'async function finalizeVerifiedDeletion(' in idx
assert 'await D.verifyCleanup(db,paths)' in idx
assert 'await assertReservationOwnedOrEmpty(eventId,code)' in idx
for page in ('index.html','viewer.html'):
 s=Path(page).read_text()
 for kind in ('js','css'):
  assets=re.findall(r'assets/(?:index|viewer)-v014-[0-9a-f]{12}\.'+kind,s)
  assert len(assets)==1,(page,kind,assets)
  asset=Path(assets[0]);prefix=asset.stem.split('-')[-1]
  assert hashlib.sha256(asset.read_bytes()).hexdigest().startswith(prefix),asset
print('PASS: manifest + historical back-end integrity + V0.14 immutable assets')
PY_VERIFY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required'; exit 3; }
for f in functions/*.js assets/*.js; do node --check "$f"; done
node --test tests/*.test.js
python3 tests/check_static.py
python3 tests/check_rules_syntax.py
python3 tests/check_cleanup_rules.py
python3 deploy/merge-rules.py docs/previous-v09-rules.json /tmp/bbx-v014-test-merge.json
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI missing'; exit 4; }
# No production DB data is accessed by Emulator; demo-* project is mandatory.
npm ci --prefix tests --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v011 --config firebase.json 'cd tests && node rules-emulator.test.cjs'
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v014-preflight-ok"
echo 'PASS: BBX-V0.14 back-end deletion compatibility and RTDB Emulator tests'
