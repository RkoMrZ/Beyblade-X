# BBX-V0.14｜跨版本賽事完整刪除（候選測試版）

## 真正版本模型
V0.12、V0.13、V0.14 為網站交付版本，雲端新賽事沿用 V0.11 權威協定：`events/{eventId}/releaseTag = BBX-V0.11`。
**不能**因為網站版本變了就把既有 event.releaseTag 直接改成新版字串；否則裁判、公開 SSE、歷史資料讀寫會被現有 Cloud Functions 拒絕。

## 刪除規則
原 Google 建立者在 V0.14 刪除時，根據不可變 eventId 及其實際 releaseTag 驗證，從永久累積清理清單與個別登記記錄所有已知歷史節點；不修改其他賽事、其他 UID 索引、帳號層建立鎖。
先標記 deleting、沿用舊版同賽事鎖並阻斷新寫入；原子刪除並逐項讀回，確認全部不存在後才清除五碼 reservation。
成功後 registry 壓縮成 `{status:'deleted',verified:true}` 的極小防重播標記。因 CREATE eventId 以 uid+opId 決定，若完全移除這個標記，舊 CREATE 操作重播會重新建立原已刪除的賽事。

已經被舊版刪除的存根不在這次部署時自動清除；需先核對 verified、清理路徑、code 映射及可能重用狀態，不能以只看到 status=deleted 就批次刪除。未完成刪除仍保留完整 registry 供主辦續刪。

## 部署範圍
部署 **bbxV011DeleteAuthority** 一支 Cloud Function 和 `bbxs-tamsui` Hosting。其他八支 Functions、RTDB Rules、現有三場賽事、獨立報名系統一律不修改。
部署前必須通過 manifest/Node.js 22/全套 Node 回歸測試、Rules 語法與合併檢查，及 Firebase Realtime Database Emulator 權限測試。Emulator 不會連接正式 DB。

## 實機驗收尚未完成
V0.13 建立的賽事跨版刪除、同碼重用、iPhone Safari、Android Chrome、PC 等，尚未在真實網站驗收；不要把自動模擬當成實機通過。不要使用正式賽事當測試刪除樣本。
