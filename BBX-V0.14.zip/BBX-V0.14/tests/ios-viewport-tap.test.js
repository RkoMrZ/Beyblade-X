const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const js=fs.readFileSync(path.join(root,'assets/index-v014.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/index-v014.css'),'utf8');
function geometry(){
 const match=js.match(/function bbxOverlayViewportGeometry\([^]*?\n}\nfunction syncAppVisualViewport/);
 assert.ok(match,'one geometry function');
 return vm.runInNewContext(match[0].replace(/\nfunction syncAppVisualViewport$/,'')+'\nbbxOverlayViewportGeometry;',{});
}
test('one set of document coordinates across iOS, Android, PC, modal and bracket',()=>{
 assert.match(css,/\.matchModal,\.scorePickerPop,\.resetChoiceModal,\.raffleWinnerModal\{/);
 assert.match(css,/position:absolute;/);
 assert.match(css,/body\.bracketFullscreen \.bracketShell\{\s*position:absolute;/);
 assert.doesNotMatch(css,/--app-vv|bbxIosAbsoluteOverlay|position:fixed !important/);
 assert.match(css,/min-height:44px/);
});
test('visualViewport pageTop is not double-added to offsetTop',()=>{
 const g=geometry();
 assert.deepEqual({...g({pageTop:733,pageLeft:3,width:390,height:642,offsetTop:33},0,700,390,700)}, {top:733,left:3,width:390,height:642});
 assert.deepEqual({...g({pageTop:1490,pageLeft:0,width:390,height:630,offsetTop:60},0,1430,390,700)}, {top:1490,left:0,width:390,height:630});
});
test('fallback geometry for older WebViews and desktop is finite',()=>{
 const g=geometry();
 assert.deepEqual({...g({offsetTop:30,offsetLeft:4,width:375,height:575},2,500,390,700)}, {top:530,left:6,width:375,height:575});
 assert.deepEqual({...g(null,0,400,390,690)}, {top:400,left:0,width:390,height:690});
});
test('position tracks browser toolbar, scroll, orientation, page restore and modal opening',()=>{
 for(const name of ['scroll','resize']) assert.ok(js.includes("visualViewport.addEventListener('"+name+"',queueAppVisualViewportSync"));
 for(const name of ['scroll','resize','orientationchange','pageshow']) assert.ok(js.includes("window.addEventListener('"+name+"',"));
 for(const name of ['openMatchEditor(ri,mi)','openRRMatch(i)','openScorePicker(inputId,buttonId)','openResetChoice(kind,ri,mi)','showRaffleWinnerModal(winner)','toggleBracketFull()']){
  assert.ok(js.includes('function '+name+'{\n  syncAppVisualViewport();'),'synchronized opening '+name);
 }
});
