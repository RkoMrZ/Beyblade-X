#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: deployment already running; read release.log'; exit 3; }
if [ -f .release-completed ];then echo 'PASS: V0.14 release already completed; read release.log';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.14 CROSS-RELEASE DELETE START %s ===\n' "$(date -u '+%FT%TZ')"
date -u > .release-started
bash deploy/BBX-V0.14-檢查.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v014-preflight-ok" 2>/dev/null)" ]] || { echo 'STOP: preflight mismatch';exit 3; }
gcloud auth print-access-token >/dev/null
# Only updated delete authority function; existing judge/score/create Functions are NOT redeployed.
firebase deploy --only functions:bbxV011DeleteAuthority --project ljt-beyblade-x --non-interactive
# Hosting is published only AFTER the new delete function succeeds.
bash deploy/BBX-V0.14-Hosting.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.14 delete Function + Hosting deployed and verified; RTDB Rules and other Functions unchanged.\n'
