#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/deploy/v01-common.sh"
bx_here
printf '====== BeybladeX V0.1 預檢（不刪除、不部署） ======\n'
printf 'Cloud 專案：%s\nRTDB：%s\n' "$BX_PROJECT" "$BX_INSTANCE"
node -v
firebase --version
bx_check_listings
bx_fetch_rules
bx_target
printf '\n===== Node 語法與 24 項測試 =====\n'
node --check functions/index.js
for f in functions/lib/*.js; do node --check "$f"; done
node --test tests/authority-regression.test.js tests/v01-management.test.js
printf '\n預檢通過；下一步：bash 02_clean_v01.sh\n'
