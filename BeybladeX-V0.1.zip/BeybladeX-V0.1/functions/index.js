"use strict";
/* Beyblade X V0.1 — isolated TEST Firebase only. Never auto-delete unrelated resources. */
const {randomBytes,createHash,createCipheriv,createDecipheriv}=require('node:crypto');
const admin=require('firebase-admin');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onValueWritten}=require('firebase-functions/v2/database');
const B=require('./lib/board.js');
const P=require('./lib/publisher.js');
const M=require('./lib/management.js');
const {DomainError}=require('./lib/engine.js');
const PROJECT='ljt-beyblade-x-test';
const DATABASE='https://ljt-beyblade-x-test-default-rtdb.asia-southeast1.firebasedatabase.app';
const ROOT='eventsV01';
const VERSION='V0.1';
const OPT={region:'asia-southeast1',maxInstances:3,timeoutSeconds:45};
const SEC={...OPT,secrets:['BX_LOCK_KEY']};
admin.initializeApp({projectId:PROJECT,databaseURL:DATABASE});
const db=admin.database();
const p=(id)=>`${ROOT}/${id}`;
function guard(){
 const project=process.env.GCLOUD_PROJECT||process.env.GCP_PROJECT||JSON.parse(process.env.FIREBASE_CONFIG||'{}').projectId;
 if(project!==PROJECT)throw new HttpsError('failed-precondition','只允許 V0.1 測試 Firebase 專案');
}
function uid(req,google=false){
 if(req.data?.clientVersion!==VERSION)throw new HttpsError('failed-precondition','網站版本過期，請重新載入 V0.1');
 if(!req.auth?.uid)throw new HttpsError('unauthenticated','請先登入 Firebase');
 if(google&&req.auth.token.firebase?.sign_in_provider!=='google.com')throw new HttpsError('permission-denied','主辦必須使用 Google 登入');
 return req.auth.uid;
}
function eventId(raw){if(!/^[A-Za-z0-9_-]{6,100}$/.test(raw||''))throw new HttpsError('invalid-argument','賽事 ID 錯誤');return raw;}
function error(e){
 if(e instanceof HttpsError)throw e;
 if(e instanceof DomainError)throw new HttpsError(e.code,e.message);
 console.error('V0.1 operation error',e);
 throw new HttpsError('internal','操作回覆尚未確認。請查詢原操作代碼，避免重複提交');
}
function secret(){const x=process.env.BX_LOCK_KEY||'';if(!/^[0-9a-f]{64}$/i.test(x))throw new HttpsError('failed-precondition','未設定 BX_LOCK_KEY');return x;}
function seal(token){
 const iv=randomBytes(12),c=createCipheriv('aes-256-gcm',Buffer.from(secret(),'hex'),iv);
 const payload=Buffer.concat([c.update(token,'utf8'),c.final()]);
 return [iv.toString('hex'),c.getAuthTag().toString('hex'),payload.toString('hex')].join(':');
}
function unpack(result){
 if(!result?.lockTokenBox)return result;
 const [a,b,c]=result.lockTokenBox.split(':');
 const cipher=createDecipheriv('aes-256-gcm',Buffer.from(secret(),'hex'),Buffer.from(a,'hex'));
 cipher.setAuthTag(Buffer.from(b,'hex'));
 const lockToken=Buffer.concat([cipher.update(Buffer.from(c,'hex')),cipher.final()]).toString('utf8');
 const {lockTokenBox,...other}=result;return {...other,lockToken};
}
function ref(id){return db.ref(p(eventId(id)));}
async function publish(id,seq){
 try{const out=await P.drain(db,id,{limit:16});return !out.busy&&out.cursor>=seq;}
 catch(e){console.warn('Publication pending; trigger repairs',id,e.message);return false;}
}
exports.createEventV01=onCall(OPT,async(req)=>{
 try{
  guard();const author=uid(req,true),data=req.data||{};B.validateOpTime(data.opId,Date.now());
  const name=String(data.name||'').trim();if(!name||name.length>70)throw new HttpsError('invalid-argument','賽事名稱錯誤');
  const id=createHash('sha256').update('bx-v01:'+author+':'+data.opId).digest('hex').slice(0,24);
  const board=B.createBoard({...data,ownerUid:author,now:Date.now()});
  const fingerprint=B.hash({name,roster:data.roster,mode:data.mode,freeFinal:data.freeFinal,pairing:data.pairing});
  const body={board,public:B.publicInitial(board,id,name),meta:{name,ownerUid:author,createdAt:Date.now(),fingerprint}};
  const t=await ref(id).transaction(cur=>cur===null?body:undefined,undefined,false);
  if(!t.committed){
   const prior=t.snapshot.val();
   if(prior?.meta?.ownerUid!==author||prior?.meta?.fingerprint!==fingerprint)throw new HttpsError('already-exists','原操作代碼已用於不同賽事');
  }
  await db.ref(`ownerIndexV01/${author}/${id}`).set({name,createdAt:body.meta.createdAt});
  return {ok:true,eventId:id,version:VERSION};
 }catch(e){error(e);}
});
exports.getEventV01=onCall(OPT,async(req)=>{
 try{
  guard();const author=uid(req),id=eventId(req.data?.eventId);
  const [snap,meta]=await Promise.all([ref(id).child('board').get(),ref(id).child('meta/name').get()]);
  return {ok:true,version:VERSION,event:M.staffView(snap.val(),meta.val()||'',id,author)};
 }catch(e){error(e);}
});
exports.getJoinCodeV01=onCall(SEC,async(req)=>{
 try{
  guard();const author=uid(req,true),id=eventId(req.data?.eventId);
  const owner=(await ref(id).child('board/access/ownerUid').get()).val();
  if(owner!==author)throw new HttpsError('permission-denied','只有主辦可以查看驗證碼');
  const now=Date.now();return {ok:true,code:M.rollingCode(secret(),id,now),expiresAt:(Math.floor(now/60000)+1)*60000};
 }catch(e){error(e);}
});
exports.joinEventV01=onCall(SEC,async(req)=>{
 try{
  guard();const author=uid(req),d=req.data||{},id=eventId(d.eventId);
  const code=String(d.code||'');if(!/^\d{6}$/.test(code))throw new HttpsError('invalid-argument','請輸入六位驗證碼');
  let approved=false,reason=null;
  const t=await ref(id).child('board').transaction(cur=>{
   reason=null;try{const r=M.refereeJoin(cur,author,code,id,secret(),Date.now(),d.refereeName);approved=r.approved||r.replay===true;return r.board??undefined;}
   catch(e){reason=e;return undefined;}
  },undefined,false);
  if(reason)throw reason;
  if(t.committed&&!approved)throw new HttpsError('permission-denied','驗證碼錯誤');
  if(!t.committed&&!approved){const ok=(await ref(id).child(`board/access/refereeUsers/${author}`).get()).val()===true;if(!ok)throw new HttpsError('aborted','加入賽事結果尚未確認');}
  return {ok:true,joined:true};
 }catch(e){error(e);}
});
const COMMANDS={claimMatchV01:'claim',scoreMatchV01:'score',completeMatchV01:'complete',releaseMatchV01:'release',resetMatchV01:'reset'};
async function command(req,action){
 guard();const author=uid(req),d=req.data||{},id=eventId(d.eventId),now=Date.now();B.validateOpTime(d.opId,now);
 const token=action==='claim'?randomBytes(24).toString('hex'):null,box=token?seal(token):null;
 let reason=null,replay=null;
 const t=await ref(id).child('board').transaction(cur=>{
  reason=null;replay=null;
  try{const r=B.applyBoard(cur,author,action,d,now,token,box);if(r.replay){replay=r.receipt;return undefined;}return r.board;}
  catch(e){reason=e;return undefined;}
 },undefined,false);
 if(!t.committed){if(reason)throw reason;if(replay)return {...unpack(replay),publicationPending:false};throw new HttpsError('aborted','交易未確認，使用原操作碼查詢');}
 const board=t.snapshot.val(),receipt=board.receipts?.[d.opId]?.result;
 if(!receipt)throw new HttpsError('aborted','操作回條暫不可用');
 const published=await publish(id,receipt.publicSeq);
 if(Object.keys(board.outbox||{}).length>48){try{await P.compactOutbox(db,id,{threshold:32});}catch(e){console.warn('Compact later',e.message);}}
 return {...unpack(receipt),publicationPending:!published};
}
for(const [name,action] of Object.entries(COMMANDS))exports[name]=onCall(action==='claim'?SEC:OPT,async(req)=>{try{return await command(req,action);}catch(e){error(e);}});
exports.getOperationV01=onCall(SEC,async(req)=>{
 try{
  guard();const author=uid(req),d=req.data||{},id=eventId(d.eventId);
  if(!B.validOp(d.opId))throw new HttpsError('invalid-argument','操作代碼錯誤');
  const r=(await ref(id).child(`board/receipts/${d.opId}`).get()).val();
  if(!r)return {ok:true,found:false};
  if(r.uid!==author)throw new HttpsError('permission-denied','無權查看其他使用者的操作結果');
  return {ok:true,found:true,result:unpack(r.result)};
 }catch(e){error(e);}
});
for(const [name,action] of [['setPublicV01','setPublic'],['deleteEventV01','delete']])exports[name]=onCall(OPT,async(req)=>{
 try{
  guard();const author=uid(req,true),d=req.data||{},id=eventId(d.eventId);
  let reason=null,replay=null;
  const t=await ref(id).child('board').transaction(cur=>{
   reason=null;replay=null;
   try{const r=M.administrativeAction(cur,author,{...d,action},Date.now());if(r.replay){replay=r.result;return undefined;}return r.board;}
   catch(e){reason=e;return undefined;}
  },undefined,false);
  if(!t.committed){if(reason)throw reason;if(replay)return replay;throw new HttpsError('aborted','管理操作尚未確認');}
  const result=t.snapshot.val().receipts[d.opId].result;
  const published=await publish(id,result.publicSeq);
  if(action==='delete')await db.ref(`ownerIndexV01/${author}/${id}`).remove();
  return {...result,publicationPending:!published};
 }catch(e){error(e);}
});
exports.publishChangesV01=onValueWritten({ref:`${ROOT}/{eventId}/board/seq`,region:'asia-southeast1',instance:'ljt-beyblade-x-test-default-rtdb',retry:true},async(ev)=>{
 guard();if(!ev.data.after.exists())return;
 const id=eventId(ev.params.eventId),seq=Number(ev.data.after.val())||0;
 const current=(await ref(id).child('public/sync/seq').get()).val()||0;
 if(current>=seq)return;
 const out=await P.drain(db,id,{limit:32});
 if(out.busy||out.cursor<seq)throw Error('Pending publication; Cloud Functions retry');
});
exports.repairPublicationV01=onCall(OPT,async(req)=>{
 try{
  guard();const author=uid(req,true),id=eventId(req.data?.eventId);
  const owner=(await ref(id).child('board/access/ownerUid').get()).val();
  if(owner!==author)throw new HttpsError('permission-denied','只有主辦可要求補發');
  return {ok:true,...await P.drain(db,id,{limit:32})};
 }catch(e){error(e);}
});
