"use strict";
/* Read-only V0.1 viewer. Requires BXSync in same HTML before this script.
 * No score writes, no callable function calls, no private reads.
 */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
  ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"})[c]);
const params = new URLSearchParams(location.search);
const isDemo = params.has("demo");
const eventId = isDemo ? "vnext-demo-24" : (params.get("event") || "");
// V0.1 viewer uses production Firebase and V01 public paths; no direct writes.
const DB = "https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app";
const basePath = `eventsV01/${encodeURIComponent(eventId)}/public`;
const CACHE_KEY = `bx-v01-public-cache-${eventId}`;
const MAX_RETRIES = 2;
let state = BXSync.newCache(eventId);
let data = null;
let scale = 1;
let stream = null;
let generation = 0;
let streamOpen = false;
let highestSeen = null;
let reconcileRunning = false;
let currentSyncRequest = null;
let resumeTimer = null;
let lastResumeAt = 0;
let lastTinyCheckAt = 0;
let persistTimer = null;
let roundObserver = null;
let roundLoading = new Map();
let roundTargets = new Map();
let rrLoading = false;
let frameVersion = "";
let demoData = null;
let demoTimers = [];
let browserReady = false;
let initialMarkerTimer = null;
let initialMarkerReceived = false;
let lastSseFrameAt = 0;
const HEALTHY_STALL_CHECK_MS = 20*60*1000 + Math.random()*5*60*1000;
let userExploredRounds = false;
let lazyScrollBound = false;

function setStatus(message, kind = "") {
  const el = $("status");
  el.textContent = message;
  el.className = "status" + (kind ? " " + kind : "");
}
function loadCache() {
  try {
    const c = JSON.parse(localStorage.getItem(CACHE_KEY) || "null");
    if (BXSync.usableCache(c, eventId, Date.now())) {
      state = c;
      setStatus("先顯示本機公開賽程快取，正在核對雲端版本…");
      renderFrame();
    } else {
      localStorage.removeItem(CACHE_KEY);
    }
  } catch (e) { /* Safari private mode and localStorage disabled */ }
}
function persistCache() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    if (!state.meta || !state.meta.publicOpen) return;
    try {
      state.updatedAt = Date.now();
      localStorage.setItem(CACHE_KEY, JSON.stringify(state));
    } catch (e) { /* cache is optional */ }
  }, 200);
}
function discardCache() {
  try { localStorage.removeItem(CACHE_KEY); } catch (e) {}
}
function syncData() {
  if (!state.meta) { data = null; return; }
  data = {meta: state.meta,
    rounds: (state.meta.rounds || []).map((d, ri) => ({...d,
      matches: state.rounds[ri] ? state.rounds[ri].matches : {}})),
    finalRR: state.finalRR};
}
function urlFor(path, query) {
  const u = new URL(`${DB}/${basePath}/${path}.json`);
  if (query) for (const [k, v] of Object.entries(query)) u.searchParams.set(k, v);
  return u.toString();
}
async function getJson(path, query) {
  if (isDemo) return demoGet(path, query);
  const ctrl = new AbortController();
  const timeout = setTimeout(() => ctrl.abort(), 10000);
  try {
    const r = await fetch(urlFor(path, query), {cache: "no-store", signal: ctrl.signal});
    if (r.status === 401 || r.status === 403) throw new Error("公開連結已關閉、過期或無權限");
    if (!r.ok) throw new Error(`Firebase HTTPS ${r.status}`);
    return await r.json();
  } finally { clearTimeout(timeout); }
}
function validateMeta(meta) {
  return Boolean(meta && meta.id === eventId && meta.appVersion === 'V0.1' &&
    Array.isArray(meta.rounds) && meta.rounds.length <= 16 &&
    meta.rounds.every((r) => Number.isInteger(r.matchCount) && r.matchCount >= 0 && r.matchCount <= 128) &&
    Number(meta.publicUntil) > Date.now() && meta.publicOpen === true);
}
function isClosed(meta) {
  return Boolean(meta && (meta.publicOpen === false || Number(meta.publicUntil) <= Date.now()));
}
function closePublic(reason) {
  state.meta = null;
  state.rounds = {};
  state.finalRR = null;
  discardCache();
  stopStream();
  $("eventView").classList.add("hidden");
  setStatus(reason || "此賽事公開連結已關閉或過期。", "error");
}
async function ensureMeta(force = false) {
  if (!force && validateMeta(state.meta)) return true;
  const latest = await getJson("meta");
  if (!validateMeta(latest)) {
    if (isClosed(latest)) closePublic("賽事公開已結束。");
    else closePublic("無法取得有效的公開賽事資料。");
    return false;
  }
  if (state.meta && state.meta.structureVersion !== latest.structureVersion) {
    state.rounds = {};
    state.finalRR = null;
  }
  state.meta = latest;
  renderFrame();
  persistCache();
  return true;
}
function roundIsVisible(ri) {
  const el = document.querySelector(`.roundCol[data-round="${ri}"]`);
  if (!el) return false;
  const scroll = document.querySelector(".bracketScroll");
  if (!scroll) return false;
  const a = el.getBoundingClientRect(), b = scroll.getBoundingClientRect();
  return a.right > b.left - 240 && a.left < b.right + 240;
}
async function loadRound(ri, force = false) {
  if (!state.meta || !state.meta.rounds[ri]) return;
  if (!force && state.rounds[ri]) return;
  if (roundLoading.has(ri)) return roundLoading.get(ri);
  const run = (async () => {
    try {
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        const fresh = BXSync.normalizeRound(await getJson(`rounds/${ri}`));
        const known = roundTargets.get(ri) || 0;
        if (fresh.revision < known) continue; // Never overwrite a newer SSE delta.
        if (BXSync.shouldReplaceRound(fresh, state.rounds[ri])) state.rounds[ri] = fresh;
        if (fresh.revision >= known) roundTargets.delete(ri);
        syncData();
        renderRound(ri);
        persistCache();
        return;
      }
      throw new Error("場次快照版本落後即時更新");
    } catch (e) {
      setStatus(`第 ${ri + 1} 輪暫時無法同步：${e.message}，可點該輪重試。`, "error");
      renderRound(ri, true);
    }
  })();
  roundLoading.set(ri, run);
  try { await run; } finally { roundLoading.delete(ri); }
}
async function loadRR() {
  if (!state.meta || !state.meta.hasFinalRR || state.finalRR || rrLoading) return;
  rrLoading = true;
  try {
    const rr = await getJson("finalRR");
    if (rr && state.meta) { state.finalRR = rr; syncData(); renderRR(); persistCache(); }
  } catch (e) { setStatus(`循環賽資料暫時無法讀取：${e.message}`, "error"); }
  finally { rrLoading = false; }
}
function observeVisibleRounds() {
  if (roundObserver) { roundObserver.disconnect(); roundObserver = null; }
  const scroll = document.querySelector(".bracketScroll");
  if (!scroll) return;
  if (typeof IntersectionObserver === "undefined") {
    for (let i = 0; i < Math.min(2, state.meta.rounds.length); i++) loadRound(i);
    return;
  }
  roundObserver = new IntersectionObserver((entries) => {
    for (const ent of entries) {
      if (!ent.isIntersecting) continue;
      if (ent.target.dataset.round !== undefined) {
        const ri = Number(ent.target.dataset.round);
        if (ri === 0 || userExploredRounds) loadRound(ri);
      }
      if (ent.target.dataset.rr !== undefined && userExploredRounds) loadRR();
    }
  }, {root: scroll, rootMargin: "0px 32px 0px 32px", threshold: 0});
  document.querySelectorAll(".roundCol[data-round], [data-rr]").forEach((el) => roundObserver.observe(el));
  if (!lazyScrollBound) {
    lazyScrollBound = true;
    scroll.addEventListener("scroll", () => {
      userExploredRounds = true;
      state.meta?.rounds.forEach((_,ri) => { if (roundIsVisible(ri)) loadRound(ri); });
      if (state.meta?.hasFinalRR) {
        const rr = scroll.querySelector("[data-rr]");
        if (rr) { const a=rr.getBoundingClientRect(),b=scroll.getBoundingClientRect();
          if(a.left < b.right + 60 && a.right > b.left - 60) loadRR(); }
      }
    }, {passive: true});
  }
}
function renderFrame() {
  syncData();
  if (!state.meta) return;
  const meta = state.meta;
  const mark = `${meta.id}:${meta.structureVersion}:${meta.rounds.length}`;
  $("eventView").classList.remove("hidden");
  $("pageSub").textContent = "雲端公開賽程・按輪次載入";
  const count = eventCount();
  $("hero").innerHTML = `<div class="muted">🏆 即時賽程（唯讀）</div>
    <h1>${esc(meta.name || "Beyblade X Tournament")}</h1>
    <div class="chips"><span class="chip">👤 ${count} 人</span>
    <span class="chip">${meta.mode === "free" ? "自由編排" : "單淘汰"}</span>
    <span class="chip">${esc(flowLabel())}</span></div>`;
  if (frameVersion !== mark) {
    frameVersion = mark;
    const cols = meta.rounds.map((r, ri) => {
      const l = layout(ri);
      const placeholder = Array.from({length: r.matchCount}, (_, mi) =>
        placeholderMatch(ri, mi)).join("");
      return `<section class="roundCol" data-round="${ri}">
        <div class="roundHead"><h3>${esc(stageLabel(ri, r))}</h3>
        <div class="sub" data-round-info="${ri}">點選或捲動後載入這一輪</div></div>
        <div class="roundMatches" style="--top:${l.top}px;--gap:${l.gap}px">${placeholder}</div>
        <button class="loadRoundButton" type="button" data-load-round="${ri}">載入第 ${ri + 1} 輪</button>
      </section>`;
    }).join("") + (meta.hasFinalRR ? `<section class="rrPanel" data-rr="1">最後三人循環・移動到這裡時載入</section>` : "");
    const canvas = document.querySelector(".bracketCanvas");
    canvas.classList.toggle("compact32", count >= 32 && count < 64);
    canvas.classList.toggle("compact64", count >= 64);
    $("bracketCols").innerHTML = cols;
    $("bracketCols").querySelectorAll("[data-load-round]").forEach((b) => {
      b.onclick = () => loadRound(Number(b.dataset.loadRound), true);
    });
    autoScale();
    observeVisibleRounds();
  }
  meta.rounds.forEach((_, ri) => renderRound(ri));
  renderRR();
  requestAnimationFrame(drawLinks);
}
function placeholderMatch(ri, mi) {
  return `<div class="bracketMatch matchPlaceholder" data-ri="${ri}" data-mi="${mi}">
    <div class="matchNo">第 ${mi + 1} 場</div>
    <div class="placeholderText">尚未載入此輪資料</div></div>`;
}
function renderRound(ri, failed = false) {
  const col = document.querySelector(`.roundCol[data-round="${ri}"]`);
  if (!col || !state.meta || !state.meta.rounds[ri]) return;
  const def = state.meta.rounds[ri], r = state.rounds[ri];
  if (r) {
    col.querySelector(".roundMatches").innerHTML = Array.from({length: def.matchCount}, (_, mi) =>
      r.matches[mi] ? matchHtml(r.matches[mi], ri, mi, def) : placeholderMatch(ri, mi)).join("");
    col.querySelector("[data-round-info]").textContent = `${def.matchCount} 場・已同步`;
    col.querySelector(".loadRoundButton").classList.add("hidden");
  } else {
    col.querySelector("[data-round-info]").textContent = failed ? "讀取失敗・點擊重試" : "等待讀取";
    col.querySelector(".loadRoundButton").classList.remove("hidden");
    col.querySelector(".roundMatches").innerHTML = Array.from({length: def.matchCount}, (_, mi) =>
      placeholderMatch(ri, mi)).join("");
  }
  $("finalBox").innerHTML = finalHtml(rounds());
  requestAnimationFrame(drawLinks);
}
function renderRR() {
  if (!state.meta || !state.meta.hasFinalRR) return;
  const target = $("bracketCols").querySelector("[data-rr]");
  if (!target) return;
  if (!state.finalRR) target.textContent = "👑 最後三人循環・尚未載入";
  else {
    // Preserve the observer target when filling its content.
    const html = rrHtml();
    const tpl = document.createElement("template");
    tpl.innerHTML = html;
    target.replaceChildren(...tpl.content.firstElementChild.childNodes);
  }
  requestAnimationFrame(drawLinks);
}
function updateVisibleAfterDelta(entry, oldState) {
  if (entry.kind === "structure") { frameVersion = ""; renderFrame(); return; }
  if (entry.kind === "meta") { renderFrame(); return; }
  if (entry.kind === "closed") { closePublic("主辦已關閉賽程公開觀看。"); return; }
  syncData();
  if (entry.kind === "match" || entry.kind === "round") {
    if (oldState.rounds[entry.ri] && !state.rounds[entry.ri] && roundIsVisible(entry.ri)) {
      loadRound(entry.ri, true);
    } else if (state.rounds[entry.ri]) renderRound(entry.ri);
  } else if (entry.kind === "rr") renderRR();
}
function acceptEntries(entries, seq) {
  const old = state;
  state = BXSync.replay(state, entries, seq); // commit only after ALL seq are contiguous
  const expanded = entries.filter((e) => e.seq > old.seq && e.seq <= state.seq)
    .flatMap((e) => e.kind === "batch" ? e.items : [e]);
  for (const entry of expanded) {
    if (entry.kind === "match") roundTargets.set(entry.ri,
      Math.max(roundTargets.get(entry.ri) || 0, entry.roundRevision));
  }
  syncData();
  // After replay, render only changed rounds (a few) rather than all 64 matches.
  const changed = expanded;
  const kinds = new Set(changed.map((e) => e.kind));
  if (kinds.has("closed")) { closePublic("主辦已關閉賽程公開觀看。"); return; }
  if (kinds.has("structure")) { frameVersion = ""; renderFrame(); }
  else {
    if (kinds.has("meta")) renderFrame();
    const roundsToRender = new Set(changed.filter((e) => e.kind === "match" || e.kind === "round")
      .map((e) => e.ri));
    for (const ri of roundsToRender) {
      if (state.rounds[ri]) renderRound(ri);
      else if (roundIsVisible(ri)) loadRound(ri, true);
    }
    if (kinds.has("rr")) renderRR();
  }
  persistCache();
}
async function fallBackToVisibleSnapshot(remoteSync, reason) {
  // Missing or too-old change log: refresh ONLY meta + visible rounds.
  const oldMeta = state.meta;
  const oldRounds = Object.keys(state.rounds).map(Number).filter((ri) => roundIsVisible(ri));
  const next = BXSync.newCache(eventId);
  next.seq = remoteSync.seq;
  state = next;
  frameVersion = "";
  roundTargets.clear();
  if (!(await ensureMeta(true))) return;
  const initial = oldRounds.length ? oldRounds : [0];
  await Promise.all(initial.filter((ri) => state.meta.rounds[ri]).slice(0, 3)
    .map((ri) => loadRound(ri, true)));
  setStatus(`已重新校正必要輪次（${reason}），其餘輪次按需載入。`, "ok");
  persistCache();
}
async function readMissingChanges(targetSeq) {
  if (targetSeq - state.seq > BXSync.MAX_CHANGE_PAGE) throw new Error("history too old");
  const raw = await getJson("changes", {orderBy: '"$key"',
    startAt: JSON.stringify(BXSync.seqKey(state.seq + 1)),
    endAt: JSON.stringify(BXSync.seqKey(targetSeq)), limitToFirst: BXSync.MAX_CHANGE_PAGE});
  return BXSync.parseHistory(raw);
}
async function processSync(marker) {
  if (!marker || !Number.isSafeInteger(marker.seq) || marker.seq < 0) throw new Error("invalid sync marker");
  if (marker.publicOpen === false) { closePublic("公開已關閉。"); return; }
  if (marker.seq < state.seq) throw new Error("server sequence appears older than local cache");
  if (marker.seq === state.seq && state.meta &&
      marker.structureVersion !== state.meta.structureVersion) {
    await fallBackToVisibleSnapshot(marker, "結構版本改變");
    return;
  }
  if (!state.meta) {
    state.seq = marker.seq;
    if (await ensureMeta()) startStream();
    return;
  }
  if (marker.seq === state.seq) {
    setStatus("已確認最新公開賽程・即時同步中", "ok");
    return;
  }
  if (marker.seq === state.seq + 1 && marker.last && marker.last.seq === marker.seq) {
    acceptEntries([marker.last], marker.seq);
  } else {
    try {
      const entries = await readMissingChanges(marker.seq);
      acceptEntries(entries, marker.seq);
    } catch (e) {
      await fallBackToVisibleSnapshot(marker, "增量紀錄不完整");
    }
  }
  if (!state.meta) {
    // A structure change invalidates only public view structure; fetch the tiny
    // meta and the first visible round (not the whole event).
    if (await ensureMeta(true)) await loadRound(0, true);
  }
  if (state.meta && !validateMeta(state.meta)) {
    closePublic("公開連結已失效或已過期。"); return;
  }
  if (state.meta) setStatus("已確認最新公開賽程・即時同步中", "ok");
}
function enqueueSync(marker) {
  marker = BXSync.expandMarker(marker);
  if (!marker || !Number.isSafeInteger(marker.seq)) return;
  if (!highestSeen || marker.seq > highestSeen.seq) highestSeen = marker;
  // Keep a single reconciliation flight; new markers are processed on exit.
  if (reconcileRunning) return;
  reconcileRunning = true;
  (async () => {
    try {
      while (highestSeen) {
        const next = highestSeen;
        highestSeen = null;
        await processSync(next);
      }
    } catch (e) {
      setStatus(`同步資料待校正：${e.message}，正在保留唯讀畫面。`, "error");
    } finally {
      reconcileRunning = false;
      if (highestSeen) enqueueSync(highestSeen);
    }
  })();
}
async function checkTinyVersion() {
  if (currentSyncRequest) return currentSyncRequest;
  currentSyncRequest = (async () => {
    lastTinyCheckAt = Date.now();
    try { enqueueSync(await getJson("sync")); }
    catch (e) { setStatus(`目前無法確認最新版本：${e.message}`, "error"); }
    finally { currentSyncRequest = null; }
  })();
  return currentSyncRequest;
}
function stopStream() {
  generation++;
  clearTimeout(initialMarkerTimer);
  initialMarkerTimer = null;
  initialMarkerReceived = false;
  if (stream) { try { stream.close(); } catch (e) {} stream = null; }
  streamOpen = false;
}
function startStream() {
  if (isDemo) { startDemoStream(); return; }
  if (stream || document.visibilityState !== "visible") return;
  if (typeof EventSource === "undefined") {
    // SSE-unavailable browsers use the small HTTP sync check instead.
    checkTinyVersion();
    return;
  }
  const myGen = ++generation;
  const s = new EventSource(urlFor("sync"));
  stream = s;
  let lastSnapshot = null;
  initialMarkerReceived = false;
  // If a proxy silently stalls the initial SSE snapshot, do ONE tiny GET.
  // Healthy streams receive the initial put and never invoke this fallback.
  initialMarkerTimer = setTimeout(() => {
    if (myGen === generation && !initialMarkerReceived) checkTinyVersion();
  }, 12000);
  s.onopen = () => {
    if (myGen !== generation || stream !== s) return;
    streamOpen = true;
    // Firebase SSE sends current sync marker via its initial `put`.
    // Do NOT issue an additional GET from onopen; this doubled requests on
    // every reconnection. Only the existing error/gap paths use HTTP fallback.
    browserReady = true;
  };
  const eventHandler = (type, event) => {
    if (myGen !== generation || stream !== s) return;
    try {
      const msg = JSON.parse(event.data);
      if (!msg || typeof msg.path !== "string") return;
      const path = msg.path.replace(/^\//, "").split("/").filter(Boolean);
      if (type === "put" && path.length === 0) {
        lastSnapshot = msg.data;
        initialMarkerReceived = true;
        clearTimeout(initialMarkerTimer);
        initialMarkerTimer = null;
      }
      else if (!lastSnapshot) { checkTinyVersion(); return; }
      else if (path.length) {
        let obj = lastSnapshot;
        for (let i = 0; i < path.length - 1; i++) {
          if (!obj[path[i]]) obj[path[i]] = {};
          obj = obj[path[i]];
        }
        if (msg.data === null) delete obj[path[path.length - 1]];
        else if (type === "patch" && msg.data && typeof msg.data === "object") {
          obj[path[path.length - 1]] = {...obj[path[path.length - 1]], ...msg.data};
        } else obj[path[path.length - 1]] = msg.data;
      } else if (type === "patch") lastSnapshot = {...lastSnapshot, ...msg.data};
      if (lastSnapshot) { lastSseFrameAt = Date.now(); enqueueSync(lastSnapshot); }
    } catch (e) { checkTinyVersion(); }
  };
  s.addEventListener("keep-alive", () => { lastSseFrameAt = Date.now(); });
  s.addEventListener("put", (e) => eventHandler("put", e));
  s.addEventListener("patch", (e) => eventHandler("patch", e));
  s.addEventListener("cancel", () => closePublic("即時訂閱被拒絕：賽事可能已關閉。"));
  s.addEventListener("auth_revoked", () => closePublic("公開讀取權限已失效。"));
  s.onerror = () => {
    if (myGen !== generation || stream !== s) return;
    streamOpen = false;
    setStatus("網路中斷，正在等待 Firebase SSE 自動重連…");
  };
}
function resume(reason = "resume") {
  if (document.visibilityState !== "visible") return;
  const now = Date.now();
  if (now - lastResumeAt < 1800) return;
  lastResumeAt = now;
  clearTimeout(resumeTimer);
  resumeTimer = setTimeout(async () => {
    // Reconnect SSE FIRST: its initial `put` includes the authoritative marker.
    // Do not GET the version and then GET the same marker through SSE.
    if (isDemo) await checkTinyVersion();
    else startStream();
  }, isDemo ? 0 : 250 + Math.random() * 1250);
}
function goBack() { stopStream(); location.href = isDemo ? "demo.html" : "../index.html"; }
function viewClosedIfExpired() {
  if (state.meta && isClosed(state.meta)) closePublic("此公開連結已過期。");
}

// The following rendering and SVG routines are preserved from the previous
// public V1.0 viewer, with only frame/lazy-fetch entry points replaced.

function eventCount(){
  const m=data?.meta||{};
  if(Array.isArray(m.roster))return m.roster.length;
  const rs=rounds();
  return Number(m.rosterCount)||((rs[0]?.matches?.length||0)*2);
}
function rounds(){
  const r=data?.rounds;
  if(Array.isArray(r))return r.filter(Boolean);
  if(r&&typeof r==='object')return Object.keys(r).sort((a,b)=>Number(a)-Number(b)).map(k=>r[k]).filter(Boolean);
  return [];
}
function matchesOf(r){
  if(Array.isArray(r?.matches))return r.matches.filter(Boolean);
  const m=r?.matches;
  if(m&&typeof m==='object')return Object.keys(m).sort((a,b)=>Number(a)-Number(b)).map(k=>m[k]).filter(Boolean);
  return [];
}
function usesRR(){return data?.meta?.freeFinal==='rr3'}
function flowLabel(){
  const n=eventCount();
  if(!usesRR())return '兩兩淘汰至冠軍＋季軍賽';
  if(n<=3)return `${n} → 3・最後三人循環`;
  const steps=[n];let cur=n;
  while(cur>6){cur=Math.ceil(cur/2);steps.push(cur)}
  if(steps[steps.length-1]!==3)steps.push(3);
  return `${steps.join(' → ')}・最後三人循環`;
}
function stageLabel(ri,r){
  if(r?.placementFinal===true)return '冠軍 / 季軍賽';
  if(usesRR()){
    if(ri===0)return `第一輪（${eventCount()}強）`;
    return `${matchesOf(r).length*2}強`;
  }
  return r?.name||`第 ${ri+1} 輪`;
}
function layout(ri){
  const count=eventCount();
  const cardH=count>=64?88:count>=32?98:104;
  const pitch=count>=64?98:count>=32?108:120;
  const minGap=count>=64?10:count>=32?12:16;
  const mult=Math.pow(2,ri);
  return {top:Math.round((pitch/2)*(mult-1)),gap:Math.max(minGap,Math.round(pitch*mult-cardH))}
}
function matchHtml(m,ri,mi,r){
  const a=m?.a??'待定',b=m?.b??'待定';
  const pa=a==='待定',pb=b==='待定';
  const sa=pa?'':(m?.sa===''||m?.sa==null?'–':m.sa);
  const sb=pb?'':(m?.sb===''||m?.sb==null?'–':m.sb);
  const title=r?.placementFinal===true?(mi===0?'🏆 冠軍賽':'🥉 季軍賽'):`第 ${mi+1} 場`;
  return `<div class="bracketMatch ${m?.winner?'done':''}" data-ri="${ri}" data-mi="${mi}">
    <div class="matchNo">${title}</div>
    <div class="bSide ${pa?'pending':''} ${m?.winner===a?'winner':''}">
      <span class="bName">${m?.winner===a?'<span class="winnerDot">●</span>':''}<span class="playerLabel">${esc(a)}</span></span><span class="bScore">${esc(sa)}</span>
    </div>
    <div class="bSide ${pb?'pending':''} ${m?.winner===b?'winner':''}">
      <span class="bName">${m?.winner===b?'<span class="winnerDot">●</span>':''}<span class="playerLabel">${esc(b)}</span></span><span class="bScore">${esc(sb)}</span>
    </div>
  </div>`;
}
function rrHtml(){
  const f=data?.finalRR;if(!f)return '';
  const players=Array.isArray(f.players)?f.players:Object.values(f.players||{});
  const games=Array.isArray(f.matches)?f.matches.filter(Boolean):Object.values(f.matches||{}).filter(Boolean);
  const stat={};players.forEach(p=>stat[p]={w:0,l:0,pf:0,pa:0});
  games.forEach(m=>{
    if(!stat[m.a])stat[m.a]={w:0,l:0,pf:0,pa:0};
    if(!stat[m.b])stat[m.b]={w:0,l:0,pf:0,pa:0};
    const hasA=m.sa!==''&&m.sa!=null,hasB=m.sb!==''&&m.sb!=null;
    if(hasA&&hasB){
      const a=Number(m.sa)||0,b=Number(m.sb)||0;
      stat[m.a].pf+=a;stat[m.a].pa+=b;stat[m.b].pf+=b;stat[m.b].pa+=a;
      if(a>b){stat[m.a].w++;stat[m.b].l++}else if(b>a){stat[m.b].w++;stat[m.a].l++}
    }
  });
  const ranked=[...players].sort((a,b)=>{
    const sa=stat[a],sb=stat[b];if(sb.w!==sa.w)return sb.w-sa.w;
    const da=sa.pf-sa.pa,db=sb.pf-sb.pa;if(db!==da)return db-da;return sb.pf-sa.pf;
  });
  return `<section class="rrPanel">
    <div class="rrHead"><b>👑 最後三人循環</b><div class="muted">決定最終名次</div></div>
    <div class="rrRanks">${ranked.map((p,i)=>`<div class="rrRankRow"><span class="rrPos">${i+1}</span><b>${esc(p)}</b><span>${stat[p].w}-${stat[p].l}</span></div>`).join('')}</div>
    <div class="rrGames">${games.map(m=>`<div class="rrMini"><b>${esc(m.a)} vs ${esc(m.b)}</b><span>${m.sa===''?'–':esc(m.sa)} : ${m.sb===''?'–':esc(m.sb)}</span></div>`).join('')}</div>
    <div class="rrStatBox"><div class="rrStatTitle">📊 循環賽得失分</div>${ranked.map(p=>{const s=stat[p],d=s.pf-s.pa;return `<div class="rrStatRow"><b>${esc(p)}</b><span>得 ${s.pf}</span><span>失 ${s.pa}</span><span>淨 ${d>0?'+':''}${d}</span></div>`}).join('')}</div>
  </section>`;
}
function finalHtml(rs){
  const fr=rs.find(r=>r?.placementFinal===true),ms=matchesOf(fr);
  if(!fr||ms.length<2)return '';
  const champ=ms[0],bronze=ms[1];
  const loser=m=>!m?.winner?'':m.winner===m.a?m.b:m.winner===m.b?m.a:'';
  const rows=[
    ['🥇','第一名',champ?.winner||'待定'],['🥈','第二名',loser(champ)||'待定'],
    ['🥉','第三名',bronze?.winner||'待定'],['4️⃣','第四名',loser(bronze)||'待定']
  ];
  return `<section class="rrPanel finalPlacings"><div class="rrHead"><b>🏆 最終名次</b><div class="muted">冠軍賽＋季軍賽完成後自動產生 1～4 名</div></div>
  <div class="rrRanks">${rows.map(([i,l,n])=>`<div class="rrRankRow"><span class="rrPos">${i}</span><b>${l}</b><span>${esc(n)}</span></div>`).join('')}</div></section>`;
}

function drawLinks(){
  if(!eventId || !data?.meta)return;

  const canvas=document.querySelector('.bracketCanvas');
  const svg=document.querySelector('.bracketLinks');
  if(!canvas||!svg)return;

  const rs=rounds();
  const cr=canvas.getBoundingClientRect();
  const inv=1/(scale||1);
  const width=canvas.scrollWidth;
  const height=canvas.scrollHeight;

  svg.setAttribute('width',width);
  svg.setAttribute('height',height);
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  svg.style.width=width+'px';
  svg.style.height=height+'px';

  const point=(el,side='center')=>{
    const r=el.getBoundingClientRect();
    const x=side==='right'?r.right:(side==='left'?r.left:(r.left+r.width/2));
    return {
      x:(x-cr.left)*inv,
      y:(r.top+r.height/2-cr.top)*inv
    };
  };

  const paths=[];

  for(let ri=0;ri<rs.length-1;ri++){
    const src=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${ri}"]`)];
    const dst=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${ri+1}"]`)];

    dst.forEach((target,j)=>{
      const t=point(target,'left');
      const pair=(rs[ri+1]?.placementFinal && src.length===2)
        ? src.filter(Boolean) : [src[j*2],src[j*2+1]].filter(Boolean);
      if(!pair.length)return;

      const sourcePoints=pair.map(el=>({el,...point(el,'right')}));
      const maxSourceX=Math.max(...sourcePoints.map(p=>p.x));
      const elbowX=maxSourceX+Math.max(16,(t.x-maxSourceX)*0.52);

      sourcePoints.forEach(p=>{
        const live=p.el.classList.contains('done')?'live':'';
        paths.push(
          `<path class="${live}" d="M ${p.x.toFixed(1)} ${p.y.toFixed(1)} H ${elbowX.toFixed(1)} V ${t.y.toFixed(1)} H ${t.x.toFixed(1)}"/>`
        );
      });
    });
  }

  if(data.finalRR){
    const last=rs.length-1;
    const src=[...canvas.querySelectorAll(`.bracketMatch[data-ri="${last}"]`)];
    const target=canvas.querySelector('.rrPanel');

    if(target&&src.length){
      const t=point(target,'left');
      const sourcePoints=src.map(el=>({el,...point(el,'right')}));
      const maxSourceX=Math.max(...sourcePoints.map(p=>p.x));
      const elbowX=maxSourceX+Math.max(16,(t.x-maxSourceX)*0.52);

      sourcePoints.forEach((p,k)=>{
        const live=p.el.classList.contains('done')?'live':'';
        const ty=t.y+(k-(sourcePoints.length-1)/2)*12;
        paths.push(
          `<path class="${live}" d="M ${p.x.toFixed(1)} ${p.y.toFixed(1)} H ${elbowX.toFixed(1)} V ${ty.toFixed(1)} H ${t.x.toFixed(1)}"/>`
        );
      });
    }
  }

  svg.innerHTML=paths.join('');
}
function setScale(v){
  scale=Math.max(.30,Math.min(1.2,v));
  const c=document.querySelector('.bracketCanvas'),st=document.querySelector('.bracketStage');if(!c||!st)return;
  c.style.transform=`scale(${scale})`;st.style.width=Math.ceil(c.scrollWidth*scale)+'px';st.style.height=Math.ceil(c.scrollHeight*scale)+'px';
  const z=document.querySelector('.zoomLabel');if(z)z.textContent=Math.round(scale*100)+'%';
}
function zoom(d){setScale(scale+d);requestAnimationFrame(drawLinks)}
function fit(){
  const sc=document.querySelector('.bracketScroll'),c=document.querySelector('.bracketCanvas');if(!sc||!c)return;
  setScale(Math.max(.30,Math.min(.92,(sc.clientWidth-14)/c.scrollWidth)));sc.scrollTo({left:0,top:0,behavior:'smooth'});requestAnimationFrame(drawLinks)
}
function autoScale(){
  const n=eventCount();
  setScale(innerWidth<=640?(n>=64?.52:n>=32?.60:.72):(n>=64?.68:n>=32?.78:.9))
}
function toggleFull(){document.body.classList.toggle('fullscreen');setTimeout(()=>{autoScale();drawLinks()},80)}
addEventListener('resize',()=>{if(eventId){clearTimeout(window.__rz);window.__rz=setTimeout(()=>{autoScale();drawLinks()},120)}});

// On-demand requests are limited to the columns the user is actually viewing.
async function loadAllRounds() {
  if (!state.meta) return;
  setStatus("手動載入完整公開樹狀圖中…");
  const indices = state.meta.rounds.map((_, ri) => ri);
  for (let i = 0; i < indices.length; i += 2) {
    await Promise.all(indices.slice(i, i+2).map((ri) => loadRound(ri)));
  }
  if (state.meta.hasFinalRR) await loadRR();
  if (state.meta) setStatus("已依要求載入全部輪次。", "ok");
}
$("loadAll").addEventListener("click", loadAllRounds);
window.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") resume("visible");
  else { stopStream(); clearTimeout(resumeTimer); }
});
window.addEventListener("pageshow", (e) => { if (e.persisted) resume("bfcache"); });
window.addEventListener("online", () => resume("online"));
window.addEventListener("pagehide", () => { stopStream(); clearTimeout(resumeTimer); });
setInterval(() => {
  if (document.visibilityState !== "visible") return;
  viewClosedIfExpired();
  if (!state.meta) return;
  // Normally a connected SSE needs zero redundant GETs. Exception: if the
  // connection is SILENT (including no keep-alive) for >20-25 minutes, one
  // randomized health GET detects half-open proxies, preventing stuck scores.
  const now = Date.now();
  if (!streamOpen && now - lastTinyCheckAt >= 30000) checkTinyVersion();
  else if (streamOpen && lastSseFrameAt > 0 &&
    now - Math.max(lastSseFrameAt, lastTinyCheckAt) >= HEALTHY_STALL_CHECK_MS) {
    checkTinyVersion();
  }
}, 30000 + Math.round(Math.random()*3000));

// Off-network demonstration. Never writes Firebase and shows same UI as real viewer.
function createDemo() {
  const count = Number(params.get("demo") || "24") === 64 ? 64 : 24;
  const rounds = [];
  let n = count, k=0;
  while (n > (count === 24 ? 3 : 2)) {
    const matches = Array.from({length: Math.ceil(n/2)}, (_, i) => {
      const initial = k===0;
      return {a: initial ? `選手 ${i*2+1}` : "待定",
        b: initial ? `選手 ${i*2+2}` : "待定", sa: "", sb: "", winner: null};
    });
    rounds.push({name:`第 ${k+1} 輪（${n} 強）`,matches});
    n=Math.ceil(n/2);k++;
  }
  if (count===64) rounds.push({name:"冠軍及季軍賽",placementFinal:true,matches:[
    {a:"待定",b:"待定",sa:"",sb:"",winner:null},
    {a:"待定",b:"待定",sa:"",sb:"",winner:null}
  ]});
  const publicUntil = Date.now() + 86400000;
  const pub = {
    meta: {id: eventId, name:`離線示範・${count} 人賽（不會連線）`,
      mode: count===24?"free":"single",freeFinal:count===24?"rr3":"champ",
      rosterCount:count,rounds:rounds.map((r)=>({name:r.name,matchCount:r.matches.length,
        placementFinal:!!r.placementFinal})),hasFinalRR:count===24,
      publicOpen:true,publicUntil,structureVersion:1,appVersion:'V0.1'},
    rounds:Object.fromEntries(rounds.map((r,ri)=>[ri,{
      revision:0,matches:Object.fromEntries(r.matches.map((m,i)=>[i,m]))}])),
    finalRR:count===24?{revision:0,players:["待定 A","待定 B","待定 C"],matches:[]}:null,
    sync:{seq:0,structureVersion:1,publicOpen:true,last:null},changes:{}
  };
  return pub;
}
async function demoGet(path, query) {
  if (!window.__bxDemoReads) window.__bxDemoReads = [];
  window.__bxDemoReads.push(path);
  await new Promise((resolve)=>setTimeout(resolve,50));
  if (path==="changes") {
    const start = JSON.parse(query.startAt), end = JSON.parse(query.endAt);
    return Object.fromEntries(Object.entries(demoData.changes)
      .filter(([k])=>k>=start&&k<=end));
  }
  const keys=path.split("/");
  return BXSync.clone(keys.reduce((v,k)=>v==null?null:v[k],demoData));
}
function startDemoStream() {
  streamOpen=true;
  setStatus("離線示範模式：只讀模擬資料，完全不連 Firebase。", "ok");
}
function demoAdvance() {
  const pub = demoData;
  const match = pub.rounds[0].matches[0];
  const updated = {...match,sa:Math.min(6,Number(match.sa||0)+1),sb:0};
  if(updated.sa>=4)updated.winner=updated.a;
  const seq=pub.sync.seq+1;
  const rev=++pub.rounds[0].revision;
  pub.rounds[0].matches[0]=updated;
  const entry={seq,kind:"match",ri:0,mi:0,roundRevision:rev,match:updated};
  pub.sync={seq,structureVersion:1,publicOpen:true,last:entry};
  pub.changes[BXSync.seqKey(seq)]=entry;
  enqueueSync(pub.sync);
}
function showDemoControls() {
  const actions=$("demoControls");
  actions.classList.remove("hidden");
  $("demoAdvance").onclick=demoAdvance;
  $("demoSkip").onclick=()=>{
    for(let i=0;i<5;i++){
      const m=demoData.rounds[0].matches[1];
      const seq=demoData.sync.seq+1,rev=++demoData.rounds[0].revision;
      const updated={...m,sa:i+1,sb:0,winner:i===4?m.a:null};
      demoData.rounds[0].matches[1]=updated;
      const entry={seq,kind:"match",ri:0,mi:1,roundRevision:rev,match:updated};
      demoData.changes[BXSync.seqKey(seq)]=entry;
      demoData.sync={seq,structureVersion:1,publicOpen:true,last:entry};
    }
    enqueueSync(demoData.sync); // Test history-gap recovery.
  };
}

async function main() {
  if (!BXSync.isValidId(eventId)) {
    setStatus("網址缺少有效的賽事 event ID。", "error"); return;
  }
  if (isDemo) { demoData=createDemo(); showDemoControls(); }
  else loadCache();
  // SSE-first: its initial put includes the tiny sync marker, so no duplicate
  // startup GET sync. Metadata and visible rounds remain lazy.
  // Demo intentionally uses getJson("sync") to keep offline smoke tests valid.
  resume("initial");
}
main();
