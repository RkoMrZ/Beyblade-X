#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/deploy/v01-common.sh"
bx_here
[[ -f .bxv01-clean-complete ]] || bx_die '請先完成 02_clean_v01.sh；拒絕略過清理'
printf '====== BeybladeX V0.1 重新部署 ======\n'
# Ensure the project and cloud APIs remain accessible before deployment.
bx_check_listings
bx_target
printf '\n安裝函式依賴並重新執行程式測試…\n'
npm --prefix functions install --omit=dev --no-audit --no-fund
node --check functions/index.js
node --test tests/authority-regression.test.js tests/v01-management.test.js
printf '\n準備 Secret Manager 金鑰（不輸出金鑰）…\n'
if firebase functions:secrets:get BX_LOCK_KEY --project "$BX_PROJECT" >/dev/null 2>&1; then
  echo '沿用現有 BX_LOCK_KEY Secret，不新增。'
else
  keyfile="$(mktemp)"
  trap 'rm -f "${keyfile:-}"' EXIT
  chmod 600 "$keyfile"
  openssl rand -hex 32 | tr -d '\n' > "$keyfile"
  firebase functions:secrets:set BX_LOCK_KEY --data-file "$keyfile" --project "$BX_PROJECT" || bx_die '建立 Secret 失敗'
  rm -f "$keyfile"
  trap - EXIT
fi
printf '\n部署且僅部署 bxv01 Cloud Functions…\n'
firebase deploy --only functions:bxv01 --project "$BX_PROJECT" || bx_die 'Functions 部署未完成；未開始 Rules 部署。'
printf '\n重新取得現有 Rules，再安全合併 V01 專屬權限…\n'
bx_fetch_rules
python3 deploy/v01-rule-tool.py merge
firebase deploy --only database --project "$BX_PROJECT" || bx_die 'Rules 部署未完成。請修正後重跑部署腳本。'
touch .bxv01-deployed
printf '\nV0.1 Functions + Rules 已執行部署。下一步：bash 04_verify_v01.sh\n'
