#!/usr/bin/env python3
"""Offline Chromium smoke tests; intercept Firebase CDN and never access real Firebase."""
import pathlib
from playwright.sync_api import sync_playwright
BASE=pathlib.Path(__file__).resolve().parents[1]
site="https://beyblade-v01.invalid"
# These fake modules only allow a no-credentials DOM smoke test; they are NOT Firebase emulation.
app='export const initializeApp=()=>({});'
auth='export const getAuth=()=>({});export const onAuthStateChanged=()=>{};export const GoogleAuthProvider=class{};export const signInWithPopup=()=>{};export const signInWithRedirect=()=>{};export const signOut=()=>{};export const signInAnonymously=()=>{};'
fns='export const getFunctions=()=>({});export const httpsCallable=()=>()=>Promise.resolve({data:{}});'
db='export const getDatabase=()=>({});export const ref=()=>({});export const get=()=>Promise.resolve({val:()=>null});export const onValue=()=>()=>{};'
with sync_playwright() as playwright:
    browser=playwright.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844})
    errors=[]
    page.on('pageerror',lambda err: errors.append(str(err)))
    def rewrite(route):
        src=route.request.url
        body=app if 'firebase-app' in src else auth if 'firebase-auth' in src else fns if 'firebase-functions' in src else db
        route.fulfill(status=200,body=body,headers={'Access-Control-Allow-Origin':'*','Content-Type':'text/javascript'})
    page.route('https://www.gstatic.com/firebasejs/**',rewrite)
    def local(route):
        uri=route.request.url.split('?')[0].split('beyblade-v01.invalid/')[-1]
        file=(BASE/uri).resolve()
        if not file.is_relative_to(BASE) or not file.is_file():return route.fulfill(status=404,body='missing')
        mime='text/javascript' if file.suffix=='.js' else 'text/css' if file.suffix=='.css' else 'text/html'
        route.fulfill(status=200,body=file.read_bytes(),headers={'Content-Type':mime,'Access-Control-Allow-Origin':'*'})
    page.route('https://beyblade-v01.invalid/**',local)
    page.goto(site+'/index.html',wait_until='domcontentloaded')
    page.wait_for_timeout(600)
    assert page.locator('#createBtn').count()==1
    assert page.locator('#joinBtn').count()==1
    assert page.locator('#scoreBtn').count()==1
    assert page.locator('#completeBtn').count()==1
    assert '尚未填入' in page.locator('#notice').inner_text(),page.locator('#notice').inner_text()
    print('STAFF_MAIN_UI_OK')
    for size in [24,64]:
        page.goto(site+'/viewer/viewer.html?demo='+str(size),wait_until='domcontentloaded')
        page.wait_for_timeout(1200)
        assert page.locator('.roundCol').count()>0, (size,page.locator('body').inner_text()[:300])
        print('VIEWER_DEMO_OK',size,'rounds=',page.locator('.roundCol').count())
    assert not errors,errors
    print('NO_UNHANDLED_BROWSER_ERRORS')
    browser.close()

