"use strict";
const test=require('node:test');const assert=require('node:assert/strict');
const B=require('../src/board.js'),M=require('../src/management.js'),P=require('../src/publisher.js');
const {randomBytes}=require('node:crypto');
const now=Date.now(),secret=randomBytes(32).toString('hex'),id='some-event-123456',uid='google-owner',judge='anonymous-judge';
let counter=0;const op=()=>now.toString(16).padStart(12,'0')+(++counter).toString(16).padStart(36,'0');
const copy=x=>JSON.parse(JSON.stringify(x));
const make=()=>B.createBoard({roster:Array.from({length:24},(_,i)=>'P'+(i+1)),mode:'free',freeFinal:'rr3',ownerUid:uid,now});
test('rolling 6-digit judge code is deterministic for the same 60s window',()=>{
 const t=Math.floor(now/60000)*60000+30000;assert.match(M.rollingCode(secret,id,t),/^\d{6}$/);
 assert.equal(M.rollingCode(secret,id,t),M.rollingCode(secret,id,t+10000));
 assert.notEqual(M.rollingCode(secret,id,t),M.rollingCode(secret,id,t+60000));
});
test('judge cannot join with a wrong code, failure attempts are bounded',()=>{
 let board=make();
 for(let n=0;n<5;n++){
  const r=M.refereeJoin(board,judge,'100000',id,secret,now,'第一裁判');
  assert.equal(r.approved,false);board=r.board;
 }
 assert.throws(()=>M.refereeJoin(board,judge,'100000',id,secret,now),/過多/);
 assert.notEqual(board.access.refereeUsers[judge],true);
});
test('judge joining authorizes specific uid without broad permission',()=>{
 const board=make();const code=M.rollingCode(secret,id,now);
 const approved=M.refereeJoin(board,judge,code,id,secret,now,'裁判甲');
 assert.equal(approved.approved,true);assert.equal(approved.board.access.refereeUsers[judge],true);
 assert.equal(approved.board.refereeNames[judge],'裁判甲');
 assert.equal(M.refereeJoin(approved.board,judge,code,id,secret,now).replay,true);
});
test('getEvent returns sanitized staff view with no lock credentials, UID roster or receipt',()=>{
 const board=make();board.access.refereeUsers[judge]=true;
 const state=M.staffView(board,'測試盃',id,judge);assert.equal(state.owner,false);
 assert.equal(state.rounds.length,board.rounds.length);
 assert.ok(!JSON.stringify(state).includes('refereeUsers'));
 assert.ok(!JSON.stringify(state).includes('outbox'));
 assert.throws(()=>M.staffView(board,'',id,'stranger'),/權限/);
});
test('admin close/open are versioned, idempotent, and with public/outbox update',()=>{
 let board=make();const input={opId:op(),action:'setPublic',open:false,eventId:id};
 const r=M.administrativeAction(board,uid,input,now);
 assert.equal(r.board.access.open,false);assert.equal(r.board.seq,1);
 assert.equal(r.board.outbox['000000000001'].wire[0].kind,'closed');
 assert.equal(M.administrativeAction(r.board,uid,input,now).replay,true);
 const patch=P.publicationPatch(r.board.outbox['000000000001']);
 assert.equal(patch['public/meta/publicOpen'],false);
 assert.equal(patch['public/sync'].seq,1);
 assert.equal(patch['staff/sync'].seq,1);
 assert.throws(()=>M.administrativeAction(board,judge,{...input,opId:op()},now),/主辦/);
 const open=M.administrativeAction(r.board,uid,{action:'setPublic',open:true,eventId:id,opId:op()},now);
 assert.equal(open.board.access.open,true);
 assert.ok(open.board.access.until>now);
});
test('delete is a tombstone with public disabled, owner blocked from further mutations',()=>{
 let board=make();const result=M.administrativeAction(board,uid,{action:'delete',eventId:id,opId:op()},now);
 assert.equal(result.board.access.deleted,true);
 assert.equal(P.publicationPatch(result.board.outbox['000000000001'])['public/meta/publicOpen'],false);
 assert.throws(()=>M.administrativeAction(result.board,uid,{action:'delete',eventId:id,opId:op()},now),/不存在/);
});
test('versioned cloud function source has no old V2/V4 call or event path',()=>{
 const fs=require('node:fs'),p=require('node:path');const root=p.join(__dirname,'..');
 const backend=fs.readFileSync(p.join(root,'functions/index.js'),'utf8');
 const index=fs.readFileSync(p.join(root,'index.html'),'utf8');
 const viewer=fs.readFileSync(p.join(root,'viewer/viewer.html'),'utf8');
 assert.doesNotMatch(backend,/eventsV4|eventsV2|matchScoreV4|matchScoreV2/);
 assert.doesNotMatch(index,/eventsV4|eventsV2|matchScoreV4|matchScoreV2/);
 assert.doesNotMatch(viewer,/eventsV4|eventsV2/);
 assert.match(backend,/eventsV01/);
 assert.match(index,/scoreMatchV01/);
 assert.match(viewer,/eventsV01/);
});
