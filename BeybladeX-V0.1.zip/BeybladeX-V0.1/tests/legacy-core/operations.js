"use strict";
const {createHash} = require("node:crypto");
const Engine = require("./engine.js");
const Pub = require("./public-protocol.js");
const PublicCore = require("./sync-core.js");
const {fail, clone, generateRounds, getTarget, propagate, getStandings, currentScore, isStarted} = Engine;
const MAX_LOCK_MS = 10 * 60 * 1000;
const validId = (s) => typeof s === "string" && /^[A-Za-z0-9_-]{6,100}$/.test(s);
const validOp = (s) => typeof s === "string" && /^[a-f0-9]{32,64}$/.test(s);
const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);
function digest(x) { return createHash("sha256").update(JSON.stringify(x)).digest("hex"); }
function sanitizeTitle(x) {
  if (typeof x !== "string" || !x.trim() || x.trim().length > 70) fail("invalid-argument", "賽事名稱無效");
  return x.trim();
}
function makeEvent({eventId, name, roster, mode, freeFinal, pairing, ownerUid, now}) {
  const spec = generateRounds(roster, {mode, freeFinal, pairing});
  const publicUntil = now + 2 * 60 * 60 * 1000;
  const p = Pub.buildPublic({...spec, id: eventId, name: sanitizeTitle(name),
    rosterCount: spec.roster.length, publicUntil});
  return {...spec, meta: {id: eventId, name: sanitizeTitle(name), mode: spec.mode,
    freeFinal: spec.freeFinal, pairing: spec.pairing, ownerUid, publicOpen: true,
    publicUntil, createdAt: now, deleted: false},
  roles: {ownerUid, admins: {}, refereeUsers: {}}, refereeClaims: {},
  version: {eventVersion: 1, structureVersion: 1}, operationReceipts: {},
  public: p};
}
function isOwner(e, uid) { return e.roles?.ownerUid === uid; }
function isStaff(e, uid) { return isOwner(e, uid) || e.roles?.admins?.[uid] === true || e.roles?.refereeUsers?.[uid] === true; }
function guard(e, uid, role, now) {
  if (!e || e.meta?.deleted) fail("not-found", "賽事不存在或已刪除");
  if (role === "owner" && !isOwner(e, uid)) fail("permission-denied", "只允許主辦操作");
  if (role === "staff" && !isStaff(e, uid)) fail("permission-denied", "沒有此賽事的執裁權限");
  if (role === "staff" && (!e.meta.publicOpen || e.meta.publicUntil <= now)) {
    fail("failed-precondition", "賽事公開已關閉或到期，暫停比分操作");
  }
}
function scoreInput(sa, sb) {
  if (!Number.isInteger(sa) || sa < 0 || sa > 6 || !Number.isInteger(sb) || sb < 0 || sb > 6) {
    fail("invalid-argument", "比分必須介於 0–6 的整數");
  }
}
function authMatch(e, uid, input, now) {
  const {m, round, ri} = getTarget(e, input.target);
  if (!Number.isInteger(input.expectedMatchVersion) || input.expectedMatchVersion < 0 ||
      input.expectedMatchVersion !== m.matchVersion) {
    fail("aborted", "場次版本已更新，請先取得最新比分");
  }
  if (!input.lockToken || typeof input.lockToken !== "string" ||
      m.lock?.uid !== uid || m.lock?.tokenHash !== digest(input.lockToken) || m.lock.expiresAt <= now) {
    fail("permission-denied", "目前沒有此場次的有效執裁鎖");
  }
  if (e.refereeClaims?.[uid]?.tokenHash !== digest(input.lockToken)) fail("permission-denied", "場次領取資訊已變更");
  if ([Engine.PENDING, Engine.BYE].includes(m.a) || [Engine.PENDING, Engine.BYE].includes(m.b)) {
    fail("failed-precondition", "選手尚未確定或屬於輪空場次");
  }
  return {m, round, ri};
}
function scoreResult(e, m, kind = "updated") {
  return {ok: true, status: kind, matchVersion: m?.matchVersion ?? null,
    eventVersion: e.version.eventVersion, structureVersion: e.version.structureVersion,
    publicSeq: e.public.sync.seq};
}
function increment(e, m, round) {
  if (m) m.matchVersion++;
  if (round) round.revision++;
  e.version.eventVersion++;
}
function matchChange(event, target, match) {
  return target.kind === "rr" ? {kind: "rr", finalRR: event.finalRR} :
    {kind: "match", ri: target.ri, mi: target.mi, match};
}
function createChanges(e, target, m, dirty, before) {
  if (dirty.includes("rr")) {
    // Public tree shape changes once when RR is created/removed.
    e.public = Pub.publishChange(e.public, {kind: "structure", rounds: e.rounds,
      finalRR: e.finalRR, meta: {...e.meta, rosterCount: e.roster.length}}, true);
    e.version.structureVersion = e.public.meta.structureVersion;
    return;
  }
  const items = [matchChange(e, target, m)];
  for (const ri of dirty) {
    // Send only changed match data, not "reload this whole round" notices.
    // An audience of 200 cached viewers can apply both advances from ONE sync packet.
    for (let mi = 0; mi < e.rounds[ri].matches.length; mi++) {
      const previous = before?.rounds?.[ri]?.matches?.[mi];
      const latest = e.rounds[ri].matches[mi];
      if (JSON.stringify(PublicCore.publicMatch(previous)) !== JSON.stringify(PublicCore.publicMatch(latest))) {
        items.push({kind: "match", ri, mi, match: latest});
      }
    }
  }
  e.public = Pub.publishChange(e.public, items.length === 1 ? items[0] : {kind: "batch", items}, true);
}
function releaseLock(e, uid, m) {
  m.lock = null;
  if (e.refereeClaims) delete e.refereeClaims[uid];
}
function ensureOp(e, uid, action, input) {
  if (!validOp(input.opId)) fail("invalid-argument", "操作代碼格式錯誤");
  if (!uid || typeof uid !== "string") fail("unauthenticated", "請先登入 Firebase");
  const hash = digest({action, input});
  const found = e.operationReceipts?.[input.opId];
  if (found) {
    if (found.uid !== uid || found.hash !== hash) fail("permission-denied", "操作代碼已使用於其他請求");
    return {hash, replay: clone(found.result)};
  }
  return {hash, replay: null};
}
function applyOperation(original, uid, action, input, now, claimToken, lockTokenBox) {
  const e = clone(original);
  if (!isObj(input) || !validId(input.eventId)) fail("invalid-argument", "賽事 ID 無效");
  const {hash, replay} = ensureOp(e, uid, action, input);
  if (replay) return {event: e, result: replay, replay: true};
  guard(e, uid, ["eventSetPublicV2", "eventDeleteV2", "roleGrantV2"]
    .includes(action) ? "owner" : "staff", now);
  let result;
  if (action === "roleGrantV2") {
    if (typeof input.refereeUid !== "string" || !/^[A-Za-z0-9_-]{6,128}$/.test(input.refereeUid))
      fail("invalid-argument", "裁判 UID 格式錯誤");
    if (input.refereeUid === uid) fail("failed-precondition", "主辦無需重複授權裁判");
    e.roles.refereeUsers[input.refereeUid] = input.enabled !== false;
    // Revocation invalidates current active lock immediately.
    if (input.enabled === false && e.refereeClaims?.[input.refereeUid]) {
      const old = e.refereeClaims[input.refereeUid];
      const oldM = getTarget(e, old).m;
      if (oldM.lock?.uid === input.refereeUid) {oldM.lock = null; oldM.matchVersion++;}
      delete e.refereeClaims[input.refereeUid];
    }
    increment(e);
    result = {ok: true, enabled: e.roles.refereeUsers[input.refereeUid]};
  } else if (action === "refereeClaimV2") {
    if (!claimToken || typeof claimToken !== "string") fail("internal", "缺少雲端領場憑證");
    const {m, round} = getTarget(e, input.target);
    if (m.winner) fail("failed-precondition", "這場比賽已完成");
    if (m.a === Engine.PENDING || m.b === Engine.PENDING || m.a === Engine.BYE || m.b === Engine.BYE)
      fail("failed-precondition", "對戰選手尚未確定");
    if (m.lock && m.lock.uid !== uid && m.lock.expiresAt > now) fail("aborted", "場次已由其他裁判領取");
    const earlier = e.refereeClaims?.[uid];
    if (earlier) {
      const past = getTarget(e, earlier).m;
      if (past.lock?.uid === uid && past.lock?.tokenHash === earlier.tokenHash && past !== m) {
        past.lock = null; past.matchVersion++;
      }
    }
    m.lock = {uid, tokenHash: digest(claimToken), expiresAt: now + MAX_LOCK_MS};
    m.matchVersion++;
    e.refereeClaims[uid] = {...input.target, tokenHash: digest(claimToken)};
    increment(e, null, round);
    e.public = Pub.publishChange(e.public, matchChange(e, input.target, m), true);
    result = {...scoreResult(e, m, "claimed"), lockToken: claimToken,
      expiresAt: m.lock.expiresAt};
  } else if (action === "refereeReleaseV2") {
    const {m, round} = authMatch(e, uid, input, now);
    releaseLock(e, uid, m); increment(e, m, round);
    e.public = Pub.publishChange(e.public, matchChange(e, input.target, m), true);
    result = scoreResult(e, m, "released");
  } else if (action === "matchScoreV2") {
    const {m, round} = authMatch(e, uid, input, now);
    if (m.winner) fail("failed-precondition", "已完成的場次不能直接改分");
    scoreInput(input.sa, input.sb);
    m.sa = input.sa; m.sb = input.sb;
    m.lock.expiresAt = now + MAX_LOCK_MS;
    increment(e, m, round);
    e.public = Pub.publishChange(e.public, matchChange(e, input.target, m), true);
    result = scoreResult(e, m);
  } else if (action === "matchCompleteV2") {
    const {m, round} = authMatch(e, uid, input, now);
    if (m.winner) fail("failed-precondition", "本場已完成");
    const sa = currentScore(m.sa), sb = currentScore(m.sb);
    if (sa === null || sb === null || Math.max(sa, sb) < 4 || sa === sb)
      fail("failed-precondition", "須達 4 分且分出勝負才能完成");
    m.winner = sa > sb ? m.a : m.b;
    releaseLock(e, uid, m);
    increment(e, m, round);
    const dirty = input.target.kind === "round" ? propagate(e) : [];
    if (input.target.kind === "rr") {
      e.finalRR.standings = getStandings(e.finalRR);
      e.finalRR.revision++;
    }
    createChanges(e, input.target, m, dirty, original);
    result = {...scoreResult(e, m, "completed"), winner: m.winner};
  } else if (action === "matchResetV2") {
    if (input.mode !== "scoreOnly" && input.mode !== "cancelComplete")
      fail("invalid-argument", "重設模式無效");
    let m, round;
    if (input.mode === "cancelComplete") {
      if (!isOwner(e, uid)) fail("permission-denied", "取消完成只允許主辦");
      ({m, round} = getTarget(e, input.target));
      if (input.expectedMatchVersion !== m.matchVersion)
        fail("aborted", "場次版本已更新，請先取得最新比分");
      if (m.lock && m.lock.expiresAt > now)
        fail("failed-precondition", "本場仍有裁判執裁，請先協調釋放");
    } else {
      ({m, round} = authMatch(e, uid, input, now));
      if (m.winner) fail("failed-precondition", "已完成場次須使用取消完成操作");
    }
    if (Engine.isByeWinner(m)) fail("failed-precondition", "輪空自動晉級不能手動重設比分");
    m.sa = 0; m.sb = 0;
    if (input.mode === "cancelComplete") m.winner = null;
    increment(e, m, round);
    const dirty = input.target.kind === "round" && input.mode === "cancelComplete" ? propagate(e) : [];
    createChanges(e, input.target, m, dirty, original);
    result = scoreResult(e, m, "reset");
  } else if (action === "eventSetPublicV2") {
    const open = input.open === true;
    if (typeof input.open !== "boolean") fail("invalid-argument", "公開狀態無效");
    e.meta.publicOpen = open;
    if (open) e.meta.publicUntil = now + 2 * 60 * 60 * 1000;
    else {
      // Revoke all locks on close; prevent stale clients from resuming editing.
      for (const round of e.rounds) for (const m of round.matches) if (m.lock) {m.lock = null; m.matchVersion++;}
      if (e.finalRR) for (const m of e.finalRR.matches) if (m.lock) {m.lock = null; m.matchVersion++;}
      e.refereeClaims = {};
    }
    increment(e);
    e.public = Pub.publishChange(e.public, open ? {kind: "meta", meta: {publicOpen: true, publicUntil: e.meta.publicUntil}} : {kind: "closed"}, true);
    result = {ok: true, publicOpen: open, publicUntil: e.meta.publicUntil};
  } else if (action === "eventDeleteV2") {
    if (input.confirm !== "DELETE") fail("failed-precondition", "刪除操作需要主辦確認");
    e.meta.deleted = true; e.meta.publicOpen = false;
    e.roles.refereeUsers = {}; e.refereeClaims = {};
    increment(e);
    e.public = Pub.publishChange(e.public, {kind: "closed"}, true);
    result = {ok: true, deleted: true};
  } else fail("invalid-argument", "未支援的操作");
  // All receipts must be stored INSIDE the same transaction as the score and public projection.
  e.operationReceipts ||= {};
  // Never store raw referee lockToken in the database receipt. A privileged
  // Cloud Function encrypts it before transaction; retries decrypt on return.
  if (action === "refereeClaimV2" && !lockTokenBox) fail("failed-precondition", "領場回條必須加密");
  const savedResult = action === "refereeClaimV2" ?
    {...result, lockToken: undefined, lockTokenBox} : result;
  e.operationReceipts[input.opId] = {uid, hash, result: savedResult, at: now};
  // Receipts stay for event lifetime in this prototype. No unsafe TTL eviction.
  return {event: e, result, replay: false};
}
module.exports = {makeEvent, applyOperation, digest, validId, validOp, isOwner, isStaff, MAX_LOCK_MS};
