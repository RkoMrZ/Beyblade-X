/* VNext read projection contract (not a deployed Cloud Function).
 * Use ONLY after authoritative backend validates identity, lock, score,
 * progression and versions. Call within eventsV2/<eventId> RTDB transaction.
 */
"use strict";
const Core = require("./sync-core.js");
const LOG_KEEP = Core.MAX_CHANGE_PAGE;
function publicFinalRR(rr) {
  if (!rr) return null;
  return {revision: Number.isInteger(rr.revision) ? rr.revision : 0,
    players: Array.isArray(rr.players) ? rr.players.map(String) : [],
    matches: Array.isArray(rr.matches) ? rr.matches.map(Core.publicMatch) : []};
}
function publicRounds(rawRounds) {
  return Object.fromEntries(rawRounds.map((round,ri)=> [ri, {
    revision: Number.isInteger(round.revision) ? round.revision : 0,
    matches: Object.fromEntries(Object.entries(round.matches || {})
      .map(([mi, match]) => [mi, Core.publicMatch(match)]))
  }]));
}
function buildPublic(spec) {
  const rounds = {};
  const desc = (spec.rounds || []).map((r, ri) => {
    const matches = {};
    (r.matches || []).forEach((m, i) => { matches[i] = Core.publicMatch(m); });
    rounds[ri] = {revision: 0, matches};
    return {name: r.name || `第 ${ri + 1} 輪`,
      matchCount: (r.matches || []).length, placementFinal: r.placementFinal === true};
  });
  return {
    meta: {id: spec.id, name: spec.name, mode: spec.mode || "free",
      freeFinal: spec.freeFinal || "rr3", rosterCount: spec.rosterCount,
      rounds: desc, hasFinalRR: !!spec.finalRR,
      publicOpen: true, publicUntil: spec.publicUntil,
      structureVersion: 1},
    rounds,
    finalRR: publicFinalRR(spec.finalRR),
    sync: {seq: 0, sv: 1, d: null},
    changes: {},
  };
}
function publishChange(publicData, change, alreadyCloned = false) {
  if (!publicData || !publicData.sync || !publicData.meta) throw new Error("no public projection");
  // applyOperation already cloned authoritative state once per transaction.
  // Avoid cloning the large public projection a second time in that path.
  const p = alreadyCloned ? publicData : Core.clone(publicData);
  const seq = p.sync.seq + 1;
  if (!Number.isSafeInteger(seq)) throw new Error("sequence overflow");
  const items = change.kind === "batch" ? change.items : [change];
  if (!Array.isArray(items) || !items.length || items.length > 16) throw new Error("invalid batch size");
  function applyOne(c) {
    if (c.kind === "match") {
      const ri = c.ri, mi = c.mi;
      const r = p.rounds[ri];
      if (!r || !Object.hasOwn(r.matches, mi)) throw new Error("unknown match");
      r.revision++;
      const match = Core.publicMatch(c.match);
      const previous = r.matches[mi] || {};
      const patch = {};
      for (const [key,value] of Object.entries(match)) {
        if (JSON.stringify(previous[key]) !== JSON.stringify(value)) patch[key] = value;
      }
      r.matches[mi] = match;
      // Public diff carries ONLY changed fields; cached viewers merge them.
      return {kind: "match", ri, mi, roundRevision: r.revision, patch};
    }
    if (c.kind === "round") {
      const r = p.rounds[c.ri];
      if (!r) throw new Error("unknown round");
      r.revision++;
      r.matches = Object.fromEntries((c.matches || []).map((m, i) => [i, Core.publicMatch(m)]));
      return {kind: "round", ri: c.ri};
    }
    if (c.kind === "rr") {
      p.finalRR = publicFinalRR(c.finalRR);
      p.meta.hasFinalRR = !!c.finalRR;
      return {kind: "rr", finalRR: Core.clone(p.finalRR)};
    }
    if (c.kind === "meta") {
      const allowed = ["name", "publicUntil", "publicOpen"];
      const meta = {};
      for (const k of allowed) if (Object.hasOwn(c.meta || {}, k)) meta[k] = c.meta[k];
      Object.assign(p.meta, meta);
      return {kind: "meta", meta};
    }
    if (c.kind === "structure") {
      const draft = c.meta || {};
      for (const key of ["name", "mode", "freeFinal", "rosterCount", "publicOpen", "publicUntil"]) {
        if (Object.hasOwn(draft, key)) p.meta[key] = draft[key];
      }
      if (!Array.isArray(c.rounds)) throw new Error("structure must supply round array");
      p.meta.rounds = c.rounds.map((r, ri) => ({
        name: String(r.name || `第 ${ri + 1} 輪`), matchCount: r.matches.length,
        placementFinal: r.placementFinal === true}));
      p.meta.hasFinalRR = !!c.finalRR;
      p.meta.structureVersion++;
      p.rounds = publicRounds(c.rounds);
      p.finalRR = publicFinalRR(c.finalRR);
      return {kind: "structure"};
    }
    if (c.kind === "closed") {
      p.meta.publicOpen = false;
      return {kind: "closed"};
    }
    throw new Error("unknown change kind");
  }
  const parts = items.map(applyOne);
  const entry = parts.length === 1 ? {seq, ...parts[0]} : {seq, kind: "batch", items: parts};
  p.changes[Core.seqKey(seq)] = entry;
  for (const key of Object.keys(p.changes).sort().slice(0, -LOG_KEEP)) delete p.changes[key];
  p.sync = {seq, sv: p.meta.structureVersion,
    d: Core.packChange(entry), ...(p.meta.publicOpen ? {} : {o: 0})};
  return p;
}
module.exports = {buildPublic, publishChange, LOG_KEEP};
