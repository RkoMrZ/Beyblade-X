"""V0.1 read-only local consistency preflight (no network, no Firebase writes)."""
from pathlib import Path
from bs4 import BeautifulSoup
import json,re,subprocess
root=Path(__file__).resolve().parents[1]
json.loads((root/'database.rules.json').read_text())
json.loads((root/'firebase.json').read_text())
json.loads((root/'.firebaserc').read_text())
assert 'ljt-beyblade-x-test' in (root/'.firebaserc').read_text()
html=(root/'index.html').read_text()
viewer=(root/'viewer/viewer.html').read_text()
backend=(root/'functions/index.js').read_text()
assert 'eventsV01' in backend and 'clientVersion' in backend and "const VERSION='V0.1'" in html
assert 'eventsV01' in viewer and "appVersion === 'V0.1'" in viewer
assert not any(x in html for x in ('eventsV4','eventsV2','matchScoreV4','matchScoreV2'))
assert "require('./lib/board.js')" in backend
assert 'public/rounds' in (root/'functions/lib/publisher.js').read_text()
ids={tag.get('id') for tag in BeautifulSoup(html,'html.parser').find_all(id=True)}
required={'homePanel','eventPanel','createBtn','joinBtn','claimBtn','scoreBtn','completeBtn','queryBtn','abandonBtn','qrBtn','notice','bracket','roleBadge'}
assert not(required-ids),required-ids
for file in (root/'functions').rglob('*.js'):
    subprocess.run(['node','--check',str(file)],check=True,stdout=subprocess.DEVNULL)
for file in (root/'src').rglob('*.js'):
    subprocess.run(['node','--check',str(file)],check=True,stdout=subprocess.DEVNULL)
for name,doc in [('index',html),('viewer',viewer)]:
    scripts=re.findall(r'<script(?:\s+[^>]*?)?>(.*?)</script>',doc,re.S)
    for i,s in enumerate(scripts):
        if not s.strip():continue
        script=root/'tests'/f'_tmp_{name}_{i}.mjs'
        try:
            script.write_text(s)
            subprocess.run(['node','--check',str(script)],check=True,stdout=subprocess.DEVNULL)
        finally:script.unlink(missing_ok=True)
print('PASS: V0.1 paths, frontend DOM, JS syntax, JSON rules, deployment sources')
if 'REPLACE_TEST_' in html:print('BLOCKER: Firebase TEST Web App apiKey/appId must be configured before deploying')
