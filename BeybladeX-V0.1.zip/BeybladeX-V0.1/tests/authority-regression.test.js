"use strict";
const test=require("node:test"),assert=require("node:assert/strict");
const {randomBytes}=require("node:crypto");
const Board=require("../src/board.js"),Pub=require("../src/publisher.js"),S=require("../src/sync-core.js");
const id=(n)=>Date.now().toString(16).padStart(12,"0")+n.toString(16).padStart(36,"0");
const clone=x=>x===undefined?undefined:JSON.parse(JSON.stringify(x));
const get=(o,p)=>p.split("/").filter(Boolean).reduce((v,k)=>v?.[k],o);
const put=(o,p,v)=>{const a=p.split("/").filter(Boolean);let t=o;for(const k of a.slice(0,-1))t=t[k]??={};if(v===null)delete t[a.at(-1)];else t[a.at(-1)]=clone(v)};
const store={eventsV01:{}};
const metrics={transaction:0,get:0,update:0,readBytes:0,writtenBytes:0};
const ref=(path)=>({
 child(k){return ref(path+"/"+k)},
 async get(){metrics.get++;const val=clone(get(store,path))??null;metrics.readBytes+=Buffer.byteLength(JSON.stringify(val));return {val:()=>val}},
 async transaction(fn){metrics.transaction++;const cur=clone(get(store,path))??null;metrics.readBytes+=Buffer.byteLength(JSON.stringify(cur));const proposed=fn(cur);
  if(proposed===undefined)return {committed:false,snapshot:{val:()=>clone(get(store,path))??null}};
  put(store,path,proposed);metrics.writtenBytes+=Buffer.byteLength(JSON.stringify(proposed));return {committed:true,snapshot:{val:()=>clone(proposed)}};},
 async update(paths){metrics.update++;for(const [key,val] of Object.entries(paths))put(store,path+"/"+key,val);
  metrics.writtenBytes+=Buffer.byteLength(JSON.stringify(paths));},
});
const db={ref};
const eid="test-id-12345",owner="owner-abcdef",other="judge-abcdef",now=Date.now();
let board=Board.createBoard({roster:Array.from({length:64},(_,i)=>"P"+(i+1)),mode:"single",ownerUid:owner,now});
let init=Board.publicInitial(board,eid,"Stage4 64");
put(store,`eventsV01/${eid}`,{board,public:init,meta:{ownerUid:owner}});
let seqN=0,firstClaim;
function tx(action,input,uid=owner){
 const d={eventId:eid,opId:id(++seqN),target:{kind:"round",ri:0,mi:0},...input};
 const token=action==="claim"?randomBytes(24).toString("hex"):null;
 const seal=token?"encrypted:"+token.slice(0,8):null;
 const b=Board.applyBoard(board,uid,action,d,now,token,seal);
 board=b.board;
 put(store,`eventsV01/${eid}/board`,board);
 return {d,receipt:b.receipt,token};
}
test("the first 64-player board transaction excludes public roster/history and root",()=>{
 const staged=Board.createBoard({roster:Array.from({length:64},(_,i)=>"P"+(i+1)),mode:"single",ownerUid:owner,now});
 const old=require("./legacy-core/operations.js").makeEvent({
  eventId:eid,name:"Stage4 64",roster:Array.from({length:64},(_,i)=>"P"+(i+1)),mode:"single",freeFinal:"champ",pairing:"ordered",ownerUid:owner,now});
 const bBytes=Buffer.byteLength(JSON.stringify(staged));
 const oldBytes=Buffer.byteLength(JSON.stringify(old));
 assert.ok(bBytes<oldBytes,`board ${bBytes} old root ${oldBytes}`);
 console.log(`ROOT_V3_BYTES=${oldBytes} BOARD_V4_BYTES=${bBytes} SAVING=${((oldBytes-bBytes)/oldBytes*100).toFixed(1)}%`);
});
test("claim + score + completion: source of truth and next-round winner are atomic",()=>{
 const c=tx("claim",{});firstClaim=c.d;assert.ok(c.token);
 const m=board.rounds[0].matches[0];
 assert.equal(m.lock.uid,owner);
 const s=tx("score",{expectedMatchVersion:m.matchVersion,lockToken:c.token,sa:4,sb:1});
 assert.equal(board.rounds[0].matches[0].sa,4);
 const finish=tx("complete",{expectedMatchVersion:board.rounds[0].matches[0].matchVersion,lockToken:c.token});
 assert.equal(board.rounds[0].matches[0].winner,"P1");
 assert.equal(board.rounds[1].matches[0].a,"P1");
 assert.ok(board.outbox[S.seqKey(finish.receipt.publicSeq)].full.some(v=>v.ri===1));
 assert.equal(board.outbox[S.seqKey(finish.receipt.publicSeq)].wire.length,2);
});
test("stale score is rejected; replay does not mutate board",()=>{
 const previous=clone(board),bad={eventId:eid,opId:id(++seqN),target:{kind:"round",ri:0,mi:0},expectedMatchVersion:0,lockToken:"wrong",sa:6,sb:0};
 assert.throws(()=>Board.applyBoard(board,owner,"score",bad,now),/版本|已完成/);
 assert.deepEqual(board,previous);
 const prior={eventId:eid,opId:board?Object.keys(board.receipts)[0]:null,target:{kind:"round",ri:0,mi:0}};
 // exact first claim input replays the result without a second authority transaction
 const original=firstClaim;
 const replay=Board.applyBoard(board,owner,"claim",original,now);
 assert.equal(replay.replay,true);assert.equal(replay.board,null);
});
test("unauthorized user cannot change score or claim",()=>{
 assert.throws(()=>Board.applyBoard(board,other,"claim",{eventId:eid,opId:id(++seqN),target:{kind:"round",ri:0,mi:1}},now,"a","box"),/沒有執裁權限/);
});
test("projection has no public read before commit and can recover after crash",async()=>{
 assert.equal(get(store,`eventsV01/${eid}/public/sync/seq`),0);
 await assert.rejects(()=>Pub.drain(db,eid,{failAfterSeq:2}),/INJECTED_PUBLICATION_CRASH/);
 assert.equal(get(store,`eventsV01/${eid}/public/sync/seq`),1);
 assert.ok(board.seq>=3);
 const repaired=await Pub.drain(db,eid);
 assert.equal(repaired.cursor,board.seq);
 const published=get(store,`eventsV01/${eid}/public`);
 assert.equal(published.rounds[0].matches[0].winner,"P1");
 assert.equal(published.rounds[1].matches[0].a,"P1");
 assert.equal(published.sync.seq,board.seq);
 assert.equal(published.changes[S.seqKey(3)].kind,"batch");
 assert.equal(published.changes[S.seqKey(3)].items.length,2);
});
test("public SSE is tiny, incremental, and contains no private lock or UID",()=>{
 const payload=get(store,`eventsV01/${eid}/public/sync`);
 assert.ok(JSON.stringify(payload).length<300);
 assert.ok(!JSON.stringify(get(store,`eventsV01/${eid}/public`)).includes(owner));
 assert.ok(!JSON.stringify(payload).includes("lockToken"));
});
test("400 simulated public clients recover a complete contiguous change log",()=>{
 const publicData=get(store,`eventsV01/${eid}/public`);
 const log=Object.values(publicData.changes).sort((a,b)=>a.seq-b.seq);
 for(let i=0;i<400;i++){
  const c=S.newCache(eid);c.seq=0;
  c.rounds={0:S.normalizeRound(init.rounds[0]),1:S.normalizeRound(init.rounds[1])};
  const next=S.replay(c,log,board.seq);
  assert.equal(next.rounds[0].matches[0].winner,"P1");
  assert.equal(next.rounds[1].matches[0].a,"P1");
 }
});
test("published entries may compact without deleting uncommitted history",async()=>{
 const before=Object.keys(board.outbox).length;
 const t=await Pub.compactOutbox(db,eid,{threshold:0});
 assert.equal(t.committed,true);
 assert.equal(Object.keys(get(store,`eventsV01/${eid}/board/outbox`)).length,0);
 assert.ok(before>=3);
});
test("comparison metric excludes true Firebase wire/storage costs",()=>{
 console.log("MOCK_METRICS="+JSON.stringify(metrics));
 assert.ok(metrics.transaction>=2&&metrics.update>=3);
});
test("timestamped operation IDs expire safely without a perpetual receipt ledger",()=>{
 const old=clone(board);
 const ancient=(now-Board.OP_WINDOW_MS-1000).toString(16).padStart(12,"0")+"e".repeat(36);
 const input={eventId:eid,opId:ancient,target:{kind:"round",ri:0,mi:1}};
 assert.throws(()=>Board.applyBoard(old,owner,"claim",input,now,"some-token","encrypted"),/過期/);
 const invented=(now+6*60000).toString(16).padStart(12,"0")+"f".repeat(36);
 assert.throws(()=>Board.applyBoard(old,owner,"claim",{...input,opId:invented},now,"some-token","encrypted"),/過期/);
});
test("new authority refuses additional writes if 64 unacknowledged public deltas accumulated",()=>{
 const stuck=clone(board);
 stuck.outbox=Object.fromEntries(Array.from({length:64},(_,i)=>[S.seqKey(i+1),{seq:i+1,wire:[]}]));
 const d={eventId:eid,opId:id(++seqN),target:{kind:"round",ri:0,mi:1}};
 assert.throws(()=>Board.applyBoard(stuck,owner,"claim",d,now,"test-token","sealed-box"),/同步積壓/);
});
test("multi-location public patch has matching cursor and change entry",()=>{
 const entry=board.outbox[S.seqKey(board.seq)];
 // Outbox was compacted in an earlier test; test the converter independently.
 const b=Board.createBoard({roster:Array.from({length:24},(_,i)=>`P${i+1}`),ownerUid:owner,now});
 const c=Board.applyBoard(b,owner,"claim",{eventId:eid,opId:id(++seqN),target:{kind:"round",ri:0,mi:0}},now,"token","encrypted");
 const env=c.board.outbox[S.seqKey(1)];const patch=Pub.publicationPatch(env);
 assert.equal(patch["public/sync"].seq,1);
 assert.ok(patch["public/changes/000000000001"]);
 assert.ok(patch["public/rounds/0/matches/0"]);
});
test("free brackets 24/36/48 advance deterministically into the final-three RR",()=>{
 for(const n of [24,36,48]){
  let b=Board.createBoard({roster:Array.from({length:n},(_,i)=>`N${i+1}`),ownerUid:owner,now,mode:"free",freeFinal:"rr3"});
  let counter=50000;
  for(let ri=0;ri<b.rounds.length;ri++)for(let mi=0;mi<b.rounds[ri].matches.length;mi++){
   let m=b.rounds[ri].matches[mi];
   if(m.winner)continue; // BYE auto-advance
   assert.ok(m.a!=="待定"&&m.b!=="待定",`${n} round ${ri} match ${mi} has participants`);
   const target={kind:"round",ri,mi},eventId=`e-${n}`;
   const run=(action,other={},tk=null)=>{
    const d={eventId,opId:id(++counter),target,...other};
    const result=Board.applyBoard(b,owner,action,d,now,tk,tk?"encrypted":"encrypted");
    b=result.board;
    // The already-tested projector acknowledged the change, so no backlog.
    b.outbox={};
    return result;
   };
   const token=`token-${n}-${ri}-${mi}`;
   run("claim",{},token);
   run("score",{expectedMatchVersion:b.rounds[ri].matches[mi].matchVersion,lockToken:token,sa:4,sb:2});
   run("complete",{expectedMatchVersion:b.rounds[ri].matches[mi].matchVersion,lockToken:token});
  }
  assert.ok(b.finalRR,`missing RR for ${n}`);
  assert.equal(b.finalRR.players.length,3);
  assert.equal(new Set(b.finalRR.players).size,3);
 }
});
test("RR score updates only its 3-match group and public standings",()=>{
 let b=Board.createBoard({roster:["A","B","C"],ownerUid:owner,now,mode:"free",freeFinal:"rr3"});
 const target={kind:"rr",mi:0},token="rr-lock",start=Date.now();
 const exec=(action,data={})=>{
  const d={eventId:eid,opId:id(++seqN),target,...data};
  const r=Board.applyBoard(b,owner,action,d,start,action==="claim"?token:null,action==="claim"?"sealed":null);
  b=r.board;return r;
 };
 exec("claim");exec("score",{expectedMatchVersion:b.finalRR.matches[0].matchVersion,lockToken:token,sa:4,sb:1});
 exec("complete",{expectedMatchVersion:b.finalRR.matches[0].matchVersion,lockToken:token});
 assert.equal(b.finalRR.standings[0].player,"A");
 const delta=b.outbox[S.seqKey(b.seq)].wire;
 assert.equal(delta.length,1);assert.equal(delta[0].kind,"rr");
});
test("bounded public history deletes the oldest published entry after 96 changes",()=>{
 const seq=97;
 const patch=Pub.publicationPatch({seq,full:[{kind:"match",ri:0,mi:0,full:{a:"A",b:"B",sa:1,sb:0}}],
  wire:[{kind:"match",ri:0,mi:0,roundRevision:97,patch:{sa:1}}]});
 assert.equal(patch["public/changes/000000000001"],null);
 assert.equal(patch["public/sync"].seq,97);
});
test("source board and public projection remain identical after a complete 24-player RR qualification",async()=>{
 const name="project-all-24",clock=Date.now();
 let b=Board.createBoard({roster:Array.from({length:24},(_,i)=>`P${i+1}`),ownerUid:owner,now:clock,mode:"free",freeFinal:"rr3"});
 put(store,`eventsV01/${name}`,{board:b,public:Board.publicInitial(b,name,"Project all"),meta:{ownerUid:owner}});
 let number=70000;
 for(let ri=0;ri<b.rounds.length;ri++)for(let mi=0;mi<b.rounds[ri].matches.length;mi++){
  if(b.rounds[ri].matches[mi].winner)continue;
  const token=`winner-${ri}-${mi}`,target={kind:"round",ri,mi};
  for(const action of ["claim","score","complete"]){
   const inp={eventId:name,opId:id(++number),target};
   if(action!=="claim"){
    inp.lockToken=token;
    inp.expectedMatchVersion=b.rounds[ri].matches[mi].matchVersion;
   }
   if(action==="score"){inp.sa=4;inp.sb=2;}
   const result=Board.applyBoard(b,owner,action,inp,clock,action==="claim"?token:null,action==="claim"?"encrypted":null);
   b=result.board;put(store,`eventsV01/${name}/board`,b);
   const x=await Pub.drain(db,name,{limit:32});
   assert.equal(x.cursor,b.seq);
  }
 }
 const published=get(store,`eventsV01/${name}/public`);
 assert.equal(published.sync.seq,b.seq);
 for(let ri=0;ri<b.rounds.length;ri++){
  const a=b.rounds[ri],p=published.rounds[ri];
  assert.equal(p.revision,a.revision);
  for(let mi=0;mi<a.matches.length;mi++)assert.deepEqual(p.matches[mi],S.publicMatch(a.matches[mi]));
 }
 assert.deepEqual(published.finalRR.players,b.finalRR.players);
 assert.equal(published.meta.hasFinalRR,true);
});
test("held publication lease makes writer wait instead of publishing out of sequence",async()=>{
 const name="lease-test-12345",clock=Date.now();
 const b=Board.createBoard({roster:["A","B","C"],ownerUid:owner,now:clock});
 put(store,`eventsV01/${name}`,{board:b,public:Board.publicInitial(b,name,"Lease"),publisherLease:{token:"another",until:clock+50000}});
 const busy=await Pub.drain(db,name,{now:()=>clock});assert.equal(busy.busy,true);
 const later=await Pub.drain(db,name,{now:()=>clock+60000});assert.equal(later.busy,false);
});
