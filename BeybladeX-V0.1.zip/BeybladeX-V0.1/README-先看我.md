# Beyblade X 賽程表 V0.1 — 全系統整合候選包

**用途**：把 V0.1 主辦／裁判與 Stage 4 小型交易、公開同步、觀眾延遲載入接到同一版。正式網址規劃使用 `https://rkomrz.github.io/Beyblade-X/`，**Firebase 後端暫指向 `ljt-beyblade-x-test`**，與線上報名 `ljtreg-39954` 完全隔離。

> **重要：這份是待部署與待雲端驗收的候選包，不是已部署完成的網站。請勿只上傳 `index.html` 就宣稱全功能正常。**

## 已接通的候選操作（程式已編寫，尚未做真 Firebase 端到端驗證）

- Google 主辦登入、建立賽事、只讀取自己 `ownerIndexV01` 賽事索引。
- 自由編排／標準單淘汰、依序／抽籤配對、24→12→6→3 與三人循環、36／48 人不規則輪次。
- 主辦 60 秒六碼入場、裁判匿名登入、一次加入、主辦關閉／重新開放／刪除標記。
- 裁判領場、場次鎖定、比分 0–6、先在手機快速加分後一次送出、完成、釋放、未完成比分歸零。
- Cloud Functions 單次操作內驗證 uid／操作碼／執裁鎖／比分版本；同一 board transaction 完成相關晉級。
- 已發生、但手機沒收到成功的操作，可用同一 opId 查詢回條；不能以舊版本覆蓋比分。
- `Publisher.drain()` 將權威交易 outbox 以原子 multipath 更新公開輪次、精簡 SSE、staff/sync。觸發器負責補發。
- 觀眾新手機按輪次載入；已有有效快取時 SSE-first，正常無額外版本 GET。
- 版本隔離：`eventsV01`、`ownerIndexV01`、`*V01`，不呼叫 V2、V4 或正式 V1 函式。

## 明確未完成／不可宣稱通過

1. **正式 V1.0 的全功能等價尚未完成**：已完成比分撤回／安全回退下游、雲端編輯選手／抽籤重排、裁判人數及名稱管理、進階樹狀圖與部分主辦工具仍待移植。後端對已完成場次復原採拒絕而不是冒險覆寫。
2. **真 Firebase Emulator／測試專案尚未驗收**：Realtime Database Rules、Google／匿名 Auth、Secret Manager、Functions triggers、跨手機一致性、200 人 SSE、長場次交易及實際費用都還未測試。
3. 裁判六碼僅設基本 UID 10 分鐘 5 次限制；匿名帳號可輪替，對外公開前需加入 App Check 及更完整的防濫用限制。
4. 計分 Function 仍對該場權威 `board` 節點執行 transaction，伺服器成本尚未證明低於 V1.0。
5. **GitHub Pages 與 Firebase 未在這次回合實際部署。**

## 檔案說明

- `index.html`：根目錄主辦＋裁判 V0.1（不是只有觀眾展示）。
- `viewer/viewer.html`：公開只讀觀眾 V0.1、SSE-first、按輪次載入。
- `functions/index.js`、`functions/lib/*`：可獨立打包的 V01 Functions；不依賴上層資料夾（解決 Stage4 先前 `../src` 外部路徑問題）。
- `database.rules.json`：預覽待 Emulator 驗證的 V01 規則，拒絕所有客戶端直接寫入。
- `src/*`：同版純邏輯測試副本。
- `tests/*`：24 項 Node 純邏輯測試（並發／出錯重試／賽制／管理權限等），**不等同真雲端測試**。
- `deploy/*`：版本核對與依據資源清單清理的操作規範；開發期不要求網站備份。

## 真正部署前至少需要

1. **Firebase TEST Web App 參數**：在 `index.html` 把 `REPLACE_TEST_API_KEY` 與 `REPLACE_TEST_APP_ID` 換成 `ljt-beyblade-x-test` 對應的值，**不能拿正式專案或線上報名專案的 key/appId 混用**。
2. Firebase Auth 需啟用 Google、匿名登入，Authorized Domains 包含 `rkomrz.github.io`，並完成 App Check／流量限制評估。
3. Firebase 測試專案需 Blaze、Cloud Functions 依賴與 `BX_LOCK_KEY` 32-byte 隨機 Secret Manager 金鑰（不可寫入網頁或 GitHub）。
4. 使用者授權及實際 GitHub/Firebase CLI 存取；正式網址根目錄 GitHub Pages 需用新版完整文件更新。
5. 先執行 Emulator 測試及必要的功能驗收，不得跳過到正式開放。

## 版本升級與清理制度

每版都用新函式名稱／節點版本；清理時按 **Beyblade X 賽程專屬資源清單** 操作。先確認 Firebase projectId、列出舊函式／路徑，確認無其他專案資料後，再刪除已核准的舊版本。開發測試期依使用者決定不備份目前空白網站；正式對外開放後再加入資料備份與回復流程。絕不執行整個帳號／資料庫根 `/` 的盲刪。不能只靠刪除阻擋舊手機：Cloud Functions、Rules 與 HTML 也要驗證版本。

**V0.1 尚未實際上傳正式網址，這次沒有刪除任何 Firebase 資料／函式。**
