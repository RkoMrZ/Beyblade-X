#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/deploy/v01-common.sh"
bx_here
printf '====== BeybladeX V0.1 雲端部署查驗 ======\n'
bx_check_listings
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('/tmp/bxv01-gcloud-functions.json').read_text())
n={f['name'].split('/')[-1] for f in r}
need={'createEventV01','getEventV01','getJoinCodeV01','joinEventV01','claimMatchV01','scoreMatchV01','completeMatchV01','releaseMatchV01','resetMatchV01','getOperationV01','setPublicV01','deleteEventV01','publishChangesV01','repairPublicationV01'}
missing=need-n
if missing:raise SystemExit('未成功部署所有函式：'+', '.join(sorted(missing)))
print('確認 14/14 支 V0.1 函式存在。')
PY
bx_fetch_rules
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('/tmp/bxv01-live-rules.json').read_text())
if isinstance(r,str):r=json.loads(r)
for k in ('eventsV01','ownerIndexV01'):
    assert k in r['rules'],f'缺少 V01 Rules：{k}'
print('確認 V01 Rules 已存在，其他專案不在操作範圍內。')
PY
printf '\n查驗完成。仍需在網頁驗證 Google/匿名登入、主辦、裁判與觀眾同步，不能只憑這一步宣稱整套功能通過。\n'
