#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT='ljt-beyblade-x'
INSTANCE='ljt-beyblade-x-default-rtdb'
DB="https://${INSTANCE}.asia-southeast1.firebasedatabase.app"
mode="${1:-}"
fail() { echo "停止：$*" >&2; exit 1; }
[ "$(basename "$PWD")" = 'BeybladeX-V0.1' ] || fail '請先 cd ~/BeybladeX-V0.1'
[ -f firebase.json ] && [ -f functions/index.js ] || fail '缺少必要程式'
command -v firebase >/dev/null || fail '沒有 Firebase CLI；先執行 npm install -g firebase-tools'
command -v gcloud >/dev/null || fail '此工具需於 Google Cloud Shell 執行'
command -v python3 >/dev/null || fail '找不到 Python 3'

prepare_rules() {
  local tok
  tok="$(gcloud auth print-access-token)" || fail 'Cloud Shell 尚未登入正確的 Google 帳號'
  curl -fsSL --retry 2 --connect-timeout 15 --max-time 45 -H "Authorization: Bearer ${tok}" \
    "${DB}/.settings/rules.json" -o /tmp/bxv01-live-rules.json || fail '無法取得正式 Firebase 現有 Rules。請不要直接部署候選規則！'
  python3 deploy/merge-live-rules.py || fail 'Rules 合併檢查失敗'
}

case "$mode" in
  prepare)
    rm -f .v01-prepared
    [ "$(node -p 'process.versions.node.split(".")[0]')" = '22' ] || fail '此版本需要 Node.js 22。請執行 nvm use 22'
    echo '確認正式賽程專案的登入權限…'
    firebase projects:list --project "$PROJECT" >/dev/null || fail 'Firebase CLI 尚未登入或無正式專案權限：firebase login --no-localhost'
    echo '先確認 Cloud Functions API 存取（避免部署到一半才報錯）…'
    if ! firebase functions:list --project "$PROJECT" >/dev/null 2>&1; then
      fail '仍無法讀取 Cloud Functions。請先執行 bash 00_audit.sh 查看 API／權限錯誤，再處理，不要清空 Cloud Shell。'
    fi
    firebase database:instances:list --project "$PROJECT" || fail '無法列出 Realtime Database'
    echo '檢查與安裝 Functions 依賴…'
    npm --prefix functions install --omit=dev --no-audit --no-fund
    node --check functions/index.js
    for f in functions/lib/*.js; do node --check "$f"; done
    node --test tests/authority-regression.test.js tests/v01-management.test.js
    prepare_rules
    firebase target:apply database bxv01-main "$INSTANCE" --project "$PROJECT"
    python3 - <<'PY'
import json
from pathlib import Path
path=Path('firebase.json'); obj=json.loads(path.read_text())
obj['database']={'target':'bxv01-main','rules':'database.rules.json'}
path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print('固定 Rules 部署目標為 ljt-beyblade-x-default-rtdb')
PY
    touch .v01-prepared
    echo 'PREPARE 完成。尚未部署。下一步可執行：bash deploy/cloudshell-v01.sh functions'
    ;;
  functions)
    [ -f .v01-prepared ] || fail '請先執行 prepare'
    echo '準備 BX_LOCK_KEY，只有 V01 需要；不輸出金鑰。'
    if firebase functions:secrets:get BX_LOCK_KEY --project "$PROJECT" >/dev/null 2>&1; then
      echo '使用已存在的 BX_LOCK_KEY，不覆蓋 Secret。'
    else
      umask 077
      keyfile="$(mktemp)"
      trap 'rm -f "${keyfile:-}"' EXIT
      openssl rand -hex 32 | tr -d "\n" > "$keyfile"
      firebase functions:secrets:set BX_LOCK_KEY --data-file "$keyfile" --project "$PROJECT" || fail 'Secret 建立失敗'
      rm -f "$keyfile"
      trap - EXIT
    fi
    echo '只部署 bxv01 codebase，不刪除其他 Functions。'
    firebase deploy --only functions:bxv01 --project "$PROJECT" || fail '函式部署失敗，請提供末段錯誤畫面'
    echo 'FUNCTIONS 部署完成。可執行：bash deploy/cloudshell-v01.sh rules'
    ;;
  rules)
    [ -f .v01-prepared ] || fail '請先執行 prepare'
    echo '部署前重新取得正式 Rules 並合併，只變動 V01 節點…'
    prepare_rules
    firebase deploy --only database --project "$PROJECT" || fail 'Rules 部署失敗'
    echo 'RULES 部署完成。請再檢查 Functions 清單。'
    firebase functions:list --project "$PROJECT"
    ;;
  *)
    cat <<'HELP'
用法（Cloud Shell，在 BeybladeX-V0.1 目錄執行）：
  bash deploy/cloudshell-v01.sh prepare
  bash deploy/cloudshell-v01.sh functions
  bash deploy/cloudshell-v01.sh rules
本工具不刪資料、不清空網站，也不刪舊函式；先保留既有 Rules，再只更新 V01 節點。
HELP
    exit 2
    ;;
esac
