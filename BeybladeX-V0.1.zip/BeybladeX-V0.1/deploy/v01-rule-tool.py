#!/usr/bin/env python3
"""Strip or merge only V01 rules, with strict non-V01 preservation."""
import json
import sys
from pathlib import Path

mode=sys.argv[1]
live=json.loads(Path('/tmp/bxv01-live-rules.json').read_text())
if isinstance(live,str): live=json.loads(live)
if not isinstance(live,dict) or not isinstance(live.get('rules'),dict):
    raise SystemExit('停止：線上 Rules 不合法')
raw=live['rules']
if raw.get('.read') is True or raw.get('.write') is True:
    raise SystemExit('停止：線上根規則過於寬鬆，需要人工檢查')
orig={k:v for k,v in raw.items() if k not in ('eventsV01','ownerIndexV01')}
if mode=='strip':
    raw.pop('eventsV01',None)
    raw.pop('ownerIndexV01',None)
elif mode=='merge':
    newer=json.loads(Path('database.rules.v01-only.json').read_text())['rules']
    if set(newer)!={'.read','.write','eventsV01','ownerIndexV01'}:
        raise SystemExit('停止：規則範本出現非預期欄位')
    if newer['.read'] is not False or newer['.write'] is not False:
        raise SystemExit('停止：規則範本根權限設定錯誤')
    for k in ('eventsV01','ownerIndexV01'):
        raw[k]=newer[k]
else: raise SystemExit('停止：未知操作')
assert {k:v for k,v in raw.items() if k not in ('eventsV01','ownerIndexV01')}==orig
Path('database.rules.json').write_text(json.dumps(live,ensure_ascii=False,indent=2)+'\n')
print('Rules '+mode+' 完成；其他權限分支沒有被修改。')
