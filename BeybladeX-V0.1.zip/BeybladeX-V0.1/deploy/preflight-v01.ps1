# Read-only (no Firebase calls): verify the local V0.1 code and version bindings.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if ((Get-Content .firebaserc -Raw) -notmatch 'ljt-beyblade-x-test') { throw '停止：不是指定 TEST 專案' }
if ((Get-Content index.html -Raw) -match 'REPLACE_TEST_') { throw '停止：尚未設定 TEST 專案的 Firebase Web apiKey/appId' }
if ((Get-Content functions/index.js -Raw) -match 'eventsV4|eventsV2') { throw '停止：發現舊資料節點' }
node --check functions/index.js
if ($LASTEXITCODE -ne 0) { throw 'Cloud Functions 語法檢查失敗' }
node --test tests/authority-regression.test.js tests/v01-management.test.js
if ($LASTEXITCODE -ne 0) { throw '測試未通過' }
Write-Host '本機 V0.1 程式檢查完成；未執行部署或刪除。' -ForegroundColor Green
