#!/usr/bin/env bash
# Shared safety guards for the Beyblade X tournament V0.1 ONLY.
set -Eeuo pipefail
BX_PROJECT='ljt-beyblade-x'
BX_INSTANCE='ljt-beyblade-x-default-rtdb'
BX_REGION='asia-southeast1'
BX_DB_URL="https://${BX_INSTANCE}.${BX_REGION}.firebasedatabase.app"
BX_EXPECTED_FUNCTIONS=(
  createEventV01 getEventV01 getJoinCodeV01 joinEventV01
  claimMatchV01 scoreMatchV01 completeMatchV01 releaseMatchV01 resetMatchV01
  getOperationV01 setPublicV01 deleteEventV01 publishChangesV01 repairPublicationV01
)
bx_die(){ printf '\n停止：%s\n' "$*" >&2; exit 1; }
bx_here(){
  cd "$(dirname "${BASH_SOURCE[0]}")/.."
  [[ "$(basename "$PWD")" == 'BeybladeX-V0.1' ]] || bx_die '資料夾名稱不是 BeybladeX-V0.1'
  [[ -f .firebaserc && -f firebase.json && -f functions/index.js && -f database.rules.v01-only.json ]] || bx_die '缺少 V0.1 必要檔案'
  command -v firebase >/dev/null || bx_die '找不到 Firebase CLI；先執行 npm install -g firebase-tools'
  command -v gcloud >/dev/null || bx_die '本腳本只能在 Google Cloud Shell 使用'
  command -v python3 >/dev/null || bx_die '找不到 Python3'
  command -v curl >/dev/null || bx_die '找不到 curl'
  [[ "$(node -p 'process.versions.node.split(".")[0]')" == '22' ]] || bx_die 'Node.js 必須為 22；請先使用 nvm use 22'
  python3 - <<'PY'
import json
from pathlib import Path
assert json.loads(Path('.firebaserc').read_text())['projects']['default']=='ljt-beyblade-x', '專案設定不符'
a=json.loads(Path('firebase.json').read_text())
assert a['functions'][0]['codebase']=='bxv01', 'Cloud Functions codebase 不符'
assert a['functions'][0]['source']=='functions', 'Cloud Functions source 不符'
PY
  [[ "$(gcloud config get-value project 2>/dev/null)" == "$BX_PROJECT" ]] || bx_die 'Google Cloud 目前選取的專案不是 ljt-beyblade-x'
}
bx_check_listings(){
  printf '\n===== Google Cloud V2 Functions (只列出，不刪除) =====\n'
  gcloud functions list --v2 --regions="$BX_REGION" --project="$BX_PROJECT" --format=json > /tmp/bxv01-gcloud-functions.json || bx_die 'Google Cloud 不能列出第二代函式。停止清理。'
  python3 deploy/v01-inventory.py /tmp/bxv01-gcloud-functions.json
  printf '\n===== Firebase CLI Functions 查詢 =====\n'
  if ! firebase functions:list --project "$BX_PROJECT" > /tmp/bxv01-firebase-functions.txt 2>&1; then
    tail -n 15 /tmp/bxv01-firebase-functions.txt
    bx_die 'Firebase functions:list 仍然失敗。請先排除權限或 API 問題，不可先刪再部署。'
  fi
  tail -n 24 /tmp/bxv01-firebase-functions.txt
}
bx_fetch_rules(){
  local token
  token="$(gcloud auth print-access-token)" || bx_die '無法取得 Cloud Shell 登入權杖'
  curl -fLsS --retry 2 --connect-timeout 10 --max-time 40 \
    -H "Authorization: Bearer ${token}" \
    "$BX_DB_URL/.settings/rules.json" -o /tmp/bxv01-live-rules.json || bx_die '讀取正式資料庫 Rules 失敗。停止操作。'
  python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('/tmp/bxv01-live-rules.json').read_text())
if isinstance(r,str): r=json.loads(r)
assert isinstance(r,dict) and isinstance(r.get('rules'),dict), '線上 Rules 結構不合法'
assert r['rules'].get('.read') is not True and r['rules'].get('.write') is not True, '不接受根規則全開放'
print('確認只接觸 ljt-beyblade-x 的 Rules；現有節點：', ', '.join(sorted(r['rules'])))
PY
}
bx_target(){
  firebase target:apply database bxv01-main "$BX_INSTANCE" --project "$BX_PROJECT" >/dev/null || bx_die '無法鎖定 RTDB instance'
  python3 - <<'PY'
import json
from pathlib import Path
p=Path('firebase.json'); j=json.loads(p.read_text());j['database']={'target':'bxv01-main','rules':'database.rules.json'}
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
PY
}
