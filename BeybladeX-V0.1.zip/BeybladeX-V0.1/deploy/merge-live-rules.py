#!/usr/bin/env python3
"""Safely merge only Beyblade X V0.1 subtrees into fetched live RTDB rules."""
import json
from pathlib import Path

live_path = Path('/tmp/bxv01-live-rules.json')
candidate_path = Path('database.rules.v01-only.json')
out_path = Path('database.rules.json')

raw = json.loads(live_path.read_text(encoding='utf-8'))
if isinstance(raw, str):
    raw = json.loads(raw)
new = json.loads(candidate_path.read_text(encoding='utf-8'))
if not isinstance(raw, dict) or not isinstance(raw.get('rules'), dict):
    raise SystemExit('停止：線上 Rules 回應無合法 rules 物件，禁止覆寫')
if not isinstance(new, dict) or not isinstance(new.get('rules'), dict):
    raise SystemExit('停止：候選規則沒有 rules 物件')
expected = {'ownerIndexV01', 'eventsV01'}
if set(new['rules']) != {'.read', '.write'} | expected:
    raise SystemExit('停止：V0.1 規則包含非預期頂層節點')
if new['rules'].get('.read') is not False or new['rules'].get('.write') is not False:
    raise SystemExit('停止：V0.1 規則根節點不得開放讀寫')
if raw['rules'].get('.read') is True or raw['rules'].get('.write') is True:
    raise SystemExit('停止：線上規則根節點已開放讀寫，請人工檢查後再操作')
old_keys = set(raw['rules'])
for key in expected:
    raw['rules'][key] = new['rules'][key]
out_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
if set(raw['rules']) != old_keys | expected:
    raise SystemExit('停止：合併過程影響了非 V0.1 節點')
print('合併成功：只加入／更新 eventsV01、ownerIndexV01；其他現有 Rules 分支未改動。')
print('保留原有規則分支：', ', '.join(sorted(old_keys - expected)) or '(none)')
