#!/usr/bin/env python3
"""List and validate gen2 function names before any V01 deletion."""
import json
import re
import sys
from pathlib import Path

EXACT = {
    'createEventV01', 'getEventV01', 'getJoinCodeV01', 'joinEventV01',
    'claimMatchV01', 'scoreMatchV01', 'completeMatchV01',
    'releaseMatchV01', 'resetMatchV01', 'getOperationV01',
    'setPublicV01', 'deleteEventV01', 'publishChangesV01',
    'repairPublicationV01',
}
items = json.loads(Path(sys.argv[1]).read_text())
if not isinstance(items,list): raise SystemExit('停止：Cloud Functions 回傳格式不正確')
seen=set()
for item in items:
    name=item.get('name','').split('/')[-1]
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,127}',name):
        raise SystemExit('停止：函式名稱格式異常')
    if name.lower().endswith('v01') and name not in EXACT:
        raise SystemExit('停止：發現非預期 V01 函式 '+name+'，請人工核對。')
    if name in EXACT:
        seen.add(name)
print('可以識別的 V0.1 函式：', ', '.join(sorted(seen)) if seen else '(尚未部署)')
print('其他函式：', len(items)-len(seen), '支；不會刪除')
if len(sys.argv)>2:
    Path(sys.argv[2]).write_text('\n'.join(sorted(seen))+'\n')
