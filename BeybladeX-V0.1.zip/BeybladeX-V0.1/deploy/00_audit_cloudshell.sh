#!/usr/bin/env bash
# Read-only Cloud Shell workspace inventory. No Firebase changes, no deletion.
set -Eeuo pipefail
PROJECT='ljt-beyblade-x'
echo '===== 1/5 Cloud Shell 環境 ====='
printf 'HOME=%s\nPWD=%s\n' "$HOME" "$PWD"
printf 'Google Cloud project='; (gcloud config get-value project 2>/dev/null || true)
printf 'Node='; (node --version 2>/dev/null || echo '未安裝')
printf 'Node 執行位置='; (command -v node || true)
printf 'Firebase CLI='; (firebase --version 2>/dev/null || echo '未安裝')
echo '===== 2/5 家目錄頂層清冊（只顯示名稱，不讀取內容） ====='
find "$HOME" -mindepth 1 -maxdepth 1 -printf '%y %f\n' | LC_ALL=C sort | sed -n '1,150p'
echo '===== 3/5 賽程表候選清理項目（不包含線上報名） ====='
python3 - <<'PY'
import re
from pathlib import Path
home=Path.home()
patterns=[r'BeybladeX-V\d+\.\d+(?:\.zip)?',r'Beyblade-X-VNext-.*',r'Beyblade-X-V0\.1-.*']
items=sorted((p for p in home.iterdir() if any(re.fullmatch(x,p.name) for x in patterns)),key=lambda p:p.name)
for p in items: print(('目錄 ' if p.is_dir() else '檔案 ')+str(p))
if not items:print('未找到賽程表舊工作檔')
print('保護：所有 BeybladeX-reg-*、.nvm、.config、.ssh、.cache 均不列入清理')
PY
echo '===== 4/5 登入狀態（請勿分享含帳號的截圖） ====='
if command -v firebase >/dev/null; then firebase login:list 2>&1 | head -n 8 || true; fi
echo '===== 5/5 目前專案的 API 診斷（純讀取） ====='
if command -v gcloud >/dev/null; then
  gcloud services list --enabled --project "$PROJECT" --format='value(config.name)' 2>/dev/null | grep -E 'cloudfunctions.googleapis.com|cloudbuild.googleapis.com|run.googleapis.com|firebase.googleapis.com|firebasedatabase.googleapis.com' || echo 'API 清單無法取得或尚未啟用相關 API'
fi
if command -v firebase >/dev/null; then
  tmp=$(mktemp); chmod 600 "$tmp"; trap 'rm -f "$tmp"' EXIT
  if firebase functions:list --project "$PROJECT" --debug >"$tmp" 2>&1; then
    echo 'Cloud Functions 清單取得成功'
  else
    echo 'Cloud Functions 清單仍失敗。以下僅顯示錯誤概要（不顯示 OAuth headers）：'
    python3 - "$tmp" <<'PY'
import sys,re
lines=open(sys.argv[1],encoding='utf8',errors='replace').read().splitlines()
pat=re.compile(r'\b(?:401|403|404|429|500|503)\b|\berror\b|permission|denied|disabled|not.?enabled|forbidden|unauthorized|failed',re.I)
filtered=[]
for line in lines:
 if not pat.search(line):continue
 if re.search(r'Authorization:|Bearer |access_token|id_token|refresh_token|api[_-]?key|Authorization.*=',line,re.I):continue
 if len(line)>300:line=line[:300]+' …'
 filtered.append(line)
for line in filtered[-12:]:print(line)
PY
  fi
fi
echo '稽核完成：本腳本沒有刪除檔案或部署 Firebase。'
