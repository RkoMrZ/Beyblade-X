#!/usr/bin/env bash
# Only delete obsolete Beyblade X tournament workspaces in Cloud Shell $HOME.
# NEVER touches Firebase/GitHub, signup app, authentication or Node.
set -Eeuo pipefail
mode="${1:-preview}"
case "$mode" in preview|--execute) ;; *) echo '用法: bash deploy/02_clean_old_cloudshell.sh [preview|--execute]'; exit 2;; esac
python3 - "$mode" <<'PY'
from pathlib import Path
import sys,re,shutil
home=Path.home().resolve()
mode=sys.argv[1]
patterns=(r'BeybladeX-V\d+\.\d+(?:\.zip)?',r'Beyblade-X-VNext-.*',r'Beyblade-X-V0\.1-.*')
keep=Path.cwd().resolve() # Never delete running source or its containing directory.
items=[]
for p in home.iterdir():
 if not any(re.fullmatch(q,p.name) for q in patterns):continue
 if p.is_symlink():continue
 path=p.resolve()
 if path==keep or path in keep.parents:continue
 if path.parent!=home:continue
 items.append(p)
print('只會處理以下賽程表開發檔：')
for p in sorted(items):print('  '+str(p))
print('保留：當前工作資料夾 '+str(keep))
print('保留：BeybladeX-reg-*、其他專案、.nvm、Firebase 登入憑證和所有雲端資料')
if mode!='--execute':
 print('目前為預覽；未刪除任何檔案。如要執行，使用 --execute')
else:
 for p in items:
  if p.is_dir():shutil.rmtree(p)
  else:p.unlink()
 print(f'清理完成：{len(items)} 個舊賽程表檔案／資料夾；未操作 Firebase。')
PY
