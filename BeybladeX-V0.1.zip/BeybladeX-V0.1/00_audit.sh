#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
bash deploy/00_audit_cloudshell.sh
echo '===== 賽程表舊版清理預覽（尚未刪除） ====='
bash deploy/02_clean_old_cloudshell.sh preview
