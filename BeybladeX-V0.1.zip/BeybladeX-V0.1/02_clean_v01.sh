#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/deploy/v01-common.sh"
bx_here
printf '====== 僅清除 ljt-beyblade-x 的 V0.1 資源 ======\n'
bx_check_listings
bx_fetch_rules
bx_target
python3 deploy/v01-inventory.py /tmp/bxv01-gcloud-functions.json /tmp/bxv01-functions-to-delete.txt
printf '\n唯一預定刪除的資料節點：\n  /eventsV01\n  /ownerIndexV01\n'
printf '舊 V01 Rules 分支將移除後再重新部署；BX_LOCK_KEY 先保留（不確定是否被其他函式使用）。\n'
printf '不觸及：ljtreg-39954、GitHub reg/、BeybladeX-reg-V0.2.zip。\n'
read -r -p '確認真的要刪 V0.1 資料與上述 V0.1 函式？請輸入 CLEAN-V01：' answer
[[ "$answer" == 'CLEAN-V01' ]] || bx_die '使用者取消；沒有執行清理'
printf '\n先停止 V01 前端讀取 Rules…\n'
python3 deploy/v01-rule-tool.py strip
firebase deploy --only database --project "$BX_PROJECT" || bx_die 'Rules 清理失敗，停止後續刪除。'
printf '\n刪除經驗證的 V0.1 Cloud Functions…\n'
while IFS= read -r function; do
  [[ -z "$function" ]] && continue
  printf '刪除：%s\n' "$function"
  gcloud functions delete "$function" --region="$BX_REGION" --project="$BX_PROJECT" --quiet || bx_die "函式刪除失敗：$function；可修正後重跑"
done < /tmp/bxv01-functions-to-delete.txt
printf '\n清除 V01 賽事及主辦索引節點…\n'
firebase database:remove /eventsV01 --instance "$BX_INSTANCE" --project "$BX_PROJECT" --force || bx_die 'eventsV01 清理失敗'
firebase database:remove /ownerIndexV01 --instance "$BX_INSTANCE" --project "$BX_PROJECT" --force || bx_die 'ownerIndexV01 清理失敗'
touch .bxv01-clean-complete
printf '\nV0.1 專屬清理已完成；下一步：bash 03_deploy_v01.sh\n'
