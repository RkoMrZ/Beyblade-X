# BeybladeX-V0.1 — Google Cloud Shell 清理與重新部署

只允許操作 `ljt-beyblade-x`（賽程表正式 Firebase 專案）中的 **V0.1 專屬資源**。不操作獨立報名專案 `ljtreg-39954`，不刪 GitHub `reg/`，不碰 `BeybladeX-reg-V0.2.zip`。

## Cloud Shell 操作順序

手機先將本壓縮檔上傳 GitHub `rkomrz/Beyblade-X` 主分支根目錄，覆蓋原本同名 ZIP，再到 Google Cloud Shell 輸入：

```bash
cd ~ && curl -fLsS --retry 3 -o BeybladeX-V0.1.zip 'https://raw.githubusercontent.com/rkomrz/Beyblade-X/main/BeybladeX-V0.1.zip' && unzip -oq BeybladeX-V0.1.zip -d ~ && cd ~/BeybladeX-V0.1 && nvm use 22 && bash 01_preflight.sh
```

檢查結果成功、確認專案後：

```bash
cd ~/BeybladeX-V0.1 && bash 02_clean_v01.sh
```

畫面會列出**精確**清理名單，需要輸入 `CLEAN-V01` 才真正刪除。此步驟會刪除 `eventsV01`、`ownerIndexV01` 資料及 V0.1 已存在的函式，移除 V01 Rules 分支，不保留這些測試資料。

清理成功後才重新部署：

```bash
cd ~/BeybladeX-V0.1 && bash 03_deploy_v01.sh
```

最後查驗：

```bash
cd ~/BeybladeX-V0.1 && bash 04_verify_v01.sh
```

## 注意事項

- 避免直接執行 `firebase database:remove /`，**永遠不能整個資料庫清空**。
- 如果仍出現 `Error: Failed to list functions for ljt-beyblade-x`，預檢會停止，**沒有任何清理動作**。先提供錯誤訊息，判斷是否 API 未啟用、IAM 授權或 CLI/API 問題。
- 如果 Google Cloud 已有非預期的 `*V01` 函式，預檢同樣會停止，不會猜測哪些函式可刪。
- `BX_LOCK_KEY` 因為名稱未加版本號，腳本不會自動刪除；重新部署可安全沿用原 Secret。
- 清除後舊版頁面可能仍在 GitHub/手機快取，雲端舊操作將失效；GitHub Pages 需要另外更新根目錄 `index.html` 及 `viewer/` 文件，ZIP 上傳本身不會更新頁面。
- V0.1 真實雲端權限／交易與手機同步尚未完成端到端實測，上述腳本只提供有範圍的部署流程，不能代替驗收。
