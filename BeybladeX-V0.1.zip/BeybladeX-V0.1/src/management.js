"use strict";
// V0.1 privileged, bounded, idempotent administrative mutations on the board shard.
const crypto=require('node:crypto');
const {validateOpTime,hash}=require('./board.js');
const Sync=require('./sync-core.js');
const {DomainError}=require('./engine.js');
const fail=(code,message)=>{throw new DomainError(code,message)};
const copy=x=>JSON.parse(JSON.stringify(x));
function rollingCode(key,eventId,time){
 if(!/^[0-9a-f]{64}$/i.test(key||''))fail('failed-precondition','缺少雲端驗證密鑰');
 const slot=Math.floor(time/60000);
 const digest=crypto.createHmac('sha256',Buffer.from(key,'hex')).update('v01-join:'+eventId+':'+slot).digest();
 return String(digest.readUInt32BE(0)%1000000).padStart(6,'0');
}
function requireOwner(b,uid){
 if(!b||b.access.deleted)fail('not-found','賽事不存在');
 if(b.access.ownerUid!==uid)fail('permission-denied','只有主辦可操作');
}
function administrativeAction(raw,uid,input,now){
 validateOpTime(input.opId,now);
 requireOwner(raw,uid);
 if(!['setPublic','delete'].includes(input.action))fail('invalid-argument','管理操作未支援');
 const proof=hash({action:input.action,open:input.open===true,eventId:input.eventId});
 const existing=raw.receipts?.[input.opId];
 if(existing){
  if(existing.uid!==uid||existing.hash!==proof)fail('permission-denied','操作代碼已用於其他內容');
  return {replay:true,result:existing.result};
 }
 const b=copy(raw);
 const outbox=b.outbox||{};
 if(Object.keys(outbox).length>=64)fail('resource-exhausted','公開同步延遲，暫停管理操作');
 let delta;
 if(input.action==='setPublic'){
  b.access.open=input.open===true;
  b.access.until=b.access.open?now+2*60*60*1000:now;
  delta=b.access.open?{kind:'meta',meta:{publicOpen:true,publicUntil:b.access.until}}:{kind:'closed'};
 }else{
  b.access.deleted=true;b.access.open=false;b.access.until=now;
  delta={kind:'closed'};
 }
 b.seq++;
 outbox[Sync.seqKey(b.seq)]={seq:b.seq,wire:[delta],full:[]};
 const result={ok:true,publicSeq:b.seq,action:input.action,open:b.access.open,until:b.access.until};
 b.receipts[input.opId]={uid,hash:proof,result,at:now};
 return {board:b,result,replay:false};
}
function refereeJoin(raw,uid,code,eventId,key,now,refereeName=""){
 if(!raw||raw.access.deleted)fail('not-found','找不到賽事');
 if(!raw.access.open||raw.access.until<=now)fail('failed-precondition','賽事未開放或已過期');
 if(raw.access.refereeUsers?.[uid]===true)return {replay:true,board:null};
 const attempt=raw.joinAttempts?.[uid]||{at:now,count:0};
 const slotValid=now-attempt.at<10*60000;
 const count=slotValid?attempt.count:0;
 if(count>=5)fail('resource-exhausted','驗證失敗次數過多，請稍後再試');
 const valid=code===rollingCode(key,eventId,now)||code===rollingCode(key,eventId,now-60000);
 const b=copy(raw);b.joinAttempts??={};
 if(!valid){b.joinAttempts[uid]={at:slotValid?attempt.at:now,count:count+1};return {board:b,approved:false};}
 b.access.refereeUsers[uid]=true;
 b.refereeNames??={};b.refereeNames[uid]=String(refereeName||'裁判').slice(0,24);
 delete b.joinAttempts[uid];
 return {board:b,approved:true};
}
function staffView(board,name,eventId,uid){
 if(!board||board.access.deleted)fail('not-found','找不到賽事');
 const owner=board.access.ownerUid===uid;
 if(!owner&&board.access.refereeUsers?.[uid]!==true)fail('permission-denied','未取得賽事權限');
 const S=require('./sync-core.js');
 return {eventId,name,owner,seq:board.seq,open:board.access.open,until:board.access.until,
  mode:board.mode,freeFinal:board.freeFinal,
  rounds:board.rounds.map(r=>({name:r.name,placementFinal:r.placementFinal===true,
   revision:r.revision||0,matches:r.matches.map(S.publicMatch)})),
  finalRR:board.finalRR?{revision:board.finalRR.revision,players:board.finalRR.players,
   matches:board.finalRR.matches.map(S.publicMatch),standings:board.finalRR.standings||null}:null};
}
module.exports={rollingCode,administrativeAction,refereeJoin,staffView};
