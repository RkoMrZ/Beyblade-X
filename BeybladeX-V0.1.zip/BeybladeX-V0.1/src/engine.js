"use strict";

// Pure V2 match engine. No Firebase access, no browser state, no private data projection.
const {randomInt} = require("node:crypto");
const PENDING = "待定";
const BYE = "BYE";
class DomainError extends Error {
  constructor(code, message) { super(message); this.name = "DomainError"; this.code = code; }
}
const fail = (code, msg) => { throw new DomainError(code, msg); };
const clone = (v) => JSON.parse(JSON.stringify(v));
const currentScore = (v) => v === "" || v === undefined || v === null ? null : Number(v);
function match(a = PENDING, b = PENDING) {
  return {a, b, sa: "", sb: "", winner: null, matchVersion: 0, lock: null};
}
function isByeWinner(m) {
  return m.a === BYE && m.b !== PENDING && m.b !== BYE ? m.b :
    m.b === BYE && m.a !== PENDING && m.a !== BYE ? m.a : null;
}
function isStarted(m) {
  return m.winner && !isByeWinner(m) || m.lock ||
    currentScore(m.sa) !== null || currentScore(m.sb) !== null;
}
function assertRoster(roster, mode) {
  if (!Array.isArray(roster)) fail("invalid-argument", "參賽名單必須是陣列");
  const limit = mode === "free" ? [3, 6, 12, 24, 36, 48] : null;
  if (mode !== "free" && mode !== "single") fail("invalid-argument", "賽制不支援");
  if (mode === "free" ? !limit.includes(roster.length) : roster.length < 2 || roster.length > 64) {
    fail("invalid-argument", "參賽人數不符合所選賽制");
  }
  const names = roster.map((s) => typeof s === "string" ? s.trim() : "");
  if (names.some((s) => !s || s.length > 40 || [PENDING, BYE].includes(s)))
    fail("invalid-argument", "參賽名稱無效或使用了保留名稱");
  if (new Set(names).size !== names.length) fail("invalid-argument", "參賽名稱不可重複");
  return names;
}
function shuffle(items) {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) { const j = randomInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function generateRounds(roster, opts = {}) {
  const mode = opts.mode || "free";
  const freeFinal = mode === "single" ? "champ" : (opts.freeFinal || "rr3");
  if (!["rr3", "champ"].includes(freeFinal)) fail("invalid-argument", "決賽模式錯誤");
  const names = assertRoster(roster, mode);
  const pairing = opts.pairing || "ordered";
  if (!["ordered", "random"].includes(pairing)) fail("invalid-argument", "配對方式錯誤");
  const lineup = pairing === "random" ? shuffle(names) : [...names];
  if (mode === "free" && freeFinal === "rr3" && names.length === 3) {
    return {roster: lineup, mode, freeFinal, pairing, rounds: [],
      finalRR: {revision: 0, players: lineup, matches: [
        match(lineup[0], lineup[1]), match(lineup[1], lineup[2]), match(lineup[0], lineup[2])], standings: []}};
  }
  let first = [];
  if (mode === "single") {
    let p = 1; while (p < lineup.length) p *= 2;
    let ix = 0;
    for (let i = 0; i < p - lineup.length; i++) first.push(match(lineup[ix++], BYE));
    while (ix < lineup.length) first.push(match(lineup[ix++], lineup[ix++] || BYE));
  } else {
    for (let i = 0; i < lineup.length; i += 2) first.push(match(lineup[i], lineup[i + 1] || BYE));
  }
  for (const m of first) m.winner = isByeWinner(m);
  const rounds = [{name: "第 1 輪", revision: 0, matches: first}];
  let count = first.length;
  while (count > (freeFinal === "rr3" ? 3 : 2)) {
    count = Math.ceil(count / 2);
    rounds.push({name: `第 ${rounds.length + 1} 輪`, revision: 0,
      matches: Array.from({length: count}, () => match())});
  }
  if (freeFinal === "champ" && count === 2) {
    rounds.push({name: "最終名次", placementFinal: true, revision: 0,
      matches: [match(), match()]});
  }
  if (freeFinal === "champ" && count === 1) {
    // Two-player tournament consists of one championship game, no bronze game.
    rounds[0].name = "冠軍賽";
  }
  const event = {roster: lineup, mode, freeFinal, pairing, rounds, finalRR: null};
  propagate(event, {allowDangerous: false});
  return event;
}
function loser(m) {
  if (!m.winner) return PENDING;
  if (m.a === m.winner) return m.b;
  if (m.b === m.winner) return m.a;
  return PENDING;
}
function setParticipants(target, a, b, options) {
  const na = a || PENDING, nb = b || PENDING;
  if (target.a === na && target.b === nb) return false;
  if (isStarted(target) && !options.allowDangerous)
    fail("failed-precondition", "後續場次已有比分或執裁鎖定，禁止直接覆蓋晉級結果");
  target.a = na; target.b = nb;
  target.sa = ""; target.sb = ""; target.winner = isByeWinner(target); target.lock = null;
  target.matchVersion = (target.matchVersion || 0) + 1;
  return true;
}
function propagate(event, options = {}) {
  const dirty = new Set();
  const rounds = event.rounds || [];
  for (let ri = 0; ri < rounds.length - 1; ri++) {
    const round = rounds[ri], next = rounds[ri + 1];
    if (next.placementFinal) {
      const s1 = round.matches[0], s2 = round.matches[1];
      if (setParticipants(next.matches[0], s1.winner || PENDING, s2.winner || PENDING, options)) dirty.add(ri + 1);
      if (setParticipants(next.matches[1], loser(s1), loser(s2), options)) dirty.add(ri + 1);
    } else {
      for (let mi = 0; mi < next.matches.length; mi++) {
        const left = round.matches[mi * 2], right = round.matches[mi * 2 + 1];
        const a = left && left.winner || PENDING;
        const b = right ? right.winner || PENDING : BYE;
        if (setParticipants(next.matches[mi], a, b, options)) dirty.add(ri + 1);
      }
    }
  }
  if (event.freeFinal === "rr3" && rounds.length) {
    const last = rounds[rounds.length - 1];
    const qualifiers = last.matches.map((m) => m.winner);
    if (qualifiers.length === 3 && qualifiers.every(Boolean)) {
      if (!event.finalRR || qualifiers.join("\u0000") !== event.finalRR.players.join("\u0000")) {
        if (event.finalRR && event.finalRR.matches.some(isStarted) && !options.allowDangerous)
          fail("failed-precondition", "三人循環已開始，不允許直接改動晉級選手");
        event.finalRR = {revision: (event.finalRR?.revision || 0) + 1, players: qualifiers,
          matches: [match(qualifiers[0], qualifiers[1]), match(qualifiers[1], qualifiers[2]),
            match(qualifiers[0], qualifiers[2])], standings: []};
        dirty.add("rr");
      }
    } else if (event.finalRR) {
      if (event.finalRR.matches.some(isStarted) && !options.allowDangerous)
        fail("failed-precondition", "三人循環已有操作，無法直接取消");
      event.finalRR = null; dirty.add("rr");
    }
  }
  for (const ri of dirty) if (ri !== "rr") rounds[ri].revision = (rounds[ri].revision || 0) + 1;
  return [...dirty];
}
function getTarget(event, target) {
  if (!target || !["round", "rr"].includes(target.kind)) fail("invalid-argument", "場次類型無效");
  if (!Number.isInteger(target.mi) || target.mi < 0) fail("invalid-argument", "場次索引無效");
  if (target.kind === "rr") {
    const rr = event.finalRR;
    const m = rr && rr.matches[target.mi];
    if (!m) fail("not-found", "找不到三人循環場次");
    return {m, ri: null, round: rr};
  }
  if (!Number.isInteger(target.ri) || target.ri < 0) fail("invalid-argument", "輪次索引無效");
  const round = event.rounds[target.ri], m = round?.matches[target.mi];
  if (!m) fail("not-found", "找不到對戰場次");
  return {m, ri: target.ri, round};
}
function getStandings(finalRR) {
  if (!finalRR) return [];
  const table = Object.fromEntries(finalRR.players.map((n) => [n, {player: n, wins: 0, losses: 0, for: 0, against: 0, diff: 0}]));
  for (const m of finalRR.matches) {
    if (!m.winner) continue;
    const a = table[m.a], b = table[m.b], sa = Number(m.sa), sb = Number(m.sb);
    a.for += sa; a.against += sb; b.for += sb; b.against += sa;
    table[m.winner].wins++;
    table[m.winner === m.a ? m.b : m.a].losses++;
  }
  const rows = Object.values(table);
  for (const r of rows) r.diff = r.for - r.against;
  rows.sort((a, b) => b.wins - a.wins || b.diff - a.diff || b.for - a.for || a.player.localeCompare(b.player));
  rows.forEach((r, i) => { r.rank = i + 1; });
  return rows;
}
module.exports = {PENDING, BYE, DomainError, fail, clone, match, assertRoster, generateRounds,
  currentScore, isStarted, isByeWinner, propagate, getTarget, getStandings};
