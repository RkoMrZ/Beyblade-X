/* Beyblade X VNext public incremental synchronization protocol.
 * Browser + Node 22 compatible. No Firebase dependency.
 * Cache is read-only and never eligible for an authoritative score write.
 */
(function(root, factory) {
  "use strict";
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.BXSync = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function() {
  "use strict";
  const CACHE_SCHEMA = 2;
  const PACK_KEYS = {a:"a",b:"b",sa:"x",sb:"y",winner:"w",matchVersion:"v",claimed:"c"};
  const UNPACK_KEYS = Object.fromEntries(Object.entries(PACK_KEYS).map(([a,b])=>[b,a]));
  function packChange(entry) {
    if (!entry) return null;
    if (entry.kind==="match")return ["m",entry.ri,entry.mi,entry.roundRevision,
      Object.fromEntries(Object.entries(entry.patch||entry.match||{}).map(([k,v])=>[PACK_KEYS[k]||k,v]))];
    if (entry.kind==="batch")return ["b",entry.items.map(packChange)];
    if (entry.kind==="rr")return ["r",entry.finalRR];
    if (entry.kind==="meta")return ["t",entry.meta];
    if (entry.kind==="structure")return ["s"];
    if (entry.kind==="closed")return ["c"];
    if (entry.kind==="round")return ["R",entry.ri];
    throw new Error("unknown public packet kind");
  }
  function unpackChange(part) {
    if (!Array.isArray(part)) throw new Error("invalid compact public delta");
    const kind=part[0];
    if (kind==="m")return {kind:"match",ri:part[1],mi:part[2],roundRevision:part[3],
      patch:Object.fromEntries(Object.entries(part[4]||{}).map(([k,v])=>[UNPACK_KEYS[k]||k,v]))};
    if (kind==="b")return {kind:"batch",items:(part[1]||[]).map(unpackChange)};
    if (kind==="r")return {kind:"rr",finalRR:part[1]};
    if (kind==="t")return {kind:"meta",meta:part[1]};
    if (kind==="s")return {kind:"structure"};
    if (kind==="c")return {kind:"closed"};
    if (kind==="R")return {kind:"round",ri:part[1]};
    throw new Error("invalid compact public delta kind");
  }
  function expandMarker(raw) {
    if (!raw || typeof raw!=="object")return raw;
    if (!Object.prototype.hasOwnProperty.call(raw,"d")) return raw; // Stage2 wire compatible.
    return {seq:raw.seq,structureVersion:raw.sv,publicOpen:raw.o!==0,
      last:raw.d ? {seq:raw.seq,...unpackChange(raw.d)} : null};
  }

  const MAX_CHANGE_PAGE = 96;
  const MAX_CACHE_AGE_MS = 12 * 60 * 60 * 1000;
  function seqKey(n) {
    if (!Number.isSafeInteger(n) || n < 0) throw new Error("invalid sequence");
    return String(n).padStart(12, "0");
  }
  function isValidId(id) { return /^[A-Za-z0-9_-]{6,100}$/.test(id || ""); }
  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function newCache(id) {
    return {schema: CACHE_SCHEMA, eventId: id, seq: 0, meta: null,
      rounds: {}, finalRR: null, updatedAt: 0};
  }
  function usableCache(c, id, now) {
    return Boolean(c && c.schema === CACHE_SCHEMA && c.eventId === id &&
      Number.isSafeInteger(c.seq) && c.seq >= 0 &&
      Number.isFinite(c.updatedAt) && c.updatedAt > 0 &&
      now - c.updatedAt >= 0 && now - c.updatedAt < MAX_CACHE_AGE_MS &&
      c.meta && c.meta.publicOpen === true && Number(c.meta.publicUntil) > now &&
      c.rounds && typeof c.rounds === "object");
  }
  function normalizeRound(raw) {
    if (!raw || typeof raw !== "object" || !Number.isSafeInteger(raw.revision) || raw.revision < 0) {
      throw new Error("invalid round snapshot");
    }
    const matches = raw.matches && typeof raw.matches === "object" ? raw.matches : {};
    return {revision: raw.revision, matches: clone(matches)};
  }
  function applyOne(cache, entry) {
    if (entry.kind === "match") {
      if (!Number.isInteger(entry.ri) || entry.ri < 0 ||
          !Number.isInteger(entry.mi) || entry.mi < 0 ||
          !Number.isInteger(entry.roundRevision) || entry.roundRevision < 1 ||
          (!entry.patch || typeof entry.patch !== "object") &&
          (!entry.match || typeof entry.match !== "object")) {
        throw new Error("invalid match delta");
      }
      const r = cache.rounds[entry.ri];
      if (r) {
        // A cached round may be missing an earlier update; never apply a later
        // per-round revision on top of it. It will lazy-refetch when visible.
        if (entry.roundRevision !== r.revision + 1) delete cache.rounds[entry.ri];
        else {
          r.matches[String(entry.mi)] = entry.patch ?
            {...r.matches[String(entry.mi)], ...clone(entry.patch)} : clone(entry.match);
          r.revision = entry.roundRevision;
        }
      }
    } else if (entry.kind === "round") {
      if (!Number.isInteger(entry.ri) || entry.ri < 0) throw new Error("invalid round delta");
      // May encode many dependent advances; reload just this round on demand.
      delete cache.rounds[entry.ri];
    } else if (entry.kind === "rr") {
      // RR delta is compact. A full RR object is small (3 matches).
      if (!entry.finalRR || typeof entry.finalRR !== "object") throw new Error("invalid RR delta");
      cache.finalRR = clone(entry.finalRR);
    } else if (entry.kind === "meta") {
      if (!entry.meta || typeof entry.meta !== "object") throw new Error("invalid metadata delta");
      cache.meta = {...cache.meta, ...clone(entry.meta)};
    } else if (entry.kind === "structure") {
      // Structure has changed; old round layout and names are not trustworthy.
      cache.meta = null;
      cache.rounds = {};
      cache.finalRR = null;
    } else if (entry.kind === "closed") {
      cache.meta = {...cache.meta, publicOpen: false};
      cache.rounds = {};
      cache.finalRR = null;
    } else {
      throw new Error("unknown delta kind");
    }
  }
  function applyChange(cache, entry) {
    if (!entry || !Number.isSafeInteger(entry.seq) || entry.seq !== cache.seq + 1) {
      throw new Error("non-contiguous change sequence");
    }
    const actions = entry.kind === "batch" ? entry.items : [{...entry, seq: undefined}];
    if (!Array.isArray(actions) || actions.length < 1 || actions.length > 16) {
      throw new Error("invalid batch");
    }
    for (const action of actions) {
      if (!action || action.kind === "batch" || action.seq !== undefined) throw new Error("invalid batch member");
      applyOne(cache, action);
    }
    cache.seq = entry.seq;
  }
  function replay(cache, entries, targetSeq) {
    if (!Array.isArray(entries) || !Number.isSafeInteger(targetSeq) || targetSeq < cache.seq) {
      throw new Error("invalid replay parameters");
    }
    const next = clone(cache);
    // Safe if the server returns an empty log only when already current.
    for (const entry of entries) {
      if (entry.seq <= next.seq) continue;
      if (entry.seq > targetSeq) break;
      applyChange(next, entry);
    }
    if (next.seq !== targetSeq) throw new Error("change history gap or truncated log");
    return next;
  }
  function parseHistory(raw) {
    if (!raw || typeof raw !== "object") return [];
    return Object.entries(raw).sort(([a],[b]) => a.localeCompare(b)).map(([key,e]) => {
      if (seqKey(e && e.seq) !== key) throw new Error("invalid history key");
      return e;
    });
  }
  function shouldReplaceRound(incoming, existing) {
    return !existing || incoming.revision >= existing.revision;
  }
  function publicMatch(m) {
    if (!m) return null;
    // Whitelist only harmless public fields; never publish lock, auth or secrets.
    return {a: String(m.a == null ? "待定" : m.a), b: String(m.b == null ? "待定" : m.b),
      sa: m.sa == null ? "" : m.sa, sb: m.sb == null ? "" : m.sb,
      winner: m.winner == null ? null : String(m.winner),
      matchVersion: Number.isInteger(m.matchVersion) ? m.matchVersion : 0,
      claimed: Boolean(m.lock)};
  }
  return {CACHE_SCHEMA, MAX_CHANGE_PAGE, MAX_CACHE_AGE_MS, seqKey, isValidId,
    newCache, usableCache, normalizeRound, applyChange, replay,
    parseHistory, shouldReplaceRound, publicMatch, clone, packChange, expandMarker};
});
