/* Run on HTTPS browsers with crypto.getRandomValues; Node test uses crypto.randomBytes. */
(function(root){
 function createOperationId(){
  const prefix=Date.now().toString(16).padStart(12,"0");
  const b=new Uint8Array(18);root.crypto.getRandomValues(b);
  return prefix+Array.from(b,x=>x.toString(16).padStart(2,"0")).join("");
 }
 if(typeof module!=="undefined"&&module.exports)module.exports={createOperationId};
 else root.BXOperationId=createOperationId;
})(globalThis);
