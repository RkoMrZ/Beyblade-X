"use strict";
/* Projector: only one publisher per event; atomically publish changed public
   match paths + history entry + sync cursor via ONE small multipath update.
   Authority can lead public cursor temporarily; cannot lose committed outbox. */
const {randomBytes}=require("node:crypto");
const Sync=require("./sync-core.js");
const key=Sync.seqKey;
const clone=x=>JSON.parse(JSON.stringify(x));
function publicationPatch(entry){
 const actions=entry.wire;
 const updates={};
 for(const d of entry.full){
  if(d.kind==="match"){
   const path=`public/rounds/${d.ri}`;
   updates[`${path}/matches/${d.mi}`]=d.full;
  }else if(d.kind==="rr"){
   updates["public/finalRR"]=d.finalRR;
   // The public meta flag changes only on first creation/removal of RR.
   updates["public/meta/hasFinalRR"]=!!d.finalRR;
  }
 }
 for(const d of actions){
  if(d.kind==="meta")for(const [field,value] of Object.entries(d.meta||{}))updates[`public/meta/${field}`]=value;
  if(d.kind==="closed"){
   updates['public/meta/publicOpen']=false;
   updates['public/meta/publicUntil']=0;
  }
 }
 for(const d of actions)if(d.kind==="match")updates[`public/rounds/${d.ri}/revision`]=
  Math.max(updates[`public/rounds/${d.ri}/revision`]||0,d.roundRevision);
 const parts=actions.length===1?{...actions[0]}:{kind:"batch",items:actions};
 const publicEntry={seq:entry.seq,...parts};
 updates[`public/changes/${key(entry.seq)}`]=publicEntry;
 if(entry.seq>Sync.MAX_CHANGE_PAGE) updates[`public/changes/${key(entry.seq-Sync.MAX_CHANGE_PAGE)}`]=null;
 updates["public/sync"]={seq:entry.seq,sv:1,d:Sync.packChange(publicEntry)};
 updates["staff/sync"]={seq:entry.seq,sv:1,d:Sync.packChange(publicEntry)};
 return updates;
}
async function drain(db,eventId,{now=()=>Date.now(),failAfterSeq=null,limit=32}={}){
 const eventRef=db.ref(`eventsV01/${eventId}`), leaseRef=eventRef.child("publisherLease");
 const mine=randomBytes(12).toString("hex"),at=now();
 const claimed=await leaseRef.transaction(cur=>!cur||cur.until<at?{token:mine,until:at+30000}:undefined,undefined,false);
 if(!claimed.committed)return {busy:true,published:0};
 let published=0,last=0;
 try{
  const cursor=(await eventRef.child("public/sync/seq").get()).val()||0;
  last=cursor;
  for(let seq=cursor+1;seq<=cursor+limit;seq++){
   if(now()-at>20000)break; // Lease expiry never permits two overlapping publishers.
   const event=(await eventRef.child(`board/outbox/${key(seq)}`).get()).val();
   if(!event)break;
   if(event.seq!==seq)throw Error("Outbox sequence corrupted");
   if(failAfterSeq===seq)throw Error("INJECTED_PUBLICATION_CRASH");
   const patch=publicationPatch(event);
   // Multi-location write is atomic in RTDB; audience never sees cursor without data.
   await eventRef.update(patch);
   published++;last=seq;
  }
  return {busy:false,published,cursor:last};
 }finally{
  // Do not erase another writer's lease if ours expired or changed.
  await leaseRef.transaction(x=>x?.token===mine?null:undefined,undefined,false);
 }
}
async function compactOutbox(db,eventId,{threshold=32}={}){
 const event=db.ref(`eventsV01/${eventId}`);
 const seq=(await event.child("public/sync/seq").get()).val()||0;
 const boardRef=event.child("board");
 return boardRef.transaction(b=>{
  if(!b||Object.keys(b.outbox||{}).length<=threshold)return undefined;
  for(const k of Object.keys(b.outbox||{}))if(Number(k)<=seq)delete b.outbox[k];
  return b;
 },undefined,false);
}
module.exports={publicationPatch,drain,compactOutbox};
