"use strict";
/* Authority shard: ONE RTDB transaction per match command, deliberately excluding
   entire public rounds/history, owner indices, join codes and user profiles.
   Its shared ancestor is required for atomically changing a finished match AND
   its descendants. Public projection is eventually consistent via durable outbox. */
const {createHash} = require("node:crypto");
const E = require("./engine.js");
const S = require("./sync-core.js");
const deep = x=>JSON.parse(JSON.stringify(x));
const hash = x=>createHash("sha256").update(JSON.stringify(x)).digest("hex");
// Client-generated 48-hex op id: first 12 hex = creation time (ms), last 36 random.
// Once expired it cannot be accepted as a new operation, even if old receipts
// were compacted. This makes bounded receipts safe without an extra preflight.
const validOp = x=>typeof x==="string"&&/^[a-f0-9]{48}$/.test(x);
const OP_WINDOW_MS=30*60*1000;
const RECEIPT_KEEP_MS=35*60*1000;
function validateOpTime(opId,now){
 if(!validOp(opId))E.fail("invalid-argument","操作代碼格式錯誤");
 const time=parseInt(opId.slice(0,12),16);
 if(!Number.isSafeInteger(time)||time>now+5*60000||time<now-OP_WINDOW_MS)
  E.fail("failed-precondition","過期操作禁止重送，請先同步最新比分");
}

const maxOutbox=64; // fail closed if publication stalls; never silently discard deltas.
function createBoard({roster,mode="free",freeFinal="rr3",pairing="ordered",ownerUid,now}){
 const spec=E.generateRounds(roster,{mode,freeFinal,pairing});
 return {mode:spec.mode,freeFinal:spec.freeFinal,rosterCount:spec.roster.length,rounds:spec.rounds,finalRR:spec.finalRR,
  access:{ownerUid,refereeUsers:{},open:true,until:now+7200000,deleted:false},
  claims:{},seq:0,receipts:{},outbox:{}};
}
function publicInitial(board,eventId,name){
 return {meta:{id:eventId,name,mode:board.mode,freeFinal:board.freeFinal,
  rosterCount:board.rosterCount,appVersion:'V0.1',
  rounds:board.rounds.map((r,i)=>({name:r.name||`第 ${i+1} 輪`,matchCount:r.matches.length,placementFinal:r.placementFinal===true})),
  hasFinalRR:!!board.finalRR,structureVersion:1,publicOpen:true,publicUntil:board.access.until},
  rounds:Object.fromEntries(board.rounds.map((r,ri)=>[ri,{revision:r.revision||0,
   matches:Object.fromEntries(r.matches.map((m,mi)=>[mi,S.publicMatch(m)]))}])),
  finalRR:board.finalRR?{revision:board.finalRR.revision,players:board.finalRR.players,matches:board.finalRR.matches.map(S.publicMatch)}:null,
  sync:{seq:0,sv:1,d:null},changes:{}};
}
function changes(before,after){
 const changed=[];
 for(let ri=0;ri<after.rounds.length;ri++) for(let mi=0;mi<after.rounds[ri].matches.length;mi++){
  const older=before.rounds[ri].matches[mi],next=after.rounds[ri].matches[mi];
  const a=S.publicMatch(older),b=S.publicMatch(next),patch={};
  for(const k of Object.keys(b))if(JSON.stringify(a[k])!==JSON.stringify(b[k]))patch[k]=b[k];
  if(Object.keys(patch).length) changed.push({kind:"match",ri,mi,roundRevision:after.rounds[ri].revision,patch,full:b});
 }
 const oldRR=JSON.stringify(before.finalRR&&{players:before.finalRR.players,
  matches:before.finalRR.matches.map(S.publicMatch),standings:before.finalRR.standings});
 const newRR=JSON.stringify(after.finalRR&&{players:after.finalRR.players,
  matches:after.finalRR.matches.map(S.publicMatch),standings:after.finalRR.standings});
 if(oldRR!==newRR)changed.push({kind:"rr",finalRR:after.finalRR?{
  players:after.finalRR.players,revision:after.finalRR.revision,
  matches:after.finalRR.matches.map(S.publicMatch),standings:after.finalRR.standings}:null});
 return changed;
}
function applyBoard(raw,uid,action,input,now,token=null,tokenBox=null){
 if(!raw)E.fail("not-found","找不到賽事");
 validateOpTime(input.opId,now);
 const h=hash({action,input});
 const prior=raw.receipts?.[input.opId];
 if(prior){
  if(prior.uid!==uid||prior.hash!==h)E.fail("permission-denied","操作代碼重複且內容不符");
  return {board:null,replay:true,receipt:prior.result};
 }
 const b=deep(raw),access=b.access;
 for(const [id,rec] of Object.entries(b.receipts||{}))if(rec.at<now-RECEIPT_KEEP_MS)delete b.receipts[id];
 if(access.deleted)E.fail("not-found","賽事已刪除");
 const owner=access.ownerUid===uid;
 if(!owner&&access.refereeUsers?.[uid]!==true)E.fail("permission-denied","沒有執裁權限");
 if(!access.open||access.until<=now)E.fail("failed-precondition","賽事目前未開放");
 if(Object.keys(b.outbox||{}).length>=maxOutbox)E.fail("resource-exhausted","公開同步積壓，暫停比分避免資料分離");
 const t=input.target, target=E.getTarget(b,t),m=target.m;
 const lockValid=()=>{
  if(input.expectedMatchVersion!==m.matchVersion)E.fail("aborted","比分版本過期，請同步");
  if(!m.lock||m.lock.uid!==uid||m.lock.expiresAt<=now||!input.lockToken||
    m.lock.tokenHash!==hash(input.lockToken)||b.claims[uid]?.tokenHash!==hash(input.lockToken))
    E.fail("permission-denied","執裁鎖已失效");
 };
 const old=deep(b);let receipt;
 if(action==="claim"){
  if(m.winner||[E.PENDING,E.BYE].some(x=>m.a===x||m.b===x))E.fail("failed-precondition","不可領取未就緒場次");
  if(m.lock&&m.lock.uid!==uid&&m.lock.expiresAt>now)E.fail("aborted","已有其他裁判執裁");
  if(!token||!tokenBox)E.fail("failed-precondition","缺少加密執裁憑證");
  const prev=b.claims[uid];
  if(prev){const pm=E.getTarget(b,prev).m;if(pm.lock?.uid===uid){pm.lock=null;pm.matchVersion++;if(prev.kind==="rr")b.finalRR.revision++;else b.rounds[prev.ri].revision++;}}
  m.lock={uid,tokenHash:hash(token),expiresAt:now+600000};m.matchVersion++;
  b.claims[uid]={...t,tokenHash:hash(token)};
  target.round.revision++;
  receipt={ok:true,matchVersion:m.matchVersion,expiresAt:m.lock.expiresAt,lockTokenBox:tokenBox};
 }else if(action==="score"||action==="complete"||action==="release"||action==="reset"){
  lockValid();
  if(action==="score"||action==="complete"){
   if(m.winner)E.fail("failed-precondition","已完成場次不可直接修改");
  }
  if(action==="score"){
   if(!Number.isInteger(input.sa)||input.sa<0||input.sa>6||!Number.isInteger(input.sb)||input.sb<0||input.sb>6)E.fail("invalid-argument","比分範圍應為0–6");
   m.sa=input.sa;m.sb=input.sb;m.lock.expiresAt=now+600000;
  }else if(action==="complete"){
   const sa=E.currentScore(m.sa),sb=E.currentScore(m.sb);
   if(sa===null||sb===null||Math.max(sa,sb)<4||sa===sb)E.fail("failed-precondition","須達4分且分出勝負");
   m.winner=sa>sb?m.a:m.b;m.lock=null;delete b.claims[uid];
  }else if(action==="release"){
   m.lock=null;delete b.claims[uid];
  }else if(action==="reset"){
   if(m.winner)E.fail("failed-precondition","已完成的場次禁止直接重設");m.sa=0;m.sb=0;
  }
  m.matchVersion++;target.round.revision++;
  if(action==="complete"){
   if(t.kind==="round")E.propagate(b);
   else {b.finalRR.standings=E.getStandings(b.finalRR);b.finalRR.revision++;}
  }
  receipt={ok:true,status:action,matchVersion:m.matchVersion,winner:m.winner||null};
 }else E.fail("invalid-argument","不支援的場次操作");
 const delta=changes(old,b);
 const counts={};
 for(const x of delta)if(x.kind==="match")counts[x.ri]=(counts[x.ri]||0)+1;
 for(const [ri,count] of Object.entries(counts))if(count>1)b.rounds[ri].revision+=count-1;
 const used={};for(const x of delta)if(x.kind==="match"){
  const n=used[x.ri]||0;used[x.ri]=n+1;
  x.roundRevision=b.rounds[x.ri].revision-(counts[x.ri]-1-n);
 }
 // A command changes one target and at most a handful of dependency matches.
 // Avoid unsupported >16 batch: emit a typed round refresh for affected rounds.
 let wire=delta.map(({full,...rest})=>rest);
 if(wire.length>16){
  const riSet=[...new Set(wire.filter(x=>x.kind==="match").map(x=>x.ri))];
  wire=riSet.map(ri=>({kind:"round",ri}));
  if(delta.some(x=>x.kind==="rr"))wire.push(delta.find(x=>x.kind==="rr"));
 }
 const seq=++b.seq;
 b.outbox[S.seqKey(seq)]={seq,wire,full:delta};
 receipt.publicSeq=seq;
 b.receipts[input.opId]={uid,hash:h,result:receipt,at:now};
 return {board:b,replay:false,receipt};
}
module.exports={createBoard,publicInitial,applyBoard,changes,hash,validOp,validateOpTime,OP_WINDOW_MS,RECEIPT_KEEP_MS};
