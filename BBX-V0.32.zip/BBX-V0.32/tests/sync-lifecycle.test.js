 'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const dir=path.resolve(__dirname,'..');
const index=fs.readFileSync(path.join(dir,'assets/index-v032.js'),'utf8');
const viewer=fs.readFileSync(path.join(dir,'assets/viewer-v032.js'),'utf8');

const pick=(source,start,end)=>{
 const a=source.indexOf(start),b=source.indexOf(end,a);
 assert.ok(a!==-1 && b>a,`source slice ${start}`);
 return source.slice(a,b);
};
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const tick=()=>new Promise(r=>setImmediate(r));
const ownerHelpers=pick(index,'function ownerIndexErrorLabel(error){','function renderHomeSelections(){');


test('viewer: failed-stream GET cannot overwrite a newer SSE score',async()=>{
 const fragment=pick(viewer,'async function checkFailure(kind,id){','// iOS Safari / Web App');
 const gate=deferred();
 const ctx={Promise, console, streamGeneration:3,receivedEventSerial:7,streamKind:'publicEvents',streamId:'EVENT',
  document:{visibilityState:'visible'},failureCheckBusy:false,data:{meta:{seq:1}},gotFirst:true,lastResyncAt:0,
  fetch:()=>gate.promise,streamUrl:()=>'/endpoint',stream:{close(){ctx.closed=true}},setStatus(t){ctx.status=t},scheduleRender(){ctx.rendered=true},Date};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 const process=vm.runInContext('checkFailure("publicEvents","EVENT")',ctx);
 // SSE arrives AFTER fetch starts. The older GET reply must be discarded.
 ctx.receivedEventSerial=8;ctx.data={meta:{seq:2}};
 gate.resolve({ok:true,status:200,json:async()=>({meta:{seq:1}})});
 await process;
 assert.equal(ctx.data.meta.seq,2);assert.equal(ctx.rendered,undefined);
 assert.equal(ctx.failureCheckBusy,false);
});

test('viewer: reply from an old stream generation is discarded',async()=>{
 const fragment=pick(viewer,'async function checkFailure(kind,id){','// iOS Safari / Web App');
 const gate=deferred();
 const ctx={console,streamGeneration:1,receivedEventSerial:0,streamKind:'publicEvents',streamId:'EVENT',
 document:{visibilityState:'visible'},failureCheckBusy:false,data:{marker:'new'},fetch:()=>gate.promise,streamUrl:()=>'/endpoint',
 stream:{close(){throw Error('closed new connection')}},setStatus(){throw Error('status from stale request')},scheduleRender(){throw Error('render stale')},Date};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 const p=vm.runInContext('checkFailure("publicEvents","EVENT")',ctx);ctx.streamGeneration=2;
 gate.resolve({ok:true,status:200,json:async()=>({marker:'old'})});await p;
 assert.equal(ctx.data.marker,'new');
});

test('home: uses incoming index snapshot, coalesces rapid changes, detaches on background',async()=>{
 const block=ownerHelpers+pick(index,'function stopMyCloudEventIndexListener(){','async function bootstrapCloud(){');
 let callback,detached=0;const gate=deferred(),applied=[];
 const ctx={console,ownerIndexUnsub:null,ownerIndexBoundUid:null,bbxCanRunOwnerIndex(){return ctx.document.visibilityState!=="hidden"},bbxLifecycleNote(){},ownerIndexSyncBusy:false,ownerIndexPendingSnapshot:null,ownerIndexGeneration:0,
  ownerIndexProbeTimer:null,ownerIndexRetryTimer:null,ownerIndexProbeBusy:false,ownerIndexRetryDelay:4000,ownerIndexLastProbe:0,
  ownerIndexState:{phase:'restoring',verified:false,sdkSlots:null,restSlots:null},cloudEventsCache:{},
  setTimeout:()=>123,clearTimeout:()=>{},Date, navigator:{onLine:true},
  document:{visibilityState:'visible'},fbAuth:{currentUser:{uid:'owner'}},
  isGoogleUser:()=>true,fbDb:{ref:p=>({on(type,cb){assert.equal(p,'userEvents/owner');callback=cb},off(){detached++}})},
  syncMyCloudEvents:async(snapshot,valid)=>{if(snapshot['0']==='FIRST')await gate.promise;if(valid())applied.push(snapshot['0'])},
  renderSavedEvents(){},renderHomeSelections(){},$:id=>({classList:{contains:()=>id==='ownerDiagPanel'}})};
 vm.createContext(ctx);vm.runInContext(block,ctx);
 vm.runInContext('listenMyCloudEventIndex()',ctx);
 callback({val:()=>({'0':'FIRST'})});await tick();
 callback({val:()=>({'0':'SECOND'})});callback({val:()=>({'0':'THIRD'})});
 gate.resolve();await tick();await tick();
 assert.deepEqual(applied,['FIRST','THIRD']);
 vm.runInContext('stopMyCloudEventIndexListener()',ctx);assert.equal(detached,1);
 ctx.document.visibilityState='hidden';vm.runInContext('listenMyCloudEventIndex()',ctx);
 assert.equal(detached,1,'no listener in background');
});

test('admin background stops listeners but does not cancel in-flight score opIds',()=>{
 const hidden=pick(index,"document.addEventListener('visibilitychange',()=>{","window.addEventListener('pagehide',()=>{");
 assert.match(hidden,/if\(cloudUnsub\)/);
 assert.match(hidden,/stopMyCloudEventIndexListener\(\)/);
 assert.match(hidden,/stopAdminCodeRotation\(\)/);
 assert.match(hidden,/stopRefereeCodeRotation\(\)/);
 assert.doesNotMatch(hidden,/v05ScoreQueues\.clear\(/);
 assert.match(index,/await v05FlushScores\(q\.kind,q\.ri,q\.mi\)/);
});

test('home: transient per-event read rejection preserves every indexed tournament and never removes a slot',async()=>{
 const fragment=ownerHelpers+pick(index,'async function syncMyCloudEvents(', '\n\nasync function backfillMyCloudEventIndex(){');
 let deleteCalls=0;
 const old={id:'E1',ownerUid:'owner',name:'Six players'};
 const ctx={console,fbAuth:{currentUser:{uid:'owner'}},isGoogleUser:()=>true,
  cloudEventsCache:{E1:old},cloudEventIds:['E1'],cloudEventSlots:{E1:'0'},
  rtdbRestGet:async p=>{if(p==='events/E1')throw Error('offline');return {0:'E1',1:'E2'}},
  rtdbRestDelete:async()=>{deleteCalls++}};
 vm.createContext(ctx); vm.runInContext(fragment,ctx);
 const n=await vm.runInContext('syncMyCloudEvents({0:"E1",1:"E2"})',ctx);
 assert.equal(n,2);assert.equal(ctx.cloudEventIds.length,2);
 assert.equal(ctx.cloudEventsCache.E1.name,'Six players');
 assert.equal(ctx.cloudEventsCache.E2.pendingSync,true);
 assert.equal(deleteCalls,0);
});

test('home: null event payload cannot auto-delete Firebase owner index',async()=>{
 const fragment=ownerHelpers+pick(index,'async function syncMyCloudEvents(', '\n\nasync function backfillMyCloudEventIndex(){');
 let deleted=0;
 const ctx={console,fbAuth:{currentUser:{uid:'owner'}},isGoogleUser:()=>true,
  cloudEventsCache:{},cloudEventIds:[],cloudEventSlots:{},
  rtdbRestGet:async()=>null,rtdbRestDelete:async()=>{deleted++}};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 await vm.runInContext('syncMyCloudEvents({0:"E1"})',ctx);
 assert.equal(deleted,0);assert.deepEqual([...ctx.cloudEventIds],['E1']);
 assert.equal(ctx.cloudEventsCache.E1.pendingSync,true);
});

test('home: temporary auth null or temporarily missing owner index cannot erase known cloud events',async()=>{
 const fragment=ownerHelpers+pick(index,'async function syncMyCloudEvents(', '\n\nasync function backfillMyCloudEventIndex(){');
 const ctx={console,fbAuth:{currentUser:{uid:'owner'}},isGoogleUser:()=>false,
  cloudEventsCache:{E1:{id:'E1',ownerUid:'owner'}},cloudEventIds:['E1'],cloudEventSlots:{E1:'0'},
  rtdbRestGet:async()=>null};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 assert.equal(await vm.runInContext('syncMyCloudEvents(null)',ctx),1);
 assert.deepEqual([...ctx.cloudEventIds],['E1']);
 ctx.isGoogleUser=()=>true;
 assert.equal(await vm.runInContext('syncMyCloudEvents(null)',ctx),1);
 assert.deepEqual([...ctx.cloudEventIds],['E1']);
});

test('foreground null and background null do not clear event, route, or owner index',()=>{
 const foreground=pick(index,'async function resyncCurrentCloudEventOnForeground(',"window.addEventListener('pageshow',e=>{");
 const background=pick(index,'async function backgroundRefreshCurrentEvent(id){','function stopMyCloudEventIndexListener(){');
 assert.match(foreground,/Foreground event returned null; retaining organizer session/);
 assert.doesNotMatch(foreground,/if\(!latest\)\{[\s\S]{0,150}clearActiveView\(/);
 assert.match(background,/Background event returned null; preserving organizer view/);
 assert.doesNotMatch(background,/if\(!data\)\{[\s\S]{0,150}clearActiveView\(/);
 const sync=pick(index,'async function syncMyCloudEvents(', '\n\nasync function backfillMyCloudEventIndex(){');
 assert.doesNotMatch(sync,/rtdbRestDelete/);
 assert.match(index,/if\(\$\('home'\)&&!\$\('home'\)\.classList\.contains\('hidden'\)\)\{/);
});

test('iOS tab eviction: only an owner-bound cloud pointer survives; no score, roster or private event cached',()=>{
 const fragment=pick(index,"const ACTIVE_VIEW_KEY='bx_live_active_view';",'function showTab(t){');
 const storage=new Map();const localStorage={setItem:(k,v)=>storage.set(k,v),getItem:k=>storage.get(k)||null,removeItem:k=>storage.delete(k)};
 const ev={id:'EV6',ownerUid:'owner',name:'123',roster:['A','B','C'],rounds:[{matches:[{s1:6}]}]};
 const ctx={console,Date,localStorage,sessionStorage:{setItem(){},getItem(){return null},removeItem(){}},
  fbAuth:{currentUser:{uid:'owner'}},isGoogleUser:()=>true,ev,location:{href:'https://bbxs-tamsui.web.app/'},
  history:{replaceState(){}}};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 vm.runInContext('persistActiveView("bracket")',ctx);
 const hint=JSON.parse(storage.get('bx_cloud_last_view_pointer'));
 assert.deepEqual(Object.keys(hint).sort(),['eventId','ownerUid','tab','ts']);
 assert.equal(hint.eventId,'EV6');assert.equal(storage.get('bx_live_active_view'),undefined);
 assert.equal(vm.runInContext('readActiveView()?.eventId',ctx),'EV6');
 ctx.fbAuth.currentUser.uid='different';
 assert.equal(vm.runInContext('readActiveView()',ctx),null);
 ctx.fbAuth.currentUser.uid='owner';
 vm.runInContext('clearActiveView()',ctx);
 assert.equal(storage.get('bx_cloud_last_view_pointer'),undefined);
});

test('home: omitted index slot cannot silently discard existing owner tournament',async()=>{
 const fragment=ownerHelpers+pick(index,'async function syncMyCloudEvents(', '\n\nasync function backfillMyCloudEventIndex(){');
 const ctx={console,fbAuth:{currentUser:{uid:'owner'}},isGoogleUser:()=>true,
  cloudEventsCache:{E1:{id:'E1',ownerUid:'owner',name:'Saved six player event'},E2:{id:'E2',ownerUid:'owner',name:'Old event'}},
  cloudEventIds:['E1','E2'],cloudEventSlots:{E1:'0',E2:'1'},rtdbRestGet:async p=>({id:'E2',ownerUid:'owner'})};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 await vm.runInContext('syncMyCloudEvents({1:"E2"})',ctx);
 assert.deepEqual([...ctx.cloudEventIds],['E2','E1']);
 assert.equal(ctx.cloudEventsCache.E1.name,'Saved six player event');
 assert.equal(ctx.cloudEventsCache.E1.pendingSync,true);
});

test('authority calls route V0.11 matches to V0.11, not stale V0.10',()=>{
 const fragment=pick(index,'function authorityFnName(action, event=ev)', 'const isV1Authority=');
 const ctx={ev:{releaseTag:'BBX-V0.11'}};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 assert.equal(vm.runInContext('authorityFnName("CommandAuthority")',ctx),'bbxV011CommandAuthority');
 assert.equal(vm.runInContext('authorityFnName("GetOperation")',ctx),'bbxV011GetOperation');
 assert.equal(vm.runInContext('authorityFnName("CommandAuthority",{releaseTag:"BBX-V0.10"})',ctx),'bbxV010CommandAuthority');
 assert.equal(vm.runInContext('authorityFnName("CommandAuthority",{releaseTag:"BBX-V0.9"})',ctx),'bbxV09CommandAuthority');
});
