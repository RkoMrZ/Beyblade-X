'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v032.js'),'utf8');
function client(){
 const start=src.indexOf('function listenCloudEvent(id){');
 const end=src.indexOf('async function waitForAuthRestore(',start);
 assert.ok(start>=0&&end>start);
 const paths=new Map();
 const obj={console,Date,JSON,Number,Map,Set,window:{},setTimeout,clearTimeout,
  setInterval:()=>10,clearInterval:()=>{},
  document:{visibilityState:'visible'},
  ev:{id:'E100',rounds:[{matches:Array.from({length:20},(_,i)=>({a:'A'+i,b:'B'+i,sa:0,sb:0,matchVersion:1,refereeActive:false}))}],refereeClaims:{},refereeNames:['裁判 1','裁判 2'],publishedSeq:1},
  cloudReady:true,isAdmin:true,isReferee:false,cloudUnsub:null,cloudListenerEpoch:0,
  cloudResyncBlocked:false,cloudEventsCache:{},liveRetryAttempts:new Map(),liveTransportRecoveryAt:new Map(),
  refereeClaimsStreamRevision:0,currentAdminTab:'bracket',
  fbDb:{ref(p){if(!paths.has(p))paths.set(p,new Map());return {on(t,fn){if(paths.get(p).has(t))throw Error('duplicated callback');paths.get(p).set(t,fn)},off(t,fn){if(paths.get(p).get(t)===fn)paths.get(p).delete(t)}}}},
  $:()=>null,normalizeRefereeClaimsData:x=>x||{},confirmRefereeClaims:()=>false,refereeClaimsConfirmed:()=>false,
  renderAdmin:()=>{},renderReferee:()=>{},v05ScorePending:()=>false};
 vm.createContext(obj);vm.runInContext(src.slice(start,end),obj);obj.listenCloudEvent('E100');
 return {obj,paths,close:()=>obj.cloudUnsub()};
}
test('twenty existing matches produce twenty child_added callbacks but no twenty GETs or changed match versions',()=>{
 const c=client();try{
  const events=c.paths.get('events/E100/rounds/0/matches');
  assert.ok(events.has('child_added'));
  for(let i=0;i<20;i++)events.get('child_added')({key:String(i),val:()=>({a:'A'+i,b:'B'+i,sa:0,sb:0,matchVersion:1,refereeActive:false})});
  const m=c.obj.window.__bbxSyncMetrics;
  assert.equal(m.childAdded,20);
  assert.equal(m.childChanged,0);
  assert.equal(m.matchReads,0);
  assert.equal(m.fullReads,0);
  assert.equal(m.events,0);
  assert.equal(m.trace.filter(e=>e.stage==='sdk child_added').length,1,'initial event log is aggregated');
  events.get('child_changed')({key:'4',val:()=>({a:'A4',b:'B4',sa:1,sb:0,matchVersion:2,refereeActive:false})});
  assert.equal(m.childChanged,1);
  assert.equal(m.events,1);
  assert.equal(m.duplicateSubscriptions,0);
  assert.equal(m.uniqueSubscriptions,c.paths.size*1+2,'each match path has three event subscriptions');
 }finally{c.close()}
});
test('transport switch is opt-in and blocks reload when scores remain unconfirmed',()=>{
 const start=src.indexOf('function switchBbxTransportAfterConfirmation(){');
 const end=src.indexOf('function firebaseConfigured()',start);
 assert.ok(start>=0&&end>start);
 let url=null,alerts=0,confirmed=0;
 const ctx={bbxRealtimeTransport:'long-polling',ev:{id:'E100',publicCode:'ABCD1'},currentAdminTab:'bracket',
  v05ScoreQueues:new Map(),URL,window:{location:{href:'https://bbxs-tamsui.web.app/?event=ABCD1'},confirm(){confirmed++;return true}},alert(){alerts++}};
 ctx.window.location.assign=u=>{url=u};
 vm.createContext(ctx);vm.runInContext(src.slice(start,end),ctx);
 ctx.v05ScoreQueues.set('one',{run:true});assert.equal(ctx.switchBbxTransportAfterConfirmation(),false);assert.equal(url,null);assert.equal(alerts,1);
 ctx.v05ScoreQueues.clear();assert.equal(ctx.switchBbxTransportAfterConfirmation(),true);assert.equal(confirmed,1);
 assert.equal(new URL(url).searchParams.get('bbxTransport'),'auto');
 assert.equal(new URL(url).searchParams.get('event'),'ABCD1');
 assert.equal(new URL(url).searchParams.has('auth'),false);
});
