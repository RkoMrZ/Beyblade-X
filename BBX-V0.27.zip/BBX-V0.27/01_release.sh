#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.27 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.27 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.27 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v027.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v027-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
# Update only authoritative publisher functions before the new listener uses
# the events/{id}/publishedSeq watermark. RTDB Rules are unchanged.
gcloud auth print-access-token >/dev/null
firebase deploy --only "functions:bbxV011CommandAuthority,functions:bbxV011OrganizerAuthority,functions:bbxV011PublishAuthority,functions:bbxV011RepairPublication,functions:bbxV011RepairQueue" --project ljt-beyblade-x --non-interactive
bash deploy/hosting-v027.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.27 V0.27-compatible publisher Functions + Hosting deployed and verified; Rules and saved event data untouched.\n'
# Only remove recoverable local old build folders once the new release succeeded.
cd "$HOME"
for old in BBX-V0.5 BBX-V0.6 BBX-V0.7 BBX-V0.8 BBX-V0.9 BBX-V0.10 BBX-V0.11 BBX-V0.12 BBX-V0.13 BBX-V0.14 BBX-V0.15 BBX-V0.16 BBX-V0.17 BBX-V0.18 BBX-V0.19 BBX-V0.20 BBX-V0.21 BBX-V0.22 BBX-V0.23 BBX-V0.24 BBX-V0.25; do
 [[ -d "$old" && -f "$old/MANIFEST.json" ]] || continue
 rm -rf -- "$old"
done
