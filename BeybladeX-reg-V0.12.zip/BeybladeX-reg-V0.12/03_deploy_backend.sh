#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
bash 06_source_guard.sh
# Existing same-name V06 endpoints; no Rules deployment or data reset.
firebase deploy --only functions:registration --project ljtreg-39954 --non-interactive
