#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
umask 077
exec 9>.release.lock
flock -n 9 || { echo 'Already running: reconnect reg-v012-release'; exit 3; }
[ ! -f .release-completed ] || { echo RELEASE_ALREADY_COMPLETED; exit 0; }
exec > >(tee -a release.log) 2>&1
trap 'rc=$?; if [ "$rc" -ne 0 ]; then echo "RELEASE_STOPPED=$rc; do not reset data. If maintenance started it remains active. Resume: bash 08_release.sh"; fi' EXIT
sha256sum -c FILE_SHA256.txt >/dev/null
[ -f "$HOME/BeybladeX-reg-V0.7/.release-completed" ] && [ -f "$HOME/BeybladeX-reg-V0.7/.backend-completed" ] || { echo 'STOP: V0.7 completed upgrade evidence missing; do not reinstall or reset. Send this output for review.'; exit 2; }
[ "$(node -p 'process.versions.node.split(".")[0]')" = 22 ] || { echo 'Node.js 22 required'; exit 2; }
bash 06_source_guard.sh
node functions/tests/v07.compat.test.js
npm ci --prefix functions --no-audit --no-fund
# Compatible V06 backend already has the maintenance gate. No bootstrap or data migration.
if [ ! -f .maintenance-owned ]; then
 state=$(firebase database:get /registrationServiceState/active --project ljtreg-39954 --instance ljtreg-39954-default-rtdb)
 [ "$state" = false ] || { echo 'STOP: maintenance already active/unknown. Send this output for review.'; exit 2; }
 date -u > .maintenance-owned
fi
state_file=$(mktemp)
trap 'rm -f "$state_file"' RETURN
printf 'true\n' > "$state_file"
firebase database:set /registrationServiceState/active "$state_file" --force --project ljtreg-39954 --instance ljtreg-39954-default-rtdb
firebase deploy --only hosting --config firebase.maintenance.json --project ljtreg-39954 --non-interactive
echo 'Maintenance enabled. Waiting 130 seconds for accepted writes to finish; safe to reconnect tmux.'
sleep 130
if [ ! -f .backup-completed ]; then bash 02_backup_database.sh; date -u > .backup-completed; fi
if [ ! -f .backend-completed ]; then bash 03_deploy_backend.sh; date -u > .backend-completed; fi
bash 07_deploy_hosting.sh
bash 05_verify.sh
printf 'false\n' > "$state_file"
firebase database:set /registrationServiceState/active "$state_file" --force --project ljtreg-39954 --instance ljtreg-39954-default-rtdb
rm -f "$state_file"
date -u > .release-completed
echo 'RELEASE_COMPLETED V0.12: V06 forms, participants, URLs and backend namespace retained.'
