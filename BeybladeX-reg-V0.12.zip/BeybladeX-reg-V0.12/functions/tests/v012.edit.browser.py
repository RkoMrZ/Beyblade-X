"""Offline tests of the shipped edit handler; no production traffic."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
from browser_support import browser_options
root=Path(__file__).resolve().parents[2];src=(root/'web/js/index.js').read_text()
fn=src[src.index('function editEvent(){'):src.index('\nfunction toggleOpen')]
with sync_playwright() as p:
 b=p.chromium.launch(**browser_options());page=b.new_page()
 page.set_content('<main id="modalContent"></main>')
 page.evaluate('''window.$=id=>document.getElementById(id);window.safe=x=>String(x??'');window.eid='ABCDE';window.eventMeta={title:'原設定',capacity:32,startTime:'21:30',signupClosesAt:123,version:5};window.deadlineValue=x=>x?'2026-11-12T21:00':'';window.formFields=m=>`<input name="title" value="${m.title}"><input name="capacity" value="${m.capacity}"><input name="startTime" value="${m.startTime}"><input name="signupDeadline" value="${deadlineValue(m.signupClosesAt)}">`;window.openModal=h=>$('modalContent').innerHTML=h;window.closeModal=()=>window.modalClosed=true;window.msg=()=>{};window.collect=f=>{let d=Object.fromEntries(new FormData(f));d.capacity=Number(d.capacity);return d};window.attempt=(name,data)=>window.sent={name,data};'''+fn+';editEvent();')
 page.locator('[type=submit]').click();assert page.evaluate('window.modalClosed===true && !window.sent')
 page.evaluate('editEvent();eventMeta={...eventMeta,version:6,title:"其他裝置的新設定"}')
 page.locator('[name=capacity]').fill('48');page.locator('[type=submit]').click()
 got=page.evaluate('sent.data');assert got['expectedVersion']==5 and got['capacity']==48
 assert got['title']=='原設定'
 assert "b.textContent='修改尚未確認：'+e.message" in src
 print('PASS actual edit handler: no-op avoids write; displayed snapshot version stays 5 after background update to 6; capacity payload correct; actual server error rendered with textContent')
 b.close()
