'use strict';
// Runs ONLY against a local Firebase RTDB Emulator (never against production).
// Invoke from BeybladeX-reg-V0.6 root:
// firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const Module=require('node:module');
const host=process.env.FIREBASE_DATABASE_EMULATOR_HOST||'';
if(!/^(localhost|127\.0\.0\.1):\d+$/.test(host)){
 console.error('REFUSING TO RUN: FIREBASE_DATABASE_EMULATOR_HOST must point to local RTDB emulator');process.exit(2);
}
// Local emulator traffic must bypass HTTP/WebSocket proxies.
for(const key of ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','WS_PROXY','WSS_PROXY','ws_proxy','wss_proxy'])delete process.env[key];
process.env.NODE_USE_ENV_PROXY='0';
// Use an isolated database namespace, never the real ljtreg-39954 namespace.
process.env.FIREBASE_CONFIG=JSON.stringify({projectId:'demo-ljtreg',databaseURL:'https://demo-ljtreg-default-rtdb.firebaseio.com'});
// We only replace the callable HTTP wrapper; all Firebase Admin SDK/database
// transactions are REAL and are routed to the emulator by the env variable.
const old=Module._load;
Module._load=function(id,parent,isMain){
 if(id==='firebase-functions/v2/https'){
  const real=old.apply(this,arguments);return {...real,onCall:(_cfg,fn)=>fn};
 }
 return old.apply(this,arguments);
};
const api=require('../index.js'),previous=require('../compat_v06_baseline.cjs');Module._load=old;
const {getDatabase}=require('firebase-admin/database');
const db=getDatabase();
const owner={auth:{uid:'preflight-owner',token:{firebase:{sign_in_provider:'google.com'}}}};
const intruder={auth:{uid:'preflight-intruder',token:{firebase:{sign_in_provider:'google.com'}}}};
const guest={auth:null};
const createId=()=>crypto.randomBytes(24).toString('hex');
const invoke=(name,data,who=owner)=>api[name]({...who,data:{...data,clientVersion:'V0.7'}});
const prefix='emulator_'+Date.now().toString(36);
const mkForm=i=>({playerName:prefix+'_player_'+i,phone3:'093',lineName:'sameLINE',rid:createId()});
let eid=null;
(async()=>{
 const base={title:'模擬器 '+prefix,eventDate:'2099-11-01',checkinTime:'09:00',startTime:'10:00',venue:'測試體育館',fee:0,capacity:32};
 const cid=createId(),created=await invoke('regV06CreateEvent',{...base,createId:cid});eid=created.eid;
 assert.match(eid,/^[A-Z0-9]{5}$/,'event IDs must be 5 readable characters');
 const again=await invoke('regV06CreateEvent',{...base,createId:cid});assert.equal(again.eid,eid);
 await assert.rejects(invoke('regV06SetOpen',{eid,open:false,expectedVersion:1},intruder));
 const forms=Array.from({length:64},(_,i)=>({...mkForm(i),eid}));
 const results=await Promise.all(forms.map(f=>invoke('regV06Submit',f,guest)));
 const nums=results.map(x=>x.signupNo).sort((a,b)=>a-b);
 assert.deepEqual(nums,Array.from({length:64},(_,i)=>i+1));
 assert.equal((await db.ref(`publicRowsV06/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`rankActiveV06/${eid}`).get()).numChildren(),64);
 const ownNo=n=>results.findIndex(x=>x.signupNo===n);
 const myRank=n=>invoke('regV06MyRank',{eid,rid:forms[ownNo(n)].rid},guest);
 assert.equal((await myRank(33)).rankLabel,'備選#1');
 await invoke('regV06Review',{eid,key:'p00000001',status:'rejected',expectedVersion:1});
 assert.equal((await myRank(33)).rankLabel,'正選#32');
 await invoke('regV06Review',{eid,key:'p00000001',status:'approved',expectedVersion:2});
 assert.equal((await myRank(33)).rankLabel,'備選#1');
 assert.equal((await db.ref(`privateRowsV06/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`managerRowsV06/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`nameClaimsV06/${eid}`).get()).numChildren(),64);
 // V0.12: change capacity/time after real entries, preserving all registration records.
 const keepRoots=['publicRowsV06','privateRowsV06','managerRowsV06','rankActiveV06','receiptsV06','nameClaimsV06'];
 const kept={};for(const root of keepRoots)kept[root]=(await db.ref(`${root}/${eid}`).get()).val();
 const saveMeta=async delta=>{const m=(await db.ref(`eventsV06/${eid}/meta`).get()).val();return invoke('regV06UpdateEvent',{...m,...delta,eid,expectedVersion:m.version});};
 await saveMeta({capacity:48});assert.equal((await myRank(33)).rankLabel,'正選#33');
 assert.equal((await db.ref(`ownerEventsV06/preflight-owner/${eid}/capacity`).get()).val(),48);
 await saveMeta({capacity:16});assert.equal((await myRank(33)).rankLabel,'備選#17');
 await saveMeta({capacity:32,startTime:'11:30'});
 assert.equal((await db.ref(`eventsV06/${eid}/meta/startTime`).get()).val(),'11:30');
 assert.equal((await myRank(33)).rankLabel,'備選#1');
 for(const root of keepRoots)assert.deepEqual((await db.ref(`${root}/${eid}`).get()).val(),kept[root],root+' unchanged');
 const prior=(await db.ref(`eventsV06/${eid}/meta`).get()).val();
 await assert.rejects(invoke('regV06UpdateEvent',{...base,eid,capacity:48,expectedVersion:prior.version-1}),/其他裝置/);
 await assert.rejects(invoke('regV06UpdateEvent',{...base,eid,capacity:48,expectedVersion:prior.version},intruder),/權限/);
 await assert.rejects(saveMeta({startTime:'08:00'}),/設定/);
 await assert.rejects(saveMeta({signupDeadline:'2099-11-01T12:00'}),/截止/);
 assert.deepEqual((await db.ref(`eventsV06/${eid}/meta`).get()).val(),prior);
 const changed=await Promise.allSettled([saveMeta({capacity:40}),saveMeta({capacity:50})]);
 assert(changed.some(x=>x.status==='fulfilled'));
 const stable=(await db.ref(`eventsV06/${eid}/meta`).get()).val();
 assert.equal((await db.ref(`allocV06/${eid}/capacity`).get()).val(),stable.capacity);
 await saveMeta({capacity:32});
 const lastChanges=(await db.ref(`changesV06/${eid}`).orderByKey().limitToLast(1).get()).val();
 assert.equal(Object.values(lastChanges)[0].type,'meta');
 console.log('PASS V0.12: populated capacity up/down, time-only edit, immutable participant records, owner/version guards, atomic allocator/index/meta consistency and metadata sync notification');
 const replay=await invoke('regV06Submit',forms[0],guest);assert.equal(replay.signupNo,results[0].signupNo);
 await assert.rejects(invoke('regV06Submit',{...forms[0],rid:createId(),phone3:'777'},guest));
 const both=await Promise.allSettled([invoke('regV06Review',{eid,key:'p00000010',status:'rejected',expectedVersion:1}),invoke('regV06Review',{eid,key:'p00000010',status:'approved',expectedVersion:1})]);
 assert.equal(both.filter(x=>x.status==='fulfilled').length,1,'only one review may commit for a record version');
 const rv=(await db.ref(`publicRowsV06/${eid}/p00000010`).get()).val();assert.equal(rv.recordVersion,2);
 // Verify that external unauthenticated visitors cannot download LINE/private information.
 const namespace='demo-ljtreg-default-rtdb';
 const res=await fetch(`http://${host}/privateRowsV06/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.notEqual(res.status,200,'anonymous REST read of privateRows must be denied by Rules');
 const idx=await fetch(`http://${host}/rankActiveV06/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.notEqual(idx.status,200,'anonymous REST read of rankActive must be denied by Rules');
 const pub=await fetch(`http://${host}/publicRowsV06/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.equal(pub.status,200,'public simplified roster should be readable');
 const data=await pub.json();assert.equal(Object.values(data)[0].lineName,undefined);
 // V0.6 lean projection is atomically updated and owner-only; internal data is server-only.
 const {initializeApp}=require('firebase-admin/app');
 const ownerApp=initializeApp({projectId:'demo-ljtreg',databaseURL:'https://demo-ljtreg-default-rtdb.firebaseio.com',databaseAuthVariableOverride:{uid:'preflight-owner',token:{firebase:{sign_in_provider:'google.com'}}}},'rules-owner');
 const otherApp=initializeApp({projectId:'demo-ljtreg',databaseURL:'https://demo-ljtreg-default-rtdb.firebaseio.com',databaseAuthVariableOverride:{uid:'other',token:{firebase:{sign_in_provider:'google.com'}}}},'rules-other');
 const ownerDb=getDatabase(ownerApp),otherDb=getDatabase(otherApp);
 const projected=(await ownerDb.ref(`managerRowsV06/${eid}/p00000002`).get()).val();
 assert.deepEqual(Object.keys(projected).sort(),['lineName','recordVersion']);
 await assert.rejects(otherDb.ref(`managerRowsV06/${eid}`).get());
 await assert.rejects(ownerDb.ref(`privateRowsV06/${eid}`).get());
 await assert.rejects(ownerDb.ref(`managerRowsV06/${eid}/p00000002/lineName`).set('forbidden'));
 const orig=(await db.ref(`publicRowsV06/${eid}/p00000002`).get()).val();
 const edited=await invoke('regV06EditEntry',{eid,key:'p00000002',expectedVersion:orig.recordVersion,playerName:orig.playerName,phone3:orig.phone3,lineName:'Updated LINE'});
 assert.deepEqual(Object.keys(edited.private).sort(),['lineName','recordVersion']);
 assert.equal((await db.ref(`managerRowsV06/${eid}/p00000002/lineName`).get()).val(),'Updated LINE');
 await invoke('regV06Review',{eid,key:'p00000002',expectedVersion:edited.row.recordVersion,status:'approved'});
 const journal=(await db.ref(`changesV06/${eid}`).orderByKey().limitToLast(2).get()).val();
 assert(Object.values(journal).every(x=>Number.isSafeInteger(x.recordVersion)));
 console.log('PASS V06 PROJECTION: owner-only lean records; foreign owner/internal records/client writes denied; edit/review versions published');
 // Real RTDB Emulator collision regression; the seed pair maps to PYC7C at attempt 0.
 const collisionA='00000000000000000000000000000000000000000000437c';
 const collisionB='0000000000000000000000000000000000000000000049d5';
 const [first,second]=await Promise.all([
  invoke('regV06CreateEvent',{...base,title:'碰撞測試 A',createId:collisionA}),
  invoke('regV06CreateEvent',{...base,title:'碰撞測試 B',createId:collisionB})
 ]);
 assert.notEqual(first.eid,second.eid,'atomic code allocation must survive concurrent creation and a collision');
 assert([first.eid,second.eid].includes('2LR2M'),'both requests have the same attempt-zero code');
 assert.equal((await db.ref(`eventsV06/${first.eid}/meta/title`).get()).val(),'碰撞測試 A');
 assert.equal((await db.ref(`eventsV06/${second.eid}/meta/title`).get()).val(),'碰撞測試 B');
 assert.equal((await invoke('regV06CreateEvent',{...base,title:'碰撞測試 B',createId:collisionB})).eid,second.eid);
 await invoke('regV06DeleteEvent',{eid:first.eid});
 await invoke('regV06DeleteEvent',{eid:second.eid});
 console.log('PASS 5-CHAR COLLISION EMULATOR: both owners/requests isolated with deterministic retry');
 await invoke('regV06DeleteEvent',{eid});
 assert.equal((await db.ref(`privateRowsV06/${eid}`).get()).exists(),false);
 assert.equal((await db.ref(`managerRowsV06/${eid}`).get()).exists(),false);
 // Legacy per-event cleanup is owner-only and cannot affect a sibling version.
 await db.ref('registrationMaintenanceV06/legacyCleanupReadyAt').set(Date.now()-1);
 const legacy='LG123';
 const {roots:cleanupRoots,cleanupPaths}=require('../cleanup_manifest');
 for(const v of ['V03','V04']){
  const fixtures={};
  for(const root of cleanupRoots[v]){fixtures[`${root}${v}/${legacy}`]={sentinel:'cleanup-target'};fixtures[`${root}${v}/OTHER`]={sentinel:'must-remain'};}
  await db.ref().update(fixtures);
  await db.ref().update({[`events${v}/${legacy}`]:{ownerUid:'preflight-owner',meta:{title:'archived'}},[`ownerEvents${v}/preflight-owner/${legacy}`]:{title:'archived'},[`publicRows${v}/${legacy}/p00000001`]:{playerName:'archived'},[`privateRows${v}/${legacy}/p00000001`]:{lineName:'hidden'}});
 }
 await assert.rejects(invoke('regV06DeleteLegacyEvent',{eid:legacy,sourceVersion:'V03',confirm:legacy},intruder));
 await invoke('regV06DeleteLegacyEvent',{eid:legacy,sourceVersion:'V03',confirm:legacy});
 assert.equal((await db.ref(`publicRowsV03/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`privateRowsV03/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`eventsV03/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`eventsV04/${legacy}/ownerUid`).get()).val(),'preflight-owner');
 await db.ref(`eventsV04/${legacy}`).remove(); // simulate stale old index without proof
 await assert.rejects(invoke('regV06DeleteLegacyEvent',{eid:legacy,sourceVersion:'V04',confirm:legacy}));
 await db.ref(`eventsV04/${legacy}/ownerUid`).set('preflight-owner');
 await invoke('regV06DeleteLegacyEvent',{eid:legacy,sourceVersion:'V04',confirm:legacy});
 assert.equal((await db.ref(`privateRowsV04/${legacy}`).get()).exists(),false);
 assert.equal((await db.ref(`ownerEventsV04/preflight-owner/${legacy}`).get()).exists(),false);
 await invoke('regV06DeleteLegacyEvent',{eid:legacy,sourceVersion:'V03',confirm:legacy});
 for(const v of ['V03','V04']){
  for(const target of Object.keys(cleanupPaths(v,legacy,'preflight-owner')))assert.equal((await db.ref(target).get()).exists(),false,target);
  for(const root of cleanupRoots[v])assert.equal((await db.ref(`${root}${v}/OTHER/sentinel`).get()).val(),'must-remain');
 }
 const recover=(await invoke('regV06CreateEvent',{...base,title:'lifecycle recovery',createId:createId()})).eid;
 await db.ref().update({[`eventsV06/${recover}`]:null,[`ownerEventsV06/preflight-owner/${recover}`]:null,[`privateRowsV06/${recover}`]:{sample:'orphan'}});
 await assert.rejects(invoke('regV06DeleteEvent',{eid:recover},intruder));
 await invoke('regV06DeleteEvent',{eid:recover});
 assert.equal((await db.ref(`privateRowsV06/${recover}`).get()).exists(),false);
 assert.equal((await db.ref(`eventLifecycleV06/V06/${recover}`).get()).exists(),false);
 // V06 must fully erase V05 data, including V05 deletion markers and ledgers.
 const {completeCleanupPaths,registry}=require('../cleanup_manifest');
 const oldId='OLD05',oldUid=owner.auth.uid;
 const oldPaths=completeCleanupPaths('V05',oldId,oldUid);
 const seeded=Object.fromEntries(Object.keys(cleanupPaths('V05',oldId,oldUid)).map(p=>[p,{sentinel:'remove'}]));
 seeded[`eventsV05/${oldId}`]={ownerUid:oldUid,deleted:true,createProof:'old-proof'};
 seeded[`allocV05/${oldId}`]={deleted:true,open:false};
 for(const root of registry.lifecycleRoots)seeded[`${root}/V05/${oldId}`]={ownerUid:oldUid,sourceVersion:'V05',eventId:oldId,paths:Object.keys(cleanupPaths('V05',oldId,oldUid)),state:'deleted',createProof:'old-proof'};
 for(const root of registry.cleanupReceiptRoots)seeded[`${root}/V05/${oldId}`]={ownerUid:oldUid,finishedAt:1};
 seeded[`eventsV06/${oldId}`]={ownerUid:oldUid,meta:{title:'same code new version'}};
 await db.ref().update(seeded);
 await db.ref('registrationMaintenanceV06/legacyCleanupReadyAt').remove();
 await assert.rejects(invoke('regV06DeleteLegacyEvent',{eid:oldId,sourceVersion:'V05',confirm:oldId}));
 assert.equal((await db.ref(`eventsV05/${oldId}`).get()).exists(),true);
 await db.ref('registrationMaintenanceV06/legacyCleanupReadyAt').set(Date.now()-1);
 await assert.rejects(invoke('regV06DeleteLegacyEvent',{eid:oldId,sourceVersion:'V05',confirm:oldId},intruder));
 await invoke('regV06DeleteLegacyEvent',{eid:oldId,sourceVersion:'V05',confirm:oldId});
 for(const target of Object.keys(oldPaths))assert.equal((await db.ref(target).get()).exists(),false,target);
 assert.equal((await db.ref(`eventsV06/${oldId}/meta/title`).get()).val(),'same code new version');
 assert.equal((await invoke('regV06DeleteLegacyEvent',{eid:oldId,sourceVersion:'V05',confirm:oldId})).alreadyAbsent,true);
 // Missing original event can still be cleaned using the historical ledger.
 const orphanId='ORP05';
 await db.ref(`privateRowsV05/${orphanId}`).set({private:'remove'});
 await db.ref(`eventLifecycleV05/V05/${orphanId}`).set({ownerUid:oldUid,sourceVersion:'V05',eventId:orphanId,paths:Object.keys(cleanupPaths('V05',orphanId,oldUid)),state:'deleted'});
 await invoke('regV06DeleteLegacyEvent',{eid:orphanId,sourceVersion:'V05',confirm:orphanId});
 for(const target of Object.keys(completeCleanupPaths('V05',orphanId,oldUid)))assert.equal((await db.ref(target).get()).exists(),false,target);
 for(const v of ['V03','V04'])for(const target of Object.keys(completeCleanupPaths(v,legacy,oldUid)))assert.equal((await db.ref(target).get()).exists(),false,target);
 console.log('PASS V06 COMPLETE HISTORICAL CLEANUP: V03/V04/V05 zero event data/ledger/receipts; missing main recovered; retry no archive; ownership and sibling version protected');
 console.log('PASS REAL RTDB LIFECYCLE: missing main/index recovered with server ledger');
 console.log('PASS REAL RTDB EMULATOR LEGACY: V03/V04 cleanup, strict owner proof, cross-version isolation, second-owner forbidden');
 const oldOwner={auth:{uid:'v07-old-owner',token:{firebase:{sign_in_provider:'google.com'}}}};
 const oldData={...base,title:'V06 real retained',createId:createId()};
 const oldEvent=await previous.regV06CreateEvent({...oldOwner,data:oldData});
 const oldPerson={...mkForm('old'),eid:oldEvent.eid};
 await previous.regV06Submit({...guest,data:oldPerson});
 const oldSnapshot=(await db.ref(`eventsV06/${oldEvent.eid}`).get()).val();
 assert.equal((await invoke('regV06CreateEvent',oldData,oldOwner)).eid,oldEvent.eid);
 assert.deepEqual((await db.ref(`eventsV06/${oldEvent.eid}`).get()).val(),oldSnapshot);
 assert.equal((await invoke('regV06Submit',oldPerson,guest)).replayed,true);
 await assert.rejects(api.regV06Submit({...guest,data:oldPerson}),/重新整理/);
 const quotaOwner={auth:{uid:'v07-quota-owner',token:{firebase:{sign_in_provider:'google.com'}}}};
 const many=await Promise.allSettled(Array.from({length:8},()=>invoke('regV06CreateEvent',{...base,createId:createId()},quotaOwner)));
 assert.equal(many.filter(x=>x.status==='fulfilled').length,5);
 assert.equal(many.filter(x=>x.status==='rejected'&&x.reason.code==='resource-exhausted').length,3);
 assert.equal((await db.ref('ownerEventsV06/v07-quota-owner').get()).numChildren(),5);
 assert.equal((await db.ref('registrationCreateGates/v07-quota-owner').get()).exists(),false);
 await assert.rejects(ownerDb.ref('registrationServiceState/active').set(true));
 await assert.rejects(ownerDb.ref('registrationCreateGates/preflight-owner').set({token:'forged'}));
 await db.ref('registrationServiceState/active').set(true);
 await assert.rejects(invoke('regV06Submit',oldPerson,guest),/維修/);
 const blocked=await fetch(`http://${host}/publicRowsV06/${oldEvent.eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.notEqual(blocked.status,200);
 await db.ref('registrationServiceState/active').set(false);
 assert.equal((await invoke('regV06Submit',oldPerson,guest)).replayed,true);
 await invoke('regV06DeleteEvent',{eid:oldEvent.eid},oldOwner);
 for(const root of ['publicRows','privateRows','managerRows','nameClaims','receipts','changes','sync','rankActive'])assert.equal((await db.ref(`${root}V06/${oldEvent.eid}`).get()).exists(),false);
 assert.equal((await db.ref(`eventLifecycleV06/V06/${oldEvent.eid}`).get()).exists(),false);
 console.log('PASS V07 REAL RTDB: V06 data/URL/request replay preserved; 8 simultaneous creates -> 5 accepted; old client refresh required; maintenance Rules and APIs enforced; organizer cannot toggle; legacy form business data deleted');
 console.log('PASS RANK INDEX: direct callable rank, reject/promote/restore, private index denied; PASS RTDB EMULATOR: 64 genuinely concurrent transactions, unique name, idempotency, 2-owner version conflict, public/private Rules, full-event cleanup');
})().catch(async err=>{
 console.error('FAIL RTDB EMULATOR:',err.stack||err);
 if(eid){try{await invoke('regV06DeleteEvent',{eid})}catch{}}
 process.exitCode=1;
}).finally(async()=>{await Promise.all(require('firebase-admin/app').getApps().map(app=>app.delete()))});
