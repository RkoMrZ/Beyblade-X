'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {buildProjectionPatch}=require('../functions/bbx-v09-publication');
const eid='BBX123456';
test('delayed stale open/close outbox never modifies current public gate',()=>{
 for(const open of [true,false]){
  const patch=buildProjectionPatch(eid,{seq:1,changes:[
   {path:'publicOpen',value:open,publicPath:'meta/publicOpen',publicValue:open},
   {path:'publicUntil',value:123,publicPath:'meta/publicUntil',publicValue:123}
  ]},{publicOpen:!open,publicUntil:987});
  assert.deepEqual(Object.keys(patch),[`publicEvents/${eid}/meta/authoritySeq`]);
 }
});
test('private-only referee claim never causes public score update',()=>{
 const patch=buildProjectionPatch(eid,{seq:2,changes:[{path:'rounds/0/matches/0',value:{claimUid:'owner'},publicChanged:false}]},{publicOpen:true});
 assert.equal(patch[`publicEvents/${eid}/rounds/0/matches/0`],undefined);
 assert.deepEqual(patch[`events/${eid}/rounds/0/matches/0`],{claimUid:'owner'});
});
test('public score patch changes only impacted match, never whole bracket',()=>{
 const patch=buildProjectionPatch(eid,{seq:4,changes:[{path:'rounds/0/matches/1',value:{sa:4},publicValue:{sa:4}}]},{publicOpen:true});
 assert.deepEqual(Object.keys(patch).sort(),[`events/${eid}/rounds/0/matches/1`,`publicEvents/${eid}/rounds/0/matches/1`,`publicEvents/${eid}/meta/authoritySeq`].sort());
});
test('malformed outbox paths cannot escape their tournament',()=>{
 assert.throws(()=>buildProjectionPatch(eid,{seq:1,changes:[{path:'../../secrets',value:1,publicValue:1}]},{publicOpen:true}),/BBX_INVALID_PROJECTION_PATH/);
 assert.throws(()=>buildProjectionPatch(eid,{seq:1,changes:[{path:'secrets',value:1,publicValue:1}]},{publicOpen:true}),/BBX_UNSUPPORTED_PROJECTION_PATH/);
});
test('missing public value fails loudly before projection starts',()=>{
 assert.throws(()=>buildProjectionPatch(eid,{seq:1,changes:[{path:'roster',value:['A']}]},{publicOpen:true}),/BBX_MISSING_PUBLIC_VALUE/);
});

test('old queued structure epoch never rolls back immediate organizer structure epoch',()=>{
 const patch=buildProjectionPatch(eid,{seq:6,changes:[{path:'structureVersion',value:1,publicChanged:false}]},{publicOpen:true});
 assert.equal(patch[`events/${eid}/structureVersion`],undefined);
 assert.deepEqual(Object.keys(patch),[`publicEvents/${eid}/meta/authoritySeq`]);
});
