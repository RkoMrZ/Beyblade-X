 'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const dir=path.resolve(__dirname,'..');
const index=fs.readFileSync(path.join(dir,'assets/index-v09.js'),'utf8');
const viewer=fs.readFileSync(path.join(dir,'assets/viewer-v09.js'),'utf8');

const pick=(source,start,end)=>{
 const a=source.indexOf(start),b=source.indexOf(end,a);
 assert.ok(a!==-1 && b>a,`source slice ${start}`);
 return source.slice(a,b);
};
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const tick=()=>new Promise(r=>setImmediate(r));

test('viewer: failed-stream GET cannot overwrite a newer SSE score',async()=>{
 const fragment=pick(viewer,'async function checkFailure(kind,id){','// iOS Safari / Web App');
 const gate=deferred();
 const ctx={Promise, console, streamGeneration:3,receivedEventSerial:7,streamKind:'publicEvents',streamId:'EVENT',
  document:{visibilityState:'visible'},failureCheckBusy:false,data:{meta:{seq:1}},gotFirst:true,lastResyncAt:0,
  fetch:()=>gate.promise,streamUrl:()=>'/endpoint',stream:{close(){ctx.closed=true}},setStatus(t){ctx.status=t},scheduleRender(){ctx.rendered=true},Date};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 const process=vm.runInContext('checkFailure("publicEvents","EVENT")',ctx);
 // SSE arrives AFTER fetch starts. The older GET reply must be discarded.
 ctx.receivedEventSerial=8;ctx.data={meta:{seq:2}};
 gate.resolve({ok:true,status:200,json:async()=>({meta:{seq:1}})});
 await process;
 assert.equal(ctx.data.meta.seq,2);assert.equal(ctx.rendered,undefined);
 assert.equal(ctx.failureCheckBusy,false);
});

test('viewer: reply from an old stream generation is discarded',async()=>{
 const fragment=pick(viewer,'async function checkFailure(kind,id){','// iOS Safari / Web App');
 const gate=deferred();
 const ctx={console,streamGeneration:1,receivedEventSerial:0,streamKind:'publicEvents',streamId:'EVENT',
 document:{visibilityState:'visible'},failureCheckBusy:false,data:{marker:'new'},fetch:()=>gate.promise,streamUrl:()=>'/endpoint',
 stream:{close(){throw Error('closed new connection')}},setStatus(){throw Error('status from stale request')},scheduleRender(){throw Error('render stale')},Date};
 vm.createContext(ctx);vm.runInContext(fragment,ctx);
 const p=vm.runInContext('checkFailure("publicEvents","EVENT")',ctx);ctx.streamGeneration=2;
 gate.resolve({ok:true,status:200,json:async()=>({marker:'old'})});await p;
 assert.equal(ctx.data.marker,'new');
});

test('home: uses incoming index snapshot, coalesces rapid changes, detaches on background',async()=>{
 const block=pick(index,'function stopMyCloudEventIndexListener(){','async function bootstrapCloud(){');
 let callback,detached=0;const gate=deferred(),applied=[];
 const ctx={console,ownerIndexUnsub:null,ownerIndexSyncBusy:false,ownerIndexPendingSnapshot:null,ownerIndexGeneration:0,
  document:{visibilityState:'visible'},fbAuth:{currentUser:{uid:'owner'}},
  isGoogleUser:()=>true,fbDb:{ref:p=>({on(type,cb){assert.equal(p,'userEvents/owner');callback=cb},off(){detached++}})},
  syncMyCloudEvents:async(snapshot,valid)=>{if(snapshot['0']==='FIRST')await gate.promise;if(valid())applied.push(snapshot['0'])},
  renderSavedEvents(){},$:id=>({classList:{contains:()=>false}})};
 vm.createContext(ctx);vm.runInContext(block,ctx);
 vm.runInContext('listenMyCloudEventIndex()',ctx);
 callback({val:()=>({'0':'FIRST'})});await tick();
 callback({val:()=>({'0':'SECOND'})});callback({val:()=>({'0':'THIRD'})});
 gate.resolve();await tick();await tick();
 assert.deepEqual(applied,['FIRST','THIRD']);
 vm.runInContext('stopMyCloudEventIndexListener()',ctx);assert.equal(detached,1);
 ctx.document.visibilityState='hidden';vm.runInContext('listenMyCloudEventIndex()',ctx);
 assert.equal(detached,1,'no listener in background');
});

test('admin background stops listeners but does not cancel in-flight score opIds',()=>{
 const hidden=pick(index,"document.addEventListener('visibilitychange',()=>{","window.addEventListener('pagehide',()=>{");
 assert.match(hidden,/if\(cloudUnsub\)/);
 assert.match(hidden,/stopMyCloudEventIndexListener\(\)/);
 assert.match(hidden,/stopAdminCodeRotation\(\)/);
 assert.match(hidden,/stopRefereeCodeRotation\(\)/);
 assert.doesNotMatch(hidden,/v05ScoreQueues\.clear\(/);
 assert.match(index,/await v05FlushScores\(q\.kind,q\.ri,q\.mi\)/);
});
