#!/usr/bin/env python3
"""BBX V0.9 preflight: externalized assets preserve V0.8 functional markup and styling."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def older(name):return (root/'baseline'/name.replace('.html','.v08.html')).read_text()
def cur(name):return (root/name).read_text()
# No user-facing markup changes except intentional audience Return removal.
def markup(t):
 t=re.sub(r'<style\b[^>]*>[\s\S]*?</style>','',t,flags=re.I)
 t=re.sub(r'<script\b[^>]*>[\s\S]*?</script>','',t,flags=re.I)
 t=re.sub(r'<link rel="stylesheet" href="\./assets/index-v09.css">','',t)
 return re.sub(r'\s+',' ',t).strip()
a,b=markup(older('index.html')),markup(cur('index.html'))
assert a==b,'Tournament HTML markup changed unexpectedly'
a=markup(older('viewer.html')).replace('<button type="button" onclick="goBack()">返回</button>','')
b=markup(cur('viewer.html'))
assert a.replace('>  </div>','> </div>')==b,'Viewer markup changed unexpectedly beyond requested back removal'
for name in ('index','viewer'):
 orig='\n\n'.join(re.findall(r'<style\b[^>]*>([\s\S]*?)</style>',older(name+'.html'),re.I))+'\n'
 assert cur('assets/'+name+'-v09.css')==orig,name+' stylesheet changed'
 assert '<style' not in cur(name+'.html')
print('PASS original tournament & viewer markup and CSS preserved, only viewer return removed')
ui=cur('assets/index-v09.js'); viewer=cur('assets/viewer-v09.js'); fn=cur('functions/index.js'); rules=json.loads(cur('database.rules.json'))['rules']
for text in ('startPrizeRaffle','resetPrizeRaffleRound','raffleState','randomRebuild','v1OrganizerAction(\'randomRebuild\')'):
 assert text in ui,text
assert "ev.roster=shuffle(ev.roster)" in ui
assert "this feature" not in ui # no English regression notice
assert "function publicUrl()" in ui and 'bbxs-tamsui.web.app/v/' in ui
assert "params.get('event')||pathCode" in viewer
assert "bbxV09CreateAuthority" in fn and "bbxV09CreateAuthority" in ui
assert 'authorityBBXV09/${eventId}' in fn
assert "ref:'authorityBBXV09/{eventId}/board/seq'" in fn
assert "document.visibilityState==='hidden'" in viewer
assert 'bbxV09PublicationPending' in rules and 'authorityBBXV09' in rules
assert 'authorityBBXV08' in rules['publicEvents']['$eventId']['.read']
assert 'authorityBBXV09' in rules['publicEvents']['$eventId']['.read']
assert rules['authorityBBXV08']=={'.read':False,'.write':False}
assert rules['authorityBBXV09']=={'.read':False,'.write':False}
assert 'ljtreg' not in fn+ui
assert ui.count('onValue(`events/${id}/raffleState`')==1
print('PASS prize raffle is distinct from roster redraw; short URL and private authority')
assert 'inFlightRestReads' in ui and 'inFlightPublicReads' in ui
assert 'await db.ref().update(rootWrites)' in fn
assert "db.ref(`events/${eventId}/authorityBBX`).get()" in fn
assert "db.ref(`events/${eventId}`).get()" not in fn[fn.index('async function publish('):fn.index('async function publishSafely(')]
print('PASS concurrent read coalescing and incremental projection scope')
