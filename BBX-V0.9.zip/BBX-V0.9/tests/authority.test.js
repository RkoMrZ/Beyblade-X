'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const Core=require('../functions/bbx-v09-core');
const uid='owner-1';let counter=0;const epoch=1792159000000;
const op=()=>epoch.toString(16).padStart(12,'0')+(++counter).toString(16).padStart(36,'0');
const m=(a,b)=>({a,b,sa:'',sb:'',winner:null,referee:'',refereeActive:false});
function board4(){return Core.bootstrap({id:'EVT001',ownerUid:uid,publicOpen:true,publicUntil:epoch+3600000,mode:'single',freeFinal:'champ',roster:['A','B','C','D'],rounds:[{name:'四強',matches:[m('A','B'),m('C','D')]},{name:'最終名次',placementFinal:true,matches:[m('待定','待定'),m('待定','待定')]}],finalRR:null});}
function cmd(board,action,target={kind:'round',ri:0,mi:0},data={},u=uid,permissions={owner:true}){
 return Core.apply(board,u,{opId:op(),action,target,expectedStructureVersion:0,expectedMatchVersion:target.kind==='rr'?board.finalRR.matches[target.mi].matchVersion:board.rounds[target.ri].matches[target.mi].matchVersion,referee:'裁判 1',...data},epoch,permissions);
}
function doCmd(board,action,target,data){return cmd(board,action,target,data).board;}
test('V1 bootstrap preserves original roster/rounds/UI data shape',()=>{
 const b=board4();assert.equal(b.rounds.length,2);assert.deepEqual(b.roster,['A','B','C','D']);assert.equal(b.rounds[0].matches[0].matchVersion,0);
});
test('Cloud scores only change corresponding match and version, not entire public bracket',()=>{
 let b=board4();b=doCmd(b,'claim');const r=cmd(b,'score',undefined,{sa:4,sb:1});
 assert.equal(r.board.rounds[0].matches[0].sa,4);assert.equal(r.board.rounds[0].matches[1].sa,'');
 assert.equal(r.changes.length,1);assert.deepEqual(r.changes.map(x=>x.path),['rounds/0/matches/0']);
 assert.deepEqual(Object.keys(r.changes[0].publicValue).sort(),['a','b','sa','sb','winner']);
});
test('Cloud completion advances winner and loser to original V1 championship + bronze matches',()=>{
 let b=board4();b=doCmd(b,'claim');b=doCmd(b,'score',undefined,{sa:4,sb:2});b=doCmd(b,'complete',undefined,{sa:4,sb:2});
 assert.equal(b.rounds[1].matches[0].a,'A');assert.equal(b.rounds[1].matches[1].a,'B');
 const target={kind:'round',ri:0,mi:1};b=doCmd(b,'claim',target);b=doCmd(b,'score',target,{sa:0,sb:4});
 const r=cmd(b,'complete',target,{sa:0,sb:4});b=r.board;
 assert.equal(b.rounds[1].matches[0].b,'D');assert.equal(b.rounds[1].matches[1].b,'C');
 assert.equal(r.changes.length,3);
});
test('Rejects old matchVersion instead of overwriting a newer result',()=>{
 const b=board4();const after=doCmd(b,'claim');
 assert.throws(()=>Core.apply(after,uid,{opId:op(),action:'score',target:{kind:'round',ri:0,mi:0},expectedStructureVersion:0,expectedMatchVersion:0,sa:4,sb:0,referee:'裁判 1'},epoch,{owner:true}),e=>e.code==='aborted');
});
test('Rejects double winner >=4 and incomplete under 4',()=>{
 let b=doCmd(board4(),'claim');
 assert.throws(()=>cmd(b,'score',undefined,{sa:4,sb:4}),e=>e.code==='invalid-argument');
 b=doCmd(b,'score',undefined,{sa:3,sb:2});
 assert.throws(()=>cmd(b,'complete',undefined,{sa:3,sb:2}),e=>e.code==='failed-precondition');
});
test('Retains server-side ownership: unclaimed user cannot score, unverified referee cannot claim',()=>{
 let b=board4();assert.throws(()=>cmd(b,'claim',undefined,{},'stranger',{referee:false}),e=>e.code==='permission-denied');
 assert.throws(()=>cmd(b,'claim',undefined,{},'ref-1',{referee:true,refereeName:'裁判 2'}),e=>e.code==='permission-denied');
 b=doCmd(b,'claim');assert.throws(()=>cmd(b,'score',undefined,{sa:2,sb:1},'ref-2',{referee:true,refereeName:'裁判 1'}),e=>e.code==='permission-denied');
});
test('Prevents completed match re-adjudication after downstream began',()=>{
 let b=board4();b=doCmd(b,'claim');b=doCmd(b,'score',undefined,{sa:4,sb:0});b=doCmd(b,'complete',undefined,{sa:4,sb:0});
 const target={kind:'round',ri:0,mi:1};b=doCmd(b,'claim',target);b=doCmd(b,'score',target,{sa:4,sb:0});b=doCmd(b,'complete',target,{sa:4,sb:0});
 b=doCmd(b,'claim',{kind:'round',ri:1,mi:0});
 b=doCmd(b,'score',{kind:'round',ri:1,mi:0},{sa:1,sb:0});
 b=doCmd(b,'claim',{kind:'round',ri:0,mi:0});b=doCmd(b,'score',undefined,{sa:0,sb:4});
 assert.throws(()=>cmd(b,'complete',undefined,{sa:0,sb:4}),e=>e.code==='failed-precondition');
});
test('Replayed operation id is idempotent and does not increment sequence',()=>{
 const b=board4(),id0=op();const req={opId:id0,action:'claim',target:{kind:'round',ri:0,mi:0},expectedStructureVersion:0,expectedMatchVersion:0,referee:'裁判 1'};
 const first=Core.apply(b,uid,req,epoch,{owner:true});
 const second=Core.apply(first.board,uid,req,epoch,{owner:true});
 assert.equal(second.replay,true);assert.equal(second.receipt.seq,first.result.seq);
});
test('RR3 qualifiers and resulting three-player rounds generated in cloud',()=>{
 const bb=Core.bootstrap({id:'EVT006',ownerUid:uid,publicOpen:true,publicUntil:epoch+3600000,mode:'free',freeFinal:'rr3',roster:['A','B','C','D','E','F'],rounds:[{name:'第一輪',matches:[m('A','B'),m('C','D'),m('E','F')]}],finalRR:null});
 let b=bb;
 for(let i=0;i<3;i++){
  let t={kind:'round',ri:0,mi:i};b=doCmd(b,'claim',t);b=doCmd(b,'score',t,{sa:4,sb:0});b=doCmd(b,'complete',t,{sa:4,sb:0});
 }
 assert.deepEqual(b.finalRR.players,['A','C','E']);
 assert.equal(b.finalRR.matches.length,3);assert.equal(b.rounds.length,1);
});
test('Receipt retention and expiry prevent replay after operation window',()=>{
 const b=board4();const request={opId:(epoch-3600000).toString(16).padStart(12,'0')+'a'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedStructureVersion:0,expectedMatchVersion:0,referee:'裁判 1'};
 assert.throws(()=>Core.apply(b,uid,request,epoch,{owner:true}),e=>e.code==='failed-precondition');
});
test('Revision to completed match is private until server confirms downstream change',()=>{
 let b=board4();b=doCmd(b,'claim');b=doCmd(b,'score',undefined,{sa:4,sb:2});b=doCmd(b,'complete',undefined,{sa:4,sb:2});
 b=doCmd(b,'claim');let r=cmd(b,'score',undefined,{sa:2,sb:4});b=r.board;
 assert.equal(b.rounds[0].matches[0].winner,'A');
 const published=r.changes.find(x=>x.path==='rounds/0/matches/0').publicValue;
 assert.equal(published.winner,'A');assert.equal(published.sa,4);assert.equal(published.sb,2);
 r=cmd(b,'complete',undefined,{sa:2,sb:4});
 assert.equal(r.board.rounds[0].matches[0].winner,'B');assert.equal(r.changes[0].publicValue.winner,'B');
});
test('Referee claim is private; public viewer is not notified when public match data is unchanged',()=>{
 const r=cmd(board4(),'claim');assert.equal(r.changes.length,1);assert.equal(r.changes[0].publicChanged,false);
});

test('complete cannot silently replace private score using a stale client payload',()=>{
 let b=board4();b=doCmd(b,'claim');b=doCmd(b,'score',undefined,{sa:0,sb:5});
 const original=JSON.stringify(b.rounds[0].matches[0]);
 assert.throws(()=>cmd(b,'complete',undefined,{sa:0,sb:4}),e=>e.code==='aborted');
 assert.equal(JSON.stringify(b.rounds[0].matches[0]),original);
 const result=cmd(b,'complete',undefined,{sa:0,sb:5});
 assert.equal(result.board.rounds[0].matches[0].winner,'B');
});
