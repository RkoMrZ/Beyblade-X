#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
P=ljt-beyblade-x
DB=ljt-beyblade-x-default-rtdb
[[ "$(basename "$PWD")" == BBX-V0.9 ]] || { echo 'STOP: wrong folder'; exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v09-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: tests and Emulator not passed for this release'; exit 3; }
gcloud auth print-access-token >/dev/null
[[ "$(gcloud config get-value project 2>/dev/null)" == "$P" ]] || { echo 'STOP: wrong project'; exit 3; }
[[ "$(python3 -c 'import json;print(json.load(open(".firebaserc"))["projects"]["default"])')" == "$P" ]] || { echo 'STOP: Firebase project mismatch'; exit 3; }
FN='functions:bbxV09CreateAuthority,functions:bbxV09CommandAuthority,functions:bbxV09GetOperation,functions:bbxV09RepairPublication,functions:bbxV09PublishAuthority,functions:bbxV09OrganizerAuthority,functions:bbxV09DeleteAuthority,functions:bbxV09RepairQueue,functions:bbxV09AssignPublicCode'
echo '=== Deploy V0.9 Functions ==='
firebase deploy --only "$FN" --project "$P" --non-interactive --force
python3 - <<'PY'
import subprocess,json
want=set(json.load(open('MANIFEST.json'))['functions_exports'])
a=json.loads(subprocess.check_output(['gcloud','functions','list','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=json'],text=True))
got={x['name'].split('/')[-1] for x in a}
assert want.issubset(got),f'Missing V0.9 functions: {sorted(want-got)}'
print('PASS: all 9 V0.9 Functions deployed')
PY
TOKEN="$(gcloud auth print-access-token)"
URL="https://${DB}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
curl -fLsS -H "Authorization: Bearer $TOKEN" "$URL" -o /tmp/bbx-v09-live-before-rules.json
python3 deploy/merge-rules.py /tmp/bbx-v09-live-before-rules.json database.deploy.rules.json
python3 - <<'PY'
import json
v=json.load(open('firebase.json'));v['database']['rules']='database.deploy.rules.json'
with open('firebase.deploy.json','w') as f:json.dump(v,f)
PY
echo '=== Deploy version-safe RTDB Rules ==='
firebase deploy --only database --config firebase.deploy.json --project "$P" --non-interactive
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS -H "Authorization: Bearer $TOKEN" "$URL" -o /tmp/bbx-v09-live-after-rules.json
python3 - <<'PY'
import json
def obj(file):
 x=json.load(open(file));return json.loads(x) if isinstance(x,str) else x
assert obj('database.deploy.rules.json')==obj('/tmp/bbx-v09-live-after-rules.json'),'Rules verification failed'
print('PASS: live V0.9 Rules verified')
PY
# Only after V0.9 Functions + Rules are verified, retire V0.8 equivalents.
python3 - <<'PY'
import json,subprocess
m=json.load(open('MANIFEST.json'))
old=m['previous_function_exports'];assert all(x.startswith('bbxV08') for x in old)
def funcs():
 a=json.loads(subprocess.check_output(['gcloud','functions','list','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=json'],text=True))
 return {x['name'].split('/')[-1] for x in a}
for name in old:
 if name in funcs():
  print('Retiring V0.8:',name,flush=True)
  subprocess.run(['gcloud','functions','delete',name,'--region=asia-southeast1','--project=ljt-beyblade-x','--quiet'],check=True)
now=funcs()
assert set(m['functions_exports']).issubset(now) and not(set(old)&now)
print('PASS: V0.9 functions present; V0.8 retired; other resources untouched')
PY
printf '\nPASS: BBX-V0.9 Functions (9) + Rules deployed and verified.\n'
