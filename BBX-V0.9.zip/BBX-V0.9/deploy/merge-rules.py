#!/usr/bin/env python3
"""Strict safe migration from original V1 or deployed V0.3 to BBX-V0.9."""
import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def load(p):
 x=json.loads(Path(p).read_text());return json.loads(x) if isinstance(x,str) else x
base=load(root/'baseline/rules.v1.json')['rules']
want=load(root/'database.rules.json')['rules']
# Previous test rules are copied as evidence, never deployed from that file.
prev=load(root/'docs/previous-v04-rules.json')['rules']
prev06=load(root/'docs/previous-v06-rules.json')['rules']
prev07=load(root/'docs/previous-v07-rules.json')['rules']
prev08=load(root/'docs/previous-v08-rules.json')['rules']
def atVersion(tree,path):
 value=tree
 for key in path:
  if not isinstance(value,dict) or key not in value:return SENT
  value=value[key]
 return value
old=load(sys.argv[1]);live=old['rules']
assert old['rules']['.read'] is False and old['rules']['.write'] is False
changes=[]
SENT=object()
def merge(key_path,initial,prior,target,current):
 if isinstance(target,dict) and (isinstance(initial,dict) or initial is SENT) and (isinstance(current,dict) or current is SENT):
  # if adding an entire new branch, the only permitted roots are explicitly enumerated
  if initial is SENT:
   assert '/'.join(key_path) in {'authorityBBXV06','bbxV06PublicationPending','authorityBBXV04','authorityBBXV05','bbxV05PublicationPending','authorityBBXV07','bbxV07PublicationPending','authorityBBXV08','bbxV08PublicationPending','authorityBBXV09','bbxV09PublicationPending','authorityBBX','events/$eventId/authorityBBX','bbxPublicCodeLookup','bbxPublicCodeReservations','bbxEventCleanupRegistry'},'unapproved branch '+str(key_path)
   if current is SENT:changes.append('/'.join(key_path));return target
   if current!=target:raise ValueError('Existing branch differs: '+str(key_path))
   return current
  result=dict(current) if isinstance(current,dict) else {}
  for k,v in target.items():
   i=initial.get(k,SENT)
   p=prior.get(k,SENT) if isinstance(prior,dict) else SENT
   c=current.get(k,SENT) if isinstance(current,dict) else SENT
   result[k]=merge(key_path+[k],i,p,v,c)
  return result
 if initial==target:return current if current is not SENT else target
 # only the BBX-specific .write rules and authority nodes can change
 name='/'.join(key_path)
 if name not in {'events/$eventId/.write','publicEvents/$eventId/.write','publicEvents/$eventId/.read'} and not (name.startswith(('events/$eventId/','publicEvents/$eventId/')) and name.endswith('/.write')):
  raise ValueError('unexpected rule patch: '+name)
 if current not in (initial,prior,atVersion(prev06,key_path),atVersion(prev07,key_path),atVersion(prev08,key_path),target):raise ValueError('online Rules are customized: '+name)
 changes.append(name);return target
output={**old,'rules':merge([],base,prev,want,live)}
assert output['rules']['.read'] is False and output['rules']['.write'] is False
Path(sys.argv[2]).write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print('PASS: preserved all unrelated rules; BBX patch changes:',len(changes))
