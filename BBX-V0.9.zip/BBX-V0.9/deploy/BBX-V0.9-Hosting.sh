#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.9 ]] || { echo 'STOP: wrong version folder';exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v09-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight missing';exit 3; }
P=ljt-beyblade-x
SITE=bbxs-tamsui
gcloud auth print-access-token >/dev/null
firebase hosting:sites:get "$SITE" --project "$P" >/dev/null
mkdir -p hosting-public/assets
cp -f index.html viewer.html hosting-public/
cp -f assets/index-v09.css assets/index-v09.js assets/viewer-v09.css assets/viewer-v09.js hosting-public/assets/
test -s hosting-public/index.html && test -s hosting-public/viewer.html
firebase deploy --only hosting --config firebase.hosting.json --project "$P" --non-interactive
# Hosting's CDN may take a brief moment to serve the new revision.
for attempt in 1 2 3 4 5; do
 if curl --fail --location --silent --show-error --max-time 12 "https://${SITE}.web.app/" | grep -q 'index-v09'; then
  echo 'PASS: Hosting homepage serves V0.9';break
 fi
 if [ "$attempt" -eq 5 ];then echo 'STOP: CDN homepage did not verify V0.9';exit 4;fi
 sleep 3
done
printf '\nPASS: V0.9 Homepage + /v/5-character viewer deployed on %s.web.app\n' "$SITE"
