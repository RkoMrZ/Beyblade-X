#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
# Cloud Shell is already in tmux, no nested tmux/screen.
exec bash 01_release.sh
