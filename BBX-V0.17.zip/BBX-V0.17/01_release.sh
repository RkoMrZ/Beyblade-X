#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.17 deployment is already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.17 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.17 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/BBX-V0.17-檢查.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v017-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
gcloud auth print-access-token >/dev/null
# Hosting ONLY: auto16 server logic, Rules and ALL Cloud Functions unchanged.
bash deploy/BBX-V0.17-Hosting.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.17 Hosting ONLY deployed and verified; Functions, Rules and saved events untouched.\n'
