'use strict';
// BBX V0.5 per-event command authority; isolated asynchronous public projection.
const admin=require('firebase-admin');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onValueWritten}=require('firebase-functions/v2/database');
const {onSchedule}=require('firebase-functions/v2/scheduler');
const P=require('./bbx-v05-publication');
const C=require('./bbx-v05-core');
const O=require('./bbx-v05-organizer');
const D=require('./bbx-v05-cleanup');
const L=require('./bbx-v05-lifecycle');
const PROJECT='ljt-beyblade-x';
const DB_URL='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app';
const VERSION='bbx-v0.5-authority-1';
const PENDING='bbxV05PublicationPending';
const REGISTRY='bbxEventCleanupRegistry';
const CODE_RESERVATIONS='bbxPublicCodeReservations';
const CODE_LOOKUP='bbxPublicCodeLookup';
admin.initializeApp({projectId:PROJECT,databaseURL:DB_URL});
const db=admin.database();
const OPT={region:'asia-southeast1',timeoutSeconds:60,maxInstances:12,concurrency:20};
const ID=/^[A-Za-z0-9_-]{6,100}$/;
const id=x=>{if(!ID.test(x||''))throw new HttpsError('invalid-argument','賽事代碼格式錯誤');return x};
function auth(req,google=false){
 if(req.data?.clientVersion!==VERSION)throw new HttpsError('failed-precondition','舊版網頁無法修改此賽事，請更新網頁');
 if(!req.auth?.uid)throw new HttpsError('unauthenticated','請先登入');
 if(google&&req.auth.token?.firebase?.sign_in_provider!=='google.com')throw new HttpsError('permission-denied','主辦需 Google 身分');
 return req.auth.uid;
}
function catchError(e){
 if(e instanceof HttpsError)throw e;
 if(e instanceof C.CommandError)throw new HttpsError(e.code,e.message);
 console.error('V1 authority error',e);
 throw new HttpsError('internal','伺服器尚未確認結果；請使用相同操作代碼查詢，不要重複點擊');
}
const base=eventId=>`authorityBBXV05/${eventId}`;
// RTDB transaction callbacks can receive null on a cold SDK cache even when the
// server node exists. Warm the same SDK reference with an actual value listener
// BEFORE a read-modify-write transaction. Never insert an assumed client snapshot.
async function compareAndSwap(ref,change){
 await ref.once('value');
 return ref.transaction(change,undefined,false);
}

// The command lock protects authoritative board writes ONLY. A separate
// publication lease owns the idempotent public projection. Neither job takes
// the other's lock, so a slow viewer projection cannot block a referee action.
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function takeLease(path,token,durationMs=75000,attempts=1){
 for(let attempt=0;attempt<attempts;attempt++){
  const now=Date.now();
  const res=await compareAndSwap(path,cur=>
   !cur||Number(cur.expiresAt||cur.until||0)<now?
    {token,expiresAt:now+durationMs}:undefined);
  if(res.committed)return true;
  if(attempt+1<attempts)await sleep(Math.min(450,90+attempt*40));
 }
 return false;
}
async function releaseLease(path,token){
 try{await compareAndSwap(path,cur=>cur?.token===token?null:undefined)}
 catch(e){console.error('BBX lease release failed',path.toString(),e)}
}
async function withCommandLock(eventId,task){
 const lock=db.ref(`${base(eventId)}/operationLock`);
 const token=crypto.randomBytes(12).toString('hex');
 if(!await takeLease(lock,token,75000,18))
  throw new HttpsError('resource-exhausted','賽事資料正在更新，請等待短暫同步');
 try{return await task()}finally{await releaseLease(lock,token)}
}
// Publication lease never grabs operationLock. Its 75s TTL exceeds the 60s
// function timeout, preventing a second publisher from overtaking a slow first.
async function withPublishLease(eventId,task,{attempts=1}={}){
 const lock=db.ref(`${base(eventId)}/publishing`);
 const token=crypto.randomBytes(12).toString('hex');
 if(!await takeLease(lock,token,75000,attempts))return {busy:true};
 try{return await task({token,lock})}
 finally{await releaseLease(lock,token)}
}
function changedLeaves(before,after){
 const writes={};
 const walk=(a,b,path)=>{
  if(JSON.stringify(a)===JSON.stringify(b))return;
  if(path&&(a==null||b==null||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b)||
      (Array.isArray(a)&&a.length!==b.length))){writes[path]=b===undefined?null:b;return;}
  if(a==null||b==null||typeof a!=='object'||typeof b!=='object')throw Error('invalid board diff');
  const keys=new Set([...Object.keys(a),...Object.keys(b)]);
  for(const key of keys)walk(a[key],b[key],path?`${path}/${key}`:key);
 };
 walk(before,after,'');return writes;
}
// Optimistic preparation: expensive board reads, bracket propagation and diff
// calculation happen before taking the EXISTING per-event command lock.
// The lock covers only a cheap seq check and one atomic multipath commit.
// Other matches may prepare in parallel, but common advancement/outbox state
// remains serializable. Stale preparations are NEVER committed.
const STALE_BOARD=Symbol('BBX_V05_STALE_BOARD');
function prepareMutation(original,operation){
 const result=operation(original);
 if(result.replay)return {immediate:{...result.receipt,replayed:true}};
 if(result.unchanged)return {immediate:{...result,ok:true},verifySeq:true,expectedSeq:Number(original.seq||0)};
 const writes=changedLeaves(original,result.board);
 if(!Object.keys(writes).length)throw new HttpsError('internal','此次操作沒有產生可確認的資料變更');
 return {result,writes,expectedSeq:Number(original.seq||0)};
}
async function commitMutation(eventId,prepared){
 const rootWrites={};
 for(const [key,value] of Object.entries(prepared.writes))
  rootWrites[`${base(eventId)}/board/${key}`]=value;
 rootWrites[`events/${eventId}/authoritySeq`]=prepared.result.board.seq;
 if(Number.isInteger(prepared.writes.structureVersion))
  rootWrites[`events/${eventId}/structureVersion`]=prepared.result.board.structureVersion;
 // Repair index and outbox are committed in the SAME atomic RTDB update.
 rootWrites[`${PENDING}/${eventId}`]={seq:prepared.result.board.seq,updatedAt:Date.now()};
 // Security-sensitive viewer revocation is committed with authority, not later
 // by the asynchronous public projector.
 if(typeof prepared.writes.publicOpen==='boolean'||typeof prepared.writes.publicUntil==='number'){
  // Publish access gate directly as part of the authority commit. This covers
  // BOTH open and close; delayed outbox jobs never publish stale gate values.
  rootWrites[`events/${eventId}/publicOpen`]=prepared.result.board.publicOpen===true;
  rootWrites[`publicEvents/${eventId}/meta/publicOpen`]=prepared.result.board.publicOpen===true;
  rootWrites[`events/${eventId}/publicUntil`]=Number(prepared.result.board.publicUntil)||0;
  rootWrites[`publicEvents/${eventId}/meta/publicUntil`]=Number(prepared.result.board.publicUntil)||0;
 }
 await db.ref().update(rootWrites);
 return prepared.result.result;
}
async function applyToPrivateBoard(eventId,operation){
 const ref=db.ref(`${base(eventId)}/board`);
 // Two speculative attempts keep independent-match calculations off the lock.
 // Under sustained contention, fall back to the original serialized reducer
 // rather than failing six judges just because their snapshots changed.
 for(let attempt=0;attempt<2;attempt++){
  const original=(await ref.get()).val();
  if(!original||original.deleted===true)throw new HttpsError('not-found','賽事權威狀態不存在或已刪除');
  const prepared=prepareMutation(original,operation);
  if(prepared.immediate&&!prepared.verifySeq)return prepared.immediate;
  const committed=await withCommandLock(eventId,async()=>{
   const currentSeq=Number((await ref.child('seq').get()).val()||0);
   if(currentSeq!==prepared.expectedSeq)return STALE_BOARD;
   if(prepared.immediate)return prepared.immediate;
   // The only writer of the authoritative board is this command lock.
   // No other command can commit between this check and the multipath update.
   return commitMutation(eventId,prepared);
  });
  if(committed!==STALE_BOARD)return committed;
  // Release mutex BEFORE another full read/recalculation.
  await sleep(25+attempt*35);
 }
 return withCommandLock(eventId,async()=>{
  // Safety fallback on heavy contention: same correctness as V0.5's original
  // serialized path, without a new lock or cross-match partial commit.
  const latest=(await ref.get()).val();
  if(!latest||latest.deleted===true)throw new HttpsError('not-found','賽事權威狀態不存在或已刪除');
  const prepared=prepareMutation(latest,operation);
  return prepared.immediate||commitMutation(eventId,prepared);
 });
}

function projectGuard(){
 const project=process.env.GCLOUD_PROJECT||process.env.GCP_PROJECT||JSON.parse(process.env.FIREBASE_CONFIG||'{}').projectId;
 if(project!==PROJECT)throw new HttpsError('failed-precondition','Firebase 專案不符');
}
async function authz(uid,eventId){
 const [e,claims,ref,adminFlag]=await Promise.all([
   db.ref(`events/${eventId}/ownerUid`).get(),
   db.ref(`refereeClaims/${eventId}`).get(),
   db.ref(`refereeUsers/${eventId}/${uid}`).get(),
   db.ref(`admins/${eventId}/${uid}`).get()
 ]);
 const owner=e.val()===uid;
 let refereeName=null;
 if(ref.exists())for(const x of Object.values(claims.val()||{}))if(x?.uid===uid){refereeName=String(x.name||'');break;}
 return {owner,admin:adminFlag.exists(),referee:ref.exists()&&!!refereeName,refereeName};
}
async function markRepairComplete(eventId,cursor){
 const hint=db.ref(`${PENDING}/${eventId}`);
 // Never clear a newer command's repair hint based on an earlier projection.
 await compareAndSwap(hint,cur=>cur&&Number(cur.seq)<=cursor?null:undefined);
}
async function publish(eventId){
 return withPublishLease(eventId,async({token,lock})=>{
  const ref=db.ref(base(eventId));
  const started=Date.now();
  let cursor=Number((await ref.child('publishedSeq').get()).val()||0);
  for(let batch=0;batch<16;batch++){
   if(Date.now()-started>18000)break;
   const gate=(await db.ref(`events/${eventId}`).get()).val();
   if(!gate||gate.authorityBBX!=='active'||gate.releaseTag!=='BBX-V0.5'||
      (await ref.child('board/deleted').get()).val()===true)return {disabled:true,publishedSeq:cursor};
   const next=cursor+1;
   const item=(await ref.child(`board/outbox/${String(next).padStart(12,'0')}`).get()).val();
   if(!item){
    const latest=Number((await ref.child('board/seq').get()).val()||0);
    if(next<=latest)throw Error(`BBX_PUBLICATION_GAP event=${eventId} missing=${next} latest=${latest}`);
    break;
   }
   const patch=P.buildProjectionPatch(eventId,item,gate);
   const lease=(await lock.get()).val();
   if(lease?.token!==token||Number(lease.expiresAt)<=Date.now())
    throw Error(`BBX_PUBLICATION_LEASE_LOST event=${eventId}`);
   // Persist projection first. Replaying it is safe; cursor advances only on success.
   await db.ref().update(patch);
   await ref.update({publishedSeq:next,[`board/outbox/${String(next).padStart(12,'0')}`]:null});
   cursor=next;
  }
  const latest=Number((await ref.child('board/seq').get()).val()||0);
  if(cursor>=latest)await markRepairComplete(eventId,cursor);
  return {ok:true,publishedSeq:cursor,pending:cursor<latest};
 });
}
async function publishSafely(eventId,source){
 try{
  const result=await publish(eventId);
  if(result.busy||result.pending){
   console.warn(JSON.stringify({type:'BBX_PUBLICATION_PENDING',eventId,source,...result}));
  }
  return result;
 }catch(error){
  console.error(JSON.stringify({type:'BBX_PUBLICATION_FAILURE',eventId,source,
   message:error?.message||String(error),stack:String(error?.stack||'').slice(0,1600)}));
  throw error;
 }
}

// BBX-V0.5: one single authoritative CREATE operation, not stage + activate.
// The client sends configuration ONLY. Server constructs the bracket and index.
// All authoritative nodes become visible in the SAME atomic RTDB multipath update.
const crypto=require('node:crypto');
const CREATE_OP=/^[a-f0-9]{48}$/;
const cleanName=s=>typeof s==='string'?s.trim():'';
const publicMatch=m=>C.sanitizedMatch(m);
function projectPublic(ev){
 return {meta:{id:ev.id,name:ev.name,publicCode:ev.publicCode||null,mode:ev.mode,pairing:ev.pairing,
    freeFinal:ev.freeFinal,roster:ev.roster,created:ev.created,cloudVersion:5,
    syncVersion:ev.syncVersion,publicOpen:ev.publicOpen,publicUntil:ev.publicUntil},
    rounds:ev.rounds.map(r=>({name:r.name,...(r.placementFinal?{placementFinal:true}:{}),matches:(r.matches||[]).map(publicMatch)})),
    finalRR:ev.finalRR?{players:ev.finalRR.players,matches:ev.finalRR.matches.map(publicMatch)}:null};
}
function validateCreate(d){
 const name=cleanName(d.name)||'Beyblade X Tournament';
 if(name.length>100)throw new HttpsError('invalid-argument','賽事名稱過長');
 if(!Array.isArray(d.roster)||d.roster.length<2||d.roster.length>64)throw new HttpsError('invalid-argument','選手人數須介於2至64');
 const roster=d.roster.map(x=>cleanName(x));
 if(roster.some(x=>!x||x.length>60||x==='BYE'||x==='待定'||/[\u0000-\u001f]/.test(x))||new Set(roster).size!==roster.length)
   throw new HttpsError('invalid-argument','選手名稱不可為空、重複或保留字');
 if(!['free','single'].includes(d.mode)||!['ordered','random','manual'].includes(d.pairing)||!['champ','rr3'].includes(d.freeFinal))
   throw new HttpsError('invalid-argument','賽制參數無效');
 if(d.mode==='free'&&d.freeFinal==='rr3'){
   let n=roster.length;while(n>3)n=Math.ceil(n/2);
   if(n!==3)throw new HttpsError('invalid-argument','人數無法自然晉級至三人循環');
 }
 return {name,roster,mode:d.mode,pairing:d.pairing,freeFinal:d.freeFinal};
}
// One-time alias allocation. Reservation is a server transaction, not a judge mutex.
// Permanent code reservations prevent accidentally re-using an old shared link.
async function allocatePublicCode(uid,eventId){
 for(let i=0;i<80;i++){
  const code=L.shortCode(uid,eventId,i);
  const ref=db.ref(`${CODE_RESERVATIONS}/${code}`);
  const claimed=await compareAndSwap(ref,cur=>!cur?{eventId,state:'reserved',reservedAt:Date.now()}:undefined);
  if(claimed.committed)return code;
  const existing=(await ref.get()).val();
  if(existing?.eventId===eventId)return code; // idempotent replay
 }
 throw new HttpsError('resource-exhausted','五碼活動 ID 暫時無法配置，請稍後重試');
}
async function registerEventAlias(uid,eventId,ev,slot){
 const code=ev.publicCode||await allocatePublicCode(uid,eventId);
 // Imported historical code must also be reserved before publishing its alias.
 const owned=await compareAndSwap(db.ref(`${CODE_RESERVATIONS}/${code}`),cur=>
   !cur?{eventId,state:'reserved',reservedAt:Date.now()}:undefined);
 if(!owned.committed){
   const prev=(await db.ref(`${CODE_RESERVATIONS}/${code}`).get()).val();
   if(prev?.eventId!==eventId)throw new HttpsError('already-exists','五碼活動 ID 已被其他賽事預留');
 }
 const seen=(await Promise.all(D.EVENT_ROOTS.map(async root=>({root,exists:(await db.ref(`${root}/${eventId}`).get()).exists()}))));
 const record=L.registry({eventId,ownerUid:uid,originVersion:ev.releaseTag,code,slot,createdAt:ev.created,
   actualRoots:seen.filter(x=>x.exists).map(x=>x.root)});
 const registryRef=db.ref(`${REGISTRY}/${eventId}`);
 const old=(await registryRef.get()).val();
 const updated=L.mergeRegistered(old,record);
 if(ev.publicCode&&ev.publicCode!==code)throw Error('event alias changed during update');
 // Public projection and alias become visible atomically; existing internal IDs remain intact.
 const updates={
  [`events/${eventId}/publicCode`]:code,
  [`publicEvents/${eventId}/meta/publicCode`]:code,
  [`${CODE_LOOKUP}/${code}`]:eventId,
  [`${REGISTRY}/${eventId}`]:updated,
  [`${CODE_RESERVATIONS}/${code}/state`]:'active'
 };
 await db.ref().update(updates);
 return code;
}

exports.bbxV05CreateAuthority=onCall(OPT,async req=>{
 let lockHeld=false,lockPath=null,token=null;
 try{
  projectGuard(); const uid=auth(req,true), opId=req.data?.opId;
  if(!CREATE_OP.test(opId||''))throw new HttpsError('invalid-argument','建立操作代碼無效');
  const d=validateCreate(req.data), now=Date.now();
  const eventId='B5_'+crypto.createHash('sha256').update(uid+':'+opId).digest('hex').slice(0,26);
  const eventRef=db.ref(`events/${eventId}`);
  const lifecycleState=(await db.ref(`${REGISTRY}/${eventId}/status`).get()).val();
  if(lifecycleState==='deleted'||lifecycleState==='deleting')
    throw new HttpsError('failed-precondition','此建立操作曾被刪除或正在清理，不得用舊操作代碼重建');
  const existing=(await eventRef.get()).val();
  if(existing){
    if(existing.ownerUid===uid&&existing.releaseTag==='BBX-V0.5'&&existing.authorityBBX==='active'){
      const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
      const slot=Object.keys(slots).find(k=>slots[k]===eventId);
      return {ok:true,eventId,slot,publicCode:existing.publicCode||null,existing:true};
    }
    throw new HttpsError('already-exists','代碼已建立但狀態不完整，請聯絡管理者');
  }
  token=crypto.randomBytes(12).toString('hex');lockPath=db.ref(`bbxV05CreateLocks/${uid}`);
  const claim=await compareAndSwap(lockPath,cur=>!cur||Number(cur.until)<Date.now()?{token,until:Date.now()+90000}:undefined);
  if(!claim.committed)throw new HttpsError('resource-exhausted','此帳號正在建立另一場賽事，請稍候');
  lockHeld=true;
  // Re-check inside account lock, including idempotent retries.
  const innerState=(await db.ref(`${REGISTRY}/${eventId}/status`).get()).val();
  if(innerState==='deleted'||innerState==='deleting')
    throw new HttpsError('failed-precondition','此賽事的永久清理紀錄禁止重新建立');
  const again=(await eventRef.get()).val();
  if(again?.authorityBBX==='active'&&again.ownerUid===uid){
    const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
    return {ok:true,eventId,slot:Object.keys(slots).find(k=>slots[k]===eventId),publicCode:again.publicCode||null,existing:true};
  }
  const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
  // A previously failed test release may leave an owner slot without its event.
  // Only reclaim truly missing events; never remove an existing V1 or V0.x event.
  let free;
  for(const k of ['0','1','2']){
    if(!slots[k]){free=k;break;}
    const referenced=await db.ref(`events/${String(slots[k])}`).get();
    if(!referenced.exists()){free=k;break;}
  }
  if(free===undefined)throw new HttpsError('resource-exhausted','雲端賽事已達三場上限');
  const built=O.build(d.roster,d.mode,d.freeFinal),adminCode=String(crypto.randomInt(100000,1000000));
  const publicCode=await allocatePublicCode(uid,eventId);
  const lifecycle=L.registry({eventId,ownerUid:uid,originVersion:'BBX-V0.5',code:publicCode,slot:free,createdAt:now,actualRoots:['events','publicEvents','authorityBBXV05','secrets','admins']});
  const ev={id:eventId,ownerUid:uid,created:now,testOnly:false,releaseTag:'BBX-V0.5',
    authorityBBX:'active',authoritySeq:0,structureVersion:0,cloudVersion:5,syncVersion:now,publicCode,
    ...d,rounds:built.rounds,finalRR:built.finalRR,refereeCount:1,
    refereeNames:['裁判 1'],publicOpen:true,publicUntil:now+4*3600000,
    raffleState:null};
  const board=C.bootstrap(ev);
  const updates={
    [`events/${eventId}`]:ev,
    [`publicEvents/${eventId}`]:projectPublic(ev),
    [`authorityBBXV05/${eventId}/board`]:board,
    [`authorityBBXV05/${eventId}/publishedSeq`]:0,
    [`userEvents/${uid}/${free}`]:eventId,
    [`secrets/${eventId}`]:{adminCode,expiresAt:now+60000},
    [`admins/${eventId}/${uid}`]:adminCode,
    [`${REGISTRY}/${eventId}`]:lifecycle,
    [`${CODE_LOOKUP}/${publicCode}`]:eventId,
    [`${CODE_RESERVATIONS}/${publicCode}/state`]:'active'
  };
  await db.ref().update(updates);  // one atomic server commit across all nodes
  return {ok:true,eventId,slot:free,publicCode,created:true};
 }catch(e){catchError(e)}
 finally{
  if(lockHeld&&lockPath){try{await compareAndSwap(lockPath,cur=>cur?.token===token?null:undefined)}catch(e){console.error('create lock release failure',e)}}
 }
});

// Owner-initiated ONE-TIME alias/registry backfill for pre-existing V0.x events.
// Never changes releaseTag or the old internal ID. Does not delete any data.
exports.bbxV05AssignPublicCode=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const task=async()=>{
   const ev=(await db.ref(`events/${eventId}`).get()).val();
   if(!ev||ev.ownerUid!==uid||!D.DELETE_VERSIONS.includes(ev.releaseTag))
    throw new HttpsError('permission-denied','只能替自己的已知版本賽事建立五碼活動 ID');
   if(ev.publicCode){
    const reg=(await db.ref(`${REGISTRY}/${eventId}`).get()).val();
    if(reg?.status==='active'&&reg?.publicCode===ev.publicCode)return {ok:true,eventId,publicCode:ev.publicCode,existing:true};
   }
   const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
   const slot=Object.keys(slots).find(k=>slots[k]===eventId);
   return {ok:true,eventId,publicCode:await registerEventAlias(uid,eventId,ev,slot),created:true};
  };
  const version=(await db.ref(`events/${eventId}/releaseTag`).get()).val();
  if(version==='BBX-V0.5')return await withCommandLock(eventId,task);
  if(version==='BBX-V0.4')return await withLegacyV04DeletionLocks(eventId,task);
  return await withCommandLock(eventId,task); // Existing command mutex also serializes legacy lifecycle actions.
 }catch(e){catchError(e)}
});

exports.bbxV05CommandAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('failed-precondition','尚未切換為雲端權威版本');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin&&!permission.referee)throw new HttpsError('permission-denied','未取得主辦或裁判授權');
  const result=await applyToPrivateBoard(eventId,cur=>C.apply(cur,uid,req.data,Date.now(),permission));
  if(result.replayed)return result;
  // Commit is definitive; a concurrent projector may still be catching up.
  // Successful return means authoritative board + outbox committed atomically.
  // Background publisher runs independently; never block judge/organizer on SSE.
  return {...result,published:false,publicationPending:true};
 }catch(e){catchError(e)}
});
exports.bbxV05GetOperation=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId),opId=req.data?.opId;
  if((await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('failed-precondition','只能查詢 V0.5 操作');
  if(req.data?.readMatch===true){
   const p=await authz(uid,eventId);
   if(!p.owner&&!p.admin&&!p.referee)throw new HttpsError('permission-denied','無權查詢權威比分');
   const t=req.data.target||{};
   if(!['round','rr'].includes(t.kind)||!Number.isInteger(t.mi)||t.mi<0||t.mi>127||
      (t.kind==='round'&&(!Number.isInteger(t.ri)||t.ri<0||t.ri>20)))
    throw new HttpsError('invalid-argument','場次索引不正確');
   const matchPath=t.kind==='rr'?`finalRR/matches/${t.mi}`:`rounds/${t.ri}/matches/${t.mi}`;
   const snap=await db.ref(`${base(eventId)}/board/${matchPath}`).get();
   if(!snap.exists())throw new HttpsError('not-found','雲端沒有這場比賽');
   const m=snap.val();
   return {found:true,match:{a:m.a,b:m.b,sa:m.sa??'',sb:m.sb??'',
    winner:m.winner||null,referee:m.referee||'',refereeActive:m.refereeActive===true,
    matchVersion:Number(m.matchVersion)||0}};
  }
  if(typeof opId!=='string'||!/^[a-f0-9]{48}$/.test(opId))throw new HttpsError('invalid-argument','操作代碼無效');
  const r=(await db.ref(`${base(eventId)}/board/receipts/${opId}`).get()).val();
  if(!r)return {found:false};
  if(r.uid!==uid)throw new HttpsError('permission-denied','不能讀取別人的操作結果');
  return {found:true,...r.result};
 }catch(e){catchError(e)}
});
exports.bbxV05RepairPublication=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const owner=(await db.ref(`events/${eventId}/ownerUid`).get()).val();
  if(owner!==uid||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('permission-denied','只有 V0.5 主辦能要求修復');
  return publishSafely(eventId,'manual-repair');
 }catch(e){catchError(e)}
});
// The RTDB change is only a fast wake-up signal. The outbox repair hint persists
// independently, so a malformed or failed event cannot generate seven days of
// repeated billed retries. Scheduled recovery handles missed notifications.
exports.bbxV05PublishAuthority=onValueWritten({ref:'authorityBBXV05/{eventId}/board/seq',
 region:'asia-southeast1',instance:'ljt-beyblade-x-default-rtdb',retry:false},async e=>{
 projectGuard();if(!e.data.after.exists())return;
 const n=id(e.params.eventId);
 try{await publishSafely(n,'board-seq-trigger')}
 catch(e){ /* already logged; pending index persists for repair */ }
});
// One lightweight indexed scan for ALL events every five minutes, not a scan
// of every event board and not an always-connected worker.
exports.bbxV05RepairQueue=onSchedule({schedule:'every 5 minutes',
 region:'asia-southeast1',timeoutSeconds:120,maxInstances:1},async()=>{
 projectGuard();
 const hints=(await db.ref(PENDING).orderByChild('updatedAt').limitToFirst(20).get()).val()||{};
 for(const [eventId,seen] of Object.entries(hints)){
  if(!ID.test(eventId))continue;
  try{
   const result=await publishSafely(eventId,'scheduled-repair');
   if(result.disabled){
    // Ignore deleted / old releases: remove only the same hint, never a newer one.
    await compareAndSwap(db.ref(`${PENDING}/${eventId}`),cur=>
     cur&&Number(cur.seq)<=Number(seen.seq)?null:undefined);
   }
  }catch(e){
   // Move a repeatedly failing event to the back of the recovery queue.
   await compareAndSwap(db.ref(`${PENDING}/${eventId}`),cur=>
    cur&&Number(cur.seq)===Number(seen.seq)?{...cur,updatedAt:Date.now()}:undefined);
  }
 }
});

// Organizer mutations use the same atomic event authority as match commands.
// Never accepts a client-provided roster, rounds, or complete event snapshot.
exports.bbxV05OrganizerAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('failed-precondition','尚未啟用雲端權威');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin)throw new HttpsError('permission-denied','需要主辦權限');
  if(req.data?.action==='setReferees') {
   const claims=(await db.ref(`refereeClaims/${eventId}`).get()).val()||{};
   if(Object.values(claims).some(Boolean))throw new HttpsError('failed-precondition','仍有已領取的裁判身分，請先釋放全部裁判再修改名單');
  }
  const result=await applyToPrivateBoard(eventId,cur=>O.apply(cur,uid,req.data,Date.now(),permission));
  if(result.replayed||result.unchanged)return result;
  // Commit is definitive; a concurrent projector may still be catching up.
  // Successful return means authoritative board + outbox committed atomically.
  // Background publisher runs independently; never block judge/organizer on SSE.
  return {...result,published:false,publicationPending:true};
 }catch(e){catchError(e)}
});


// Legacy V0.1-V0.3 used authorityBBX without an event mutex. Those retired
// releases can be safely deleted once their old functions have been removed.
// V0.4 uses both original lock paths; V0.5 uses its own split leases.
async function withLegacyV04DeletionLocks(eventId,task){
 const root=db.ref(`authorityBBXV04/${eventId}`);
 const operationLock=root.child('operationLock');
 const token=crypto.randomBytes(12).toString('hex');
 if(!await takeLease(operationLock,token,75000,18))
  throw new HttpsError('resource-exhausted','舊賽事操作鎖尚未到期，請稍後重試刪除');
 try{
  const publishLock=root.child('publishing');
  const publishToken=crypto.randomBytes(12).toString('hex');
  if(!await takeLease(publishLock,publishToken,75000,18))
   throw new HttpsError('resource-exhausted','舊賽事發布鎖尚未到期，請稍後重試刪除');
  try{return await task()}
  finally{await releaseLease(publishLock,publishToken)}
 }finally{await releaseLease(operationLock,token)}
}


exports.bbxV05DeleteAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const ev=(await db.ref(`events/${eventId}`).get()).val();
  const deleting=(await db.ref(`${REGISTRY}/${eventId}`).get()).val();
  if(!ev&&deleting?.status==='deleting'&&deleting?.ownerUid===uid&&D.DELETE_VERSIONS.includes(deleting.originVersion)){
   // A previous attempt may have atomically removed the main event but failed
   // while verifying/archiving. The server-owned registry proves ownership.
   const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
   const paths=L.deletionPaths(deleting,eventId,uid,slots);
   if(deleting.publicCode){
    const target=(await db.ref(`${CODE_LOOKUP}/${deleting.publicCode}`).get()).val();
    if(target!==null&&target!==eventId)throw new HttpsError('failed-precondition','活動代碼已改指其他賽事，停止恢復');
   }
   await db.ref().update(Object.fromEntries(paths.map(x=>[x,null])));
   const remaining=await D.verifyCleanup(db,paths);
   if(remaining.length)throw new HttpsError('internal','續刪仍有殘留，未標記完成');
   await db.ref(`${REGISTRY}/${eventId}`).update({status:'deleted',deletedAt:Date.now(),verified:true});
   if(deleting.publicCode)await db.ref(`${CODE_RESERVATIONS}/${deleting.publicCode}`).update({state:'deleted',eventId:null,deletedAt:Date.now()});
   return {ok:true,deleted:true,verified:true,recovered:true};
  }
  const version=ev?.releaseTag;
  if(!ev||ev.ownerUid!==uid||!D.DELETE_VERSIONS.includes(version))
   throw new HttpsError('permission-denied','只允許 Google 建立者刪除自己建立的 BBX 測試版賽事');
  if(['BBX-V0.4','BBX-V0.5'].includes(version)&&ev.authorityBBX!=='active')
   throw new HttpsError('failed-precondition','雲端權威尚未啟用，停止刪除');

  const remove=async authorityRoot=>{
   // Re-validate the owner and version WITHIN the appropriate event locks.
   // No V1.0 tournament, unrelated account, or other event can be removed.
   const again=(await db.ref(`events/${eventId}`).get()).val();
   if(!again||again.ownerUid!==uid||again.releaseTag!==version||
      (['BBX-V0.4','BBX-V0.5'].includes(version)&&again.authorityBBX!=='active'))
    throw new HttpsError('failed-precondition','建立者或賽事版本已變更，停止刪除');
   const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
   const registryRef=db.ref(`${REGISTRY}/${eventId}`);
   const prior=(await registryRef.get()).val();
   // Pre-registry events remain deletable using the complete historical structure inventory.
   // They are *adopted* into the permanent registry only after owner confirmation.
   const code=prior?.publicCode||again.publicCode||null;
   if(prior?.publicCode&&again.publicCode&&prior.publicCode!==again.publicCode)
    throw new HttpsError('failed-precondition','五碼活動 ID 與永久登記不一致，停止刪除');
   const synthetic=L.registry({eventId,ownerUid:uid,originVersion:version,code,
     slot:Object.keys(slots).find(k=>slots[k]===eventId),createdAt:again.created,actualRoots:['events',authorityRoot]});
   let record,paths;
   try{
    record=L.mergeRegistered(prior,synthetic);
    paths=L.deletionPaths(record,eventId,uid,slots);
   }catch(e){throw new HttpsError('failed-precondition','永久清理資料登記不一致，已停止刪除：'+e.message)}
   // Verify alias belongs to THIS immutable event before deleting alias mapping.
   if(code){
    const lookup=(await db.ref(`${CODE_LOOKUP}/${code}`).get()).val();
    if(lookup!==null&&lookup!==eventId)throw new HttpsError('failed-precondition','五碼已指向另一賽事，停止刪除');
   }
   await registryRef.set({...record,status:'deleting',deleteRequestedAt:Date.now()});
   // Fence off in-flight writers BEFORE dropping any event-specific namespace.
   const boardRef=db.ref(`${authorityRoot}/${eventId}/board`);
   if((await boardRef.get()).exists())await boardRef.child('deleted').set(true);
   const updates=Object.fromEntries(paths.map(p=>[p,null]));
   await db.ref().update(updates);
   const residual=await D.verifyCleanup(db,paths);
   if(residual.length){
    console.error('BBX_V05_DELETE_RESIDUAL',eventId,residual);
    throw new HttpsError('internal','賽事刪除後仍有資料殘留；請停止重建並回報管理員');
   }
   // Keep only a small tombstone/audit index; none of the tournament's actual
   // board, roster, permissions, tokens or projection records remain.
   await registryRef.set({...record,status:'deleted',deletedAt:Date.now(),verified:true});
   if(code)await db.ref(`${CODE_RESERVATIONS}/${code}`).update({state:'deleted',eventId:null,deletedAt:Date.now()});
   console.info('BBX_V05_DELETE_VERIFIED',version,eventId,'paths',paths.length);
   return {ok:true};
  };

  if(version==='BBX-V0.4'){
   // Use the two ORIGINAL V0.4 lock paths, not V0.5 lock paths;
   // an expired old lease can be safely reclaimed by token-checked CAS.
   await withLegacyV04DeletionLocks(eventId,()=>remove('authorityBBXV04'));
  }else if(version==='BBX-V0.5'){
   await withCommandLock(eventId,async()=>{
    const result=await withPublishLease(eventId,async()=>remove('authorityBBXV05'),{attempts:18});
    if(result.busy)throw new HttpsError('resource-exhausted','公開資料發布中，暫時無法刪除賽事，請稍候重試');
   });
  }else{
   await withCommandLock(eventId,()=>remove('authorityBBX')); // Re-use command lock for legacy lifecycle actions.
  }
  return {ok:true,deleted:true,verified:true};
 }catch(e){catchError(e)}
});
