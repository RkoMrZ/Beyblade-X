'use strict';
// BBX V0.5 per-event command authority; isolated asynchronous public projection.
const admin=require('firebase-admin');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onValueWritten}=require('firebase-functions/v2/database');
const {onSchedule}=require('firebase-functions/v2/scheduler');
const P=require('./bbx-v05-publication');
const C=require('./bbx-v05-core');
const O=require('./bbx-v05-organizer');
const PROJECT='ljt-beyblade-x';
const DB_URL='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app';
const VERSION='bbx-v0.5-authority-1';
const PENDING='bbxV05PublicationPending';
admin.initializeApp({projectId:PROJECT,databaseURL:DB_URL});
const db=admin.database();
const OPT={region:'asia-southeast1',timeoutSeconds:60,maxInstances:12,concurrency:20};
const ID=/^[A-Za-z0-9_-]{6,100}$/;
const id=x=>{if(!ID.test(x||''))throw new HttpsError('invalid-argument','賽事代碼格式錯誤');return x};
function auth(req,google=false){
 if(req.data?.clientVersion!==VERSION)throw new HttpsError('failed-precondition','舊版網頁無法修改此賽事，請更新網頁');
 if(!req.auth?.uid)throw new HttpsError('unauthenticated','請先登入');
 if(google&&req.auth.token?.firebase?.sign_in_provider!=='google.com')throw new HttpsError('permission-denied','主辦需 Google 身分');
 return req.auth.uid;
}
function catchError(e){
 if(e instanceof HttpsError)throw e;
 if(e instanceof C.CommandError)throw new HttpsError(e.code,e.message);
 console.error('V1 authority error',e);
 throw new HttpsError('internal','伺服器尚未確認結果；請使用相同操作代碼查詢，不要重複點擊');
}
const base=eventId=>`authorityBBXV05/${eventId}`;
// RTDB transaction callbacks can receive null on a cold SDK cache even when the
// server node exists. Warm the same SDK reference with an actual value listener
// BEFORE a read-modify-write transaction. Never insert an assumed client snapshot.
async function compareAndSwap(ref,change){
 await ref.once('value');
 return ref.transaction(change,undefined,false);
}

// The command lock protects authoritative board writes ONLY. A separate
// publication lease owns the idempotent public projection. Neither job takes
// the other's lock, so a slow viewer projection cannot block a referee action.
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function takeLease(path,token,durationMs=75000,attempts=1){
 for(let attempt=0;attempt<attempts;attempt++){
  const now=Date.now();
  const res=await compareAndSwap(path,cur=>
   !cur||Number(cur.expiresAt||cur.until||0)<now?
    {token,expiresAt:now+durationMs}:undefined);
  if(res.committed)return true;
  if(attempt+1<attempts)await sleep(Math.min(450,90+attempt*40));
 }
 return false;
}
async function releaseLease(path,token){
 try{await compareAndSwap(path,cur=>cur?.token===token?null:undefined)}
 catch(e){console.error('BBX lease release failed',path.toString(),e)}
}
async function withCommandLock(eventId,task){
 const lock=db.ref(`${base(eventId)}/operationLock`);
 const token=crypto.randomBytes(12).toString('hex');
 if(!await takeLease(lock,token,75000,18))
  throw new HttpsError('resource-exhausted','賽事資料正在更新，請等待短暫同步');
 try{return await task()}finally{await releaseLease(lock,token)}
}
// Publication lease never grabs operationLock. Its 75s TTL exceeds the 60s
// function timeout, preventing a second publisher from overtaking a slow first.
async function withPublishLease(eventId,task,{attempts=1}={}){
 const lock=db.ref(`${base(eventId)}/publishing`);
 const token=crypto.randomBytes(12).toString('hex');
 if(!await takeLease(lock,token,75000,attempts))return {busy:true};
 try{return await task({token,lock})}
 finally{await releaseLease(lock,token)}
}
function changedLeaves(before,after){
 const writes={};
 const walk=(a,b,path)=>{
  if(JSON.stringify(a)===JSON.stringify(b))return;
  if(path&&(a==null||b==null||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b)||
      (Array.isArray(a)&&a.length!==b.length))){writes[path]=b===undefined?null:b;return;}
  if(a==null||b==null||typeof a!=='object'||typeof b!=='object')throw Error('invalid board diff');
  const keys=new Set([...Object.keys(a),...Object.keys(b)]);
  for(const key of keys)walk(a[key],b[key],path?`${path}/${key}`:key);
 };
 walk(before,after,'');return writes;
}
// Optimistic preparation: expensive board reads, bracket propagation and diff
// calculation happen before taking the EXISTING per-event command lock.
// The lock covers only a cheap seq check and one atomic multipath commit.
// Other matches may prepare in parallel, but common advancement/outbox state
// remains serializable. Stale preparations are NEVER committed.
const STALE_BOARD=Symbol('BBX_V05_STALE_BOARD');
function prepareMutation(original,operation){
 const result=operation(original);
 if(result.replay)return {immediate:{...result.receipt,replayed:true}};
 if(result.unchanged)return {immediate:{...result,ok:true},verifySeq:true,expectedSeq:Number(original.seq||0)};
 const writes=changedLeaves(original,result.board);
 if(!Object.keys(writes).length)throw new HttpsError('internal','此次操作沒有產生可確認的資料變更');
 return {result,writes,expectedSeq:Number(original.seq||0)};
}
async function commitMutation(eventId,prepared){
 const rootWrites={};
 for(const [key,value] of Object.entries(prepared.writes))
  rootWrites[`${base(eventId)}/board/${key}`]=value;
 rootWrites[`events/${eventId}/authoritySeq`]=prepared.result.board.seq;
 if(Number.isInteger(prepared.writes.structureVersion))
  rootWrites[`events/${eventId}/structureVersion`]=prepared.result.board.structureVersion;
 // Repair index and outbox are committed in the SAME atomic RTDB update.
 rootWrites[`${PENDING}/${eventId}`]={seq:prepared.result.board.seq,updatedAt:Date.now()};
 // Security-sensitive viewer revocation is committed with authority, not later
 // by the asynchronous public projector.
 if(typeof prepared.writes.publicOpen==='boolean'||typeof prepared.writes.publicUntil==='number'){
  // Publish access gate directly as part of the authority commit. This covers
  // BOTH open and close; delayed outbox jobs never publish stale gate values.
  rootWrites[`events/${eventId}/publicOpen`]=prepared.result.board.publicOpen===true;
  rootWrites[`publicEvents/${eventId}/meta/publicOpen`]=prepared.result.board.publicOpen===true;
  rootWrites[`events/${eventId}/publicUntil`]=Number(prepared.result.board.publicUntil)||0;
  rootWrites[`publicEvents/${eventId}/meta/publicUntil`]=Number(prepared.result.board.publicUntil)||0;
 }
 await db.ref().update(rootWrites);
 return prepared.result.result;
}
async function applyToPrivateBoard(eventId,operation){
 const ref=db.ref(`${base(eventId)}/board`);
 // Two speculative attempts keep independent-match calculations off the lock.
 // Under sustained contention, fall back to the original serialized reducer
 // rather than failing six judges just because their snapshots changed.
 for(let attempt=0;attempt<2;attempt++){
  const original=(await ref.get()).val();
  if(!original||original.deleted===true)throw new HttpsError('not-found','賽事權威狀態不存在或已刪除');
  const prepared=prepareMutation(original,operation);
  if(prepared.immediate&&!prepared.verifySeq)return prepared.immediate;
  const committed=await withCommandLock(eventId,async()=>{
   const currentSeq=Number((await ref.child('seq').get()).val()||0);
   if(currentSeq!==prepared.expectedSeq)return STALE_BOARD;
   if(prepared.immediate)return prepared.immediate;
   // The only writer of the authoritative board is this command lock.
   // No other command can commit between this check and the multipath update.
   return commitMutation(eventId,prepared);
  });
  if(committed!==STALE_BOARD)return committed;
  // Release mutex BEFORE another full read/recalculation.
  await sleep(25+attempt*35);
 }
 return withCommandLock(eventId,async()=>{
  // Safety fallback on heavy contention: same correctness as V0.5's original
  // serialized path, without a new lock or cross-match partial commit.
  const latest=(await ref.get()).val();
  if(!latest||latest.deleted===true)throw new HttpsError('not-found','賽事權威狀態不存在或已刪除');
  const prepared=prepareMutation(latest,operation);
  return prepared.immediate||commitMutation(eventId,prepared);
 });
}

function projectGuard(){
 const project=process.env.GCLOUD_PROJECT||process.env.GCP_PROJECT||JSON.parse(process.env.FIREBASE_CONFIG||'{}').projectId;
 if(project!==PROJECT)throw new HttpsError('failed-precondition','Firebase 專案不符');
}
async function authz(uid,eventId){
 const [e,claims,ref,adminFlag]=await Promise.all([
   db.ref(`events/${eventId}/ownerUid`).get(),
   db.ref(`refereeClaims/${eventId}`).get(),
   db.ref(`refereeUsers/${eventId}/${uid}`).get(),
   db.ref(`admins/${eventId}/${uid}`).get()
 ]);
 const owner=e.val()===uid;
 let refereeName=null;
 if(ref.exists())for(const x of Object.values(claims.val()||{}))if(x?.uid===uid){refereeName=String(x.name||'');break;}
 return {owner,admin:adminFlag.exists(),referee:ref.exists()&&!!refereeName,refereeName};
}
async function markRepairComplete(eventId,cursor){
 const hint=db.ref(`${PENDING}/${eventId}`);
 // Never clear a newer command's repair hint based on an earlier projection.
 await compareAndSwap(hint,cur=>cur&&Number(cur.seq)<=cursor?null:undefined);
}
async function publish(eventId){
 return withPublishLease(eventId,async({token,lock})=>{
  const ref=db.ref(base(eventId));
  const started=Date.now();
  let cursor=Number((await ref.child('publishedSeq').get()).val()||0);
  for(let batch=0;batch<16;batch++){
   if(Date.now()-started>18000)break;
   const gate=(await db.ref(`events/${eventId}`).get()).val();
   if(!gate||gate.authorityBBX!=='active'||gate.releaseTag!=='BBX-V0.5'||
      (await ref.child('board/deleted').get()).val()===true)return {disabled:true,publishedSeq:cursor};
   const next=cursor+1;
   const item=(await ref.child(`board/outbox/${String(next).padStart(12,'0')}`).get()).val();
   if(!item){
    const latest=Number((await ref.child('board/seq').get()).val()||0);
    if(next<=latest)throw Error(`BBX_PUBLICATION_GAP event=${eventId} missing=${next} latest=${latest}`);
    break;
   }
   const patch=P.buildProjectionPatch(eventId,item,gate);
   const lease=(await lock.get()).val();
   if(lease?.token!==token||Number(lease.expiresAt)<=Date.now())
    throw Error(`BBX_PUBLICATION_LEASE_LOST event=${eventId}`);
   // Persist projection first. Replaying it is safe; cursor advances only on success.
   await db.ref().update(patch);
   await ref.update({publishedSeq:next,[`board/outbox/${String(next).padStart(12,'0')}`]:null});
   cursor=next;
  }
  const latest=Number((await ref.child('board/seq').get()).val()||0);
  if(cursor>=latest)await markRepairComplete(eventId,cursor);
  return {ok:true,publishedSeq:cursor,pending:cursor<latest};
 });
}
async function publishSafely(eventId,source){
 try{
  const result=await publish(eventId);
  if(result.busy||result.pending){
   console.warn(JSON.stringify({type:'BBX_PUBLICATION_PENDING',eventId,source,...result}));
  }
  return result;
 }catch(error){
  console.error(JSON.stringify({type:'BBX_PUBLICATION_FAILURE',eventId,source,
   message:error?.message||String(error),stack:String(error?.stack||'').slice(0,1600)}));
  throw error;
 }
}

// BBX-V0.5: one single authoritative CREATE operation, not stage + activate.
// The client sends configuration ONLY. Server constructs the bracket and index.
// All authoritative nodes become visible in the SAME atomic RTDB multipath update.
const crypto=require('node:crypto');
const CREATE_OP=/^[a-f0-9]{48}$/;
const cleanName=s=>typeof s==='string'?s.trim():'';
const publicMatch=m=>C.sanitizedMatch(m);
function projectPublic(ev){
 return {meta:{id:ev.id,name:ev.name,mode:ev.mode,pairing:ev.pairing,
    freeFinal:ev.freeFinal,roster:ev.roster,created:ev.created,cloudVersion:5,
    syncVersion:ev.syncVersion,publicOpen:ev.publicOpen,publicUntil:ev.publicUntil},
    rounds:ev.rounds.map(r=>({name:r.name,...(r.placementFinal?{placementFinal:true}:{}),matches:(r.matches||[]).map(publicMatch)})),
    finalRR:ev.finalRR?{players:ev.finalRR.players,matches:ev.finalRR.matches.map(publicMatch)}:null};
}
function validateCreate(d){
 const name=cleanName(d.name)||'Beyblade X Tournament';
 if(name.length>100)throw new HttpsError('invalid-argument','賽事名稱過長');
 if(!Array.isArray(d.roster)||d.roster.length<2||d.roster.length>64)throw new HttpsError('invalid-argument','選手人數須介於2至64');
 const roster=d.roster.map(x=>cleanName(x));
 if(roster.some(x=>!x||x.length>60||x==='BYE'||x==='待定'||/[\u0000-\u001f]/.test(x))||new Set(roster).size!==roster.length)
   throw new HttpsError('invalid-argument','選手名稱不可為空、重複或保留字');
 if(!['free','single'].includes(d.mode)||!['ordered','random','manual'].includes(d.pairing)||!['champ','rr3'].includes(d.freeFinal))
   throw new HttpsError('invalid-argument','賽制參數無效');
 if(d.mode==='free'&&d.freeFinal==='rr3'){
   let n=roster.length;while(n>3)n=Math.ceil(n/2);
   if(n!==3)throw new HttpsError('invalid-argument','人數無法自然晉級至三人循環');
 }
 return {name,roster,mode:d.mode,pairing:d.pairing,freeFinal:d.freeFinal};
}
exports.bbxV05CreateAuthority=onCall(OPT,async req=>{
 let lockHeld=false,lockPath=null,token=null;
 try{
  projectGuard(); const uid=auth(req,true), opId=req.data?.opId;
  if(!CREATE_OP.test(opId||''))throw new HttpsError('invalid-argument','建立操作代碼無效');
  const d=validateCreate(req.data), now=Date.now();
  const eventId='B5_'+crypto.createHash('sha256').update(uid+':'+opId).digest('hex').slice(0,26);
  const eventRef=db.ref(`events/${eventId}`);
  const existing=(await eventRef.get()).val();
  if(existing){
    if(existing.ownerUid===uid&&existing.releaseTag==='BBX-V0.5'&&existing.authorityBBX==='active'){
      const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
      const slot=Object.keys(slots).find(k=>slots[k]===eventId);
      return {ok:true,eventId,slot,existing:true};
    }
    throw new HttpsError('already-exists','代碼已建立但狀態不完整，請聯絡管理者');
  }
  token=crypto.randomBytes(12).toString('hex');lockPath=db.ref(`bbxV05CreateLocks/${uid}`);
  const claim=await compareAndSwap(lockPath,cur=>!cur||Number(cur.until)<Date.now()?{token,until:Date.now()+90000}:undefined);
  if(!claim.committed)throw new HttpsError('resource-exhausted','此帳號正在建立另一場賽事，請稍候');
  lockHeld=true;
  // Re-check inside account lock, including idempotent retries.
  const again=(await eventRef.get()).val();
  if(again?.authorityBBX==='active'&&again.ownerUid===uid){
    const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
    return {ok:true,eventId,slot:Object.keys(slots).find(k=>slots[k]===eventId),existing:true};
  }
  const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
  // A previously failed test release may leave an owner slot without its event.
  // Only reclaim truly missing events; never remove an existing V1 or V0.x event.
  let free;
  for(const k of ['0','1','2']){
    if(!slots[k]){free=k;break;}
    const referenced=await db.ref(`events/${String(slots[k])}`).get();
    if(!referenced.exists()){free=k;break;}
  }
  if(free===undefined)throw new HttpsError('resource-exhausted','雲端賽事已達三場上限');
  const built=O.build(d.roster,d.mode,d.freeFinal),adminCode=String(crypto.randomInt(100000,1000000));
  const ev={id:eventId,ownerUid:uid,created:now,testOnly:false,releaseTag:'BBX-V0.5',
    authorityBBX:'active',authoritySeq:0,structureVersion:0,cloudVersion:5,syncVersion:now,
    ...d,rounds:built.rounds,finalRR:built.finalRR,refereeCount:1,
    refereeNames:['裁判 1'],publicOpen:true,publicUntil:now+4*3600000,
    raffleState:null};
  const board=C.bootstrap(ev);
  const updates={
    [`events/${eventId}`]:ev,
    [`publicEvents/${eventId}`]:projectPublic(ev),
    [`authorityBBXV05/${eventId}/board`]:board,
    [`authorityBBXV05/${eventId}/publishedSeq`]:0,
    [`userEvents/${uid}/${free}`]:eventId,
    [`secrets/${eventId}`]:{adminCode,expiresAt:now+60000},
    [`admins/${eventId}/${uid}`]:adminCode
  };
  await db.ref().update(updates);  // one atomic server commit across all nodes
  return {ok:true,eventId,slot:free,created:true};
 }catch(e){catchError(e)}
 finally{
  if(lockHeld&&lockPath){try{await compareAndSwap(lockPath,cur=>cur?.token===token?null:undefined)}catch(e){console.error('create lock release failure',e)}}
 }
});

exports.bbxV05CommandAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('failed-precondition','尚未切換為雲端權威版本');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin&&!permission.referee)throw new HttpsError('permission-denied','未取得主辦或裁判授權');
  const result=await applyToPrivateBoard(eventId,cur=>C.apply(cur,uid,req.data,Date.now(),permission));
  if(result.replayed)return result;
  // Commit is definitive; a concurrent projector may still be catching up.
  // Successful return means authoritative board + outbox committed atomically.
  // Background publisher runs independently; never block judge/organizer on SSE.
  return {...result,published:false,publicationPending:true};
 }catch(e){catchError(e)}
});
exports.bbxV05GetOperation=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId),opId=req.data?.opId;
  if(typeof opId!=='string'||!/^[a-f0-9]{48}$/.test(opId))throw new HttpsError('invalid-argument','操作代碼無效');
  if((await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('failed-precondition','只能查詢 V0.5 操作');
  const r=(await db.ref(`${base(eventId)}/board/receipts/${opId}`).get()).val();
  if(!r)return {found:false};
  if(r.uid!==uid)throw new HttpsError('permission-denied','不能讀取別人的操作結果');
  return {found:true,...r.result};
 }catch(e){catchError(e)}
});
exports.bbxV05RepairPublication=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const owner=(await db.ref(`events/${eventId}/ownerUid`).get()).val();
  if(owner!==uid||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('permission-denied','只有 V0.5 主辦能要求修復');
  return publishSafely(eventId,'manual-repair');
 }catch(e){catchError(e)}
});
// The RTDB change is only a fast wake-up signal. The outbox repair hint persists
// independently, so a malformed or failed event cannot generate seven days of
// repeated billed retries. Scheduled recovery handles missed notifications.
exports.bbxV05PublishAuthority=onValueWritten({ref:'authorityBBXV05/{eventId}/board/seq',
 region:'asia-southeast1',instance:'ljt-beyblade-x-default-rtdb',retry:false},async e=>{
 projectGuard();if(!e.data.after.exists())return;
 const n=id(e.params.eventId);
 try{await publishSafely(n,'board-seq-trigger')}
 catch(e){ /* already logged; pending index persists for repair */ }
});
// One lightweight indexed scan for ALL events every five minutes, not a scan
// of every event board and not an always-connected worker.
exports.bbxV05RepairQueue=onSchedule({schedule:'every 5 minutes',
 region:'asia-southeast1',timeoutSeconds:120,maxInstances:1},async()=>{
 projectGuard();
 const hints=(await db.ref(PENDING).orderByChild('updatedAt').limitToFirst(20).get()).val()||{};
 for(const [eventId,seen] of Object.entries(hints)){
  if(!ID.test(eventId))continue;
  try{
   const result=await publishSafely(eventId,'scheduled-repair');
   if(result.disabled){
    // Ignore deleted / old releases: remove only the same hint, never a newer one.
    await compareAndSwap(db.ref(`${PENDING}/${eventId}`),cur=>
     cur&&Number(cur.seq)<=Number(seen.seq)?null:undefined);
   }
  }catch(e){
   // Move a repeatedly failing event to the back of the recovery queue.
   await compareAndSwap(db.ref(`${PENDING}/${eventId}`),cur=>
    cur&&Number(cur.seq)===Number(seen.seq)?{...cur,updatedAt:Date.now()}:undefined);
  }
 }
});

// Organizer mutations use the same atomic event authority as match commands.
// Never accepts a client-provided roster, rounds, or complete event snapshot.
exports.bbxV05OrganizerAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active'||(await db.ref(`events/${eventId}/releaseTag`).get()).val()!=='BBX-V0.5')throw new HttpsError('failed-precondition','尚未啟用雲端權威');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin)throw new HttpsError('permission-denied','需要主辦權限');
  if(req.data?.action==='setReferees') {
   const claims=(await db.ref(`refereeClaims/${eventId}`).get()).val()||{};
   if(Object.values(claims).some(Boolean))throw new HttpsError('failed-precondition','仍有已領取的裁判身分，請先釋放全部裁判再修改名單');
  }
  const result=await applyToPrivateBoard(eventId,cur=>O.apply(cur,uid,req.data,Date.now(),permission));
  if(result.replayed||result.unchanged)return result;
  // Commit is definitive; a concurrent projector may still be catching up.
  // Successful return means authoritative board + outbox committed atomically.
  // Background publisher runs independently; never block judge/organizer on SSE.
  return {...result,published:false,publicationPending:true};
 }catch(e){catchError(e)}
});


// Delete is scoped to a single verified, active BBX test tournament.
// In-flight operations see the tombstone and will not recreate removed data.
exports.bbxV05DeleteAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const ev=(await db.ref(`events/${eventId}`).get()).val();
  if(!ev||ev.ownerUid!==uid||ev.releaseTag!=='BBX-V0.5')
   throw new HttpsError('permission-denied','只允許建立者刪除本測試版的賽事');
  if(ev.authorityBBX !== 'active')
   throw new HttpsError('failed-precondition','尚未啟用的測試賽事只允許執行失敗後清理');
  await withCommandLock(eventId,async()=>{
    // Destructive operation must also own publisher lease, preventing an
    // in-flight projector from recreating deleted public/private branches.
    const removal=await withPublishLease(eventId,async()=>{
      const boardRef=db.ref(`${base(eventId)}/board`);
      await boardRef.child('deleted').set(true);
      const slots=(await db.ref(`userEvents/${uid}`).get()).val()||{};
      const updates={};
      for(const path of ['events','publicEvents','refereeClaims','refereeUsers','refereeSecrets','secrets','admins','authorityBBXV05','bbxV05PublicationPending'])
        updates[`${path}/${eventId}`]=null;
      for(const [slot,value] of Object.entries(slots))if(value===eventId)updates[`userEvents/${uid}/${slot}`]=null;
      await db.ref().update(updates);
      return {ok:true};
    },{attempts:18});
    if(removal.busy)throw new HttpsError('resource-exhausted','公開資料發布中，暫時無法刪除賽事，請稍候重試');
  });
  return {ok:true,deleted:true};
 }catch(e){catchError(e)}
});
