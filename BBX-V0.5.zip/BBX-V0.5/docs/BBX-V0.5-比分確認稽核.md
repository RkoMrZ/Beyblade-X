# BBX-V0.5 單場比分確認稽核

## 問題證據

- 先前使用者提供 2026-10-17 17:08 UTC 附近的 `bbxv05commandauthority` 連續 429（約 6 秒），接續 409；與 75 秒操作鎖或前序 stale version 競爭相符，**沒有同時間的詳細 token/租約日誌，不能唯一斷定鎖釋放失敗**。
- 目前畫面 0:6 卻提示「上一筆比分沒有確認成功」；與 `index.html` 的 `v05DrainScores` 設定 `state.lastError`，`v05FlushScores` 拒絕 `complete` 精確對應。此畫面數值先在手機本地更新，不能視為雲端確認。
- `index.html` 原版 `v1FinishCloud` 不會在 `lastError` 留存時讀取雲端權威值，所以 HTTP 429 已解除也可能被前端錯誤狀態攔住，造成無法完成。

## 本次修正（不改寫權威後端）

1. 連續快速加分沿用單場佇列與操作 ID；不增加未確認的重試。
2. 按「此場完成」設單場 single-flight，凍結此場編輯，等待送分中的 HTTP/收據處理結束。
3. 不論之前分數回應是否失敗，**只讀這一場** `bbxV05GetOperation(readMatch:true)` 權威資料，確認選手、比分、`matchVersion`。
4. 手機畫面與雲端不相符：顯示兩組分數、將畫面還原為雲端、禁止晉級。只有裁判再次明確確認後才可能重新提交。
5. 相符：取得權威 `matchVersion` 並向既有 `bbxV05CommandAuthority` 提交 `complete`。後端再比對已保存比分、版本、裁判權與晉級；其他人先更改則提交拒絕。
6. 權威已產生 winner：直接視為已完成，不再重送完成指令。
7. 讀取私有比分失敗：絕不晉級，也不盲目把本機數字發送雲端。

## 對應官方文件

- Firebase RTDB `transaction` 與 `committed`：https://firebase.google.com/docs/reference/js/database
- Firebase RTDB 多路徑 `update()` 原子性：https://firebase.google.com/docs/database/web/read-and-write
- Cloud Functions callable 錯誤回報：https://firebase.google.com/docs/functions/callable

## 稽核結果及剩餘限制

- Node 專案本地測試 103 項成功；前端 JavaScript 語法及靜態檢查成功。
- 沒有取得線上私人賽事資料、操作鎖節點與最新 Function 完整日誌，因此**沒有實證證明所有 429 已排除**。
- 尚未實際通過 Firebase Database Emulator、iPhone 斷線/重連、六位裁判併發或 200 位觀眾的線上負載驗收。
- 此次 `functions/index.js` 沒有新增修改；上一回操作鎖修補是否實際部署須由線上日誌確認。
- 下一階段先以一場 4 人或 8 人測試賽事驗收一次真實記分/晉級；問題再發生時檢查 `BBX_COMMAND_LOCK_BUSY` 與 `BBX_LEASE_RELEASE_*`，不主動刪除線上鎖或資料。
