# BBX-V0.5：Cloud Functions 裁判操作鎖修復（待實機驗收）

## 依據
在 2026-10-17 17:08:03 UTC 有 200，隨後 17:08:05–17:08:37 UTC 有四筆耗時約 6 秒的 429，於 17:09:23 UTC 出現 409。時間順序符合曾有操作鎖殘留直到 75 秒租約到期的假說，但日誌尚不能唯一證明釋放失敗為根因。

## 修正
- releaseLease 先檢查 RTDB transaction 的 committed 欄位；遇到 aborted CAS 時讀取目前鎖，只有自己的 token 仍持有才有限次重試，絕不刪掉新持有者的鎖。
- 每次 retry、釋放未確認、鎖遭他人接手時有明確日志代碼；節點 token 不寫入日志。
- 命令操作鎖的 429 僅於衝突時額外讀取鎖並記錄 leasePresent、expiresInMs，排查下一次鎖究竟是持有中或已逾期。
- 未縮短 75 秒的租約期限，未移除防競爭機制，無資料庫、Rules、觀眾端、UI 改動。

## 測試
- Node 測試：98/98 通過，其中 5 項新增釋放鎖的中止重試／非本人 token／已釋放／有限重試／暫時錯誤驗證。
- node --check functions/index.js 通過。
- 未以線上 Realtime Database 實際測試；不可視為線上修復已驗收。

## 部署範圍
僅需部署 functions:bbxV05CommandAuthority，其他函數雖共用 functions/index.js 但未部署的不會自動更新。若需其他使用 releaseLease 的函數也具備相同行為，應視測試結果再挑選更新；不建議直接全量更新。
