# BBX-V0.5 Cloud Create Registry-Key Hotfix

**Problem observed in live Cloud Function logs (2026-10-17 16:54 UTC):**
`update failed: values argument contains an invalid key (BBX-V0.5) in property bbxEventCleanupRegistry.<eventId>.releases`.

**Root cause:** Realtime Database forbids `. # $ / [ ]` in object property names; `registry()` used the human-readable release string as the key of `releases`. One atomic create update was rejected, so the event was not committed; the client received `functions/internal`. A subsequent overlapping attempt hit the per-user create lock, returning `functions/resource-exhausted`.

**Fix:** `functions/bbx-v05-lifecycle.js` keeps `originVersion: 'BBX-V0.5'` as a value, but stores release map keys as `BBX-V0_5`. Legacy release map keys are normalized when merging, and key validation has been added to the lifecycle and create-integration tests.

**Not changed:** `index.html`, `viewer.html`, rules, other function behavior, project identity, deleting any online data, or other Firebase projects.

**Validation:** 93 Node tests passed, HTML static checks passed, rules merge checks passed in local sandbox. This does not replace a live create test.

**Deployment:** Only the Functions importing the lifecycle helper need redeploy: bbxV05CreateAuthority, bbxV05AssignPublicCode, bbxV05DeleteAuthority. Keep all other deployed functions and RTDB rules unchanged. Then run one unique create operation and confirm the owner index and cleanup registry. A previously abandoned `bbxPublicCodeReservations` record might remain from the failed first attempt; do a separately authorized, read-only audit before any cleanup, and never delete blindly.
