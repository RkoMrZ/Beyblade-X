'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../functions/index.js'),'utf8');
const start=source.indexOf('async function releaseLease(path,token){');
const end=source.indexOf('\nasync function withCommandLock',start);
assert.ok(start!==-1 && end!==-1,'production releaseLease found');
const code=source.slice(start,end);
function createHarness(cas,read){
 const warns=[],errors=[],sleeps=[];
 const log={warn:(...args)=>warns.push(args),error:(...args)=>errors.push(args)};
 const sleep=async(ms)=>sleeps.push(ms);
 const release=Function('compareAndSwap','sleep','console',`return (${code})`)(cas,sleep,log);
 return {release,path:{toString:()=>'/lock',get:async()=>({val:()=>read()})},warns,errors,sleeps};
}
test('a non-committed release retries when our token still owns the lock',async()=>{
 let current={token:'ours',expiresAt:99999},attempt=0;
 const h=createHarness(async(_ref,change)=>{
  attempt++;
  if(attempt===1)return {committed:false};
  current=change(current);
  return {committed:true};
 },()=>current);
 assert.equal(await h.release(h.path,'ours'),true);
 assert.equal(attempt,2);
 assert.equal(current,null);
 assert.equal(h.sleeps.length,1);
 assert.ok(h.warns.some(x=>x[0]==='BBX_LEASE_RELEASE_RETRY'));
});
test('never removes the lease if it belongs to another token',async()=>{
 const current={token:'successor'};
 const h=createHarness(async()=>({committed:false}),()=>current);
 assert.equal(await h.release(h.path,'ours'),false);
 assert.equal(current.token,'successor');
 assert.equal(h.sleeps.length,0);
});
test('accepts a lease already cleared after an aborted release transaction',async()=>{
 const h=createHarness(async()=>({committed:false}),()=>null);
 assert.equal(await h.release(h.path,'ours'),true);
 assert.equal(h.sleeps.length,0);
});
test('logs unconfirmed releases after bounded retries',async()=>{
 const h=createHarness(async()=>({committed:false}),()=>({token:'ours'}));
 assert.equal(await h.release(h.path,'ours'),false);
 assert.equal(h.sleeps.length,3);
 assert.ok(h.errors.some(x=>x[0]==='BBX_LEASE_RELEASE_UNCONFIRMED'));
});
test('recovers after a transient SDK exception',async()=>{
 let attempts=0;
 const h=createHarness(async(_ref,change)=>{
  if(++attempts===1)throw new Error('transient');
  return {committed:true};
 },()=>({token:'ours'}));
 assert.equal(await h.release(h.path,'ours'),true);
 assert.equal(attempts,2);
});
