'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync(require('node:path').join(__dirname,'../index.html'),'utf8');
const start=html.indexOf('async function v1FinishCloud(');
const end=html.indexOf('async function v1CloudOrganizerCommand(',start);
assert.ok(start>0&&end>start);
const src=html.slice(start,end)+'\nglobalThis.finishCloud=v1FinishCloud;';
function setup({display=[0,6],server=[0,6],error=null,winner=null,delay=0,failRead=false}={}){
 const m={a:'A',b:'B',sa:display[0],sb:display[1],refereeActive:true,matchVersion:3};
 const event={id:'B5_test_match',releaseTag:'BBX-V0.5',authorityBBX:'active',rounds:[{matches:[m]}]};
 const alerts=[],commands=[],changes=[],calls=[];
 let inFlightRead=0;
 const state={version:3,lastError:error?new Error(error):null,desired:null,confirmed:null};
 const key=(eventId,kind,ri,mi)=>`${eventId}:${kind}:${ri}:${mi}`;
 const scope={Map,Set,Error,Number,console,ev:event,alert:s=>alerts.push(s),
  v05FinishInFlight:new Set(),v05ScoreKey:key,
  isV1Authority:()=>true,
  v1Match:()=>m,
  v05ScoreState:()=>state,
  v05FlushScores:async()=>{calls.push('flush'); if(error)throw Error(error);},
  v05ReadAuthoritativeMatch:async()=>{calls.push('read');inFlightRead++;if(delay)await new Promise(r=>setTimeout(r,delay));inFlightRead--;if(failRead)throw Error('offline');return {match:{a:'A',b:'B',sa:server[0],sb:server[1],winner,matchVersion:7,refereeActive:true}};},
  v05AcceptServerMatch:(_k,_ri,_mi,remote)=>{Object.assign(m,remote);changes.push(remote);},
  canCompleteMatch:match=>Math.max(Number(match.sa),Number(match.sb))>=4&&Number(match.sa)!==Number(match.sb),
  v1CloudMatchCommand:async(action,_kind,_ri,_mi,opts)=>{commands.push({action,opts});return {ok:true}},
  backToBracketFromMatch:()=>calls.push('back'),
  backgroundRefreshCurrentEvent:async()=>{},
  openMatchEditor:()=>calls.push('editor'),openRRMatch:()=>calls.push('rr'),
  $:()=>({classList:{contains:()=>true}}),
 };
 vm.createContext(scope);vm.runInContext(src,scope);
 return {scope,m,event,alerts,commands,changes,calls,state,inFlight:()=>inFlightRead};
}
test('stale failure but identical private score may finish using verified server matchVersion',async()=>{
 const t=setup({error:'previous 429'});await t.scope.finishCloud('round',0,0);
 assert.equal(t.commands.length,1);assert.equal(t.commands[0].action,'complete');
 assert.equal(t.commands[0].opts.expectedMatchVersion,7);
 assert.equal(t.commands[0].opts.sb,6);
 assert.equal(t.state.lastError,null);
 assert.ok(t.calls.indexOf('read')>t.calls.indexOf('flush'));
 assert.deepEqual(t.alerts,[]);
});
test('local unconfirmed 0:6 versus server 0:3 never completes and restores private score',async()=>{
 const t=setup({server:[0,3],error:'previous 429'});await t.scope.finishCloud('round',0,0);
 assert.equal(t.commands.length,0);
 assert.equal(t.m.sb,3);
 assert.equal(t.state.version,7);
 assert.ok(t.alerts.some(x=>x.includes('0：6')&&x.includes('0：3')));
});
test('double taps while verification is in flight issue exactly one completion',async()=>{
 const t=setup({delay:20});const first=t.scope.finishCloud('round',0,0);
 const second=t.scope.finishCloud('round',0,0);
 await Promise.all([first,second]);assert.equal(t.commands.length,1);assert.equal(t.scope.v05FinishInFlight.size,0);
});
test('already completed on server never sends a duplicate completion',async()=>{
 const t=setup({winner:'B'});await t.scope.finishCloud('round',0,0);
 assert.equal(t.commands.length,0);
 assert.ok(t.calls.includes('back'));
});
test('unknown or unreachable server score never completes',async()=>{
 const t=setup({failRead:true,error:'429'});await t.scope.finishCloud('round',0,0);
 assert.equal(t.commands.length,0);
 assert.ok(t.alerts.some(x=>x.includes('無法讀取雲端比分')));
});
