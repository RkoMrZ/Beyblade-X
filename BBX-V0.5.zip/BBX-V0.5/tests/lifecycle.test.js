'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../functions/bbx-v05-lifecycle');
const D=require('../functions/bbx-v05-cleanup');
const ID1='B3_test_event_123',ID2='B4_test_event_123';
const OWNER='google-creator';
test('five-character aliases are NOT datastore IDs, have exact allowed alphabet and are stable',()=>{
 const first=L.shortCode(OWNER,ID1),second=L.shortCode(OWNER,ID1);
 assert.match(first,/^[A-HJ-NP-Z2-9]{5}$/);assert.equal(first.length,5);assert.equal(first,second);
 assert.equal(L.validCode('ABCDE'),true);
 assert.equal(L.validCode('ABCD0'),false);
 assert.notEqual(first,ID1);assert.notEqual(L.shortCode(OWNER,ID2),first);
});
test('two releases may have the SAME public 5-character code but must never share a cleanup record',()=>{
 const a=L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.3',code:'ABCDE',slot:'0'});
 const b=L.registry({eventId:ID2,ownerUid:OWNER,originVersion:'BBX-V0.4',code:'ABCDE',slot:'1'});
 assert.notEqual(a.eventId,b.eventId);
 assert.equal(a.releases['BBX-V0_3'],true);
 assert.equal(b.releases['BBX-V0_4'],true);
 assert.equal(Object.hasOwn(a.releases,'BBX-V0.3'),false);
 assert.throws(()=>L.mergeRegistered(a,b),/identity/);
 const paths=L.deletionPaths(a,ID1,OWNER,{0:ID1,1:ID2});
 assert(!paths.some(path=>path.endsWith('/'+ID2)));
 assert(paths.includes('userEvents/'+OWNER+'/0'));
 assert(!paths.includes('userEvents/'+OWNER+'/1'));
});
test('legacy registry accumulates paths over upgrades and cannot delete arbitrary database locations',()=>{
 const v03=L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.3',slot:0,actualRoots:['authorityBBX']});
 const v04={...v03,releases:{...v03.releases,'BBX-V0.4':true},locations:[...v03.locations,'authorityBBXV04/'+ID1]};
 const merged=L.mergeRegistered(v03,v04);
 assert(merged.locations.includes('authorityBBX/'+ID1));
 assert(merged.locations.includes('authorityBBXV04/'+ID1));
 assert(merged.releases['BBX-V0_4']);
 assert(!Object.hasOwn(merged.releases,'BBX-V0.4'));
 assert(Object.keys(merged.releases).every(key=>!/[.#$/\[\]]/.test(key)));
 assert.throws(()=>L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.3',extra:['userEvents/another-account/0']}),/non-event/);
 assert.throws(()=>L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.3',extra:['secrets/'+ID2]}),/non-event/);
 assert.throws(()=>L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.3',extra:['.settings/rules']}),/non-event/);
});
test('cleanup respects re-used organizer slots and old static locations',()=>{
 const record=L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.3',code:'PQRST',slot:0});
 const paths=L.deletionPaths(record,ID1,OWNER,{'0':ID2});
 assert(!paths.includes(`userEvents/${OWNER}/0`));
 assert(paths.includes('authorityBBX/'+ID1));
 assert(paths.includes('authorityBBXV05/'+ID1));
 assert(paths.includes('bbxPublicCodeLookup/PQRST'));
 for(const root of D.EVENT_ROOTS)assert(paths.includes(root+'/'+ID1));
});
test('registry cannot mutate after deletion, change owner or switch public code',()=>{
 const reg=L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.3',code:'ABCDE'});
 assert.throws(()=>L.mergeRegistered({...reg,status:'deleted'},reg),/lifecycle/);
 assert.throws(()=>L.mergeRegistered(reg,{...reg,ownerUid:'attacker'}),/identity/);
 assert.throws(()=>L.mergeRegistered(reg,{...reg,publicCode:'FGHJK'}),/cannot change/);
});
test('permanent structure catalog covers every code-supported historical event root',()=>{
 const fs=require('node:fs');
 const path=require('node:path');
 const file=path.join(__dirname,'../docs/BBX-永久資料結構登記表.json');
 const catalog=JSON.parse(fs.readFileSync(file,'utf8'));
 assert.deepEqual([...catalog.eventScopedRoots].sort(),[...D.EVENT_ROOTS].sort());
 assert.equal(catalog.privateLedgerRoot,'bbxEventCleanupRegistry/{immutableEventId}');
});

test('create registry values contain no Firebase-disallowed nested keys',()=>{
 const r=L.registry({eventId:ID1,ownerUid:OWNER,originVersion:'BBX-V0.5',slot:0,actualRoots:['events']});
 const validate=(obj,path='')=>{
  if(Array.isArray(obj)){obj.forEach((child,i)=>validate(child,path+'/'+i));return}
  if(!obj||typeof obj!=='object')return;
  for(const [key,value] of Object.entries(obj)){
   assert(!/[.#$/\[\]\x00-\x1f\x7f]/.test(key),`invalid RTDB key: ${path}/${key}`);
   validate(value,path+'/'+key);
  }
 };
 validate(r);
 assert.equal(r.originVersion,'BBX-V0.5');
 assert.equal(r.releases['BBX-V0_5'],true);
});
