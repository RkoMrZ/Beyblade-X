'use strict';
const assert=require('node:assert/strict');
const test=require('node:test');
const Module=require('node:module');
const originalLoad=Module._load;
process.env.GCLOUD_PROJECT='ljt-beyblade-x';
const COPY=v=>v===undefined?undefined:JSON.parse(JSON.stringify(v));
const store={};
const transactions=[];const writes=[];const lockReads={fullBoard:0,seq:0};
function parts(p){return String(p||'').split('/').filter(Boolean)}
function getAt(path){let n=store;for(const k of parts(path)){if(!n||typeof n!=='object'||!(k in n))return null;n=n[k]}return COPY(n)}
function setAt(path,v){let a=parts(path),o=store;for(let i=0;i<a.length-1;i++){o[a[i]]??={};o=o[a[i]]}if(v===null)delete o[a.at(-1)];else o[a.at(-1)]=COPY(v)}
class Ref{
 constructor(p=''){this.p=p}
 child(n){return new Ref(this.p+'/'+n)}
 async get(){
  const match=this.p.match(/^authorityBBXV05\/([^/]+)\/board(\/seq)?$/);
  if(match&&getAt(`authorityBBXV05/${match[1]}/operationLock`)?.token){
   if(match[2])lockReads.seq++;else lockReads.fullBoard++;
  }
  return new Snap(getAt(this.p))
 }
 async once(){return this.get()}
 orderByChild(){return this}
 limitToFirst(){return this}
 async set(v){setAt(this.p,v)}
 async update(up){for(const [k,v] of Object.entries(up)){writes.push(this.p+'/'+k);setAt(this.p+'/'+k,v)}}
 async transaction(change){transactions.push(this.p);const current=getAt(this.p);const res=change(COPY(current));if(res===undefined)return {committed:false,snapshot:new Snap(current)};setAt(this.p,res);return {committed:true,snapshot:new Snap(getAt(this.p))}}
}
class Snap{constructor(v){this.v=v}val(){return COPY(this.v)}exists(){return this.v!==null&&this.v!==undefined}}
const fakeDb={ref:p=>new Ref(p)};
class HttpsError extends Error{constructor(code,message){super(message);this.code=code}}
Module._load=function(request,parent,isMain){
 if(parent?.filename?.endsWith('/functions/index.js')){
  if(request==='firebase-admin')return {initializeApp(){},database:()=>fakeDb};
  if(request==='firebase-functions/v2/https')return {onCall:(_opt,fn)=>fn,HttpsError};
  if(request==='firebase-functions/v2/database')return {onValueWritten:(_opt,fn)=>fn};
  if(request==='firebase-functions/v2/scheduler')return {onSchedule:(_opt,fn)=>fn};
 }
 return originalLoad.apply(this,arguments);
};
const f=require('../functions/index.js');Module._load=originalLoad;
function op(){return Date.now().toString(16).padStart(12,'0')+'d'.repeat(36)}
function request(data,uid='owner',google=true){return {data:{clientVersion:'bbx-v0.5-authority-1',...(data?.target?{expectedStructureVersion:0}:{}),...data},auth:uid?{uid,token:{firebase:{sign_in_provider:google?'google.com':'anonymous'}}}:null}}
const roster=['A','B','C','D'];const make=opId=>request({opId,name:'Test Event',roster,mode:'single',pairing:'ordered',freeFinal:'champ'});
let eventId;
test('atomic server CREATE writes owner index / private / public / board together',async()=>{
 const result=await f.bbxV05CreateAuthority(make(op()));assert.equal(result.ok,true);eventId=result.eventId;
 assert.equal(result.slot,'0');assert.equal(result.eventId.startsWith('B5_'),true);
 assert.equal(getAt('events/'+eventId+'/releaseTag'),'BBX-V0.5');
 assert.equal(getAt('events/'+eventId+'/authorityBBX'),'active');
 assert.equal(getAt('publicEvents/'+eventId+'/meta/id'),eventId);
 assert.equal(getAt('userEvents/owner/0'),eventId);
 assert.equal(getAt('authorityBBXV05/'+eventId+'/board/seq'),0);
 assert.equal(getAt('authorityBBXV05/'+eventId+'/board/rounds/0/matches/0/a'),'A');
 assert.equal(getAt('admins/'+eventId+'/owner')!==null,true);
 assert.equal(getAt('bbxV05CreateLocks/owner'),null);
});
test('same create operation is idempotent and does not allocate another slot',async()=>{
 const id='d'.repeat(36),o=Date.now().toString(16).padStart(12,'0')+id;
 const a=await f.bbxV05CreateAuthority(make(o));const b=await f.bbxV05CreateAuthority(make(o));
 assert.equal(a.eventId,b.eventId);assert.equal(b.existing,true);assert.equal(b.slot,'1');
});
test('new request increments owner slot, but fourth create is refused',async()=>{
 await f.bbxV05CreateAuthority(make(op().slice(0,12)+'e'.repeat(36)));
 await assert.rejects(()=>f.bbxV05CreateAuthority(make(op().slice(0,12)+'f'.repeat(36))),e=>e.code==='resource-exhausted');
 assert.equal(Object.keys(getAt('userEvents/owner')).length,3);
});
test('anonymous and non-Google cannot create authoritative event',async()=>{
 await assert.rejects(()=>f.bbxV05CreateAuthority(request(make(op()).data,null)),e=>e.code==='unauthenticated');
 await assert.rejects(()=>f.bbxV05CreateAuthority(request(make(op()).data,'bad',false)),e=>e.code==='permission-denied');
});
test('server score/claim advances one match and rejects old matchVersion',async()=>{
 const a=await f.bbxV05CommandAuthority(request({eventId,opId:op(),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'}));
 assert.equal(a.ok,true);
 assert.equal(a.matchVersion,1);
 assert.equal(getAt(`events/${eventId}/rounds/0/matches/0/referee`),''); assert.equal(getAt(`authorityBBXV05/${eventId}/board/rounds/0/matches/0/referee`),'裁判 1');
 await assert.rejects(()=>f.bbxV05CommandAuthority(request({eventId,opId:op().slice(0,12)+'b'.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,sa:4,sb:1})),e=>e.code==='aborted');
 const s=await f.bbxV05CommandAuthority(request({eventId,opId:op().slice(0,12)+'c'.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:1,sa:4,sb:1}));assert.equal(s.ok,true);
 assert.equal(getAt(`authorityBBXV05/${eventId}/board/rounds/0/matches/0/sa`),4); assert.equal(getAt(`publicEvents/${eventId}/rounds/0/matches/0/sa`),'');
 assert.equal(transactions.some(p=>p.endsWith('/board')),false,'the private board must never be transacted wholesale');
 assert.equal(writes.includes(`authorityBBXV05/${eventId}/board/rounds`),false,'score must not write the entire rounds tree');
 assert.ok(writes.some(p=>p.endsWith('/board/rounds/0/matches/0/sa')),'score writes its match leaf');
});
test('publish runs with separate lease and drains ordered outbox',async()=>{
 assert.equal(getAt(`authorityBBXV05/${eventId}/board/seq`),2);
 assert.equal(getAt(`authorityBBXV05/${eventId}/publishedSeq`),0);
 const r=await f.bbxV05PublishAuthority({params:{eventId},data:{after:new Snap(2)}});
 assert.equal(r,undefined);
 assert.equal(getAt(`authorityBBXV05/${eventId}/publishedSeq`),2);
 assert.equal(getAt(`events/${eventId}/rounds/0/matches/0/referee`),'裁判 1');
 assert.equal(getAt(`publicEvents/${eventId}/rounds/0/matches/0/sa`),4);
 assert.equal(getAt(`authorityBBXV05/${eventId}/publishing`),null);
 assert.equal(getAt(`authorityBBXV05/${eventId}/operationLock`),null);
});
test('occupied publication lease retries without locking organizer writes',async()=>{
 const path=`authorityBBXV05/${eventId}/publishing`;
 setAt(path,{token:'someone-else',expiresAt:Date.now()+60000});
 const opId=op().slice(0,12)+'9'.repeat(36);
 const a=await f.bbxV05OrganizerAuthority(request({eventId,opId,expectedSeq:2,action:'closePublic'}));
 assert.equal(a.ok,true);assert.equal(a.publicationPending,true);
 assert.equal(getAt(`authorityBBXV05/${eventId}/board/publicOpen`),false);
 assert.equal(getAt(`publicEvents/${eventId}/meta/publicOpen`),false);
 await f.bbxV05PublishAuthority({params:{eventId},data:{after:new Snap(3)}});
 assert.equal(getAt(`bbxV05PublicationPending/${eventId}/seq`),3);
 assert.equal(getAt(path).token,'someone-else');
 setAt(path,{token:'expired',expiresAt:Date.now()-1000});
 await f.bbxV05PublishAuthority({params:{eventId},data:{after:new Snap(3)}});
 assert.equal(getAt(`publicEvents/${eventId}/meta/publicOpen`),false);
 assert.equal(getAt(`authorityBBXV05/${eventId}/publishedSeq`),3);
});
test('different tournaments do not share command locks',async()=>{
 const r=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'2'.repeat(36),name:'Other tournament',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'isolated'));
 const other=r.eventId;
 setAt(`authorityBBXV05/${eventId}/operationLock`,{token:'other-event-working',expiresAt:Date.now()+60000});
 const out=await f.bbxV05CommandAuthority(request({eventId:other,opId:op().slice(0,12)+'3'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},'isolated'));
 assert.equal(out.ok,true);
 assert.equal(getAt(`authorityBBXV05/${eventId}/operationLock`).token,'other-event-working');
 setAt(`authorityBBXV05/${eventId}/operationLock`,null);
});
test('old release client version cannot operate V0.5 event',async()=>{
 await assert.rejects(()=>f.bbxV05CommandAuthority({data:{clientVersion:'bbx-v0.3-authority-1',eventId,action:'claim'},auth:request({}).auth}),e=>e.code==='failed-precondition');
});
test('orphaned slot from prior failed release can be reclaimed without deleting existing events',async()=>{
 setAt('userEvents/newowner/0','ORPHAN_OLD_A');
 const made=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'a'.repeat(36),name:'Clean old orphan',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'newowner'));
 assert.equal(made.slot,'0');assert.equal(getAt('userEvents/newowner/0'),made.eventId);
 assert.equal(getAt('userEvents/owner/0'),eventId);
});
test('server deletion is scoped, serialized against publisher and removes private/public/index together',async()=>{
 const removed=await f.bbxV05DeleteAuthority(request({eventId}));
 assert.deepEqual(removed,{ok:true,deleted:true});
 for(const p of [`events/${eventId}`,`publicEvents/${eventId}`,`authorityBBXV05/${eventId}`,'userEvents/owner/0'])assert.equal(getAt(p),null,p);
 assert.ok(getAt('userEvents/owner/1'),'other existing event untouched');
 assert.ok(getAt('events/'+getAt('userEvents/owner/1')),'other event still exists');
});
test('simultaneous stale score commands cannot both commit',async()=>{
 const r=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'8'.repeat(36),name:'Racing scoreboard',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},'newowner'));
 const eid=r.eventId;
 await f.bbxV05CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+'1'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},'newowner'));
 const score=(ending,tail)=>f.bbxV05CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+tail.repeat(36),action:'score',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:1,sa:ending,sb:1},'newowner'));
 const results=await Promise.allSettled([score(3,'2'),score(4,'3')]);
 assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
 assert.ok(['aborted','resource-exhausted'].includes(results.find(x=>x.status==='rejected').reason.code));
 assert.equal(getAt(`authorityBBXV05/${eid}/board/rounds/0/matches/0/matchVersion`),2);
});
test('durable scheduled repair drains a missed publication trigger without blocking a different tournament',async()=>{
 const user='repair-user';
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'4'.repeat(36),name:'Repair test',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},user));
 const eid=created.eventId;
 const claim=await f.bbxV05CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+'5'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},user));
 assert.equal(claim.seq,1);
 assert.equal(getAt(`authorityBBXV05/${eid}/publishedSeq`),0);
 assert.equal(getAt(`bbxV05PublicationPending/${eid}/seq`),1);
 await f.bbxV05RepairQueue();
 assert.equal(getAt(`authorityBBXV05/${eid}/publishedSeq`),1);
 assert.equal(getAt(`bbxV05PublicationPending/${eid}`),null);
});
test('outbox sequence gap remains on repair queue and never skips publication cursor',async()=>{
 const user='missing-outbox-user';
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'6'.repeat(36),name:'Lost record',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},user));
 const eid=created.eventId;
 await f.bbxV05CommandAuthority(request({eventId:eid,opId:op().slice(0,12)+'7'.repeat(36),action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},user));
 setAt(`authorityBBXV05/${eid}/board/outbox/000000000001`,null);
 await f.bbxV05PublishAuthority({params:{eventId:eid},data:{after:new Snap(1)}});
 assert.equal(getAt(`authorityBBXV05/${eid}/publishedSeq`),0);
 assert.equal(getAt(`bbxV05PublicationPending/${eid}/seq`),1);
});

// V0.5 concurrent court regression: preserve the original one-referee-per-
// match claim. Six DIFFERENT matches may prepare independently, but every
// shared sequence / outbox commit must still be atomic and gap-free.
test('six referees across six courts: claim, score and simultaneous advancement are lossless',async()=>{
 const owner='parallel-owner';
 const roster=Array.from({length:12},(_,i)=>`選手${i+1}`);
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'8',name:'六場同時執裁',roster,mode:'free',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const refNames=Array.from({length:6},(_,i)=>`裁判${i+1}`);
 for(let i=0;i<6;i++){
  setAt(`refereeUsers/${eid}/judge${i}`,true);
  setAt(`refereeClaims/${eid}/${i}`,{uid:`judge${i}`,name:refNames[i],claimedAt:Date.now()});
 }
 let nonce=10000;
 const uniqueOp=()=>Date.now().toString(16).padStart(12,'0')+(nonce++).toString(16).padStart(36,'0');
 const command=(i,action,expectedMatchVersion,extra={})=>f.bbxV05CommandAuthority(request({
  eventId:eid,opId:uniqueOp(),action,target:{kind:'round',ri:0,mi:i},expectedMatchVersion,...extra
 },`judge${i}`,false));
 for(const [action,version,extra] of [
  ['claim',0,i=>({referee:refNames[i]})],
  ['score',1,()=>({sa:4,sb:1})],
  ['complete',2,()=>({sa:4,sb:1})]
 ]){
  const outcomes=await Promise.allSettled(Array.from({length:6},(_,i)=>command(i,action,version,extra(i))));
  assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,6,
   `${action} rejected: ${outcomes.filter(x=>x.status==='rejected').map(x=>x.reason?.message)}`);
 }
 const root=`authorityBBXV05/${eid}/board`;
 assert.equal(getAt(`${root}/seq`),18);
 assert.equal(Object.keys(getAt(`${root}/outbox`)).length,18);
 for(let i=0;i<6;i++){
  const m=getAt(`${root}/rounds/0/matches/${i}`);
  assert.equal(m.matchVersion,3);assert.equal(m.winner,roster[i*2]);
  assert.equal(m.refereeActive,false);assert.equal(m.claimUid??null,null);
 }
 for(let i=0;i<3;i++){
  const next=getAt(`${root}/rounds/1/matches/${i}`);
  assert.equal(next.a,roster[i*4]);assert.equal(next.b,roster[i*4+2]);
 }
 await f.bbxV05PublishAuthority({params:{eventId:eid},data:{after:new Snap(18)}});
 await f.bbxV05PublishAuthority({params:{eventId:eid},data:{after:new Snap(18)}});
 assert.equal(getAt(`authorityBBXV05/${eid}/publishedSeq`),18);
 assert.equal(getAt(`bbxV05PublicationPending/${eid}`),null);
 for(let i=0;i<6;i++)assert.equal(getAt(`publicEvents/${eid}/rounds/0/matches/${i}/winner`),roster[i*2]);
});

test('two referee UIDs claiming SAME match cannot both become active',async()=>{
 const owner='same-court-owner';
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'9',name:'互斥接手',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 for(const [slot,uid] of ['judge-a','judge-b'].entries()){
  setAt(`refereeUsers/${eid}/${uid}`,true);
  setAt(`refereeClaims/${eid}/${slot}`,{uid,name:uid,claimedAt:Date.now()});
 }
 const claims=['judge-a','judge-b'].map((uid,i)=>f.bbxV05CommandAuthority(request({
  eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+(i+501).toString(16).padStart(36,'0'),
  action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:uid
 },uid,false)));
 const results=await Promise.allSettled(claims);
 assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
 assert.equal(results.filter(x=>x.status==='rejected').length,1);
 const m=getAt(`authorityBBXV05/${eid}/board/rounds/0/matches/0`);
 assert.equal(m.matchVersion,1);
 assert.ok(['judge-a','judge-b'].includes(m.claimUid));
});


test('normal court command reads full board BEFORE lock and only verifies seq UNDER lock',async()=>{
 const owner='latency-owner';
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'a',name:'快速正常路徑',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const before={...lockReads};
 const r=await f.bbxV05CommandAuthority(request({eventId:created.eventId,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'b',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,referee:'裁判 1'},owner));
 assert.equal(r.ok,true);
 assert.equal(lockReads.fullBoard-before.fullBoard,0,'uncontended match prep must not download entire board under the write lock');
 assert.equal(lockReads.seq-before.seq,1,'atomic commit must compare the current event revision under lock');
});

test('bracket rebuild invalidates an old referee claim even if matchVersion resets to zero',async()=>{
 const owner='rebuild-owner';
 const roster=['紅','橙','黃','綠'];
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'c',name:'換籤版本保護',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const swap=await f.bbxV05OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'d',action:'swapPlayers',ri:0,i:0,j:2,expectedSeq:0},owner));
 assert.equal(swap.ok,true);
 const privateRoot=`authorityBBXV05/${eid}/board`;
 assert.equal(getAt(`${privateRoot}/structureVersion`),1);
 assert.equal(getAt(`events/${eid}/structureVersion`),1);
 assert.equal(getAt(`${privateRoot}/rounds/0/matches/0/matchVersion`),0);
 const stale=request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'e',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,expectedStructureVersion:0,referee:'裁判 1'},owner);
 await assert.rejects(()=>f.bbxV05CommandAuthority(stale),e=>e.code==='aborted');
 assert.equal(getAt(`${privateRoot}/rounds/0/matches/0/refereeActive`),false);
 const fresh=request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'f',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,expectedStructureVersion:1,referee:'裁判 1'},owner);
 const r=await f.bbxV05CommandAuthority(fresh);assert.equal(r.ok,true);
 assert.equal(getAt(`${privateRoot}/rounds/0/matches/0/matchVersion`),1);
});

test('close then reopen viewer access is immediate even while old publication is queued',async()=>{
 const owner='gate-owner';
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'1',name:'公開權限交錯',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const old=await f.bbxV05OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'2',action:'closePublic',expectedSeq:0},owner));
 assert.equal(old.ok,true);
 assert.equal(getAt(`publicEvents/${eid}/meta/publicOpen`),false);
 const opened=await f.bbxV05OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'3',action:'extendPublic',expectedSeq:1},owner));
 assert.equal(opened.ok,true);
 assert.equal(getAt(`events/${eid}/publicOpen`),true);
 assert.equal(getAt(`publicEvents/${eid}/meta/publicOpen`),true);
 assert.equal(getAt(`authorityBBXV05/${eid}/publishedSeq`),0);
 await f.bbxV05PublishAuthority({params:{eventId:eid},data:{after:new Snap(2)}});
 assert.equal(getAt(`publicEvents/${eid}/meta/publicOpen`),true);
 assert.equal(getAt(`authorityBBXV05/${eid}/publishedSeq`),2);
});

test('concurrent bracket rebuild vs stale judge claim cannot both change incompatible state',async()=>{
 const owner='barrier-owner';
 const created=await f.bbxV05CreateAuthority(request({opId:op().slice(0,12)+'0'.repeat(35)+'4',name:'重編與執裁互斥',roster,mode:'single',pairing:'ordered',freeFinal:'champ'},owner));
 const eid=created.eventId;
 const fnA=f.bbxV05OrganizerAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'5',action:'swapPlayers',ri:0,i:0,j:2,expectedSeq:0},owner));
 const fnB=f.bbxV05CommandAuthority(request({eventId:eid,opId:Date.now().toString(16).padStart(12,'0')+'0'.repeat(35)+'6',action:'claim',target:{kind:'round',ri:0,mi:0},expectedMatchVersion:0,expectedStructureVersion:0,referee:'裁判 1'},owner));
 const settled=await Promise.allSettled([fnA,fnB]);
 assert.equal(settled.filter(x=>x.status==='fulfilled').length,1,JSON.stringify(settled.map(x=>x.reason?.message)));
 assert.equal(settled.filter(x=>x.status==='rejected').length,1);
 const b=getAt(`authorityBBXV05/${eid}/board`);
 assert.equal(b.seq,1);
 if(b.structureVersion===1)assert.equal(b.rounds[0].matches[0].refereeActive,false);
 else assert.equal(b.rounds[0].matches[0].refereeActive,true);
});
