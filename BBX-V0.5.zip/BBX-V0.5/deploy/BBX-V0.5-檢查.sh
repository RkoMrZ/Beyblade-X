#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == BBX-V0.5 ]] || { echo 'STOP: incorrect BBX project folder'; exit 2; }
python3 - <<'PY'
import json,hashlib
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.5' and m['firebase_project']=='ljt-beyblade-x'
assert m['release_status']=='PREDEPLOY_TEST_REQUIRED'
for item in m['files']:
 p=Path(item['path'])
 assert p.is_file(),str(p)
 raw=p.read_bytes()
 assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],f'Package differs: {p}'
assert 'ljtreg' not in Path('.firebaserc').read_text()
print('PASS BBX-V0.5 integrity, only tournament Firebase project')
PY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == '22' ]] || { echo 'STOP: Node 22 required'; exit 3; }
node --check functions/index.js
node --check functions/bbx-v05-core.js
node --check functions/bbx-v05-organizer.js
node --check functions/bbx-v05-publication.js
node --check functions/bbx-v05-cleanup.js
node --test tests/authority.test.js tests/organizer.test.js tests/compare-brackets.test.js tests/progression-compare.test.js tests/create-integration.test.js tests/publication.test.js tests/cleanup.test.js
python3 tests/check_static.py
python3 tests/check_cleanup_rules.py
# Test preservation of deployed V0.4 Rules with an offline merge.
python3 deploy/merge-rules.py docs/previous-v04-rules.json /tmp/bbx-v05-preflight-merged.json
python3 - <<'RULETEST'
import json
old=json.load(open('docs/previous-v04-rules.json'))['rules']
new=json.load(open('/tmp/bbx-v05-preflight-merged.json'))['rules']
assert new['authorityBBXV04']==old['authorityBBXV04']
assert new['authorityBBXV05']=={'.read':False,'.write':False}
assert new['bbxV05PublicationPending']=={'.read':False,'.write':False,'.indexOn':['updatedAt']}
assert 'authorityBBXV05' in new['publicEvents']['$eventId']['.read']
assert all(new[k]==v for k,v in old.items() if k not in ('events','publicEvents','bbxV05PublicationPending'))
print('PASS safe Rules migration preserves V0.4 and unrelated branches')
RULETEST
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI missing'; exit 4; }
command -v java >/dev/null || { echo 'STOP: Java needed for database emulator'; exit 4; }
# Emulator uses DEMO project, no production Firebase modifications.
npm --prefix tests install --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v05 'cd tests && node rules-emulator.test.cjs'
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v05-preflight-ok"
printf '\nPASS: BBX-V0.5 tests + Firebase Emulator. Deployment may be started.\n'
