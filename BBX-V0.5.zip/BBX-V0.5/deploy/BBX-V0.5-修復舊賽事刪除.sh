#!/usr/bin/env bash
# Upgrade ONLY V0.5 DeleteAuthority and safely reconcile historical private Rules.
# Never deletes a tournament during deployment. Deletion is owner-initiated in UI.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == BBX-V0.5 ]] || { echo 'STOP: wrong project folder'; exit 2; }
python3 - <<'PY'
import json,hashlib
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.5' and m['firebase_project']=='ljt-beyblade-x'
for item in m['files']:
 b=Path(item['path']).read_bytes()
 assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'],item['path']
assert 'bbx-v05-cleanup' in Path('functions/index.js').read_text()
assert 'authorityBBXV04' in json.loads(Path('database.rules.json').read_text())['rules']
print('PASS exact ZIP files, legacy paths and historical deny-Rules')
PY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required'; exit 3; }
for tool in gcloud firebase curl npm python3 node java; do command -v "$tool" >/dev/null || { echo "STOP: $tool missing"; exit 3; }; done
if ! gcloud auth print-access-token >/dev/null 2>&1; then
 mapfile -t ACCOUNTS < <(gcloud auth list --format='value(account)' | sed '/^$/d' | sort -u)
 [[ ${#ACCOUNTS[@]} == 1 ]] || { echo 'STOP: Google account not selected'; exit 3; }
 gcloud config set account "${ACCOUNTS[0]}" --quiet
fi
gcloud auth print-access-token >/dev/null
gcloud config set project ljt-beyblade-x --quiet
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || exit 4
[[ "$(python3 -c 'import json;print(json.load(open(".firebaserc"))["projects"]["default"])')" == ljt-beyblade-x ]] || exit 4

node --check functions/index.js
node --check functions/bbx-v05-cleanup.js
node --test tests/authority.test.js tests/organizer.test.js tests/compare-brackets.test.js tests/progression-compare.test.js tests/create-integration.test.js tests/publication.test.js tests/cleanup.test.js
python3 tests/check_static.py
python3 tests/check_cleanup_rules.py
npm --prefix tests install --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v05 'cd tests && node rules-emulator.test.cjs'

gcloud functions list --v2 --regions=asia-southeast1 --project ljt-beyblade-x --format=json > /tmp/bbx-v05-delete-functions.json
python3 - <<'PY'
import json,re
names={x['name'].split('/')[-1] for x in json.load(open('/tmp/bbx-v05-delete-functions.json'))}
m=json.load(open('MANIFEST.json'))
assert set(m['functions_exports']) <= names, 'STOP: 8 V0.5 functions must be deployed first'
assert not any(re.match(r'^bbxV0[1-4]',name) for name in names), 'STOP: an old BBX Function is still deployed; it could rewrite old event data'
print('PASS active V0.5 Functions, all V0.1–V0.4 Function writers retired')
PY

RULES_URL='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app/.settings/rules.json'
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS --retry 3 --max-time 40 -H "Authorization: Bearer $TOKEN" "$RULES_URL" > /tmp/bbx-v05-delete-live-rules.json
python3 deploy/merge-rules.py /tmp/bbx-v05-delete-live-rules.json /tmp/bbx-v05-delete-merged-rules.json
python3 - <<'PY'
import json
old=json.load(open('/tmp/bbx-v05-delete-live-rules.json'))
new=json.load(open('/tmp/bbx-v05-delete-merged-rules.json'))
assert new['rules']['authorityBBXV04']=={'.read':False,'.write':False}
assert new['rules']['authorityBBXV05']=={'.read':False,'.write':False}
for root,v in old['rules'].items():
 if root not in ('events','publicEvents','authorityBBXV04','authorityBBXV05','bbxV05PublicationPending'):
  assert new['rules'][root]==v,'unrelated Rules changed: '+root
print('PASS historical and unrelated online Rules preserved')
PY

# Apply Rules only when necessary. The merge rejects unknown privilege changes.
TMP_CFG="$(mktemp)";TMP_RC="$(mktemp)"
cp firebase.json "$TMP_CFG";cp .firebaserc "$TMP_RC"
trap 'cp "$TMP_CFG" "$ROOT/firebase.json"; cp "$TMP_RC" "$ROOT/.firebaserc"; rm -f "$TMP_CFG" "$TMP_RC" "$ROOT/deploy/.bbx-v05-delete-runtime-rules.json"' EXIT
if ! python3 - <<'RULE_COMPARE'
import json,sys
old=json.load(open('/tmp/bbx-v05-delete-live-rules.json'))
new=json.load(open('/tmp/bbx-v05-delete-merged-rules.json'))
sys.exit(0 if old==new else 1)
RULE_COMPARE
then
 # Verify the live rules are unchanged since merge, before updating permissions.
 TOKEN="$(gcloud auth print-access-token)"
 curl -fLsS --retry 3 --max-time 40 -H "Authorization: Bearer $TOKEN" "$RULES_URL" > /tmp/bbx-v05-delete-verify-live.json
 python3 - <<'PY'
import json
assert json.load(open('/tmp/bbx-v05-delete-verify-live.json'))==json.load(open('/tmp/bbx-v05-delete-live-rules.json')),'STOP: live Rules changed during preflight'
PY
 cp /tmp/bbx-v05-delete-merged-rules.json deploy/.bbx-v05-delete-runtime-rules.json
 firebase target:apply database bbxv05-main ljt-beyblade-x-default-rtdb --project ljt-beyblade-x
 python3 - <<'PY'
import json
p='firebase.json';x=json.load(open(p));x['database']={'target':'bbxv05-main','rules':'deploy/.bbx-v05-delete-runtime-rules.json'}
open(p,'w').write(json.dumps(x,indent=2)+'\n')
PY
 echo '=== Merge historical private Rules without removing unrelated branches ==='
 firebase deploy --only database:bbxv05-main --project ljt-beyblade-x --non-interactive
 TOKEN="$(gcloud auth print-access-token)"
 curl -fLsS --retry 3 --max-time 40 -H "Authorization: Bearer $TOKEN" "$RULES_URL" > /tmp/bbx-v05-delete-post-rules.json
 python3 - <<'PY'
import json
assert json.load(open('/tmp/bbx-v05-delete-post-rules.json'))==json.load(open('/tmp/bbx-v05-delete-merged-rules.json')),'STOP: online rules verification mismatch'
print('PASS historical private Rules merged and verified')
PY
else
 echo 'PASS existing online Rules already identical; no Rules redeployment needed'
fi
npm --prefix functions install --no-audit --no-fund
printf '\n=== Update ONLY bbxV05DeleteAuthority (no database record deletion) ===\n'
firebase deploy --only functions:bbxV05DeleteAuthority --project ljt-beyblade-x --non-interactive
printf '\nPASS deletion Function updated. NO TOURNAMENT WAS DELETED BY THIS DEPLOYMENT.\n'
printf 'Original Google creator may now delete their own old test tournament in the site.\n'
