#!/usr/bin/env bash
set -Eeuo pipefail
exec bash "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/BBX-V0.5-五碼與永久清理升級.sh" "$@"
