# BBX-V0.5｜戰鬥陀螺賽程表（測試版）

**唯一開發母版**：`baseline/index.v1.html`、`baseline/viewer.v1.html`、`baseline/rules.v1.json`（使用者 2026-10-17 上傳的正式 V1.0 原始三檔）。沒有重做原本介面或 CSS。

**目標 Firebase 專案**：`ljt-beyblade-x`（非獨立報名系統）。

**本次修訂重點（尚未部署）**：不新增任何鎖，保留「開始執裁」同場獨占及 V0.5 既有的主辦建賽租約、單場賽事短暫操作鎖、獨立發布租約。**不同場次先並行讀取／計算，最後只短暫序列化共同 `seq/outbox/晉級` 的原子提交**；發現賽事序號已變，先釋放鎖、依最新資料重新計算，重試後才退回保守的鎖內計算。這不是多把裁判鎖，也不宣稱多人提交完全無互斥。

**本版解決的重點**：此前 V0.1–V0.4 建立賽事採用「手機直接寫 events、公開牌，再由另一支 Function 暫存／啟用」多階段流程；手機在某一步收到 aborted / not-found，留下狀態不一致風險。V0.5 改成**單一 `bbxV05CreateAuthority` Callable**，只接受賽事設定與選手名稱，**由伺服器**依原版編排邏輯建立完整初始賽程，並以**一次原子多路徑 RTDB 更新**一併寫入：

- `events/{eventId}`：主辦、裁判讀取的管理投影（保留原 V1 UI 可讀結構）
- `publicEvents/{eventId}`：公開觀眾投影（**不含私密憑證、UID 或操作紀錄**）
- `authorityBBXV05/{eventId}/board`：唯一可信權威狀態（禁止前端直接讀寫）
- `userEvents/{uid}/{slot}`：主辦帳號的三場名額索引
- `secrets/{eventId}`、`admins/{eventId}/{uid}`：原版管理碼及原有管理權限相容

採用由 UID + 隨機操作碼決定的賽事 ID；同一操作重試只會返回原賽事，不會再建立第二場。Cloud Functions 不相信手機送來的整張淘汰樹或最終晉級結果。

## 主辦、裁判、觀眾資料讀寫

| 身分 | 即時讀取 | 操作寫入 | 完整同步的觸發 |
|---|---|---|---|
| 主辦 | 帳號索引、賽事基本資料、每輪場次 child 變動 | `bbxV05OrganizerAuthority`（名單、重排、裁判設定、抽獎、開關公開連結）、`bbxV05DeleteAuthority` | 首次開啟、賽程結構變更、失去連線後校正 |
| 裁判 | 已授權的賽事、負責場次及裁判鎖 | `bbxV05CommandAuthority`（接手、比分、完成、重設、釋放）；原有裁判身分加入節點保留 | 首次開啟、改判後依賴輪次變更、明確版本衝突 |
| 觀眾 | `publicEvents/{eventId}` 一條 SSE（第一次完整快照，之後只接收 Firebase patch） | **零寫入** | 首次開啟、斷線且未收到 SSE 恢復快照時，按需 GET；不做每四分鐘整表 GET |

**核心原則**：雲端是唯一真實賽事狀態。手機只提出操作、暫時顯示 UI；操作帶唯一碼、場次 `matchVersion` 或結構 `seq`；不符即拒絕、重新讀雲端。比分完成與晉級由伺服器取得短期賽事鎖、驗證最新權威資料後計算，且**只將變動的私人節點（比分、版本、序號、操作紀錄）寫回**；再將受影響場次增量發布至管理與公開投影。伺服器為判斷下一輪，仍會讀取一次私人權威狀態，觀眾不會讀取此狀態。已完成的比賽改判期間，會保留已確認的公開結果直到新結果完成。

## 8 支 Functions

`bbxV05CreateAuthority`、`bbxV05CommandAuthority`、`bbxV05GetOperation`、`bbxV05OrganizerAuthority`、`bbxV05DeleteAuthority`、`bbxV05RepairPublication`、`bbxV05PublishAuthority`、`bbxV05RepairQueue`。

## V0.5 鎖與增量發布重新分工

- **每場賽事獨立操作鎖**：`authorityBBXV05/{eventId}/operationLock`，只用來核對最新權威 `seq` 並提交局部更新；讀取整份 board 與計算盡量移到鎖外。不同主辦的不同賽事不共用鎖。多位裁判可以同時準備不同場次，僅共用序號提交短暫輪流進行。
- **發布獨立租約**：`authorityBBXV05/{eventId}/publishing`，不再等待也不再占用主辦／裁判鎖。操作在權威資料提交後即回覆，由背景程序按序更新管理與公開節點。
- **逾時自我恢復**：交易原子取得 + token 比對釋放；75 秒租約高於 60 秒 Function 執行上限，意外終止後可在到期時接管，不只依靠 finally。
- **重建籤表保護**：在原場次 `matchVersion` 之外新增 `structureVersion`，只有名單／配對／籤表結構變更才增加；舊手機即使碰上重建後 `matchVersion=0`，也不能接手已換選手的同位置場次。這是版本欄位，不是新鎖。
- **公開觀看開關原子生效**：開啟與關閉都由權威提交立即更新 `events` 與 `publicEvents/meta`，舊 outbox 不再能覆寫公開開關或結構版本。
- **禁止跳號及寫舊版本**：待發布 outbox 以遞增序號逐筆套用，完成後才更新 publishedSeq；失敗、積壓或租約忙碌時重試，不跳過序號。
- **公開關閉立即生效**：關閉分享會同時將公開讀取權限改為 false，即使公開投影暫時落後也無法繼續讀取。
- **節省讀取**：主辦送出的是畫面實際持有的序號，不需要每次用額外 GET 抓最新序號來冒充新畫面。
- **多賽事上限**：Callable 的 maxInstances 設為 12、concurrency 設為 20 作為測試版上限；尚未實測大量主辦與 200 名觀眾的真實負載。

V0.4 已建立且發布積壓的舊測試賽事**不會自動轉移、修好或刪除**；本版只以全新 V0.5 權威節點建立新賽事。新版本驗證成功後只精確刪除上一版 7 支 BBX Functions 與 Cloud Shell 舊測試檔，保留原本線上賽事資料。V0.4 舊賽事若需要接著操作，應先單獨規劃遷移；不要把新前端指向舊資料直接寫入。

## 測試與版本安全

- 已在本地執行 Node 純邏輯及模擬整合測試，增加六名裁判在六場比賽同時接手、計分、完賽、晉級／公開發布，及同場雙裁判接手、主辦重建與裁判接手同時送出、舊版結構阻擋等測試；亦核對原始 HTML/CSS、JS 語法與 Rules 安全合併。模擬測試的毫秒數不代表真實 Firebase 延遲。
- Firebase Emulator 依賴 Cloud Shell，**本地未能確認真實 Emulator 結果**；`deploy/BBX-V0.5-檢查.sh` 會強制執行，未通過不允許第二段部署。
- 真正 Firebase Callable + iPhone Safari、以及 200 人同時觀看，仍須線上測試；**本包不是正式 V1.0**。
- V0.4 已建立的測試場不會自動遷移為 V0.5。請使用新版建立新測試場；避免舊版本資料衝突。
- 不修改 `ljtreg-39954` 等報名專案，不刪正式 V1.0 賽事或報名資料，也不建立額外備份。
- 只有 V0.5 的 7 支 Functions 和合併 Rules 都確認部署成功後，才刪除 V0.4 的 7 支 Functions；不執行全專案刪除。

## Cloud Shell 用法（手機）

將 `BBX-V0.5.zip` 上傳 GitHub `rkomrz/Beyblade-X` 的 `main` 根目錄，然後依 `BBX-V0.5-CloudShell-指令.txt` 的兩段指令操作。第一段下載 + 完整檢查，第二段部署並只刪除前版 BBX 函數。網站請使用**同一份 ZIP** 裡的 `index.html` 與 `viewer.html` 覆蓋 Pages 根目錄原檔，不另建測試目錄。


## 公開發布與鎖分工修訂
詳細參閱 `docs/BBX-V0.5-鎖與公開發布稽核.md`。V0.5 修訂包共 8 支 Functions，新增只讀待發布索引的定時修復函數，每五分鐘檢查待處理紀錄。前端畫面、CSS 與正式 V1.0 一致；舊版資料不自動轉換。
