#!/usr/bin/env python3
from pathlib import Path
from html.parser import HTMLParser
import json, re, subprocess, hashlib
ROOT=Path(__file__).resolve().parents[1]
class Scan(HTMLParser):
 def __init__(self):super().__init__();self.tags=[];self.ids=[];self.scripts=[];self.script=False;self.styles=[];self.style=False
 def handle_starttag(self,tag,attrs):
  at=dict(attrs)
  if tag=='script':self.script=('src' not in at)
  elif tag=='style':self.style=True
  else:self.tags.append(tag)
  if 'id' in at:self.ids.append(at['id'])
 def handle_endtag(self,tag):
  if tag=='script':self.script=False
  if tag=='style':self.style=False
 def handle_data(self,data):
  if self.script:self.scripts.append(data)
  if self.style:self.styles.append(data)

def scan(p):
 x=Scan();x.feed(p.read_text());return x
for name in ['index','viewer']:
 original=scan(ROOT/f'baseline/{name}.v1.html');new=scan(ROOT/f'{name}.html');
 assert original.tags==new.tags,f'{name}: existing HTML tag structure changed'
 assert original.ids==new.ids,f'{name}: existing UI IDs changed'
 assert original.styles==new.styles,f'{name}: original CSS styles changed'
 assert len(set(new.ids))==len(new.ids),f'{name}: duplicated IDs'
 script='\n'.join(new.scripts)
 path=ROOT/f'tests/.{name}-js-check.js';path.write_text(script)
 subprocess.run(['node','--check',str(path)],check=True)
 path.unlink()
 print(f'PASS {name}: original HTML tags, IDs and styles preserved; JavaScript parses')
base=json.loads((ROOT/'baseline/rules.v1.json').read_text())['rules']
proposed=json.loads((ROOT/'database.rules.json').read_text())['rules']
for k in base:
 assert k in proposed,f'Existing RTDB branch removed: {k}'
for k in ['userEvents','secrets','admins','refereeSecrets','refereeUsers','refereeClaims']:
 assert base[k]==proposed[k],f'Non-score rules changed: {k}'
assert proposed['authorityBBX']['.read'] is False and proposed['authorityBBX']['.write'] is False
for key in ['rounds','finalRR']:
 assert 'authorityBBX' in proposed['events']['$eventId'][key]['.write']
 assert 'authorityBBX' in proposed['publicEvents']['$eventId'][key]['.write']
assert 'authorityBBX' in proposed['publicEvents']['$eventId']['.write']
print('PASS RTDB: V1.0 branches preserved; active-mode match writes blocked')
assert "!newData.exists()" in proposed['events']['$eventId']['.write'] and "data.child('authorityBBX')" in proposed['events']['$eventId']['.write'], 'Old browser can still delete an active tournament'
assert 'bbxV01OrganizerAuthority' in (ROOT/'functions/index.js').read_text()
assert 'v1CloudOrganizerCommand' in (ROOT/'index.html').read_text()
print('PASS organizer authority: active tournament parent delete forbidden; browser sends scalar commands')
for f in ('functions/index.js','functions/bbx-v01-core.js','functions/bbx-v01-organizer.js'):
 subprocess.run(['node','--check',str(ROOT/f)],check=True)
 print('PASS Node syntax:',f)

# Server authority is only available for newly created test events, never legacy V1.0.
backend=(ROOT/'functions/index.js').read_text()
front=(ROOT/'index.html').read_text()
for item in ['bbxV01ActivateAuthority','bbxV01DeleteAuthority','bbxV01OrganizerAuthority','bbxV01CommandAuthority']:
 assert item in backend,f'Cloud callable export missing: {item}'
for item in ["releaseTag:'BBX-V0.1'",'v1CloudOrganizerCommand','v1CloudMatchCommand','v1RafflePending']:
 assert item in front,f'Front-end authority entry missing: {item}'
assert "if(isV1Authority())" in front
assert 'authorityBBX' in proposed['events']['$eventId']['.write']
assert 'authorityBBX' in proposed['publicEvents']['$eventId']['.write']
print('PASS full active authority routing: event creation, organizer, judge, raffle, deletion')
