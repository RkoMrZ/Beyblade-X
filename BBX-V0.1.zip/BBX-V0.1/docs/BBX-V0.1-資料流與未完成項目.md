# BBX-V0.1 全檔稽核／資料流（2026-10-16）

## 改善架構

使用者認可的正式 V1.0 作為介面母版。只給由此版本建立、含 `releaseTag=BBX-V0.1` 的新賽事啟用 `events/$id/authorityBBX=active`。此權威狀態在 Cloud Functions 比對賽事快照並以 RTDB transaction 完成；舊版網頁無法在新 Rules 下修改受保護場次。

主辦／裁判送 Cloud Functions 純操作與版本序號：`bbxV01CommandAuthority`、`bbxV01OrganizerAuthority`，版本衝突拒絕，不由手機寫入場次或整張賽程。後端權威狀態：`authorityBBX/$id/board`；增量 outbox 按 seq 發布必要資料到 `events/$id` 與 `publicEvents/$id`。觀眾只讀公開小資料樹，未發布裁判 UID、權限碼與秘密。

## 已消除的舊版危險入口

- 新測試賽事建立後立即由 `bbxV01ActivateAuthority` 切換權威，啟用前會比較完整籤表，拒絕過期資料。
- 主辦名單及籤表、隨機重排及第一輪交換由伺服器計算，且 2–64 人原版結構逐組對照一致。
- 裁判名單、抽獎狀態、關閉／延長公開時間走伺服器版本指令；公開關閉不阻斷主辦記分。
- 永久刪除由 `bbxV01DeleteAuthority` 處理，限制為同 Firebase 專案、同測試版、同賽事建立者。
- 任何整場資料覆寫，在 active 權威模式必須被 Rules 拒絕；前端保留操作畫面但不允許舊版直接覆蓋。

## 自動測試

Node.js 純邏輯＋雲端資料庫 Mock：43 項通過，0 項失敗。包含完整舊版賽制初始籤表／比賽中晉級對照、主辦及裁判版本衝突、公開資料發布、刪除邊界。HTML 原始標籤、ID、CSS 完整性與 JavaScript 語法通過。

Rules Emulator 的實際權限測試只能在 Cloud Shell 第一步執行（本工作環境無法連 npm registry）。Cloud Shell 只有通過測試後才建立同版本 preflight 通行標記。本站不聲稱真實 200+ 裝置負載或 iOS/Android 已測試，這些需實際部署新建測試賽事後驗收。

## 安全部署

Cloud Shell 第一步下載 ZIP、驗證 MANIFEST、完整 Node/Rules Emulator 測試。第二步只部署本版本列出的 8 支 Cloud Functions、讀取線上 Rules 並驗證原版基線，安全合併後只對目標 RTDB Instance 部署。驗證新 Functions 與 Rules 一致才繼續。**不會清除報名系統、正式 V1.0 雲端資料、也不會創建舊版本備份。**

## 未完成的真實環境驗收

Firebase Rules Emulator（Cloud Shell 強制執行）、iOS Safari、Android Chrome 的主辦裁判互動、公開連結時效、頁面背景恢復，以及 200+ 同時觀看成本與實際負載。通過本地測試不等於完成上述線上驗收。
