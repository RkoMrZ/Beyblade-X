# BBX-V0.1｜賽程同步資料流（正式 V1.0 UI 不改）

## 唯一權威與讀取投影

| 節點 | 可讀角色 | 寫入角色 | 用途 |
|---|---|---|---|
| `authorityBBX/{eventId}/board` | Cloud Functions / Admin SDK | Cloud Functions 交易 | 唯一權威比分、場次版本、晉級、操作收據、增量 outbox |
| `events/{eventId}/rounds/{ri}/matches/{mi}` | 原版主辦／已授權裁判 | 只有 Cloud Functions 增量發布（啟用後） | 與 V1.0 原頁面相容的私人場次鏡像 |
| `events/{eventId}/finalRR/matches/{mi}` | 原版主辦／裁判 | Cloud Functions 增量發布 | 循環賽鏡像 |
| `publicEvents/{eventId}/rounds/{ri}/matches/{mi}` | 連結公開有效時的觀眾 | Cloud Functions 增量發布 | 不含執裁身分的最小公開比分 |
| `publicEvents/{eventId}/meta/syncVersion` | 觀眾 | Cloud Functions 增量發布 | **只有結構變化**才提示重抓完整投影 |
| `refereeUsers/{eventId}/{uid}`、`refereeClaims/{eventId}` | 現有授權設計 | 現有驗證流程 | Cloud Function 檢查裁判 UID 與名稱配對 |

## 操作規約

| 行為 | 由手機發送 | Cloud Function 負責 | 向外更新 |
|---|---|---|---|
| 接手場次 | `claim,target,version,opId` | 權限核對、同人不可同時執裁兩場、版本交易 | 私人場次、無觀眾通知 |
| 快速加分／手動比分 | `score,sa,sb,target,version,opId` | 驗證比分／版本／執裁身分 | 此場私人比分；未完成的普通場次才更新此場公開比分 |
| 此場完成 | `complete,sa,sb,target,version,opId` | 驗證 4 分、決定勝者、計算晉級、拒絕覆蓋已開賽下游 | 本場和受到影響的下游場次 |
| 修改已完成比分 | `claim → score → complete` | 原結果在確認前保持觀眾端不變；完成時一次性審核 | 確認成功才發布新結果 |
| 重設／清除 | `reset/clear,target,version,opId` | 檢查裁判鎖與後續已開賽狀態 | 本場和真正受影響的下游 |
| 釋放執裁 | `release,target,version,opId` | 停止該 UID 執裁；捨棄未確認改判 | 私人場次，公開結果不變 |

## 何時能完整同步

- 首次開啟賽事：載入一次可讀投影；之後只監聽必要輪次及小節點。原版主辦頁已有按輪次 `child_*` 監聽，不重做整套 UI。
- SSE 斷線重連、iOS 從背景恢復：可以為校正重新取得一份完整最新投影（需要節流／jitter）。
- 新增／刪除輪次、三人循環資格首次成形等結構變化：透過 `syncVersion` 觸發一次性結構重新同步。
- 無資料變動但持續看著比分：**不應**每秒輪詢整張賽程。觀眾頁已移除固定四分鐘完整 GET。

## 安全切換門檻（尚未通過）

- 必須補齊主辦所有直寫操作的 Cloud Function 指令，並以版本檢查阻擋舊手機；不能只把比分搬到雲端而放任名單／配對／賽事結構被舊前端寫回。
- 完成一次性既有賽事資料匯入、比對主辦鏡像與公開投影、受控啟用旗標與回滾計畫。`bbxV01StageAuthority` 只是存入暫存權威資料，不是啟用。
- Firebase Emulator 驗證 Rules 安全性（包括祖先授權規則）、操作競爭、網路失敗、發布失敗後補發，並確認 UI 行為與原 V1.0 一致。
- 瀏覽器實測主辦／裁判／觀眾／背景切換／舊手機升級，並進行真實模擬 200 個觀眾連線的讀取／頻寬計量。

## 本輪程式進度（未部署）

- 新增 `bbxV01OrganizerAuthority`：`rename / addPlayer / delPlayer / rebuild / randomRebuild / swapPlayers` 不接受手機上的整張賽事快照，只使用雲端權威 board 與 `expectedSeq` 交易。
- 只允許主辦／共同主辦操作；已開始比賽時阻擋重新編排；結構更新由 Cloud Functions 發布到舊版 UI 相容鏡像。
- 啟用雲端權威後，RTDB 父節點的 owner 刪除權限也會被拒絕，避免舊版手機把整場賽事刪掉。
- **仍未完成**：裁判名單增減、賽事公開時間／刪除、賽事建立後啟用交易、真實 Emulator 與多人 iOS 實測。因此部署安全鎖維持。
