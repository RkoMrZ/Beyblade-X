'use strict';
// V1.0 staged authority candidate. DO NOT deploy without full organizer-operation migration.
const admin=require('firebase-admin');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onValueWritten}=require('firebase-functions/v2/database');
const C=require('./bbx-v01-core');
const PROJECT='ljt-beyblade-x';
const DB_URL='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app';
const VERSION='bbx-v0.1-authority-1';
admin.initializeApp({projectId:PROJECT,databaseURL:DB_URL});
const db=admin.database();
const OPT={region:'asia-southeast1',timeoutSeconds:60,maxInstances:4};
const ID=/^[A-Za-z0-9_-]{6,100}$/;
const id=x=>{if(!ID.test(x||''))throw new HttpsError('invalid-argument','賽事代碼格式錯誤');return x};
function auth(req,google=false){
 if(req.data?.clientVersion!==VERSION)throw new HttpsError('failed-precondition','舊版網頁無法修改此賽事，請更新網頁');
 if(!req.auth?.uid)throw new HttpsError('unauthenticated','請先登入');
 if(google&&req.auth.token?.firebase?.sign_in_provider!=='google.com')throw new HttpsError('permission-denied','主辦需 Google 身分');
 return req.auth.uid;
}
function catchError(e){
 if(e instanceof HttpsError)throw e;
 if(e instanceof C.CommandError)throw new HttpsError(e.code,e.message);
 console.error('V1 authority error',e);
 throw new HttpsError('internal','伺服器尚未確認結果；請使用相同操作代碼查詢，不要重複點擊');
}
const base=eventId=>`authorityBBX/${eventId}`;
function projectGuard(){
 const project=process.env.GCLOUD_PROJECT||process.env.GCP_PROJECT||JSON.parse(process.env.FIREBASE_CONFIG||'{}').projectId;
 if(project!==PROJECT)throw new HttpsError('failed-precondition','Firebase 專案不符');
}
async function authz(uid,eventId){
 const [e,claims,ref,adminFlag]=await Promise.all([
   db.ref(`events/${eventId}/ownerUid`).get(),
   db.ref(`refereeClaims/${eventId}`).get(),
   db.ref(`refereeUsers/${eventId}/${uid}`).get(),
   db.ref(`admins/${eventId}/${uid}`).get()
 ]);
 const owner=e.val()===uid;
 let refereeName=null;
 if(ref.exists())for(const x of Object.values(claims.val()||{}))if(x?.uid===uid){refereeName=String(x.name||'');break;}
 return {owner,admin:adminFlag.exists(),referee:ref.exists()&&!!refereeName,refereeName};
}
async function publish(eventId){
 const ref=db.ref(base(eventId));const ownerToken=require('node:crypto').randomBytes(16).toString('hex');
 let claimed=false;
 const lock=ref.child('publishing');const now=Date.now();
 const taken=await lock.transaction(x=>!x||x.expiresAt<now?{token:ownerToken,expiresAt:now+45000}:undefined,undefined,false);
 if(!taken.committed)return {busy:true};claimed=true;
 try{
  let cursor=Number((await ref.child('publishedSeq').get()).val()||0);
  for(let batch=0;batch<24;batch++){
   const item=(await ref.child(`board/outbox/${String(cursor+1).padStart(12,'0')}`).get()).val();
   if(!item)break;
   const changes={};let structure=false;
   for(const ch of item.changes||[]){
     changes[`events/${eventId}/${ch.path}`]=ch.value;
     if(ch.publicChanged!==false)changes[`publicEvents/${eventId}/${ch.path}`]=ch.publicValue;
     if(ch.path==='finalRR/players')structure=true;
   }
   if(structure){
     const t=Date.now();changes[`events/${eventId}/syncVersion`]=t;changes[`publicEvents/${eventId}/meta/syncVersion`]=t;
   }
   if(Object.keys(changes).length)await db.ref().update(changes);
   // Idempotent updates above can safely be retried if this bookkeeping write fails.
   await ref.update({publishedSeq:cursor+1,[`board/outbox/${String(cursor+1).padStart(12,'0')}`]:null});
   cursor++;
  }
  return {ok:true,publishedSeq:cursor};
 }finally{
   if(claimed)await lock.transaction(x=>x?.token===ownerToken?null:undefined,undefined,false);
 }
}
// Explicit owner-initiated staging; does not touch the website or existing Rules.
exports.bbxV01StageAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const ev=(await db.ref(`events/${eventId}`).get()).val();
  if(!ev||ev.ownerUid!==uid)throw new HttpsError('permission-denied','只有原賽事主辦能啟用');
  const b=C.bootstrap(ev);
  const t=await db.ref(`${base(eventId)}/board`).transaction(cur=>cur===null?b:undefined,undefined,false);
  return {ok:true,staged:true,created:t.committed,active:ev.authorityBBX==='active'};
 }catch(e){catchError(e)}
});
// This endpoint deliberately refuses to activate until operator has verified Rule deployment
// and tested all V1 organizer flows. Safe default: stage only, not automatic migration.
exports.bbxV01CommandAuthority=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId);
  const gate=(await db.ref(`events/${eventId}/authorityBBX`).get()).val();
  if(gate!=='active')throw new HttpsError('failed-precondition','尚未切換為雲端權威版本');
  const permission=await authz(uid,eventId);
  if(!permission.owner&&!permission.admin&&!permission.referee)throw new HttpsError('permission-denied','未取得主辦或裁判授權');
  let error=null,replay=null;
  const t=await db.ref(`${base(eventId)}/board`).transaction(cur=>{
   error=null;replay=null;
   try{
     const result=C.apply(cur,uid,req.data,Date.now(),permission);
     if(result.replay){replay=result.receipt;return undefined;}
     return result.board;
   }catch(e){error=e;return undefined;}
  },undefined,false);
  if(!t.committed){if(error)throw error;if(replay)return {...replay,replayed:true};throw new HttpsError('aborted','變更尚未確認，請按原操作代碼查詢');}
  const b=t.snapshot.val(),result=b.receipts?.[req.data.opId]?.result;
  if(!result)throw new HttpsError('aborted','操作尚未確認，請用操作代碼查詢');
  const published=await publish(eventId);
  return {...result,published:published.publishedSeq>=result.seq};
 }catch(e){catchError(e)}
});
exports.bbxV01GetOperation=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req),eventId=id(req.data?.eventId),opId=req.data?.opId;
  if(typeof opId!=='string'||!/^[a-f0-9]{48}$/.test(opId))throw new HttpsError('invalid-argument','操作代碼無效');
  const r=(await db.ref(`${base(eventId)}/board/receipts/${opId}`).get()).val();
  if(!r)return {found:false};
  if(r.uid!==uid)throw new HttpsError('permission-denied','不能讀取別人的操作結果');
  return {found:true,...r.result};
 }catch(e){catchError(e)}
});
exports.bbxV01RepairPublication=onCall(OPT,async req=>{
 try{
  projectGuard();const uid=auth(req,true),eventId=id(req.data?.eventId);
  const owner=(await db.ref(`events/${eventId}/ownerUid`).get()).val();
  if(owner!==uid)throw new HttpsError('permission-denied','只有主辦能要求修復');
  return publish(eventId);
 }catch(e){catchError(e)}
});
exports.bbxV01PublishAuthority=onValueWritten({ref:'authorityBBX/{eventId}/board/seq',region:'asia-southeast1',instance:'ljt-beyblade-x-default-rtdb',retry:true},async e=>{
 projectGuard();if(!e.data.after.exists())return;
 const n=id(e.params.eventId),target=Number(e.data.after.val());
 const r=await publish(n);
 if(r.busy)return;
 if(r.publishedSeq<target)throw Error('Incremental publication pending');
});
