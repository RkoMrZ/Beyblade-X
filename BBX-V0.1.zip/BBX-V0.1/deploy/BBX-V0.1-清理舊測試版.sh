#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
# Called only AFTER the current version has deployed successfully.
# A new release must name EXACTLY one previous BBX-V0.* release in its manifest.
PREVIOUS="$(python3 - <<'PY2'
import json,re,sys
m=json.load(open('MANIFEST.json'))
assert m['firebase_project']=='ljt-beyblade-x'
assert m['release_status']=='TEST_DEPLOY_READY'
prev=m.get('previous_release')
if prev is not None and not re.fullmatch(r'BBX-V0\.[1-9][0-9]*',prev):
 sys.exit('拒絕不明舊版本：'+str(prev))
print(prev or '')
PY2
)"
if [[ -z "$PREVIOUS" ]]; then
 echo 'BBX-V0.1 為首個測試版：沒有前一版需要刪除。'
 exit 0
fi
# Delete only explicit exports of the immediately previous test release.
case "$PREVIOUS" in
  BBX-V0.*) oldn="${PREVIOUS#BBX-V0.}";;
  *) echo '拒絕刪除：非 BBX 測試版'; exit 2;;
esac
printf -v PRE_NUM '%02d' "$oldn"
PREFIX="bbxV${PRE_NUM}"
if [[ "$PREFIX" == 'bbxV01' && "$PREVIOUS" == 'BBX-V0.1' ]] || [[ "$PREFIX" =~ ^bbxV[0-9]{2,}$ ]]; then
 for suffix in StageAuthority CommandAuthority GetOperation RepairPublication PublishAuthority OrganizerAuthority ActivateAuthority DeleteAuthority; do
   firebase functions:delete "${PREFIX}${suffix}" --region asia-southeast1 --project ljt-beyblade-x --force
 done
else
 echo '拒絕刪除：舊版函式識別不符'; exit 2
fi
# Remove ONLY the previous BBX test build from Cloud Shell. No deployed data removed.
[[ "$PREVIOUS" != 'BBX-V0.1' || "$(basename "$ROOT")" != 'BBX-V0.1' ]] || { echo '拒絕刪除目前版本'; exit 2; }
rm -rf -- "$HOME/$PREVIOUS"
rm -f -- "$HOME/$PREVIOUS.zip"
# GitHub Pages ZIP source cleanup requires authenticated GitHub git push.
# Do not auto-delete anything in a repository without a checked-out source branch.
if [[ -n "${BBX_PAGES_REPO_DIR:-}" && -d "$BBX_PAGES_REPO_DIR/.git" ]]; then
  (cd "$BBX_PAGES_REPO_DIR" && git rm --ignore-unmatch -- "$PREVIOUS.zip" && \
   if ! git diff --cached --quiet; then git commit -m "Remove old BBX test release $PREVIOUS" && git push; fi)
else
  echo "GitHub 舊 ZIP $PREVIOUS.zip 尚未刪除：未提供具寫入權限的 BBX_PAGES_REPO_DIR。"
fi
printf '已完成 BBX 前版函式及 Cloud Shell 檔案清理；不含報名系統函式及 Firebase 賽事資料。\n'
