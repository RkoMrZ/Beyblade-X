#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PROJECT='ljt-beyblade-x'
REGION='asia-southeast1'
[[ "$(basename "$ROOT")" == 'BBX-V0.1' ]] || { echo '停止：不是 BBX-V0.1 目錄' >&2; exit 2; }
python3 - <<'PY'
import json
m=json.load(open('MANIFEST.json'))
assert m['project_id']=='BBX-V0.1' and m['firebase_project']=='ljt-beyblade-x', '不是賽程表專案'
PY
command -v gcloud >/dev/null || { echo '請在 Google Cloud Shell 執行（找不到 gcloud）' >&2; exit 2; }
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
printf '===== BBX 舊版 Functions 清理：只限 %s/%s =====\n' "$PROJECT" "$REGION"
gcloud functions list --v2 --regions="$REGION" --project="$PROJECT" --format=json > "$TMP_DIR/before.json"
python3 deploy/BBX-V0.1-盤點舊函數.py "$TMP_DIR/before.json" "$TMP_DIR/delete.txt"
if [[ ! -s "$TMP_DIR/delete.txt" ]]; then
  echo '已無任何舊版已知函式；無須刪除。'
  exit 0
fi
while IFS= read -r function_name; do
  [[ -z "$function_name" ]] && continue
  # ONLY names found in the live gcloud inventory and the exact historical allowlist.
  printf '刪除舊賽程表函式：%s\n' "$function_name"
  gcloud functions delete "$function_name" --region="$REGION" --project="$PROJECT" --quiet
done < "$TMP_DIR/delete.txt"
gcloud functions list --v2 --regions="$REGION" --project="$PROJECT" --format=json > "$TMP_DIR/after.json"
python3 deploy/BBX-V0.1-盤點舊函數.py "$TMP_DIR/after.json" "$TMP_DIR/remaining.txt"
if [[ -s "$TMP_DIR/remaining.txt" ]]; then
  echo '部分舊函式仍存在。已停止，重新執行可繼續刪除剩餘項目。' >&2
  exit 1
fi
echo '成功：已清除舊 BeybladeX-V0.1 專屬 Functions；其他 Functions 與 Realtime Database 完全未操作。'
