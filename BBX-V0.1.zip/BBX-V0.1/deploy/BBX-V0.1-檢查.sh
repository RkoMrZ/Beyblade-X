#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ "$(basename "$ROOT")" != 'BBX-V0.1' ]]; then
  echo '拒絕：必須從 BBX-V0.1 專案資料夾執行。' >&2; exit 2
fi
cd "$ROOT"
python3 - <<'PY2'
import json,hashlib
from pathlib import Path
root=Path.cwd(); manifest=json.loads((root/'MANIFEST.json').read_text())
assert manifest['project_id']=='BBX-V0.1', '錯誤：不是 BBX-V0.1 專案'
assert manifest['firebase_project']=='ljt-beyblade-x', '錯誤：不是賽程表 Firebase 專案'
for item in manifest['files']:
 p=root/item['path']
 assert p.is_file(),f'檔案遺失：{item["path"]}'
 raw=p.read_bytes()
 assert len(raw)==item['bytes'],f'檔案長度錯誤：{p}'
 assert hashlib.sha256(raw).hexdigest()==item['sha256'],f'檔案版本不符：{p}'
assert 'ljtreg' not in (root/'.firebaserc').read_text(), '錯誤：指向報名系統'
print('PASS：BBX-V0.1 專案名稱、Firebase 專案與檔案版本校驗')
print('發布狀態：'+manifest['release_status'])
PY2
node --test tests/authority.test.js
python3 tests/check_static.py
printf 'BBX-V0.1 檢查已完成（不代表可正式部署）。\n'
