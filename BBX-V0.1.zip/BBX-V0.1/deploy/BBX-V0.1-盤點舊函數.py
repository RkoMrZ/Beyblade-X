#!/usr/bin/env python3
"""Inventory the exact 14 historical tournament Functions from BeybladeX-V0.1.
No prefix-based deletion. Never selects other functions or Firebase projects.
"""
import json
import sys
from pathlib import Path

PROJECT = 'ljt-beyblade-x'
REGION = 'asia-southeast1'
OLD_NAMES = frozenset('''
createEventV01 getEventV01 getJoinCodeV01 joinEventV01
claimMatchV01 scoreMatchV01 completeMatchV01 releaseMatchV01
resetMatchV01 getOperationV01 setPublicV01 deleteEventV01
publishChangesV01 repairPublicationV01
'''.split())
NEW_NAMES = frozenset('''
bbxV01StageAuthority bbxV01CommandAuthority bbxV01GetOperation
bbxV01RepairPublication bbxV01PublishAuthority
'''.split())

def inventory(items):
    if not isinstance(items, list):
        raise ValueError('Cloud Functions 清單不是陣列，停止')
    old, untouched, suspicious = [], [], []
    seen = set()
    for item in items:
        resource = item.get('name') if isinstance(item, dict) else None
        if not isinstance(resource, str):
            raise ValueError('Cloud Functions 回傳缺少 name，停止')
        parts = resource.split('/')
        # gcloud returns fully-qualified v2 resource identifiers
        if len(parts) != 6 or parts[:5] != ['projects', PROJECT, 'locations', REGION, 'functions']:
            raise ValueError('不是預期專案/區域的函式：' + resource)
        name = parts[-1]
        if name in seen:
            raise ValueError('重複出現函式：' + name)
        seen.add(name)
        if name in OLD_NAMES:
            old.append(name)
        else:
            untouched.append(name)
            if name not in NEW_NAMES and (name.endswith('V01') or name.startswith(('bxv01', 'bbxV01'))):
                suspicious.append(name)
    return sorted(old), sorted(untouched), sorted(suspicious)


def main():
    if len(sys.argv) != 3:
        raise SystemExit('使用方式：盤點舊函數.py inventory.json plan.txt')
    old, untouched, suspicious = inventory(json.loads(Path(sys.argv[1]).read_text()))
    print('【可清除】已部署的舊賽程表函式：' + (', '.join(old) if old else '無'))
    print('【不清除】其他函式：' + (', '.join(untouched) if untouched else '無'))
    if suspicious:
        print('注意：發現未列入舊版本已知清單的類似名稱：' + ', '.join(suspicious))
        print('這些名稱不會自動刪除。')
    Path(sys.argv[2]).write_text(''.join(x+'\n' for x in old))
    print(f'舊版需刪除 {len(old)} 支，其他 {len(untouched)} 支完全不處理。')

if __name__ == '__main__':
    try:main()
    except (ValueError, KeyError, json.JSONDecodeError) as exc:raise SystemExit('停止：' + str(exc))
