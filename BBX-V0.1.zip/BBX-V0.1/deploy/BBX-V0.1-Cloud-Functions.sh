#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == BBX-V0.1 ]] || { echo 'STOP: incorrect project folder'; exit 2; }
python3 - <<'PY'
import json,sys
m=json.load(open('MANIFEST.json'))
assert m['project_id']=='BBX-V0.1' and m['firebase_project']=='ljt-beyblade-x'
assert m['release_status']=='TEST_DEPLOY_READY','尚未核准供測試部署'
PY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == '22' ]] || { echo 'STOP: Node.js 22 required'; exit 3; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v01-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: run the complete preflight and emulator tests first'; exit 3; }
for c in firebase gcloud curl python3; do command -v "$c" >/dev/null || { echo "STOP: missing $c"; exit 3; }; done
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: gcloud selected wrong project'; exit 3; }
[[ "$(python3 -c 'import json; print(json.load(open(".firebaserc"))["projects"]["default"])')" == ljt-beyblade-x ]] || { echo 'STOP: Firebase project mismatch'; exit 3; }
PROJECT=ljt-beyblade-x
INSTANCE=ljt-beyblade-x-default-rtdb
RULES_URL="https://${INSTANCE}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
echo '=== Fetching existing BBX Realtime Database Rules for safe merge ==='
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS --retry 3 --connect-timeout 10 --max-time 45 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v01-live-rules.json
python3 deploy/BBX-V0.1-安全合併Rules.py /tmp/bbx-v01-live-rules.json /tmp/bbx-v01-merged-rules.json
cp /tmp/bbx-v01-merged-rules.json database.rules.json
firebase target:apply database bbxv01-main "$INSTANCE" --project "$PROJECT"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('firebase.json');j=json.loads(p.read_text());j['database']={'target':'bbxv01-main','rules':'database.rules.json'};p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
PY
echo '=== Deploying BBX ONLY, no other project/cloud functions ==='
npm --prefix functions install --no-audit --no-fund
FN='functions:bbxV01StageAuthority,functions:bbxV01CommandAuthority,functions:bbxV01GetOperation,functions:bbxV01RepairPublication,functions:bbxV01PublishAuthority,functions:bbxV01OrganizerAuthority,functions:bbxV01ActivateAuthority,functions:bbxV01DeleteAuthority'
firebase deploy --only "$FN" --project "$PROJECT" --non-interactive
firebase deploy --only database:bbxv01-main --project "$PROJECT" --non-interactive
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS --retry 3 --connect-timeout 10 --max-time 45 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v01-rules-post.json
python3 - <<'PY'
import json
from pathlib import Path
def load(p):
 d=json.loads(Path(p).read_text());return json.loads(d) if isinstance(d,str) else d
want=load('/tmp/bbx-v01-merged-rules.json')
have=load('/tmp/bbx-v01-rules-post.json')
assert have==want,'STOP: online Rules did not match verified merged BBX rules'
print('PASS: Firebase Rules online matches merged rules, unrelated existing rules preserved')
PY
# Do not use firebase deploy --only functions: it could affect unrelated apps.
gcloud functions list --v2 --regions=asia-southeast1 --project "$PROJECT" --format=json > /tmp/bbx-v01-deployed-functions.json
python3 - <<'PYVERIFY'
import json
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
items=json.loads(Path('/tmp/bbx-v01-deployed-functions.json').read_text())
names={str(f['name']).split('/')[-1] for f in items}
missing=set(m['functions_exports'])-names
assert not missing, 'STOP: expected BBX functions missing from cloud deployment: '+str(sorted(missing))
print('PASS: all',len(m['functions_exports']),'BBX V0.1 Cloud Functions are deployed in expected region')
PYVERIFY
bash deploy/BBX-V0.1-清理舊測試版.sh
printf '\nPASS: BBX-V0.1 Functions and Rules deployed for TESTING.\n'
printf 'Next: deploy the index.html and viewer.html from this SAME BBX package to your GitHub Pages root.\n'
