#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
# BBX-V0.x tournament ONLY. Never bulk deploy/delete all functions. No backup or cleanup of RTDB data.
python3 - <<'PY2'
import json,sys
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
if m.get('project_id')!='BBX-V0.1' or m.get('firebase_project')!='ljt-beyblade-x':
 sys.exit('停止：專案不符。')
if m.get('release_status')!='RELEASE_APPROVED':
 sys.exit('停止：BBX-V0.1 仍是開發候選版，尚未通過完整整合／權限／實機測試；未執行任何 Firebase 部署或清理。')
PY2
bash "$ROOT/deploy/BBX-V0.1-檢查.sh"
if ! command -v firebase >/dev/null 2>&1; then
 echo 'Cloud Shell 尚無 Firebase CLI，請先安裝登入。' >&2; exit 3
fi
npm --prefix functions install --no-audit --no-fund
firebase deploy \
  --only 'functions:bbxV01StageAuthority,functions:bbxV01CommandAuthority,functions:bbxV01GetOperation,functions:bbxV01RepairPublication,functions:bbxV01PublishAuthority,functions:bbxV01OrganizerAuthority' \
  --project ljt-beyblade-x --non-interactive
# Only after a successful new deployment, remove exactly the previous BBX release's named functions/files.
bash "$ROOT/deploy/BBX-V0.1-清理舊測試版.sh"
echo 'BBX-V0.1 Functions 部署完成；無其他專案函數遭操作。'
