# BBX-V0.1｜原正式 V1.0 介面延伸的雲端權威測試版

**版本：BBX-V0.1；Firebase：`ljt-beyblade-x`；獨立線上報名系統不在此專案操作範圍。**

保留使用者認可的正式版 V1.0 `index.html`、`viewer.html` 原有 HTML 標籤、元素 ID、CSS 與畫面操作。雲端權威只接管由本測試版新建的賽事（`releaseTag=BBX-V0.1`）。舊版 V1.0 賽事不自動移轉。

## Cloud Shell 使用兩段指令

先將 `BBX-V0.1.zip` 放到 GitHub `rkomrz/Beyblade-X` 的 `main` 根目錄。

**第一段：完整下載及測試（本機 Node.js、原版流程對照與 Firebase Rules Emulator）**

```bash
cd ~ && curl -fLsS --retry 3 -o BBX-V0.1.zip https://raw.githubusercontent.com/rkomrz/Beyblade-X/main/BBX-V0.1.zip && unzip -tq BBX-V0.1.zip && unzip -oq BBX-V0.1.zip && cd ~/BBX-V0.1 && bash deploy/BBX-V0.1-檢查.sh
```

**第二段：一鍵只部署 BBX 的 Cloud Functions 與 Realtime Database Rules**

```bash
cd ~/BBX-V0.1 && bash deploy/BBX-V0.1-Cloud-Functions.sh
```

第二段只有第一段完整成功並留下同版本的本機驗證標記才執行。它會先讀取當下線上 Rules，檢查未知改動並僅合併 BBX 權限；只部署 `bbxV01...` 八支 Functions；不清除資料庫賽事、不刪不相關雲端函數。若有差異、權限不足或部署失敗，立即停止；不要繼續上傳網站。

完成後，再把此壓縮檔的 `index.html`、`viewer.html` 上傳到 GitHub Pages 的正式網站根目錄。單純上傳 ZIP 並不會更新網站首頁。

## 目前完成的功能

- 對照原 V1.0 2–64 人數及不同賽制，修正籤表建立與 BYE 晉級。
- 伺服器作為比分、晉級和名單編輯的唯一決策者，裁判操作含 matchVersion/序號及 opId，拒絕舊版快照覆蓋。
- 由伺服器啟用新建測試賽事、修改名單、重排籤表、關閉／延長公開連結、修改裁判名單、更新抽獎狀態、永久刪除賽事。
- 觀眾只讀公開投影；操作只發布必要比分/欄位，避免將裁判 UID 或鎖資訊送到觀眾節點。
- 原 V1.0 非測試賽事不強制切換。

## 驗證限制

本地已執行 Node.js 43 項測試與靜態檢查。此工作環境不能連到 npm 套件庫，也不能透過 Chromium 載入頁面，因此**並未在本地完成 Firebase Rules Emulator 或真實 iOS/Android 的端到端測試**。Cloud Shell 第一段有強制 Rules Emulator 測試，只有通過才能執行第二段。

即使 Cloud Shell 測試通過，仍請用**新建的測試賽事**測試登入、裁判掃碼、多人比分、公開即時查看、iOS 前景背景切換及刪除。200+ 台真實手機同時觀看的費用／負載，沒有在本地實際測量，不能當作已確認通過。

目前測試版不做歷史備份，測試成功後升到 `BBX-V0.2` 才清理前一個已部署 BBX 測試版；正式發版才使用 `BBX-V1.0`。
