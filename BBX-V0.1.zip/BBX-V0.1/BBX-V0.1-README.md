# BBX-V0.1｜戰鬥陀螺賽程表測試版（以原正式 V1.0 為母版）

**測試版命名：BBX-V0.1 → 下次重部署 BBX-V0.2 → BBX-V0.3。正式釋出後才使用 BBX-V1.0。**

- ZIP 與 Cloud Shell 資料夾：`BBX-V0.1.zip`、`~/BBX-V0.1/`。
- Firebase 專案（賽程表專用）：`ljt-beyblade-x`；**不涉及獨立線上報名專案**。
- Cloud Functions exports 全部以前綴 `bbxV01` 命名；下次改為 `bbxV02`，不使用 `--only functions` 全部部署。
- 官方頁面仍是 `index.html`、`viewer.html`，原有 HTML／CSS 與操作 UI 不重製。
- 三個正式原檔留在 `baseline/` 作為程式的來源母版，而非每個測試版的舊版本備份。
- Firebase 資料結構沿用原版既有節點，新增穩定雲端權威節點 `authorityBBX`（測試版升級不清掉賽事資料）。

## 手機 Cloud Shell：兩段指令

先將 `BBX-V0.1.zip` 上傳至 GitHub Pages 公開目錄，供 Cloud Shell 直接從網址下載。此包**沒有代替你上傳 GitHub**。

**1. 下載、解壓、版本驗證與離線測試（可直接一次貼上）**

```bash
bash -lc 'set -Eeuo pipefail; cd ~; curl --fail --location --retry 3 --output BBX-V0.1.zip "https://rkomrz.github.io/Beyblade-X/BBX-V0.1.zip"; unzip -tq BBX-V0.1.zip >/dev/null; unzip -q -o BBX-V0.1.zip; cd ~/BBX-V0.1; bash deploy/BBX-V0.1-檢查.sh'
```

**2. 完整開發／整合測試結束、正式核准後的 Functions 一次部署與前一版清理**

```bash
cd ~/BBX-V0.1 && bash deploy/BBX-V0.1-Cloud-Functions.sh
```

此時仍是 **候選版**，上述第二段會停止，不會執行部署或清理。必須等主辦全部操作移轉、Emulator／Rules／實機／多人負載驗證完成，正式發行檔才可執行。

## 前一個測試版清理規則

每次**新的** V0.x 已成功部署後，僅清除 `MANIFEST.json` 中 `previous_release` 指定的**上一個** BBX 測試版：

- Cloud Functions：只刪除上一版的 `bbxVxxStageAuthority`、`bbxVxxCommandAuthority`、`bbxVxxGetOperation`、`bbxVxxRepairPublication`、`bbxVxxPublishAuthority`；Firebase 專案嚴格固定 `ljt-beyblade-x` 與區域 `asia-southeast1`。
- Cloud Shell：只刪前一個 `~/BBX-V0.x/` 及對應 ZIP。
- GitHub Pages：前一版 ZIP 刪除需在已授權的 Git 儲存庫執行，且僅刪同名 ZIP；若未提供 Git repo 本機路徑，會報告尚未清理，**不會宣稱完成**。
- **不清理**線上報名系統任何函數或資料、不刪 Firebase 賽事節點、不操作未列明的舊函數、不建立舊版備份。

## 重要現況

這份包是「原正式 V1.0 延伸改良的測試 V0.1」，並非測試完成的可部署版本。`MANIFEST.json` 仍是 `DEVELOPMENT_CANDIDATE_DO_NOT_DEPLOY`，部署腳本保留阻擋。主辦直寫操作仍待雲端化；不可上線套用新 Rules。原版內建介面仍完整保留。
