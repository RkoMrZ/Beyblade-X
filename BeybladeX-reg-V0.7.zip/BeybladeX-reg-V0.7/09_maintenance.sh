#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
INSTANCE=ljtreg-39954-default-rtdb
case "${1:-status}" in
 on)
  # Do not enable a flag that a previous backend does not yet enforce.
  [ -f .maintenance-ready ] || { echo 'STOP: install V0.7 maintenance gate via 08_release.sh first'; exit 2; }
  tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
  printf 'true\n' > "$tmp"
  firebase database:set /registrationServiceState/active "$tmp" --force --project "$PROJECT" --instance "$INSTANCE"
  firebase deploy --only hosting --config firebase.maintenance.json --project "$PROJECT" --non-interactive
  echo 'MAINTENANCE_ON: new operations blocked; already accepted operations may finish.'
  ;;
 off)
  [ -f .backend-completed ] || { echo "STOP: complete 08_release.sh before reopening"; exit 2; }
  # Resume only after the actual app assets are live and verified.
  bash 07_deploy_hosting.sh
  python3 maintenance/verify_hosting.py
  tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
  printf 'false\n' > "$tmp"
  firebase database:set /registrationServiceState/active "$tmp" --force --project "$PROJECT" --instance "$INSTANCE"
  echo MAINTENANCE_OFF
  ;;
 status) firebase database:get /registrationServiceState --project "$PROJECT" --instance "$INSTANCE";;
 *) echo 'Usage: bash 09_maintenance.sh on|off|status'; exit 2;;
esac
