#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
umask 077
exec 9>.release.lock
flock -n 9 || { echo 'Deployment already running: reconnect tmux.'; exit 3; }
[ ! -f .release-completed ] || { echo 'RELEASE_ALREADY_COMPLETED: no redeploy'; exit 0; }
exec > >(tee -a release.log) 2>&1
trap 'rc=$?; if [ "$rc" -ne 0 ]; then echo "RELEASE_STOPPED=$rc. If maintenance was enabled it stays enabled. Data is not reset. Fix the reported error and run bash 08_release.sh in this tmux to resume."; fi' EXIT
sha256sum -c FILE_SHA256.txt >/dev/null
if [ ! -f .preflight-ok ]; then bash 01_preflight.sh; date -u > .preflight-ok; fi
if [ ! -f .maintenance-ready ]; then
 python3 maintenance/prepare_bootstrap.py
 npm ci --prefix .bootstrap-functions --no-audit --no-fund
 # Exact V06 implementation plus only a maintenance gate: live forms stay compatible.
 firebase deploy --only functions:registration,database --config .firebase-bootstrap.json --project ljtreg-39954 --non-interactive
 date -u > .maintenance-ready
fi
# Always reassert maintenance on resume; never automatically reopen on failure.
bash 09_maintenance.sh on
echo 'Waiting 130 seconds for operations accepted before maintenance to finish.'
python3 -c 'import time; time.sleep(130)'
bash 02_backup_database.sh
if [ ! -f .backend-completed ]; then bash 03_deploy_backend.sh; date -u > .backend-completed; fi
bash 07_deploy_hosting.sh
bash 05_verify.sh
# Old V03-V05 endpoints were confirmed absent above; the drain already elapsed.
legacy_gate=$(mktemp)
node -e 'process.stdout.write(String(Date.now()-1))' > "$legacy_gate"
firebase database:set /registrationMaintenanceV06/legacyCleanupReadyAt "$legacy_gate" --force --project ljtreg-39954 --instance ljtreg-39954-default-rtdb
rm -f "$legacy_gate"
# The sole reopen point follows every verification step.
tmp=$(mktemp)
printf 'false\n' > "$tmp"
firebase database:set /registrationServiceState/active "$tmp" --force --project ljtreg-39954 --instance ljtreg-39954-default-rtdb
rm -f "$tmp"
date -u > .release-completed
echo 'RELEASE_COMPLETED V0.7: V06 events, entries, codes, APIs and local receipts retained.'
