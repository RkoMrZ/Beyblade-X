#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
bash 06_source_guard.sh
# Keep exactly the V06 endpoints used by live and older browser pages.
firebase deploy --only functions:registration,database --project ljtreg-39954 --non-interactive
