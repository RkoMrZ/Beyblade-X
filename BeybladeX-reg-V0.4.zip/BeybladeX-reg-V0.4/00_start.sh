#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
SESSION=reg-v04-release
if ! tmux has-session -t "$SESSION" 2>/dev/null; then
 tmux new-session -d -s "$SESSION" -c "$PWD" 'bash -lc '\''source "$HOME/.nvm/nvm.sh" && nvm use 22 && bash 08_release.sh; exec bash'\'''
fi
if [ -n "${TMUX:-}" ]; then tmux switch-client -t "$SESSION"; else tmux attach-session -t "$SESSION"; fi
