#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
python3 build.py
node - <<'JS'
const fs=require('fs'),assert=require('assert/strict'),path=require('path');
const c=JSON.parse(fs.readFileSync('RELEASE_VERSION.json')),h=JSON.parse(fs.readFileSync('firebase.json')).hosting;
assert.equal(c.release,'V0.4');assert.equal(c.apiPrefix,'regV04');assert.equal(c.dataSuffix,'V04');assert.equal(c.firebaseProject,'ljtreg-39954');
const f=fs.readFileSync('functions/index.js','utf8');
const names=[...f.matchAll(/exports\.(reg\w+)\s*=/g)].map(m=>m[1]).sort();
assert.deepEqual(names,['CreateEvent','UpdateEvent','SetOpen','Submit','Review','EditEntry','DeleteEntry','DeleteEvent','MyRank'].map(n=>'regV04'+n).sort());
for(const file of ['functions/index.js','database.rules.json',...fs.readdirSync('web/js').map(f=>'web/js/'+f)]){
 const s=fs.readFileSync(file,'utf8');assert(!/\bregV0[123]\w*|\b\w+V0[123]\b|reg-v0[123]/.test(s),file+' has stale namespace');
}
for(const file of ['index.html','signup.html','status.html']){const s=fs.readFileSync('reg/'+file,'utf8');assert(s.includes('V0.4 測試版'));assert(!s.includes('{{'));}
assert.equal(h.site,'bbxr-tamsui');assert.equal(h.public,'reg');
assert(h.rewrites.some(x=>x.source==='/s/**'&&x.destination==='/signup.html'));assert(h.rewrites.some(x=>x.source==='/q/**'&&x.destination==='/status.html'));
const rules=JSON.parse(fs.readFileSync('database.rules.json')).rules;
assert.equal(rules['.read'],false);assert.equal(rules['.write'],false);assert(rules.managerRowsV04);assert(!rules.privateRowsV04);
const manifest=JSON.parse(fs.readFileSync('asset-manifest.json'));
for(const url of Object.values(manifest)){assert(/^\/assets\/[a-z]+\.[a-f0-9]{16}\.(js|css)$/.test(url));assert(fs.existsSync('reg'+url));}
console.log('PASS V0.4 isolation, 9 endpoints, owner projection, hashed assets and Hosting routes');
JS
