#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: another release process is running'; exit 3; }
if [ -e .release-started ]; then echo 'STOP: release already started. Read release.log and verify cloud state before retry; reconnect tmux instead of relaunching.'; exit 3; fi
sha256sum -c FILE_SHA256.txt >/dev/null
exec > >(tee -a release.log) 2>&1
bash 01_preflight.sh
read -r -p 'Upgrade uses new empty V04 data; old V03 URLs stop working. Type RELEASE-V0.4 to continue: ' answer
[ "$answer" = RELEASE-V0.4 ] || exit 2
( set -o noclobber; date -u > .release-started )
bash 03_deploy_backend.sh
bash 07_deploy_hosting.sh
bash 05_verify.sh
date -u > .release-completed
echo 'RELEASE_COMPLETED: create a V04 test event and verify login, signup, review, restore and cache on actual devices.'
