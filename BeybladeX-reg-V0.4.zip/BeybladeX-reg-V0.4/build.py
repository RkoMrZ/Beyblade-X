#!/usr/bin/env python3
"""Deterministic static build. No network, no deployment, no data writes.
Keep existing reg/assets to preserve older immutable URLs on future deployments.
Edit web/, never generated reg/ files. No minifier/runtime dependencies.
"""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent

def build():
 assets=ROOT/'reg/assets';assets.mkdir(parents=True,exist_ok=True)
 manifest={}
 for folder,ext in [('css','css'),('js','js')]:
  for path in sorted((ROOT/'web'/folder).glob('*.'+ext)):
   data=path.read_bytes();digest=hashlib.sha256(data).hexdigest()[:16]
   name=f'{path.stem}.{digest}.{ext}'
   dest=assets/name
   if dest.exists() and dest.read_bytes()!=data:raise RuntimeError('hash collision: '+name)
   dest.write_bytes(data);manifest[path.stem.upper()+'_'+ext.upper()]='/assets/'+name
 for path in (ROOT/'web/pages').glob('*.html'):
  text=path.read_text()
  for key,value in manifest.items():text=text.replace('{{'+key+'}}',value)
  assert not re.search(r'\{\{[A-Z_]+\}\}',text),path
  (ROOT/'reg'/path.name).write_text(text)
 (ROOT/'asset-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('BUILD_OK:',len(manifest),'assets; 3 HTML pages; old immutable assets retained')
if __name__=='__main__':build()
