"""Targeted V0.4 request correctness regressions. Real Chromium; fake RTDB/Auth/SSE."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_support import browser_options
import importlib.util,json
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('request_audit_browser.py'));audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
vis="Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>window.__vis||'visible'});window.__setVisibility=s=>{window.__vis=s;document.dispatchEvent(new Event('visibilitychange'))}"
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(**browser_options());ctx=browser.new_context(viewport={'width':390,'height':844});ctx.add_init_script(audit.JS_SEED);ctx.add_init_script(vis)
 # No network request may escape mocks.
 ctx.route('**/*',lambda route:route.abort())
 def manager():
  p=ctx.new_page();p.set_content(audit.html(root/'reg','index.html'));p.wait_for_selector('[data-manage]');p.locator('[data-manage]').click();p.wait_for_function("eventMeta!==null && managerOnline");p.wait_for_timeout(350);p.evaluate('__hits.length=0');return p
 p=manager();p.evaluate('Promise.all([refresh(),refresh(),refresh()])');hits=p.evaluate('__hits');assert len(hits)==4,hits;results.append({'case':'3 parallel refreshes','GET':len(hits),'paths':hits});p.close()
 p=manager()
 p.evaluate('''() => {
  const original=fetch;
  window.fetch=async(u,o)=>String(u).includes('/managerRowsV04/ABCDE/p00000001')?(__hits.push('GET managerRowsV04/ABCDE/p00000001'),new Response(JSON.stringify({lineName:'NEW-LINE',recordVersion:2}))):original(u,o);
  Object.assign(__backend.rows.p00000001,{status:'approved',recordVersion:3});
  Object.assign(__backend.changes,{'-chg0002':{type:'row',key:'p00000001',recordVersion:2},'-chg0003':{type:'review',key:'p00000001',recordVersion:3}});__backend.token='v2';
  __streams.at(-1).emit('put',{path:'/',data:{token:'v2',lastChange:'-chg0003'}});
 }''')
 p.wait_for_function("extras.p00000001.lineName==='NEW-LINE' && syncToken==='v2'")
 hits=p.evaluate('__hits');assert hits.count('GET managerRowsV04/ABCDE/p00000001')==1;assert hits.count('GET publicRowsV04/ABCDE/p00000001')==1
 results.append({'case':'edit then review retains private update','GET':len(hits),'line':'NEW-LINE'});p.close()
 p=manager()
 p.evaluate('''rows.p00000001={...rows.p00000001,status:'approved',recordVersion:3};extras.p00000001={lineName:'NEW-LINE',recordVersion:2};Object.assign(__backend.changes,{'-chg0002':{type:'row',key:'p00000001',recordVersion:2},'-chg0003':{type:'review',key:'p00000001',recordVersion:3}});__backend.token='v2';__streams.at(-1).emit('put',{path:'/',data:{token:'v2',lastChange:'-chg0003'}})''')
 p.wait_for_function("syncToken==='v2'");hits=p.evaluate('__hits');assert hits==['GET changesV04/ABCDE'],hits;results.append({'case':'confirmed row and private version skip self echo','GET':len(hits)});p.close()
 p=manager()
 p.evaluate('''() => {
  const original=fetch;window.fetch=(u,o)=>String(u).includes('/publicRowsV04/ABCDE.json')?new Promise((resolve,reject)=>{window.__release=()=>resolve(new Response(JSON.stringify(__backend.rows)));o.signal.addEventListener('abort',()=>reject(new DOMException('aborted','AbortError')))}):original(u,o);refresh();
 }''')
 p.wait_for_function("typeof __release==='function'");p.evaluate("location.hash='#create'");p.wait_for_selector('#createForm');p.evaluate('__release()');p.wait_for_timeout(100);assert p.evaluate("mode==='create' && eventMeta===null");results.append({'case':'old snapshot cannot replace new page','pass':True});p.close()
 p=manager();p.evaluate("__setVisibility('hidden')");p.clock.install();p.clock.fast_forward(1800000);assert p.evaluate('__hits.length')==0;assert p.evaluate('managerStream===null && managerWatch===null');results.append({'case':'manager hidden 30min virtual clock','GET':0});p.close()
 # Shared request pool: parallel reads coalesce, failure evicts, abort permits a fresh read.
 p=ctx.new_page();p.set_content(audit.html(root/'reg','signup.html'));p.wait_for_function('meta!==null')
 pool=p.evaluate('''async()=>{let calls=0;window.fetch=async()=>{calls++;await new Promise(r=>setTimeout(r,10));return new Response('{}')};const pool=BBX.createReadPool(()=>true);await Promise.all([pool.get('https://test/a'),pool.get('https://test/a')]);return calls}''');assert pool==1;results.append({'case':'same pending GET is shared','GET':pool});p.close()
 # 100 independent page lifecycles, actual browser pages with fake server transport.
 pages=[]
 for _ in range(100):
  p=ctx.new_page();p.set_content(audit.html(root/'reg','status.html'));p.wait_for_function('liveOnline');pages.append(p)
 assert sum(p.evaluate('__streams.filter(s=>s.readyState!==2).length') for p in pages)==100
 for p in pages:p.evaluate("__hits.length=0;__setVisibility('hidden')")
 assert all(p.evaluate('liveStream===null && statusWatch===null && reconnect===null && __hits.length===0') for p in pages)
 for p in pages:
  p.clock.install();p.clock.fast_forward(1800000)
 assert all(p.evaluate('__hits.length===0') for p in pages)
 for p in pages:p.evaluate("__setVisibility('visible')")
 for p in pages:p.wait_for_function('liveOnline')
 results.append({'case':'100 browser pages hide and restore, 30min virtual hidden','hiddenGET':0,'restoredSSE':100,'transport':'mock'})
 for p in pages:p.close()
 ctx.close();browser.close()
(root/'OPTIMIZATION_TEST_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps(results,ensure_ascii=False,indent=2))
