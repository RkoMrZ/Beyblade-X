#!/usr/bin/env bash
# Optional, explicit cleanup of RETIRED V03 only. Never erase database root/V04.
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
INSTANCE=ljtreg-39954-default-rtdb
[ ! -e .cleanup-v03-started ] || { echo 'STOP: cleanup previously started. Inspect result before any retry.'; exit 3; }
FUNCTIONS="$(firebase functions:list --project "$PROJECT")"
if printf '%s\n' "$FUNCTIONS" | grep -q 'regV03'; then echo 'STOP: regV03 Functions still exist'; exit 4; fi
printf '%s\n' "$FUNCTIONS" | grep -q 'regV04Submit' || { echo 'STOP: V04 backend missing'; exit 4; }
python3 - <<'PY'
import json
roots=['events','ownerEvents','publicRows','privateRows','alloc','changes','nameClaims','rankActive','receipts','sync','rowLocks']
json.dump({k+'V03':None for k in roots},open('.cleanup-v03.json','w'))
print('DELETE ONLY:',', '.join(k+'V03' for k in roots))
PY
read -r -p 'Confirm V03 data is disposable; type DELETE-V03-ljtreg-39954: ' answer
[ "$answer" = 'DELETE-V03-ljtreg-39954' ] || exit 2
( set -o noclobber; date -u > .cleanup-v03-started ) || exit 3
firebase database:update / .cleanup-v03.json --project "$PROJECT" --instance "$INSTANCE" --force
firebase database:get / --shallow --project "$PROJECT" --instance "$INSTANCE" | python3 -c 'import json,sys;d=json.load(sys.stdin) or {};bad=[k for k in d if k.endswith("V03")];print("Remaining V03:",bad);sys.exit(bool(bad))'
date -u > .cleanup-v03-completed
echo 'V03_CLEANUP_VERIFIED; V04 and unrelated nodes preserved.'
