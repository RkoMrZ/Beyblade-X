#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.37 ]] || { echo 'STOP: wrong version folder';exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v037-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight missing';exit 3; }
P=ljt-beyblade-x;SITE=bbxs-tamsui
gcloud auth print-access-token >/dev/null
firebase hosting:sites:get "$SITE" --project "$P" >/dev/null
mkdir -p hosting-public/assets
cp -f index.html viewer.html hosting-public/
cp -f assets/index-v037-????????????.css assets/index-v037-????????????.js assets/viewer-v037-????????????.css assets/viewer-v037-????????????.js hosting-public/assets/
python3 - <<'PY_CHECK'
import re,hashlib
from pathlib import Path
for page in ('index','viewer'):
 s=Path(page+'.html').read_text()
 refs=re.findall(r'assets/'+page+r'-v037-[0-9a-f]{12}\.(?:js|css)',s)
 assert len(refs)==2,(page,refs)
 for asset in refs:
  assert (Path('hosting-public')/asset).is_file(),asset
  assert hashlib.sha256((Path('hosting-public')/asset).read_bytes()).hexdigest().startswith(re.search(r'-([0-9a-f]{12})\.',asset).group(1))
print('PASS: fingerprinted Hosting-only contents')
PY_CHECK
firebase deploy --only hosting --config firebase.hosting.json --project "$P" --non-interactive
for attempt in 1 2 3 4 5 6;do
 temp=$(mktemp)
 if curl --fail --location --silent --show-error --max-time 15 -H 'Cache-Control: no-cache' "https://${SITE}.web.app/" -o "$temp" && cmp -s index.html "$temp";then rm -f "$temp";break;fi
 rm -f "$temp"
 if [[ "$attempt" == 6 ]];then echo 'STOP: deployed HTML verification failed';exit 4;fi
 sleep 3
done
ASSET=$(grep -o 'assets/index-v037-[0-9a-f]\{12\}\.js' index.html | head -1)
test -n "$ASSET"
temp=$(mktemp)
curl --fail --location --silent --show-error --max-time 20 "https://${SITE}.web.app/${ASSET}" -o "$temp"
cmp -s "$ASSET" "$temp" || { rm -f "$temp";echo 'STOP: CDN JS mismatch';exit 4; }
rm -f "$temp"
printf 'PASS: V0.37 exact HTML and SSE-only JS live on %s.web.app\n' "$SITE"
