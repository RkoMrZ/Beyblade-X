#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.37 ]] || { echo 'STOP: wrong V0.37 folder'; exit 2; }
[[ "$(gcloud config get-value project 2>/dev/null)" == 'ljt-beyblade-x' ]] || { echo 'STOP: wrong Firebase project'; exit 2; }
python3 - <<'PY_VERIFY'
import hashlib,json,re
from pathlib import Path
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.37' and m['firebase_project']=='ljt-beyblade-x'
assert m['hosting_site']=='bbxs-tamsui' and m['functions_deploy_only']==[]
assert m['updated_backend_hashes']=={}
for f,digest in m['untouched_backend_hashes'].items():
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==digest,f
for f in m['files']:
 raw=Path(f['path']).read_bytes()
 assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256'],f['path']
for page in ('index','viewer'):
 s=Path(page+'.html').read_text()
 assert 'v036' not in s
 for ext in ('css','js'):
  refs=re.findall(r'assets/'+page+r'-v037-[0-9a-f]{12}\.'+ext,s)
  assert len(refs)==1,(page,ext,refs)
  for ref in refs:
   assert hashlib.sha256(Path(ref).read_bytes()).hexdigest().startswith(re.search(r'-([0-9a-f]{12})\.',ref).group(1)),ref
script=Path('assets/index-v037.js').read_text()
html=Path('index.html').read_text()
for pattern in (r'firebase\.database\s*\(',r'\bfbDb\b',r'\.info/connected',r'forceLongPolling\s*\(',r'child_added',r'child_changed'):
 assert not re.search(pattern,script),pattern
assert 'firebase-database-compat.js' not in html
assert 'firebase-auth-compat.js' in html and 'firebase-functions-compat.js' in html
print('PASS: verified V0.37 manifest, SSE-only runtime and all hashed Hosting assets')
PY_VERIFY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required';exit 3; }
for f in functions/*.js assets/index-v037.js assets/viewer-v037.js;do node --check "$f";done
node --test tests/*.test.js
python3 tests/check_static.py
python3 tests/check_rules_syntax.py
python3 tests/check_cleanup_rules.py
python3 deploy/merge-rules.py docs/previous-v09-rules.json /tmp/bbx-v037-test-rules-merge.json
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI missing';exit 4; }
free_kb=$(df -Pk "$HOME" | awk 'NR==2{print $4}')
[[ "$free_kb" -ge 650000 ]] || { echo 'STOP: Cloud Shell has under 650 MB free';exit 4; }
npm ci --prefix tests --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v011 --config firebase.json 'cd tests && node rules-emulator.test.cjs'
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v037-preflight-ok"
echo 'PASS: BBX-V0.37 preflight, RTDB Emulator and SSE-only Hosting integrity'
