# BBX-V0.37 — 私人 SSE 主通道與局部 DOM 更新

本版從使用者實機可用的 V0.36 延伸，僅修改主辦／裁判前端同步與更新方式；Auth、Functions、Rules 和雲端事件資料結構均不動。

- **SSE + REST 為主要同步**：不再載入 Firebase Realtime Database SDK，不再呼叫 `firebase.database()`、`.info/connected`、`child_added`、WebSocket/長輪詢傳輸強制切換；登入仍使用 Firebase Auth，關鍵寫入仍使用 Functions 與 REST ETag/權限。
- **私人資料保護**：兩條經驗證的私人 SSE（發布提示、裁判領取），需要同時收到初始通知、雲端 REST 核對後才允許安全提交；失聯則鎖住寫入，依版本或場次提示補讀，避免頻繁整場輪詢。
- **局部賽程更新**：開始執裁、完賽、釋放、重設比分與最後三人循環的既有場次，優先只更新必要場次/列與晉級資訊，不重建整張圖；實際輪次結構改變時仍可能需要一次結構性重繪。
- **主辦領取裁判身分保留捲動**：只局部更新領取按鈕、狀態、已領取欄位，保留其他名稱輸入內容、QR Code 節點及主辦頁原捲動；雲端領取通知觸發的重畫亦使用相同機制。
- **部署只修改 Hosting**：`ljt-beyblade-x` 的 `bbxs-tamsui`。沿用已部署 V0.36 的 appendReferee 後端支援，不動任何 Functions、Database Rules、資料庫。

執行 `bash 00_start.sh` 會驗證 ZIP MANIFEST、Node 22、各項本機測試、Rules 完整性和 RTDB Emulator，全部通過才部署 Hosting 並核對 CDN。Cloud Shell 必須已具備 firebase CLI、Node 22、Google Cloud 授權。

**本版仍為 V0.x 測試版**：Chromium 模擬測試不能替代 iPhone Safari／Chrome 的實機驗收，尤其要驗證多人裁判、無固定延遲、背景恢復及結構改變時的畫面更新。
