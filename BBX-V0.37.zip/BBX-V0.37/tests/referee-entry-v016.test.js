'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const js=fs.readFileSync(path.join(__dirname,'../assets/index-v037.js'),'utf8');
const start=js.indexOf('// V0.15: Referee links must never require');
const end=js.indexOf('async function bootstrapCloud(){',start);
assert.ok(start>0 && end>start);
const segment=js.slice(start,end);
function fixture({user=null, lookup='B9_EVENT_48_PLAYERS', grant=null, putError=null, eventLoad='ok'}={}){
 const call=[];const nodes={};
 for(const id of ['home','create','admin','refereeJoin','refereeJoinStatus','refereeJoinSubmit','refereeJoinCode']){
   nodes[id]={classList:{add(c){call.push(`hide:${id}`)},remove(c){call.push(`show:${id}`)}},textContent:'',disabled:false,dataset:{},value:id==='refereeJoinCode'?'123456':''};
 }
 const ctx={console,Date,Promise,refereeJoinEventId:null,refereeJoinBusy:false,$:id=>nodes[id],
   fbAuth:{currentUser:user},
   publicCloudGet:async p=>{call.push('lookup:'+p);return lookup},
   rtdbRestGet:async p=>{call.push('read:'+p);return p.startsWith('refereeUsers/')?grant:null},
   isGoogleUser:()=>!!user?.google,
   loadCloudEvent:async id=>{call.push('private:'+id);return eventLoad},
   ensureRefereeAuth:async()=>{call.push('anonymous-auth');ctx.fbAuth.currentUser={uid:'ANON_JUDGE'};return true},
   cloudSet:async(path,value)=>{call.push('claim:'+path);if(putError)throw putError;return true},
   showTab:t=>call.push('tab:'+t)};
 vm.createContext(ctx);vm.runInContext(segment,ctx);
 return {ctx,nodes,call,run:s=>vm.runInContext(s,ctx)};
}
test('fresh 48-person referee QR: alias read then code form, no private GET before claim',async()=>{
 const x=fixture();await x.run("bootstrapRefereeEntry('ABCDE')");
 assert.deepEqual(x.call.filter(s=>s.startsWith('lookup:')),['lookup:bbxPublicCodeLookup/ABCDE']);
 assert.equal(x.call.some(s=>s.startsWith('private:')),false);
 assert.equal(x.call.some(s=>s.startsWith('read:events/')),false);
 assert.equal(x.nodes.refereeJoinSubmit.disabled,false);
 assert.match(x.nodes.refereeJoinStatus.textContent,/不需要 Google 登入/);
});
test('claim opens full board only AFTER anonymous sign-in, server-side code grant and readback',async()=>{
 const x=fixture({grant:'123456'});await x.run("bootstrapRefereeEntry('ABCDE')");
 await x.run('claimRefereeFromLink()');
 const important=x.call.filter(s=>/^(lookup:|anonymous-auth|claim:|read:|private:|tab:)/.test(s));
 assert.deepEqual(important,[
  'lookup:bbxPublicCodeLookup/ABCDE','anonymous-auth',
  'claim:refereeUsers/B9_EVENT_48_PLAYERS/ANON_JUDGE',
  'read:refereeUsers/B9_EVENT_48_PLAYERS/ANON_JUDGE',
  'private:B9_EVENT_48_PLAYERS','tab:referee']);
});
test('bad or expired 6-digit code never exposes a private event or mutates master data',async()=>{
 const denied=Object.assign(new Error('Firebase REST 403: Permission denied'),{code:'HTTP_403'});
 const x=fixture({putError:denied});await x.run("bootstrapRefereeEntry('ABCDE')");
 await x.run('claimRefereeFromLink()');
 assert.equal(x.call.some(s=>s.startsWith('private:')),false);
 assert.deepEqual(x.call.filter(s=>s.startsWith('claim:')),['claim:refereeUsers/B9_EVENT_48_PLAYERS/ANON_JUDGE']);
 assert.match(x.nodes.refereeJoinStatus.textContent,/驗證碼不正確或已過期/);
});
test('existing authorized referee restores without asking for another claim',async()=>{
 const x=fixture({user:{uid:'RETURNING_ANON'},grant:'123456'});
 await x.run("bootstrapRefereeEntry('ABCDE')");
 assert.equal(x.call.some(s=>s.startsWith('claim:')),false);
 assert.deepEqual(x.call.filter(s=>s.startsWith('read:')||s.startsWith('private:')||s.startsWith('tab:')),[
  'read:refereeUsers/B9_EVENT_48_PLAYERS/RETURNING_ANON',
  'private:B9_EVENT_48_PLAYERS','tab:referee']);
});
test('unknown invitation code keeps URL and forbids a private database read',async()=>{
 const x=fixture({lookup:null});await x.run("bootstrapRefereeEntry('ABCDE')");
 assert.equal(x.nodes.refereeJoinSubmit.disabled,true);
 assert.equal(x.call.some(s=>s.startsWith('private:')),false);
 assert.match(x.nodes.refereeJoinStatus.textContent,/活動代碼暫時無法核對/);
});
test('referee route intercepts before loadCloudEvent and preserves viewing/organizer flows',()=>{
 const bootstrap=js.slice(js.indexOf('async function bootstrapCloud(){'),js.indexOf('/* V0.14:',js.indexOf('async function bootstrapCloud(){')));
 assert.match(bootstrap,/if\(urlEvent && params\.get\('ref'\)==='1'\)[\s\S]*?await bootstrapRefereeEntry\(urlEvent\);[\s\S]*?return;[\s\S]*?if\(urlEvent\)\{\s*const result=await loadCloudEvent\(urlEvent\)/);
 assert.match(js,/\.read/); // authority code retained
 const rules=JSON.parse(fs.readFileSync(path.join(__dirname,'../database.rules.json'),'utf8')).rules;
 assert.match(rules.events.$eventId['.read'],/refereeUsers/);
 assert.match(rules.refereeUsers.$eventId.$uid['.write'],/refereeSecrets/);
});
