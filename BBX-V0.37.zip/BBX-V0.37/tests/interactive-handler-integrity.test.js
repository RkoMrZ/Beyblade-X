'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const contents=(p)=>fs.readFileSync(path.join(root,p),'utf8');
test('all named inline button handlers in organizer and viewer interfaces remain defined',()=>{
  for(const [html,js] of [['index.html','assets/index-v037.js'],['viewer.html','assets/viewer-v037.js']]){
    const source=contents(html)+'\n'+contents(js);
    const handlers=new Set([...source.matchAll(/onclick=["']?\s*([A-Za-z_$][\w$]*)\s*\(/g)].map(m=>m[1]).filter(x=>x!=='if'));
    assert.ok(handlers.size>= (html==='index.html'?40:3));
    for(const name of handlers){
      assert.match(source,new RegExp('\\b(?:function\\s+'+name+'\\s*\\(|(?:const|let|var)\\s+'+name+'\\s*=)'),`missing click handler ${name} in ${html}`);
    }
  }
});
test('no old fullscreen and match-dialog forced hit-test overrides remain',()=>{
  const css=contents('assets/index-v037.css');
  assert.equal(css.includes('bbxIosAbsoluteOverlay'),false);
  assert.equal(css.includes('--app-vv-top'),false);
  assert.equal(css.includes('position:fixed !important'),false);
  assert.equal((css.match(/\.matchModal\{\s*position:fixed/g)||[]).length,0);
  assert.equal((css.match(/\.matchModal,\.scorePickerPop,\.resetChoiceModal,\.raffleWinnerModal\{/g)||[]).length,1);
  assert.match(css,/\.matchSheet\{[\s\S]*?overflow-x:hidden;overflow-y:auto/);
});
