#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.37 deployment already running';exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.37 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.37 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v037.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v037-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
# V0.36 OrganizerAuthority already supports appendReferee.
# This release changes ONLY Hosting; no Functions or Database Rules deployment.
bash deploy/hosting-v037.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.37 Hosting deployed; Cloud Functions, Database Rules and saved events untouched.\n'
