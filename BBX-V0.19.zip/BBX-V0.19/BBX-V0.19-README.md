# BBX-V0.19 — Live publication and cross-device sync regression fix

- Retains the proven V0.16 automatic BYE plan and V0.17 no-BYE selection unchanged.
- Match/Organizer Functions now attempt bounded publication of the committed authority sequence before replying; the independent RTDB trigger and five-minute repair remain fail-safe only.
- A successful authority write is not silently described as a successful public delivery: `published` and `publicationPending` reflect actual confirmed `publishedSeq`.
- Private bracket keeps its fit/scroll position while updating score, match ownership, winner and next-round participants.
- After a true RTDB disconnect/reconnect, re-reads the authoritative event and rebinds listeners.
- Audience SSE script is unchanged; the public projection is delivered promptly by the server as part of the command flow.
- Does not change Database Rules, create/rebuild algorithm, delete authority or historical event data.
- Publishing must be verified with multiple real phones including organizer, two judges, and viewer. If the publishing lease or connection is unhealthy, success is not claimed until confirmed.
