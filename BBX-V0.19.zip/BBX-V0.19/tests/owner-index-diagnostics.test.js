'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const client=fs.readFileSync(path.join(root,'assets/index-v019.js'),'utf8');
const section=(start,end)=>{
 const a=client.indexOf(start),b=client.indexOf(end,a);
 assert.ok(a>=0&&b>a,`slice ${start}`);return client.slice(a,b);
};
const core=section('function ownerIndexErrorLabel(error){','function renderHomeSelections(){')+'\n'+
 section('async function syncMyCloudEvents(', '\n\nasync function backfillMyCloudEventIndex(){')+'\n'+
 section('function stopMyCloudEventIndexListener(){','// V0.15: Referee links must never require');
const flush=async()=>{for(let i=0;i<12;i++)await new Promise(r=>setImmediate(r));};
function setup({sdk=null,rest={},events={},uid='GOOGLE_UID_A',rejectRest=null,older={}}={}){
 const callbacks={};let detaches=0;const timers=[];
 const state={phase:'restoring',uid:null,provider:null,sdkSlots:null,restSlots:null,verified:false,source:null,error:null,checkedAt:null,indexMismatch:false};
 const ctx={console,Date,navigator:{onLine:true},setTimeout:(fn)=>{timers.push(fn);return timers.length},clearTimeout:()=>{},
  ownerIndexUnsub:null,ownerIndexPendingSnapshot:null,ownerIndexGeneration:0,ownerIndexSyncBusy:false,
  ownerIndexProbeTimer:null,ownerIndexRetryTimer:null,ownerIndexRetryDelay:4000,ownerIndexLastProbe:0,ownerIndexState:state,
  cloudEventsCache:older,cloudEventIds:Object.keys(older),cloudEventSlots:{},
  FIREBASE_CONFIG:{projectId:'ljt-beyblade-x'},document:{visibilityState:'visible'},
  fbAuth:{currentUser:{uid,providerData:[{providerId:'google.com'}]}},fbDb:{ref:()=>({on(_,cb,err){callbacks.data=cb;callbacks.error=err},off(){detaches++}})},
  isGoogleUser(){return ctx.fbAuth.currentUser?.providerData?.some(p=>p.providerId==='google.com')},
  cloudEventIdsForCurrentGoogle(){return ctx.cloudEventIds.filter(id=>ctx.cloudEventsCache[id]?.ownerUid===ctx.fbAuth.currentUser?.uid)},
  $:id=>({classList:{contains:()=>id==='ownerDiagPanel'},textContent:''}),
  renderSavedEvents(){},renderHomeSelections(){},
  rtdbRestGet:async p=>{if(p.startsWith('userEvents/')){if(rejectRest)throw rejectRest;return rest;}if(p.startsWith('events/'))return events[p.slice(7)]??null;throw Error('Unexpected GET: '+p)}
 };
 vm.createContext(ctx);vm.runInContext(core,ctx);
 vm.runInContext('listenMyCloudEventIndex()',ctx);
 return {ctx,callbacks,timers,state,getIds:()=>[...ctx.cloudEventIds],stop:()=>vm.runInContext('stopMyCloudEventIndexListener()',ctx),detaches:()=>detaches};
}
test('Safari: empty SDK snapshot does not claim zero; REST finds three owner events',async()=>{
 const ids=['EVENT_A','EVENT_B','EVENT_C'];
 const env=setup({rest:{0:ids[0],1:ids[1],2:ids[2]},events:Object.fromEntries(ids.map(id=>[id,{id,ownerUid:'GOOGLE_UID_A',name:'123'}]))});
 env.callbacks.data({val:()=>null});await flush();
 assert.equal(env.state.verified,false);
 assert.notEqual(vm.runInContext('ownerIndexStatusLabel()',env.ctx),'雲端已核對・0 個索引');
 env.timers[0]();await flush();
 assert.deepEqual(env.getIds(),ids);
 assert.equal(env.state.restSlots,3);
 assert.equal(env.state.indexMismatch,true,'SDK null disagrees with REST 3; warn rather than silently trust cache');
 assert.match(vm.runInContext('ownerDiagnosticsText()',env.ctx),/Firebase UID：GOOGLE_UID_A/);
 assert.match(vm.runInContext('ownerDiagnosticsText()',env.ctx),/REST 索引數：3/);
 env.stop();
});
test('Firebase numeric owner index serialised as Array works for SDK and REST (three events)',async()=>{
 const ids=['EVENT_A','EVENT_B','EVENT_C'];
 const events=Object.fromEntries(ids.map(id=>[id,{id,ownerUid:'GOOGLE_UID_A',name:'123'}]));
 const env=setup({rest:[...ids],events});
 env.callbacks.data({val:()=>[...ids]});await flush();
 env.timers[0]();await flush();
 assert.deepEqual(env.getIds(),ids);
 assert.equal(env.state.sdkSlots,3);
 assert.equal(env.state.restSlots,3);
 assert.equal(env.state.verified,true);
 assert.equal(env.state.error,null);
 assert.equal(env.state.indexMismatch,false);
 env.stop();
});
test('Firebase sparse Array with three numeric slots remains valid owner index',async()=>{
 const slots=[];slots[0]='EVENT_A';slots[2]='EVENT_C';
 const env=setup({rest:slots,events:{EVENT_A:{id:'EVENT_A',ownerUid:'GOOGLE_UID_A'},EVENT_C:{id:'EVENT_C',ownerUid:'GOOGLE_UID_A'}}});
 env.callbacks.data({val:()=>slots});await flush();env.timers[0]();await flush();
 assert.deepEqual(env.getIds(),['EVENT_A','EVENT_C']);
 assert.equal(env.state.restSlots,2);assert.equal(env.state.verified,true);
 env.stop();
});
test('Owner index primitives remain invalid without falsely confirming zero',async()=>{
 const env=setup({rest:'NOT_A_VALID_INDEX'});env.timers[0]();await flush();
 assert.equal(env.state.verified,false);
 assert.deepEqual(env.getIds(),[]);
 env.stop();
});
test('Safari: no SDK value event at all can recover from authoritative REST',async()=>{
 const env=setup({rest:{0:'EVENT_A'},events:{EVENT_A:{id:'EVENT_A',ownerUid:'GOOGLE_UID_A'}}});
 await flush();assert.equal(env.state.verified,false);
 env.timers[0]();await flush();
 assert.deepEqual(env.getIds(),['EVENT_A']);assert.equal(env.state.phase,'verified');
 env.stop();
});
test('Safari: permission denied is visible as failure, never a verified 0/3',async()=>{
 const err=new Error('Firebase REST 403: Permission denied');err.code='HTTP_403';
 const env=setup({rejectRest:err});env.callbacks.error(err);await flush();
 assert.equal(env.state.error,'permission_denied');
 assert.equal(env.state.verified,false);
 assert.match(vm.runInContext('ownerIndexStatusLabel()',env.ctx),/不是 0 場/);
 env.stop();
});
test('Only REST empty + no previously known event is a confirmed 0 count',async()=>{
 const env=setup({rest:null});env.callbacks.data({val:()=>null});await flush();env.timers[0]();await flush();
 assert.equal(env.state.restSlots,0);assert.equal(env.state.verified,true);
 assert.equal(env.state.indexMismatch,false);assert.deepEqual(env.getIds(),[]);
 env.stop();
});
test('A formerly known owner event with missing index stays visible but read-only',async()=>{
 const env=setup({rest:null,older:{EVENT_A:{id:'EVENT_A',ownerUid:'GOOGLE_UID_A',name:'Existing 6-player'}}});
 env.callbacks.data({val:()=>null});await flush();env.timers[0]();await flush();
 assert.deepEqual(env.getIds(),['EVENT_A']);
 assert.equal(env.ctx.cloudEventsCache.EVENT_A.pendingSync,true);
 assert.equal(env.state.indexMismatch,true);
 env.stop();
});
test('Event master GET failure marks previous successful entry unverified, disables owner actions',async()=>{
 const env=setup({rest:{0:'EVENT_A'},older:{EVENT_A:{id:'EVENT_A',ownerUid:'GOOGLE_UID_A',name:'Previous name',pendingSync:false}}});
 env.callbacks.data({val:()=>({0:'EVENT_A'})});await flush();env.timers[0]();await flush();
 assert.deepEqual(env.getIds(),['EVENT_A']);assert.equal(env.ctx.cloudEventsCache.EVENT_A.pendingSync,true);
 assert.equal(env.ctx.cloudEventsCache.EVENT_A.name,'Previous name');env.stop();
});
test('Late older UID listener cannot overwrite after switching to a new Firebase account',async()=>{
 const env=setup({rest:{0:'EVENT_A'},events:{EVENT_A:{id:'EVENT_A',ownerUid:'GOOGLE_UID_A'}}});
 const oldHandler=env.callbacks.data;
 env.ctx.fbAuth.currentUser={uid:'GOOGLE_UID_B',providerData:[{providerId:'google.com'}]};
 oldHandler({val:()=>({0:'EVENT_A'})});env.timers[0]();await flush();
 assert.deepEqual(env.getIds(),[]);assert.equal(env.state.verified,false);
 env.stop();
});
test('User diagnostic does not expose ID token, OAuth code, private scores, raffle',()=>{
 const env=setup({});env.ctx.fbAuth.currentUser.getIdToken=()=> 'DO_NOT_LEAK';
 const content=vm.runInContext('ownerDiagnosticsText()',env.ctx);
 assert.doesNotMatch(content,/DO_NOT_LEAK|score|raffle|password|authorization bearer/i);
 assert.match(content,/Provider：google\.com/);env.stop();
});
test('Cloud owner sync is read-only and legacy deletion remains separately guarded',()=>{
 const home=section('function stopMyCloudEventIndexListener(){','// V0.15: Referee links must never require')+
 section('async function syncMyCloudEvents(', '\n\nasync function backfillMyCloudEventIndex(){');
 assert.doesNotMatch(home,/rtdbRestDelete|rtdbRestMultiUpdate|cloudUpdate|remove\(/);
 assert.match(client,/bbxV011DeleteAuthority/);
});
test('Hosting references uniquely fingerprinted immutable assets for index and public viewer',()=>{
 const hosting=JSON.parse(fs.readFileSync(path.join(root,'firebase.hosting.json'),'utf8'));
 assert.ok(hosting.hosting.headers.some(h=>h.source==='/assets/**'&&h.headers[0].value.includes('immutable')));
 for(const page of ['index.html','viewer.html']){
  const html=fs.readFileSync(path.join(root,page),'utf8');
  const paths=[...html.matchAll(/assets\/((?:index|viewer)-v019-([a-f0-9]{12})\.(js|css))/g)];
  assert.equal(paths.length,2,page);
  for(const [,name,short] of paths){
   const bytes=fs.readFileSync(path.join(root,'assets',name));
   assert.equal(crypto.createHash('sha256').update(bytes).digest('hex').slice(0,12),short);
  }
 }
});
test('REST ID token cache is UID-bound and cannot be reused after Google account switch',async()=>{
 const slice=section('let restTokenCache={token:null,ts:0,uid:null};','const inFlightPublicReads=new Map();');
 const ctx={Date,fbAuth:{currentUser:{uid:'A',getIdToken:async()=> 'TOKEN_A'}}};
 vm.createContext(ctx);vm.runInContext(slice,ctx);
 assert.equal(await vm.runInContext('getRestIdToken()',ctx),'TOKEN_A');
 ctx.fbAuth.currentUser={uid:'B',getIdToken:async()=> 'TOKEN_B'};
 assert.equal(await vm.runInContext('getRestIdToken()',ctx),'TOKEN_B');
 assert.equal(vm.runInContext('restTokenCache.uid',ctx),'B');
});
test('Old pending ID token request is discarded after UID switch',async()=>{
 const slice=section('let restTokenCache={token:null,ts:0,uid:null};','const inFlightPublicReads=new Map();');
 let finish;const slow=new Promise(resolve=>finish=resolve);
 const ctx={Date,fbAuth:{currentUser:{uid:'A',getIdToken:()=>slow}}};
 vm.createContext(ctx);vm.runInContext(slice,ctx);
 const old=vm.runInContext('getRestIdToken()',ctx);
 ctx.fbAuth.currentUser={uid:'B',getIdToken:async()=> 'TOKEN_B'};
 finish('TOKEN_A');
 await assert.rejects(old,/登入身分已切換/);
 assert.equal(await vm.runInContext('getRestIdToken()',ctx),'TOKEN_B');
 assert.equal(vm.runInContext('restTokenCache.uid',ctx),'B');
});
