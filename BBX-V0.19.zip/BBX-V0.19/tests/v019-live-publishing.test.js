const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const fn=fs.readFileSync(path.join(__dirname,'../functions/index.js'),'utf8');
const ui=fs.readFileSync(path.join(__dirname,'../assets/index-v019.js'),'utf8');
const viewer=fs.readFileSync(path.join(__dirname,'../assets/viewer-v019.js'),'utf8');
test('Command and Organizer return only after inline projection attempt',()=>{
 assert.match(fn,/async function confirmLivePublication\(/);
 assert.match(fn,/return await confirmLivePublication\(eventId,result,'match-command'\)/);
 assert.match(fn,/return await confirmLivePublication\(eventId,result,'organizer-command'\)/);
 assert.match(fn,/publishedSeq/);assert.match(fn,/published:true,publicationPending:false/);
 assert.match(fn,/published:false,publicationPending:true/);
});
test('Authority operation lock is released before publication request',()=>{
 const commit=fn.indexOf('async function applyToPrivateBoard(');
 const confirm=fn.indexOf('async function confirmLivePublication(');
 assert.ok(commit>=0&&confirm>commit);
 assert.match(fn,/finally\{await releaseLease\(lock,token\)\}/);
});
test('Private board realtime changes preserve fit and refresh results & locks',()=>{
 assert.match(ui,/patchBracketMatchFromCloud\(ri,mi\)/);
 assert.match(ui,/old\?\.winner!==data\?\.winner/);
 assert.match(ui,/old\?\.refereeActive!==data\?\.refereeActive/);
 assert.match(ui,/if\(!patchBracketMatchFromCloud\(ri,mi\) \|\| changedState\)scheduleRender\(\)/);
 assert.match(ui,/bracketViewAfterRender\(bracketView\)/);
});
test('Private Firebase listeners detect connection breaks and failures',()=>{
 assert.match(ui,/fbDb\.ref\('\.info\/connected'\)/);
 assert.match(ui,/rtdb-reconnected/);
 assert.match(ui,/cloudResyncBlocked=true;\s*console\.error\('Live RTDB match listener failed/);
});
test('Viewer continues EventSource SSE with generation and fresh snapshot guards',()=>{
 assert.match(viewer,/new EventSource\(streamUrl\(kind,id\)\)/);
 assert.match(viewer,/receivedEventSerial!==requestSerial/);
 assert.doesNotMatch(viewer,/setInterval\(\s*fetchFreshSnapshot/);
});
