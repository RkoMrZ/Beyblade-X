#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.19 deployment is already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: BBX-V0.19 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.19 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/BBX-V0.19-檢查.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v019-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight state mismatch';exit 3; }
gcloud auth print-access-token >/dev/null
# npm dependency is mandatory before deploying Cloud Functions.
if [[ ! -f functions/package-lock.json ]]; then
  npm install --prefix functions --package-lock-only --no-audit --no-fund
fi
npm ci --prefix functions --no-audit --no-fund
[[ -d functions/node_modules/firebase-functions ]] || { echo 'STOP: Functions dependency missing'; exit 4; }
# Deploy only match and organizer callables. Keep scheduled/event publishers intact.
firebase deploy --only functions:bbxV011CommandAuthority,functions:bbxV011OrganizerAuthority --project ljt-beyblade-x --non-interactive
bash deploy/BBX-V0.19-Hosting.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.19 Command + Organizer callable Functions and Hosting deployed; Rules and saved events untouched.\n'
