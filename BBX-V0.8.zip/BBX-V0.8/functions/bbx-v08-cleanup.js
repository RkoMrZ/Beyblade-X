'use strict';
// Event-scoped RTDB cleanup inventory, audited against BBX V0.1 .. V0.6.
// These are namespaces whose FIRST child is eventId. Do not include account-
// wide locks, auth identities, unrelated events, or shared Rules here.
const EVENT_ROOTS=Object.freeze([
 'events',                 // private event and metadata
 'publicEvents',           // viewer projection and sharing information
 'authorityBBX',           // V0.1 / V0.2 / V0.3 private board
 'authorityBBXV04',        // V0.4 private board + locks + outbox
 'authorityBBXV05',        // V0.5 historical private board + locks + outbox
 'bbxV05PublicationPending', // V0.5 historical repair queue
 'authorityBBXV06',
 'bbxV06PublicationPending',
 'authorityBBXV07',        // V0.7 historical private board + leases
 'bbxV07PublicationPending', // V0.7 historical repair queue
 'authorityBBXV08',        // V0.8 private board + leases + outbox
 'bbxV08PublicationPending',// V0.8 repair queue / retry index
 'refereeClaims',          // claimed referee identities
 'refereeUsers',           // referee permissions
 'refereeSecrets',         // referee login secrets
 'secrets',                // organizer login secrets
 'admins',                 // organizer roles
]);
const DELETE_VERSIONS=Object.freeze(['BBX-V0.1','BBX-V0.2','BBX-V0.3','BBX-V0.4','BBX-V0.5','BBX-V0.6','BBX-V0.7','BBX-V0.8']);
const EVENT_ID=/^[A-Za-z0-9_-]{6,100}$/;
const UID=/^[^.#$\[\]/\x00-\x1F\x7F]{1,128}$/;
function assertCleanParams(eventId,uid){
 if(!EVENT_ID.test(eventId||'')||!UID.test(uid||''))throw Error('invalid cleanup identifier');
}
function buildCleanupPaths(eventId,uid,slots){
 assertCleanParams(eventId,uid);
 const paths=EVENT_ROOTS.map(root=>`${root}/${eventId}`);
 // This is the ONLY event reference under an account-level namespace.
 for(const [slot,target] of Object.entries(slots||{})){
  if(target===eventId){
   if(!/^(0|1|2)$/.test(slot))throw Error('unexpected owner index: '+slot);
   paths.push(`userEvents/${uid}/${slot}`);
  }
 }
 return paths;
}
async function verifyCleanup(db,paths){
 // Multipath deletion is atomic. Verify each namespace independently before
 // returning success; do not treat a successful SDK promise as an audit.
 const remaining=(await Promise.all(paths.map(async p=>{
  const snap=await db.ref(p).get();return snap.exists()?p:null;
 }))).filter(Boolean);
 return remaining;
}
module.exports={EVENT_ROOTS,DELETE_VERSIONS,buildCleanupPaths,verifyCleanup};
