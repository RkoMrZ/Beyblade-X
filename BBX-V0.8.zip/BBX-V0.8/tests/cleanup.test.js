'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const D=require('../functions/bbx-v08-cleanup.js');
test('cleanup list includes all historic per-event data and never account/global resources',()=>{
 const known=['events','publicEvents','authorityBBX','authorityBBXV04','authorityBBXV05','bbxV05PublicationPending','authorityBBXV06','bbxV06PublicationPending','authorityBBXV07','bbxV07PublicationPending','authorityBBXV08','bbxV08PublicationPending',
 'refereeClaims','refereeUsers','refereeSecrets','secrets','admins'];
 assert.deepEqual([...D.EVENT_ROOTS].sort(),known.sort());
 assert.deepEqual(D.DELETE_VERSIONS,['BBX-V0.1','BBX-V0.2','BBX-V0.3','BBX-V0.4','BBX-V0.5','BBX-V0.6','BBX-V0.7','BBX-V0.8']);
 const paths=D.buildCleanupPaths('TEST123','google-owner',{'0':'TEST123','1':'DIFFERENT','2':'TEST123'});
 for(const root of known)assert.ok(paths.includes(root+'/TEST123'));
 assert.ok(paths.includes('userEvents/google-owner/0'));
 assert.ok(paths.includes('userEvents/google-owner/2'));
 assert.ok(!paths.some(x=>x.includes('DIFFERENT')||x.startsWith('bbxV08CreateLocks')||x.startsWith('bbxV04CreateLocks')));
 assert.equal(paths.length,new Set(paths).size,'must not duplicate paths');
});
test('cleanup refuses unexpected index fields to protect unrelated account indexes',()=>{
 assert.throws(()=>D.buildCleanupPaths('TEST123','owner',{'../other':'TEST123'}));
 assert.throws(()=>D.buildCleanupPaths('TEST123','owner/name',{}));
 assert.throws(()=>D.buildCleanupPaths('../event','owner',{}));
});
test('independent readback finds residual paths and succeeds only on complete removal',async()=>{
 const db={ref:p=>({get:async()=>({exists:()=>p==='publicEvents/TEST123'})})};
 assert.deepEqual(await D.verifyCleanup(db,['events/TEST123','publicEvents/TEST123']),['publicEvents/TEST123']);
 assert.deepEqual(await D.verifyCleanup({ref:()=>({get:async()=>({exists:()=>false})})},['events/TEST123']),[]);
});
