#!/usr/bin/env python3
import re,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(p):return (root/p).read_text()
def nonscript(html):
 s=re.sub(r'<script\b[^>]*>[\s\S]*?</script>','<script></script>',html,flags=re.I)
 return re.sub(r'(?:<script></script>\s*)+','<script></script>\n',s)
for n,original in [('index','baseline/index.v1.html'),('viewer','baseline/viewer.v1.html')]:
 a=read(original);b=read(n+'.html')
 # Exact markup and styling (outside script tags) is preserved.
 assert nonscript(a)==nonscript(b),n+' ORIGINAL HTML/CSS structural mismatch'
 assert re.findall(r'<style[^>]*>([\s\S]*?)</style>',a)==re.findall(r'<style[^>]*>([\s\S]*?)</style>',b)
 print('PASS original',n,'HTML/CSS preserved byte for byte outside scripts')
frontend=read('index.html');fn=read('functions/index.js');viewer=read('viewer.html')
assert 'bbxV08CreateAuthority' in frontend and 'bbxV08CreateAuthority' in fn
assert 'bbxV08ActivateAuthority' not in frontend+fn
assert "const created=(await createFn" in frontend
assert "createdEventId=created.eventId" in frontend
assert "const authoritative=await rtdbRestGet" in frontend
assert "projectGuard()" in fn and "DB_URL=" in fn
assert "authorityBBXV08/${eventId}" in fn
assert "ref:'authorityBBXV08/{eventId}/board/seq'" in fn
assert 'await db.ref().update(updates);  // one atomic server commit' in fn
assert "const isV1Authority=()=>!!ev&&!ev.testOnly&&ev.authorityBBX==='active'&&ev.releaseTag==='BBX-V0.8'" in frontend
assert '每 4 分鐘做一次' not in viewer
assert "document.visibilityState==='hidden'" in viewer
assert 'bbxV04' not in fn+frontend
assert 'ljtreg' not in fn+frontend+read('.firebaserc')
base=json.loads(read('baseline/rules.v1.json'))['rules']; rules=json.loads(read('database.rules.json'))['rules']
assert all(rules[k]==base[k] for k in base if k not in {'events','publicEvents'})
assert rules['events']['$eventId']['.read']==base['events']['$eventId']['.read']
assert base['publicEvents']['$eventId']['.read'] in rules['publicEvents']['$eventId']['.read']
assert 'authorityBBXV07' in rules['publicEvents']['$eventId']['.read'] and 'authorityBBXV08' in rules['publicEvents']['$eventId']['.read']
assert rules['bbxV08PublicationPending']=={'.read':False,'.write':False,'.indexOn':['updatedAt']}
assert rules['authorityBBXV07']=={'.read':False,'.write':False}
assert rules['authorityBBXV08']=={'.read':False,'.write':False}
assert 'authorityBBX' in rules['events']['$eventId']['rounds']['.write']
assert "BBX-V0.8" in rules['events']['$eventId']['.write']
print('PASS scoped create, version gate, SSE, private authority and Rules guards')

assert "BBX-V0.4" in rules['events']['$eventId']['.write'] and "BBX-V0.8" in rules['events']['$eventId']['.write']
assert "withCommandLock" in fn and "withPublishLease" in fn and "await publish(eventId)" not in fn.split("exports.bbxV08CommandAuthority=")[1].split("exports.bbxV08GetOperation=")[0]
print("PASS V0.8 split event-local command/publish locks and V0.4 creation guards")
