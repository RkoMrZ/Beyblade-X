# BBX-V0.8

以使用者上傳的 `BBX-V0.7(1).zip` 為唯一程式基礎，保留原有 V1.0 HTML 與 CSS、裁判開始執裁、單場比分交易、賽事操作鎖及發布租約。不包含獨立報名系統。

## 本版變更
- 主辦／裁判賽事頁進背景、頁面離開時解除 RTDB 監聽與非必要定時讀取；已送出的記分請求與原操作代碼不會被中斷，回前景先核對雲端。
- 觀眾頁失敗重試 GET 加入串流世代與事件序號檢查，避免舊回應覆蓋新 SSE 增量。
- 公開發布一次讀取小型權威閘門，再按序消耗 outbox；不再每筆重新下載整份 `events/{eventId}`。發布租約仍保護刪除互斥，公開權限仍由權威狀態檢查。
- 首頁索引監聽使用回呼快照，不再次 GET `userEvents/{uid}`；連續事件合併處理最後快照，切換帳號或背景時不覆蓋新狀態。
- V0.8 只使用 `authorityBBXV08`，保留 V0.7 `authorityBBXV07` 歷史清理與公開權限檢查；既有賽事不強制改變版本。

## iPhone 手機工作流
1. 將 **BBX-V0.8.zip** 上傳 `rkomrz/Beyblade-X` 的 GitHub `main` 根目錄。
2. 於 Cloud Shell 下載 ZIP、核對 SHA-256、解壓到 `~/BBX-V0.8`。
3. 執行 `cd ~/BBX-V0.8 && bash 00_start.sh`。此腳本不使用巢狀 tmux，先檢查 Node 22、Node 測試與 Firebase Realtime Database Emulator，再部署 V0.8 九支 Cloud Functions 與相容的 Rules。
4. 部署成功後，用**同一 ZIP** 的 `index.html`、`viewer.html` 覆蓋 GitHub Pages 根目錄（非新建測試資料夾）。

只處理 `ljt-beyblade-x`。不清除現有賽事，不碰 `ljtreg-39954`。不得將本地單元測試當作實際多人雲端驗收。
