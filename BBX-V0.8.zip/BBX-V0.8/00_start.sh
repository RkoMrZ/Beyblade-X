#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
# Cloud Shell already runs in tmux. Do not nest sessions on an iPhone.
exec bash 01_release.sh
