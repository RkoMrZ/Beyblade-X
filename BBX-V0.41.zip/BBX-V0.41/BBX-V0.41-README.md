# BBX-V0.41 — 進行中賽事的獎品抽獎勾選同步修復

基於 BBX-V0.40。修復獎品抽獎勾選與同時進行的裁判比分共用全域 expectedSeq，導致正常取消勾選可能被拒絕的問題。

- **新 scoped action `setRaffleChecks`**：僅傳送異動的姓名與勾選布林值；後端依最新雲端權威狀態合併，保留獎品已中籤者與其他人勾選，不讀寫對戰順序。
- 同場的連續勾選 300ms 合併，所有寫入仍通過 `bbxV011OrganizerAuthority`、主辦權限與事件互斥；其他主辦動作仍保留嚴格 expectedSeq。
- 不修改比分交易、裁判鎖、觀眾 SSE、Rules 與獨立報名系統。
- 更新範圍：Hosting + `functions:bbxV011OrganizerAuthority`；未改其他 Functions 與資料庫。
- 抽獎「開始新一輪」及「抽出得主」的舊版整份狀態寫入路徑保留，未納入本次 scoped checkbox 修復。
- 本地測試不能取代兩支手機在賽事進行中的實機驗收。
