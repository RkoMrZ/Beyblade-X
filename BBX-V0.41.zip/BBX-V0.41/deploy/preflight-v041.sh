#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.41 ]] || { echo 'STOP: wrong release folder'; exit 2; }
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: wrong project'; exit 2; }
python3 - <<'PY_CHECK'
from pathlib import Path
import hashlib,json,re
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.41' and m['firebase_project']=='ljt-beyblade-x' and m['hosting_site']=='bbxs-tamsui'
assert m['functions_deploy_only']==['bbxV011OrganizerAuthority']
assert list(m['updated_backend_hashes'])==['functions/bbx-v011-organizer.js']
for item in m['files']:
 p=Path(item['path']);v=p.read_bytes()
 assert len(v)==item['bytes'] and hashlib.sha256(v).hexdigest()==item['sha256'],str(p)
for f,h in m['untouched_backend_hashes'].items():
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
for f,h in m['updated_backend_hashes'].items():
 assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
for page in ('index','viewer'):
 html=Path(page+'.html').read_text()
 for ext in ('js','css'):
  hits=re.findall(r'assets/'+page+r'-v041-[a-f0-9]{12}\.'+ext,html)
  assert len(hits)==1,(page,ext,hits)
  asset=Path(hits[0]);digest=re.search(r'-([a-f0-9]{12})\.',asset.name).group(1)
  assert hashlib.sha256(asset.read_bytes()).hexdigest().startswith(digest),str(asset)
assert 'firebase-database-compat.js' not in Path('index.html').read_text()
assert 'firebase-auth-compat.js' in Path('index.html').read_text()
assert 'firebase-functions-compat.js' in Path('index.html').read_text()
for word in ('firebase.database(','.info/connected','forceLongPolling('):
 assert word not in Path('assets/index-v041.js').read_text(),word
print('PASS: V0.41 manifest, backend-scope, SSE-only and immutable assets')
PY_CHECK
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required';exit 2; }
for f in functions/*.js assets/index-v041.js assets/viewer-v041.js; do node --check "$f";done
node --test tests/*.test.js
python3 tests/check_static.py
python3 tests/check_rules_syntax.py
python3 tests/check_cleanup_rules.py
python3 deploy/merge-rules.py docs/previous-v09-rules.json /tmp/bbx-v041-rules-merge.json
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI not installed'; exit 4; }
free_kb=$(df -Pk "$HOME" | awk 'NR==2{print $4}')
[[ "$free_kb" -ge 650000 ]] || { echo 'STOP: Cloud Shell free space under 650MB'; exit 4; }
npm ci --prefix tests --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v011 --config firebase.json 'cd tests && node rules-emulator.test.cjs'
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v041-preflight-ok"
echo 'PASS: V0.41 local suite, Rules Emulator and release preflight'
