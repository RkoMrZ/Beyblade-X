#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.41 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: V0.41 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.41 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v041.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v041-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight mismatch';exit 3; }
# A backward-compatible scoped raffle action; existing score and other functions
# are left untouched. Install the callable BEFORE publishing HTML which invokes it.
[[ "$(gcloud config get-value project 2>/dev/null)" == ljt-beyblade-x ]] || { echo 'STOP: wrong Firebase project'; exit 2; }
# This ZIP intentionally excludes node_modules; Firebase CLI needs installed
# local dependencies to discover the callable before Cloud Build.
npm install --prefix functions --no-audit --no-fund
firebase deploy --only functions:bbxV011OrganizerAuthority --config firebase.json --project ljt-beyblade-x --non-interactive
bash deploy/hosting-v041.sh
date -u > .release-completed
printf '\nPASS: V0.41 scoped raffle authority and Hosting deployed; Rules/data/other functions unchanged.\n'
