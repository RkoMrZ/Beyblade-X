'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const O=require('../functions/bbx-v011-organizer');
const ui=fs.readFileSync(path.resolve(__dirname,'../assets/index-v041.js'),'utf8');
let n=0;
const now=Date.now(), opId=()=>now.toString(16).padStart(12,'0')+(++n).toString(16).padStart(36,'0');
function fixture(){return {ownerUid:'ORGANIZER',seq:7,roster:['A','B','C','D'],refereeCount:4,refereeNames:['裁判 1','裁判 2','裁判 3','裁判 4'],rounds:[{matches:[{a:'A',b:'B',sa:4,sb:1,winner:'A',referee:'',refereeActive:false,claimUid:null,matchVersion:5},{a:'C',b:'D',sa:4,sb:0,winner:'C',referee:'',refereeActive:false,claimUid:null,matchVersion:6}]}],finalRR:null,outbox:{},receipts:{}}}
const run=(b,names)=>O.apply(b,'ORGANIZER',{action:'setReferees',opId:opId(),expectedSeq:b.seq,refereeNames:names},now,{});
test('V0.39: changing all four unclaimed referee names after complete is allowed, without altering completed matches',()=>{
 const b=fixture(),match=JSON.stringify(b.rounds),r=run(b,['X','Y','Z','W']);
 assert.deepEqual(r.board.refereeNames,['X','Y','Z','W']);
 assert.equal(JSON.stringify(r.board.rounds),match);
 assert.ok(r.changes.every(c=>!c.structure));
});
test('V0.39: deleting released referee after finished matches preserves historical winner and score',()=>{
 const b=fixture(),before=JSON.stringify(b.rounds),r=run(b,['裁判 1','裁判 3','裁判 4']);
 assert.equal(r.board.refereeCount,3);assert.deepEqual(r.board.refereeNames,['裁判 1','裁判 3','裁判 4']);
 assert.equal(JSON.stringify(r.board.rounds),before);
});
test('V0.39: stale claimUid on already finished match is not considered active judge',()=>{
 const b=fixture();b.rounds[0].matches[0].claimUid='OLD_UID';
 assert.equal(O.anyActiveReferee(b),false);
 assert.equal(run(b,['X','Y','Z','W']).board.refereeNames[0],'X');
});
test('V0.39: active lock or unresolved judge ownership still blocks roster replacement',()=>{
 for(const mode of ['active','unresolved']){
  const b=fixture(),m=b.rounds[0].matches[0];m.winner=null;
  if(mode==='active')m.refereeActive=true;else m.claimUid='UID';
  assert.equal(O.anyActiveReferee(b),true);assert.throws(()=>run(b,['X','Y','Z','W']),/正在執裁/);
 }
});
test('V0.39: completed scores still block structural rebuild',()=>{
 const b=fixture();assert.equal(O.anyStarted(b),true);
 assert.throws(()=>O.apply(b,'ORGANIZER',{action:'rebuild',opId:opId(),expectedSeq:b.seq},now,{}),/賽事已開始/);
});
test('V0.39: no-op name save suppresses unnecessary cloud command',()=>{
 const save=ui.slice(ui.indexOf('async function saveRefereeNames(){'),ui.indexOf('function refereeOptionsHtml('));
 assert.match(save,/nextNames\.every\(\(name,i\)=>name===ev\.refereeNames\[i\]\)\)return/);
});
test('V0.39: organizer wrapper does not render after awaited authoritative refresh',()=>{
 const wrapper=ui.slice(ui.indexOf('async function v1OrganizerAction('),ui.indexOf('function publicMatchCloudPath('));
 assert.match(wrapper,/await v1CloudOrganizerCommand/);
 assert.doesNotMatch(wrapper,/renderAdmin\(|renderReferee\(/);
});
test('V0.39: SSE coalesces structural probes but retains 12-second low-volume safety watchdog',()=>{
 const sse=ui.slice(ui.indexOf('function listenCloudEvent(id){'),ui.indexOf('async function waitForAuthRestore('));
 assert.match(sse,/scheduleStructureProbe\(\)/);
 assert.match(sse,/if\(structureProbeBusy\)\{structureProbeAgain=true;return;\}/);
 assert.match(sse,/setInterval\(watchdog,12000\)/);
 assert.doesNotMatch(sse,/firebase\.database\s*\(/);
});
