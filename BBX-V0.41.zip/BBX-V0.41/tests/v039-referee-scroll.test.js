const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../assets/index-v041.js'),'utf8');
const section=(start,end)=>source.slice(source.indexOf(start),source.indexOf(end,source.indexOf(start)+start.length));

test('claim and release identity only patch bracket, then refresh current referee tab',()=>{
  const part=section('async function releaseRefereeSlot(index){','function refereeOptionsHtml(');
  assert.doesNotMatch(part,/renderAdmin\(\)/);
  assert.match(part,/async function setMyReferee\(name\)/);
  assert.match(part,/renderAdmin\(\{bracketOnly:true\}\);\s*\n?\s*if\(isReferee/);
  assert.match(part,/showTab\('referee'\)/);
});
test('referee claim render reconciles changed rows without detaching QR or edited names',()=>{
  const part=section('function updateRefereePanelHtml(','async function renderReferee(');
  assert.match(part,/querySelectorAll\('\.refIdentityRow'\)/);
  assert.match(part,/querySelectorAll\('\.refereeNameEdit'\)/);
  assert.match(part,/querySelectorAll\(selector\)/);
  assert.match(part,/if\(before\[i\]\.outerHTML!==after\[i\]\.outerHTML\)before\[i\]\.replaceWith/);
  assert.match(part,/window\.scrollTo\(oldPage\.x,oldPage\.y\)/);
});
test('cloud claims refresh rerenders only the current referee tab',()=>{
  const part=section('async function refreshRefereeClaimsNow(){','function findRefereeIndexByName(');
  assert.match(part,/renderReferee\(\{skipCloudRefresh:true\}\)/);
  assert.doesNotMatch(part,/renderAdmin\(\)/);
});
