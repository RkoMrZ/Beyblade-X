#!/usr/bin/env python3
"""Real Chromium DOM check for the native roster disclosure, independent of Firebase."""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text()
fragment=html[html.index('<section id="create"'):html.index('<section id="admin"')].replace('<section id="create" class="hidden">','<section id="create">',1)
css=(root/'assets/index-v041.css').read_text()
js=(root/'assets/index-v041.js').read_text()
source=js[js.index('function renderRosterPreviewFromDraft(){'):js.index('function updatePreview(){')]
script='''var draftRoster=[];function $(id){return document.getElementById(id)};
function esc(v){return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')};''' +source
counts=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [375,390,768,1366]:
  page=browser.new_page(viewport={'width':width,'height':760})
  page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style>'+fragment)
  page.evaluate(script)
  toggle=page.locator('#draftRosterDisclosure summary')
  assert page.locator('#draftRosterDisclosure').get_attribute('open') is None
  assert not page.locator('#rosterPreview').is_visible()
  assert page.locator('[data-create-tournament="1"]').is_visible()
  # Update list while closed, the count remains visible.
  page.evaluate('draftRoster=Array.from({length:48},(_,i)=>`選手 ${i+1}`); renderRosterPreviewFromDraft()')
  assert page.locator('#countBadge').inner_text()=='48 人'
  assert page.locator('#rosterPreview .player').count()==48
  assert not page.locator('#rosterPreview').is_visible()
  assert page.locator('[data-create-tournament="1"]').is_visible()
  toggle.click()
  assert page.locator('#rosterPreview').is_visible()
  assert page.locator('#draftRosterDisclosure').get_attribute('open') is not None
  # Re-render must not reset the disclosure or remove other form fields.
  page.evaluate('draftRoster=Array.from({length:22},(_,i)=>`選手 ${i+1}`);renderRosterPreviewFromDraft()')
  assert page.locator('#rosterPreview .player').count()==22
  assert page.locator('#rosterPreview').is_visible()
  assert page.locator('#eventName').count()==1
  toggle.click()
  assert not page.locator('#rosterPreview').is_visible()
  assert page.locator('[data-create-tournament="1"]').is_visible()
  counts.append(width)
  page.close()
 browser.close()
print(f'PASS V0.41 collapsed default, 48 names, expand, 22-name refresh, collapse and create button in {counts}')
