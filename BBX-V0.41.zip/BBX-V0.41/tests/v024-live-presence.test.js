"use strict";
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {buildProjectionPatch}=require('../functions/bbx-v011-publication');
const {sanitizedMatch}=require('../functions/bbx-v011-core');
test('a public match shows active referee display name but never UID',()=>{
 const m=sanitizedMatch({a:'A',b:'B',sa:0,sb:0,winner:null,refereeActive:true,referee:'Secret Name',claimUid:'secretUid'});
 assert.deepEqual(m,{a:'A',b:'B',sa:0,sb:0,winner:null,refereeActive:true,referee:'Secret Name'});
 const patch=buildProjectionPatch('BBX123456',{seq:5,changes:[{path:'rounds/0/matches/1',value:{...m,matchVersion:3,claimUid:'secretUid'},publicValue:m}]});
 assert.equal(patch['publicEvents/BBX123456/rounds/0/matches/1'].refereeActive,true);
 assert.equal(patch['publicEvents/BBX123456/rounds/0/matches/1'].claimUid,undefined);
 assert.deepEqual(patch['events/BBX123456/publishedMatchHints'],{seq:5,matches:{r0_1:{version:3,refereeActive:true,referee:'Secret Name',winner:null,sa:0,sb:0}}});
 for(const key of Object.keys(patch['events/BBX123456/publishedMatchHints'].matches)) assert.match(key,/^[a-zA-Z0-9_-]+$/);
});
test('public viewer renders public display name and excludes private UID',()=>{
 const script=fs.readFileSync(path.join(__dirname,'../assets/viewer-v041.js'),'utf8');
 const code=script.slice(script.indexOf('function matchHtml('),script.indexOf('function rrHtml('));
 const ctx={esc:v=>String(v),console};vm.createContext(ctx);vm.runInContext(code,ctx);
 const active=ctx.matchHtml({a:'A',b:'B',sa:0,sb:0,refereeActive:true},0,0,{});
 assert.match(active,/judging/);assert.match(active,/執裁中：裁判/);assert.doesNotMatch(active,/refereeUid|claimUid|Secret Name/);
 const idle=ctx.matchHtml({a:'A',b:'B',sa:0,sb:0,refereeActive:false},0,0,{});
 assert.doesNotMatch(idle,/執裁中|judging/);
});
test('published hint uses safe stable keys even for multi-round and 3-player RR paths',()=>{
 const patch=buildProjectionPatch('BBX123456',{seq:17,changes:[
  {path:'rounds/2/matches/7',value:{matchVersion:9},publicChanged:false},
  {path:'finalRR/matches/2',value:{matchVersion:3},publicChanged:false}]});
 assert.deepEqual(patch['events/BBX123456/publishedMatchHints'].matches,{r2_7:{version:9,refereeActive:false,referee:'',winner:null,sa:'',sb:''},f2:{version:3,refereeActive:false,referee:'',winner:null,sa:'',sb:''}});
});
