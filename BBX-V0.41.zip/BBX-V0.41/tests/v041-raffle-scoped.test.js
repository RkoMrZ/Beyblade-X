'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const path=require('node:path');
const fs=require('node:fs');
const vm=require('node:vm');
const O=require('../functions/bbx-v011-organizer.js');
const stamp=Date.now();let increment=0;
const opId=()=>stamp.toString(16).padStart(12,'0')+(++increment).toString(16).padStart(36,'0');
function board(){return {ownerUid:'OWNER',seq:27,roster:['阿賢','阿霆','阿金'],rounds:[{matches:[{a:'阿賢',b:'阿霆',sa:3,sb:2,refereeActive:true,claimUid:'JUDGE',matchVersion:11}]}],finalRR:null,refereeNames:['裁判 1'],refereeCount:1,raffleState:{winners:[],checked:{阿賢:true,阿霆:true,阿金:true}},receipts:{},outbox:{}}}
function update(raw,checks,extras={},uid='OWNER'){
 return O.apply(raw,uid,{action:'setRaffleChecks',opId:opId(),expectedSeq:1,checks,...extras},stamp,{admin:false});
}
test('live match seq drift does not reject scoped raffle toggle; scores and lock remain byte-identical',()=>{
 const raw=board(),preMatch=JSON.stringify(raw.rounds);
 const changed=update(raw,[{name:'阿霆',checked:false}]);
 assert.equal(changed.board.seq,28);
 assert.deepEqual(changed.board.raffleState.checked,{阿賢:true,阿霆:false,阿金:true});
 assert.equal(JSON.stringify(changed.board.rounds),preMatch);
 assert.deepEqual(changed.changes.map(x=>x.path),['raffleState']);
 assert.equal(changed.changes[0].publicChanged,false);
 assert.equal(raw.raffleState.checked.阿霆,true);
});
test('two independent roster checkbox updates merge without overwriting unrelated toggles or winners',()=>{
 const raw=board();raw.raffleState.winners=['阿金'];raw.raffleState.checked.阿金=false;
 const first=update(raw,[{name:'阿賢',checked:false}]);
 const second=update(first.board,[{name:'阿霆',checked:false}]);
 assert.deepEqual(second.board.raffleState,{winners:['阿金'],checked:{阿賢:false,阿霆:false,阿金:false}});
});
test('duplicate opId returns receipt without duplicate change',()=>{
 const raw=board(),id=opId(),req={action:'setRaffleChecks',opId:id,expectedSeq:0,checks:[{name:'阿霆',checked:false}]};
 const first=O.apply(raw,'OWNER',req,stamp,{});
 const second=O.apply(first.board,'OWNER',req,stamp,{});
 assert.equal(second.replay,true);assert.equal(second.receipt.seq,first.board.seq);
});
test('only organizer can patch; no stale-seq bypass for other organizer actions',()=>{
 const raw=board();
 assert.throws(()=>update(raw,[{name:'阿霆',checked:false}],{},'OTHER'),/僅主辦/);
 assert.throws(()=>O.apply(raw,'OWNER',{action:'setRaffle',opId:opId(),expectedSeq:3,raffleState:raw.raffleState},stamp,{}),/重新載入/);
});
test('malformed, duplicate, unknown and already-won entries are rejected',()=>{
 const b=board();
 assert.throws(()=>update(b,[{name:'阿霆',checked:'false'}]),/無效/);
 assert.throws(()=>update(b,[{name:'阿霆',checked:false},{name:'阿霆',checked:true}]),/無效/);
 assert.throws(()=>update(b,[{name:'陌生人',checked:false}]),/無效/);
 b.raffleState.winners=['阿霆'];
 assert.throws(()=>update(b,[{name:'阿霆',checked:false}]),/已中籤/);
});
test('frontend checkbox posts a scoped patch, never a whole raffleState snapshot',()=>{
 const src=fs.readFileSync(path.join(__dirname,'../assets/index-v041.js'),'utf8');
 const part=src.slice(src.indexOf('function setRaffleChecked(name,checked){'),src.indexOf('function resetPrizeRaffleRound(){'));
 const calls=[];const ctx={ev:{id:'E',roster:['阿賢','阿霆'],testOnly:false,raffleState:{winners:[],checked:{阿賢:true,阿霆:true}}},
 hasOrganizerAccess:()=>true,isV1Authority:()=>true,raffleSpinning:false,getRaffleState(){return JSON.parse(JSON.stringify(ctx.ev.raffleState))},
 cloneJson:structuredClone,cloudEventsCache:{},renderDraw(){},enqueueV1RaffleCheck(...args){calls.push(args)}};
 vm.createContext(ctx);vm.runInContext(part,ctx);
 vm.runInContext('setRaffleChecked("阿霆",false)',ctx);
 assert.deepEqual(calls,[['阿霆',false]]);
 assert.equal(ctx.ev.raffleState.checked.阿霆,false);
});
test('checkbox queue batches edits and submits one callable without global seq retry',async()=>{
 const src=fs.readFileSync(path.join(__dirname,'../assets/index-v041.js'),'utf8');
 const part=src.slice(src.indexOf('let v1RaffleChecksEventId=null;'),src.indexOf('let v1RafflePending=null,v1RaffleTimer=null,v1RaffleBusy=false;'));
 let task;const calls=[];
 const ctx={ev:{id:'E'},Map,console,clearTimeout(){},setTimeout(cb){task=cb;return 1},currentAdminTab:'bracket',
 async v1CloudOrganizerCommand(action,payload,id){calls.push({action,payload,id});return {ok:true}},backgroundRefreshCurrentEvent:async()=>{},renderDraw(){},alert(){throw Error('unexpected failure')}};
 vm.createContext(ctx);vm.runInContext(part,ctx);
 vm.runInContext('enqueueV1RaffleCheck("阿賢",false);enqueueV1RaffleCheck("阿霆",false)',ctx);
 await vm.runInContext('flushV1RaffleChecks()',ctx);
 assert.equal(calls.length,1);
 assert.equal(calls[0].action,'setRaffleChecks');assert.equal(calls[0].id,'E');
 assert.deepEqual(JSON.parse(JSON.stringify(calls[0].payload.checks)),[{name:'阿賢',checked:false},{name:'阿霆',checked:false}]);
});
