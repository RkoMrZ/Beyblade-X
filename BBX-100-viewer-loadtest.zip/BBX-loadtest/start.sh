#!/usr/bin/env bash
set -euo pipefail
ROOT="$HOME/BBX-loadtest"
COUNT="${1:-100}"
DURATION="${2:-600}"
if ! [[ "$COUNT" =~ ^[0-9]+$ ]] || ((COUNT < 1 || COUNT > 100)); then echo '連線數限 1～100'; exit 2; fi
if ! [[ "$DURATION" =~ ^[0-9]+$ ]] || ((DURATION < 15 || DURATION > 900)); then echo '秒數限 15～900'; exit 2; fi
if [[ -f "$ROOT/test.pid" ]]; then
  PID="$(cat "$ROOT/test.pid")"
  if [[ "$PID" =~ ^[0-9]+$ ]] && kill -0 "$PID" 2>/dev/null && tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null | grep -q 'viewer_load.py'; then
    echo "已有測試在執行，PID=$PID。先 bash ~/BBX-loadtest/status.sh 或 stop.sh"; exit 1
  fi
fi
rm -f "$ROOT/summary.json"
nohup python3 -u "$ROOT/viewer_load.py" --viewers "$COUNT" --duration "$DURATION" --output "$ROOT" > "$ROOT/test.log" 2>&1 < /dev/null &
PID=$!
printf '%s\n' "$PID" > "$ROOT/test.pid"
sleep 2
if ! kill -0 "$PID" 2>/dev/null; then
  echo '測試啟動失敗：'; tail -30 "$ROOT/test.log"; exit 1
fi
echo "已在背景啟動：${COUNT} 位觀眾，最多 ${DURATION} 秒。PID=${PID}"
echo '現在可以切去主辦頁，測試「回首頁 → 再進賽事」。'
echo '查看狀態：bash ~/BBX-loadtest/status.sh'
echo '立即停止：bash ~/BBX-loadtest/stop.sh'
