#!/usr/bin/env bash
ROOT="$HOME/BBX-loadtest"
if [[ -f "$ROOT/test.pid" ]]; then
  PID="$(cat "$ROOT/test.pid")"
  if [[ "$PID" =~ ^[0-9]+$ ]] && kill -0 "$PID" 2>/dev/null && tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null | grep -q 'viewer_load.py'; then echo "測試執行中 (PID=$PID)"; else echo '測試已結束'; fi
else echo '尚未啟動或已手動停止'; fi
if [[ -f "$ROOT/test.log" ]]; then tail -14 "$ROOT/test.log"; fi
if [[ -f "$ROOT/summary.json" ]]; then echo '已產生：~/BBX-loadtest/summary.json'; fi
