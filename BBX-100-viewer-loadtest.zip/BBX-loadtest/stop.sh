#!/usr/bin/env bash
set -euo pipefail
ROOT="$HOME/BBX-loadtest"
if [[ ! -f "$ROOT/test.pid" ]]; then echo '沒有測試 PID 紀錄。'; exit 0; fi
PID="$(cat "$ROOT/test.pid")"
if ! [[ "$PID" =~ ^[0-9]+$ ]]; then echo 'PID 格式錯誤，不執行 kill'; exit 2; fi
if ! kill -0 "$PID" 2>/dev/null; then echo '測試已停止'; rm -f "$ROOT/test.pid"; exit 0; fi
if ! tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null | grep -q 'viewer_load.py'; then
  echo 'PID 已不屬於測試程式，安全起見不執行 kill'; exit 2
fi
kill -TERM "$PID" || true
for i in 1 2 3 4 5; do
  if ! kill -0 "$PID" 2>/dev/null; then break; fi
  sleep 1
done
if kill -0 "$PID" 2>/dev/null && tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null | grep -q 'viewer_load.py'; then
  kill -KILL "$PID" 2>/dev/null || true
fi
rm -f "$ROOT/test.pid"
echo '測試已停止，所有此程序的 SSE TCP 連線會隨程序終止而關閉。'
echo '查看報告：bash ~/BBX-loadtest/status.sh'
