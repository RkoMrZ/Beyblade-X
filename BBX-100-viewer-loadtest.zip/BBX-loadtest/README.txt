BBX /v/2NUBH 觀眾壓力測試 — Cloud Shell 背景執行

固定測試目標：
  Website: https://bbxs-tamsui.web.app/v/2NUBH
  RTDB: ljt-beyblade-x, 只讀公開 bbxPublicCodeLookup 與 publicEvents SSE

不需提供 Google 登入權杖；不寫入賽事資料；不呼叫主辦 Functions。
預設 100 位獨立訪客，每位載入 /v/2NUBH HTML、viewer CSS/JS、五碼查詢、保持一條公開 SSE。
每 30 秒測 Hosting 首頁 HTTP 可達性。
手動在主辦手機測試「首頁 -> 我的賽事 -> 進入舊賽事」，壓力工具無法模擬主辦 Google 登入。

啟動預設 100 人 / 10 分鐘： bash ~/BBX-loadtest/start.sh
啟動 40 人 / 5 分鐘： bash ~/BBX-loadtest/start.sh 40 300
查看即時狀態：           bash ~/BBX-loadtest/status.sh
提前停止全部連線：       bash ~/BBX-loadtest/stop.sh

背景程序受 Google Cloud Shell VM 生命週期影響；手機切頁一般不會立即停止，
但 Cloud Shell 若終止或 VM 回收，100 條測試連線也會立即斷開。
測試最多 15 分鐘後自動退出，避免無上限流量消耗。

test.log/status: activeSSE/initialPut/alias/patch/reconnect/errors/homepageProbes
summary.json: 完成時輸出的聚合數據，不包含比分、姓名或帳號資料

限制：這是 100 個獨立的 HTTP + SSE 連線，不是 100 個真的執行 JS、渲染 DOM 的瀏覽器；
所有連線來自同一台 Cloud Shell VM，不能完全模擬 100 支手機。Blaze 會依流量計費。
