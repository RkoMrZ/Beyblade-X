#!/usr/bin/env python3
"""Authorized, read-only BBX spectator SSE test. Python standard library only."""
import argparse
import json
import os
import random
import re
import signal
import statistics
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SITE = 'https://bbxs-tamsui.web.app'
DB = 'https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app'
CODE = '2NUBH'
STOP = threading.Event()
LOCK = threading.RLock()
STAT = {
    'started': 0, 'html_ok': 0, 'alias_ok': 0, 'assets_ok': 0,
    'active_sse': 0, 'ever_sse': 0, 'initial_put_ok': 0,
    'put': 0, 'patch': 0, 'reconnect': 0, 'errors': 0,
    'bytes_sse': 0, 'homepage_probes_ok': 0, 'homepage_probes_fail': 0,
    'first_put_sec': [], 'errors_sample': [],
}
UA = 'BBX-spectator-loadtest/1.0 (owner authorized; read-only)'


def log(msg):
    print(time.strftime('%H:%M:%S'), msg, flush=True)


def inc(key, amount=1):
    with LOCK:
        STAT[key] += amount


def error(where, exc):
    with LOCK:
        STAT['errors'] += 1
        if len(STAT['errors_sample']) < 30:
            STAT['errors_sample'].append(f'{where}: {type(exc).__name__}: {str(exc)[:160]}')


def request(url, accept=None, timeout=15):
    headers = {'User-Agent': UA, 'Cache-Control': 'no-cache'}
    if accept:
        headers['Accept'] = accept
    req = urllib.request.Request(url, headers=headers, method='GET')
    return urllib.request.urlopen(req, timeout=timeout)


def read_bounded(url, accept=None, limit=2_000_000, timeout=15):
    with request(url, accept, timeout=timeout) as response:
        if response.status != 200:
            raise RuntimeError(f'HTTP {response.status} {url}')
        data = response.read(limit + 1)
        if len(data) > limit:
            raise RuntimeError(f'unexpected large response ({limit}+ bytes) {url}')
        return data


def preflight():
    html = read_bounded(f'{SITE}/v/{CODE}', 'text/html').decode('utf-8', 'replace')
    assets = sorted(set(re.findall(r'assets/viewer-v\d{3}-[a-f0-9]{12}\.(?:js|css)', html)))
    if not assets:
        raise RuntimeError('Could not find fingerprinted viewer assets in live HTML. Stop rather than simulate an outdated version.')
    for asset in assets:
        read_bounded(f'{SITE}/{asset}')
    alias = json.loads(read_bounded(f'{DB}/bbxPublicCodeLookup/{CODE}.json', 'application/json').decode('utf-8'))
    if not isinstance(alias, str) or not re.fullmatch(r'[A-Za-z0-9_-]{6,100}', alias):
        raise RuntimeError('Public code does not resolve to a valid event ID; no test started.')
    # One bounded read to verify the event is accessible, without leaking data into logs.
    meta = json.loads(read_bounded(f'{DB}/publicEvents/{urllib.parse.quote(alias, safe="")}/meta/authoritySeq.json', 'application/json', limit=100_000).decode('utf-8'))
    log(f'PREFLIGHT OK: site={SITE}/v/{CODE} assets={len(assets)} public lookup=OK public metadata=OK')
    return alias, assets


def guest(idx, event_id, assets, gate, end_at):
    gate.wait()
    if STOP.is_set():
        return
    begin = time.monotonic()
    inc('started')
    try:
        read_bounded(f'{SITE}/v/{CODE}', 'text/html')
        inc('html_ok')
        # Cold browser: CSS and JS fetched once per visitor; no shared cache.
        for asset in assets:
            read_bounded(f'{SITE}/{asset}')
        inc('assets_ok')
        alias = json.loads(read_bounded(f'{DB}/bbxPublicCodeLookup/{CODE}.json', 'application/json').decode('utf-8'))
        if alias != event_id:
            raise RuntimeError('public code resolved to a different event during the test')
        inc('alias_ok')
    except Exception as exc:
        error(f'guest{idx}/initial-http', exc)
        return
    stream_url = f'{DB}/publicEvents/{urllib.parse.quote(event_id, safe="")}.json'
    initial_seen = False
    attempts = 0
    while not STOP.is_set() and time.monotonic() < end_at:
        attempts += 1
        active = False
        try:
            with request(stream_url, 'text/event-stream', timeout=90) as response:
                mime = response.headers.get('Content-Type', '')
                if response.status != 200 or 'text/event-stream' not in mime:
                    raise RuntimeError(f'SSE response HTTP={response.status} content-type={mime}')
                with LOCK:
                    STAT['active_sse'] += 1
                    STAT['ever_sse'] += int(attempts == 1)
                active = True
                name = ''
                event_payload = []
                # Data is not saved: public scoreboard content remains private to this request.
                while not STOP.is_set() and time.monotonic() < end_at:
                    line = response.readline()
                    if not line:
                        raise RuntimeError('SSE stream closed')
                    inc('bytes_sse', len(line))
                    s = line.decode('utf-8', 'replace').rstrip('\r\n')
                    if not s:
                        if name in ('put', 'patch'):
                            inc(name)
                            if name == 'put' and not initial_seen:
                                initial_seen = True
                                with LOCK:
                                    STAT['initial_put_ok'] += 1
                                    STAT['first_put_sec'].append(round(time.monotonic() - begin, 3))
                        if name in ('cancel', 'auth_revoked'):
                            raise RuntimeError('SSE permission revoked/cancelled')
                        name = ''
                        event_payload.clear()
                    elif s.startswith('event:'):
                        name = s[6:].strip()
                    elif s.startswith('data:'):
                        # Avoid decoding/storing snapshots; only SSE event type is needed.
                        pass
        except Exception as exc:
            if not STOP.is_set() and time.monotonic() < end_at:
                error(f'guest{idx}/sse', exc)
        finally:
            if active:
                inc('active_sse', -1)
        if STOP.is_set() or time.monotonic() >= end_at:
            break
        inc('reconnect')
        STOP.wait(random.uniform(2, 5))


def snapshot():
    with LOCK:
        s = dict(STAT)
        timings = s.pop('first_put_sec')
    if timings:
        timings = sorted(timings)
        s['initial_put_p50_sec'] = round(statistics.median(timings), 3)
        s['initial_put_p95_sec'] = timings[min(len(timings) - 1, int(0.95 * len(timings)))]
        s['initial_put_max_sec'] = timings[-1]
    return s


def terminate(signum, frame):
    STOP.set()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--viewers', type=int, default=100)
    parser.add_argument('--duration', type=int, default=600)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if not 1 <= args.viewers <= 100:
        parser.error('viewers must be 1..100')
    if not 15 <= args.duration <= 900:
        parser.error('duration must be between 15 and 900 seconds')
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    args.output.mkdir(parents=True, exist_ok=True)
    log('BBX authorized read-only test: no Firebase writes and no organizer credentials')
    try:
        event_id, assets = preflight()
    except Exception as exc:
        log(f'PREFLIGHT FAILED: {type(exc).__name__}: {exc}')
        sys.exit(2)
    end_at = time.monotonic() + args.duration
    gate = threading.Event()
    executor = ThreadPoolExecutor(max_workers=args.viewers, thread_name_prefix='viewer')
    jobs = [executor.submit(guest, i, event_id, assets, gate, end_at) for i in range(args.viewers)]
    log(f'LAUNCH viewers={args.viewers} seconds={args.duration}; simultaneous start in ~1 second; Cloud Shell may suspend on inactivity')
    time.sleep(1)
    gate.set()
    last_probe = 0
    while not STOP.is_set() and time.monotonic() < end_at:
        now = time.monotonic()
        if now - last_probe >= 30:
            last_probe = now
            try:
                read_bounded(f'{SITE}/', 'text/html', timeout=8)
                inc('homepage_probes_ok')
            except Exception as exc:
                inc('homepage_probes_fail')
                error('hosting-home-probe', exc)
        s = snapshot()
        log(f"STATUS activeSSE={s['active_sse']}/{args.viewers} initialPut={s['initial_put_ok']} html={s['html_ok']} alias={s['alias_ok']} patch={s['patch']} reconnect={s['reconnect']} errors={s['errors']} homepageOK={s['homepage_probes_ok']} homepageFAIL={s['homepage_probes_fail']}")
        STOP.wait(10)
    STOP.set()
    s = snapshot()
    s['viewers_target'] = args.viewers
    s['test_duration_limit_sec'] = args.duration
    s['finished_at'] = time.strftime('%Y-%m-%d %H:%M:%S %z')
    s['note'] = '100 independent read-only HTTP/SSE clients, NOT 100 executing browser JavaScript contexts. Organizer re-entry requires manual real-account test.'
    outfile = args.output / 'summary.json'
    outfile.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding='utf-8')
    log(f'FINAL SUMMARY {outfile}')
    log(json.dumps({k: v for k, v in s.items() if k != 'errors_sample'}, ensure_ascii=False))
    # Exit reliably even if idle SSE read() is blocked; OS closes all sockets.
    sys.stdout.flush()
    os._exit(0)


if __name__ == '__main__':
    main()
