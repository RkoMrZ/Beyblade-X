const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ui=fs.readFileSync(path.join(__dirname,'../assets/index-v022.js'),'utf8');
const css=fs.readFileSync(path.join(__dirname,'../assets/index-v022.css'),'utf8');
const part=ui.slice(ui.indexOf('function listenCloudEvent(id){'),ui.indexOf('async function waitForAuthRestore('));
test('compact hidden status and click-only detailed explanation',()=>{
 assert.match(part,/wrapper.classList.toggle\('hidden',!message\)/);
 assert.match(part,/button.addEventListener\('click'/);
 assert.match(part,/button.setAttribute\('aria-expanded','false'\)/);
 assert.match(css,/\.bbxSyncStatusButton\{/);
 assert.doesNotMatch(part,/style.cssText='margin:10px 16px/);
});
test('initial authority notification is a baseline not a missing match',()=>{
 assert.match(part,/if\(firstAuthorityNotice\)/);
 assert.match(part,/scheduleLiveRecovery\('initial-sequence-baseline',900\)/);
 assert.match(part,/if\(!soft\)\{/);
});
test('soft background verification on healthy stream cannot latch write gate',()=>{
 assert.match(part,/if\(!soft\|\|!liveConnected\)\{/);
 assert.match(part,/verifiedRestSeq>=observedAuthoritySeq/);
});
test('genuine stale-state write prevention remains',()=>{
 assert.match(ui,/if\(cloudResyncBlocked\)throw new Error/);
 assert.match(part,/cloudResyncBlocked=true/);
});
