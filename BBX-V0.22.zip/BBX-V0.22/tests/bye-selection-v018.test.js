'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),Org=require('../functions/bbx-v011-organizer');
const ui=fs.readFileSync(require('node:path').join(__dirname,'../assets/index-v022.js'),'utf8');
const definitions=['function autoFormatPlan(n){','function draftCreateFormat(n,byeOption,manualFinal){','function canFreeReachThree(n){'];
const code=ui.match(/const AUTO_FORMAT_TARGETS=Object\.freeze\(\[[^\]]+\]\);/)[0]+'\n'+definitions.map((name)=>{const i=ui.indexOf(name);assert.ok(i>=0,name);let pos=i+name.length,depth=1;for(;pos<ui.length&&depth;pos++){if(ui[pos]==='{')depth++;if(ui[pos]==='}')depth--;}return ui.slice(i,pos);}).join('\n');
const ctx=vm.createContext({});vm.runInContext(code,ctx);const plan=(n,policy,final)=>vm.runInContext(`draftCreateFormat(${n},'${policy}','${final}')`,ctx);
const roster=n=>Array.from({length:n},(_,i)=>`選手 ${i+1}`);
test('default auto16 still allocates 40 to 48 with 8 direct BYEs',()=>{const p=plan(40,'auto','rr3');assert.equal(p.target,48);assert.equal(p.byes,8);assert.equal(p.formatPolicy,'auto16');const b=Org.build(roster(40),'free',p.freeFinal,null,{formatPolicy:p.formatPolicy});assert.equal(b.rounds[0].matches.length,24);assert.equal(b.rounds[0].matches.filter(m=>m.winner).length,8)});
test('un-padded 40 first round contains 20 real matches and no BYEs',()=>{const p=plan(40,'none','rr3');assert.equal(p.target,40);assert.equal(p.byes,0);assert.equal(p.formatPolicy,null);const b=Org.build(roster(40),'free',p.freeFinal);assert.equal(b.rounds[0].matches.length,20);assert.equal(b.rounds[0].matches.filter(m=>m.a==='BYE'||m.b==='BYE').length,0)});
test('un-padded 20 entrants can select champion or 3-player cycle but later rounds may need natural bye',()=>{for(const f of ['champ','rr3']){const p=plan(20,'none',f);assert.equal(p.freeFinal,f);const b=Org.build(roster(20),'free',f);assert.equal(b.rounds[0].matches.length,10)} });
test('3 player no-bye plan creates direct round robin',()=>{const p=plan(3,'none','rr3');const b=Org.build(roster(3),'free',p.freeFinal);assert.equal(b.rounds.length,0);assert.equal(b.finalRR.matches.length,3)});
test('3 entrant cannot select champion with automatic first-round BYE',()=>assert.throws(()=>plan(3,'none','champ'),/3 人/));
test('odd entrant no-bye prohibited except direct 3-person RR',()=>{for(const n of [5,7,11,39,127])assert.throws(()=>plan(n,'none','champ'),/奇數/)});
test('no-bye 4 entrants cannot select unreachable 3-cycle',()=>assert.throws(()=>plan(4,'none','rr3'),/無法/));
test('no-bye validates 2–128 and unsupported format target',()=>{assert.throws(()=>plan(1,'none','champ'),/2～128/);assert.throws(()=>plan(129,'none','champ'),/2～128/);assert.throws(()=>plan(40,'none','other'),/目標/)});
test('the UI selector default is auto and no backend validation rules changed',()=>{const html=fs.readFileSync(require('node:path').join(__dirname,'../index.html'),'utf8');assert.match(html,/<option value="auto" selected>系統自動輪空<\/option>/);assert.match(html,/<option value="none">不輪空/);assert.match(ui,/if\(format\.formatPolicy==='auto16'\)autoPolicy=format/);assert.match(ui, /autoPolicy\?\{formatPolicy:'auto16'\}/)});

test('returning home restores the verified automatic BYE mode for next draft',()=>{assert.match(ui,/if\(\$\('byePolicy'\)\)\$\('byePolicy'\)\.value='auto'/) });
