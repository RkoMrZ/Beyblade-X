#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: deployment already running; inspect release.log'; exit 3; }
if [ -f .release-completed ]; then
 echo 'PASS: release already completed; inspect release.log';exit 0
fi
exec > >(tee -a release.log) 2>&1
printf '\n=== V0.11 RELEASE START %s ===\n' "$(date -u '+%FT%TZ')"
date -u > .release-started
bash deploy/BBX-V0.11-檢查.sh
bash deploy/BBX-V0.11-Cloud-Functions.sh
bash deploy/BBX-V0.11-Hosting.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.11 Functions (9) + Rules + Hosting deployed and verified.\n'
