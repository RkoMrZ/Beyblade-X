#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
P=ljt-beyblade-x
DB=ljt-beyblade-x-default-rtdb
[[ "$(basename "$PWD")" == BBX-V0.11 ]] || { echo 'STOP: wrong folder'; exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v011-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: tests and Emulator not passed for this release'; exit 3; }
gcloud auth print-access-token >/dev/null
[[ "$(gcloud config get-value project 2>/dev/null)" == "$P" ]] || { echo 'STOP: wrong project'; exit 3; }
[[ "$(python3 -c 'import json;print(json.load(open(".firebaserc"))["projects"]["default"])')" == "$P" ]] || { echo 'STOP: Firebase project mismatch'; exit 3; }
FN='functions:bbxV011CreateAuthority,functions:bbxV011CommandAuthority,functions:bbxV011GetOperation,functions:bbxV011RepairPublication,functions:bbxV011PublishAuthority,functions:bbxV011OrganizerAuthority,functions:bbxV011DeleteAuthority,functions:bbxV011RepairQueue,functions:bbxV011AssignPublicCode'
echo '=== Deploy V0.11 Functions ==='
firebase deploy --only "$FN" --project "$P" --non-interactive --force
python3 - <<'PY'
import subprocess,json
want=set(json.load(open('MANIFEST.json'))['functions_exports'])
a=json.loads(subprocess.check_output(['gcloud','functions','list','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=json'],text=True))
got={x['name'].split('/')[-1] for x in a}
assert want.issubset(got),f'Missing V0.11 functions: {sorted(want-got)}'
print('PASS: all 9 V0.11 Functions deployed')
PY
TOKEN="$(gcloud auth print-access-token)"
URL="https://${DB}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
curl -fLsS -H "Authorization: Bearer $TOKEN" "$URL" -o /tmp/bbx-v011-live-before-rules.json
python3 deploy/merge-rules.py /tmp/bbx-v011-live-before-rules.json database.deploy.rules.json
python3 - <<'PY'
import json
v=json.load(open('firebase.json'));v['database']['rules']='database.deploy.rules.json'
with open('firebase.deploy.json','w') as f:json.dump(v,f)
PY
echo '=== Deploy version-safe RTDB Rules ==='
firebase deploy --only database --config firebase.deploy.json --project "$P" --non-interactive
TOKEN="$(gcloud auth print-access-token)"
curl -fLsS -H "Authorization: Bearer $TOKEN" "$URL" -o /tmp/bbx-v011-live-after-rules.json
python3 - <<'PY'
import json
def obj(file):
 x=json.load(open(file));return json.loads(x) if isinstance(x,str) else x
assert obj('database.deploy.rules.json')==obj('/tmp/bbx-v011-live-after-rules.json'),'Rules verification failed'
print('PASS: live V0.11 Rules verified')
PY
# Safety: preserve V0.9 runtime while historical V0.9 tournaments may still be active.
# Deleting V0.9 callables here would break scoring/organizer operations on them.
# Dedicated future cleanup may remove them only after a verified absence of V0.9 events.
echo 'PASS: V0.11 deployed; V0.9 functions preserved for active legacy tournaments'
printf '\nPASS: BBX-V0.11 Functions (9) + Rules deployed and verified.\n'
