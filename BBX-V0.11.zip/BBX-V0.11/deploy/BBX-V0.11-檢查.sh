#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == 'BBX-V0.11' ]] || { echo 'STOP: incorrect V0.11 folder'; exit 2; }
python3 - <<'PY'
from pathlib import Path
import hashlib,json
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.11' and m['firebase_project']=='ljt-beyblade-x'
assert len(m['functions_exports'])==9
for item in m['files']:
 p=Path(item['path']);raw=p.read_bytes()
 assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],str(p)
print('PASS: V0.11 package byte-level integrity')
PY
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required'; exit 3; }
for f in functions/*.js assets/*.js; do node --check "$f"; done
node --test tests/*.test.js
python3 tests/check_static.py
python3 tests/check_cleanup_rules.py
python3 deploy/merge-rules.py docs/previous-v09-rules.json /tmp/bbx-v011-test-merge.json
python3 - <<'PY'
import json
x=json.load(open('/tmp/bbx-v011-test-merge.json'))['rules']
assert x['authorityBBXV09']=={'.read':False,'.write':False}
assert x['authorityBBXV011']=={'.read':False,'.write':False}
assert 'authorityBBXV09' in x['publicEvents']['$eventId']['.read']
assert 'authorityBBXV011' in x['publicEvents']['$eventId']['.read']
print('PASS: old V0.9 and new V0.11 public access rules are safely split')
PY
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI unavailable'; exit 4; }
command -v java >/dev/null || { echo 'STOP: Java unavailable'; exit 4; }
# Emulator uses a DEMO project and does not write to production.
npm --prefix tests install --no-audit --no-fund
npm --prefix functions install --no-audit --no-fund
firebase emulators:exec --only database --project demo-bbx-v011 'cd tests && node rules-emulator.test.cjs && node real-rtdb.cjs'
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v011-preflight-ok"
printf '\nPASS: BBX-V0.11 local tests and RTDB Emulator passed.\n'
