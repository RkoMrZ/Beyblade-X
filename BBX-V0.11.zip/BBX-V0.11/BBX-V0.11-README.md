# BBX-V0.11

來源：BBX-V0.10；不影響獨立報名系統。

- 修復 3 人直接建立最後三人循環時，RTDB 省略空 `rounds` 陣列造成的 `ev.rounds.forEach` 崩潰。
- 伺服器恢復沒有 `rounds` 的三人循環權威資料時轉回 `[]`，不能假造淘汰輪。
- 修正 iPhone Safari 動態工具列 / 視窗滑動造成彈窗視覺位置與觸控位置錯位；移除 visualViewport.offsetTop 的雙重補償。
- 保留 V0.10 / V0.9 既有賽事使用的原版本 Callable、權威節點、公開 Rules 與安全刪除；新版 V0.11 操作明確指向 V0.11 Callable，避免誤發送至 V0.10。
- 修復 iOS Safari 背景／前景切換後「我的賽事 0/3」：任何暫時讀取失敗或 null 回應都不能從 `syncMyCloudEvents` 刪除 `userEvents` 主辦索引；歷史快取保留並標記待同步。
- 當主辦索引快照短暫缺失、Auth 還在恢復、或整場資料暫時讀不到時，不自動回首頁、不清除網址／正在觀看的賽事，並暫停比分寫入等待權威重新確認。
- 只在相同 Google 主辦 UID 下使用一份小型的本機「賽事 ID／頁籤定位指標」恢復 iOS 被回收的分頁；不保存比分、名單或權威資料，雲端仍是唯一正確資料來源；主動登出會刪除此指標。
- 新增 `tools/BBX-賽事索引唯讀檢查.py`，可只讀查核已存在的賽事主檔是否已失去主辦索引；真正缺失時不得猜測自動重建。
- 原始對戰介面與賽程交易、鎖、兩種獨立抽籤邏輯保留。

操作：上傳 BBX-V0.11.zip 至 GitHub 主儲存庫根目錄，手機 Cloud Shell 以 `bash 00_start.sh` 執行前置檢查、Emulator 與部署。不可略過線上 iOS Safari 真正點擊驗收。


### 2026-10-20 跨瀏覽器同步候選修正（仍為 V0.11）

- 修復 immutable 一年快取與同名 JS/CSS 覆蓋衝突：index/viewer 均透過內容 SHA 指紋檔名載入，Safari/Chrome 不會再依同名資源使用前一版。
- 首頁顯示讀取中／失敗／REST 驗證與 SDK 差異，提供 UID、Google Provider 診斷與可複製的唯讀報告；從來不複製 ID Token。
- 同一個 UID 的 `userEvents` SDK 即時訂閱新增一次性 REST 校正與有上限的重試；讀取出錯不再偽裝成已確認 0 場、不觸發雲端刪除。
- 已知賽事在索引或主檔未核對時轉為唯讀待同步；Auth 身分切換時不沿用舊 UID 的 RAM；REST token cache 也改成 UID 綁定。
- 保留既有 9 支 Functions、Rules、裁判記分權威流程與兩種獨立抽籤；134/134 Node.js 測試通過，實機仍待驗收。
- 完整原因、診斷與驗收方式請見 `docs/BBX-V0.11-跨瀏覽器同步安全交接.md`。

### 2026-10-20 公開觀眾 Rules 括號修正

修正 `database.rules.json` 中 `publicEvents/$eventId/.read` 少右括號造成 Emulator 載入失敗；在部署前加上括號結構檢查。此更新仍為 V0.11、未改動 Functions / Firebase 真實資料，Firebase Emulator 必須在 Cloud Shell 實際通過後才允許部署。既有資料與舊版 Rules 經安全合併後才發布。
