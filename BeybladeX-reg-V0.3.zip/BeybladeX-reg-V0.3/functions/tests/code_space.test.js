'use strict';
// Pure local audit of the exact candidate generator: no Firebase calls.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const crypto=require('node:crypto');
const source=fs.readFileSync(require('node:path').join(__dirname,'../index.js'),'utf8');
const begin=source.indexOf('const EVENT_ALPHABET=');
const end=source.indexOf('\nconst checkEid=',begin);
assert(begin>=0&&end>begin,'Event generator source not found');
const scope=vm.createContext({crypto});
vm.runInContext(source.slice(begin,end)+'\n globalThis.code=eventCode;globalThis.alphabet=EVENT_ALPHABET;globalThis.space=EVENT_SPACE;globalThis.pattern=EVENT_ID_RE;',scope);
assert.equal(scope.alphabet,'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
assert.equal(scope.space,60_466_176);
const counts=new Map([...scope.alphabet].map(c=>[c,0]));
const unique=new Set();
for(let i=0;i<10000;i++){
 const createId=i.toString(16).padStart(48,'0');
 const candidate=scope.code('test-owner',createId,0);
 assert(scope.pattern.test(candidate)&&candidate.length===5,candidate);
 assert.equal(candidate,scope.code('test-owner',createId,0),'same request must recover same code');
 unique.add(candidate);
 for(const char of candidate)counts.set(char,counts.get(char)+1);
}
assert.equal(counts.size,36);
assert([...counts.values()].every(x=>x>0),'all 36 symbols must be reachable');
assert(unique.size>9950,'unexpected heavy collision concentration');
const collisionA='000000000000000000000000000000000000000000000040';
const collisionB='00000000000000000000000000000000000000000000202d';
assert.equal(scope.code('owner',collisionA,0),'NJQLQ');
assert.equal(scope.code('owner',collisionB,0),'NJQLQ');
assert.equal(scope.code('owner',collisionB,1),'CB23K');
console.log('PASS PURE BASE36: 36 symbols, 36^5 combinations, 10k deterministic samples, collision retry, 0 database calls');
