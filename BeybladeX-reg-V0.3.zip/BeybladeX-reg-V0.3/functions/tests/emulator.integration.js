'use strict';
// Runs ONLY against a local Firebase RTDB Emulator (never against production).
// Invoke from BeybladeX-reg-V0.3 root:
// firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const Module=require('node:module');
const host=process.env.FIREBASE_DATABASE_EMULATOR_HOST||'';
if(!/^(localhost|127\.0\.0\.1):\d+$/.test(host)){
 console.error('REFUSING TO RUN: FIREBASE_DATABASE_EMULATOR_HOST must point to local RTDB emulator');process.exit(2);
}
// Use an isolated database namespace, never the real ljtreg-39954 namespace.
process.env.FIREBASE_CONFIG=JSON.stringify({projectId:'demo-ljtreg',databaseURL:'https://demo-ljtreg-default-rtdb.firebaseio.com'});
// We only replace the callable HTTP wrapper; all Firebase Admin SDK/database
// transactions are REAL and are routed to the emulator by the env variable.
const old=Module._load;
Module._load=function(id,parent,isMain){
 if(id==='firebase-functions/v2/https'){
  const real=old.apply(this,arguments);return {...real,onCall:(_cfg,fn)=>fn};
 }
 return old.apply(this,arguments);
};
const api=require('../index.js');Module._load=old;
const {getDatabase}=require('firebase-admin/database');
const db=getDatabase();
const owner={auth:{uid:'preflight-owner',token:{firebase:{sign_in_provider:'google.com'}}}};
const intruder={auth:{uid:'preflight-intruder',token:{firebase:{sign_in_provider:'google.com'}}}};
const guest={auth:null};
const createId=()=>crypto.randomBytes(24).toString('hex');
const invoke=(name,data,who=owner)=>api[name]({...who,data});
const prefix='emulator_'+Date.now().toString(36);
const mkForm=i=>({playerName:prefix+'_player_'+i,phone3:'093',lineName:'sameLINE',rid:createId()});
let eid=null;
(async()=>{
 const base={title:'模擬器 '+prefix,eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'測試體育館',fee:0,capacity:32};
 const cid=createId(),created=await invoke('regV03CreateEvent',{...base,createId:cid});eid=created.eid;
 assert.match(eid,/^[A-Z0-9]{5}$/,'event IDs must be 5 readable characters');
 const again=await invoke('regV03CreateEvent',{...base,createId:cid});assert.equal(again.eid,eid);
 await assert.rejects(invoke('regV03SetOpen',{eid,open:false,expectedVersion:1},intruder));
 const forms=Array.from({length:64},(_,i)=>({...mkForm(i),eid}));
 const results=await Promise.all(forms.map(f=>invoke('regV03Submit',f,guest)));
 const nums=results.map(x=>x.signupNo).sort((a,b)=>a-b);
 assert.deepEqual(nums,Array.from({length:64},(_,i)=>i+1));
 assert.equal((await db.ref(`publicRowsV03/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`rankActiveV03/${eid}`).get()).numChildren(),64);
 const ownNo=n=>results.findIndex(x=>x.signupNo===n);
 const myRank=n=>invoke('regV03MyRank',{eid,rid:forms[ownNo(n)].rid},guest);
 assert.equal((await myRank(33)).rankLabel,'備選#1');
 await invoke('regV03Review',{eid,key:'p00000001',status:'rejected',expectedVersion:1});
 assert.equal((await myRank(33)).rankLabel,'正選#32');
 await invoke('regV03Review',{eid,key:'p00000001',status:'approved',expectedVersion:2});
 assert.equal((await myRank(33)).rankLabel,'備選#1');
 assert.equal((await db.ref(`privateRowsV03/${eid}`).get()).numChildren(),64);
 assert.equal((await db.ref(`nameClaimsV03/${eid}`).get()).numChildren(),64);
 const replay=await invoke('regV03Submit',forms[0],guest);assert.equal(replay.signupNo,results[0].signupNo);
 await assert.rejects(invoke('regV03Submit',{...forms[0],rid:createId(),phone3:'777'},guest));
 const both=await Promise.allSettled([invoke('regV03Review',{eid,key:'p00000010',status:'rejected',expectedVersion:1}),invoke('regV03Review',{eid,key:'p00000010',status:'approved',expectedVersion:1})]);
 assert.equal(both.filter(x=>x.status==='fulfilled').length,1,'only one review may commit for a record version');
 const rv=(await db.ref(`publicRowsV03/${eid}/p00000010`).get()).val();assert.equal(rv.recordVersion,2);
 // Verify that external unauthenticated visitors cannot download LINE/private information.
 const namespace='demo-ljtreg-default-rtdb';
 const res=await fetch(`http://${host}/privateRowsV03/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.notEqual(res.status,200,'anonymous REST read of privateRows must be denied by Rules');
 const idx=await fetch(`http://${host}/rankActiveV03/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.notEqual(idx.status,200,'anonymous REST read of rankActive must be denied by Rules');
 const pub=await fetch(`http://${host}/publicRowsV03/${eid}.json?ns=${encodeURIComponent(namespace)}`);
 assert.equal(pub.status,200,'public simplified roster should be readable');
 const data=await pub.json();assert.equal(Object.values(data)[0].lineName,undefined);
 // Real RTDB Emulator collision regression; the seed pair maps to 4443O at attempt 0.
 const collisionA='000000000000000000000000000000000000000000002aac';
 const collisionB='000000000000000000000000000000000000000000002bf1';
 const [first,second]=await Promise.all([
  invoke('regV03CreateEvent',{...base,title:'碰撞測試 A',createId:collisionA}),
  invoke('regV03CreateEvent',{...base,title:'碰撞測試 B',createId:collisionB})
 ]);
 assert.deepEqual([first.eid,second.eid].sort(),['4443O','T4IOU'].sort());
 assert.equal((await db.ref(`eventsV03/${first.eid}/meta/title`).get()).val(),'碰撞測試 A');
 assert.equal((await db.ref(`eventsV03/${second.eid}/meta/title`).get()).val(),'碰撞測試 B');
 assert.equal((await invoke('regV03CreateEvent',{...base,title:'碰撞測試 B',createId:collisionB})).eid,second.eid);
 await invoke('regV03DeleteEvent',{eid:first.eid});
 await invoke('regV03DeleteEvent',{eid:second.eid});
 console.log('PASS 5-CHAR COLLISION EMULATOR: both owners/requests isolated with deterministic retry');
 await invoke('regV03DeleteEvent',{eid});
 assert.equal((await db.ref(`privateRowsV03/${eid}`).get()).exists(),false);
 console.log('PASS RANK INDEX: direct callable rank, reject/promote/restore, private index denied; PASS RTDB EMULATOR: 64 genuinely concurrent transactions, unique name, idempotency, 2-owner version conflict, public/private Rules, full-event cleanup');
})().catch(async err=>{
 console.error('FAIL RTDB EMULATOR:',err.stack||err);
 if(eid){try{await invoke('regV03DeleteEvent',{eid})}catch{}}
 process.exitCode=1;
}).finally(async()=>{await Promise.all(require('firebase-admin/app').getApps().map(app=>app.delete()))});
