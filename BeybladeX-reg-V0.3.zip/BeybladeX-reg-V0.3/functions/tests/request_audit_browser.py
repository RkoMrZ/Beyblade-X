#!/usr/bin/env python3
"""Deterministic browser-level request audit. Offline mocks; no live Firebase calls.
Produces machine-readable scenario HTTP request counts (not real-world billing bytes).
"""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json,re,sys,zipfile,tempfile
ROOT=Path(__file__).resolve().parents[2]
CURRENT_VERSION=json.loads((ROOT/'RELEASE_VERSION.json').read_text())['release']
PREVIOUS_VERSION=(ROOT/'functions/tests/audit_baseline_previous.version').read_text().strip()
E='ABCDE'
JS_SEED=r'''(() => {
window.__hits=[];window.__queries=[];window.__streams=[];window.__payloadBytes=0;Object.defineProperty(window.crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(32).fill(7).buffer}});
window.__backend={meta:{title:'測試盃',eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'測試場地',fee:0,capacity:2,open:true,version:1},
rows:{p00000001:{signupNo:1,playerName:'第一位',phone3:'093',status:'pending',recordVersion:1},p00000002:{signupNo:2,playerName:'第二位',phone3:'123',status:'approved',recordVersion:1}},
changes:{'-chg0001':{type:'row',key:'p00000001'}},token:'v1'};
class FakeES {static CLOSED=2;constructor(url){this.url=url;this.readyState=1;this.listeners={};window.__streams.push(this);setTimeout(()=>this.onopen?.(),1)}addEventListener(type,cb){(this.listeners[type]??=[]).push(cb)}close(){this.readyState=FakeES.CLOSED}emit(type,data){(this.listeners[type]||[]).forEach(cb=>cb({data:JSON.stringify(data)}))}}window.EventSource=FakeES;
const user={uid:'tester',getIdToken:async()=> 'testtoken'};
window.initializeApp=()=>({});window.getAuth=()=>({});window.GoogleAuthProvider=class{};window.onAuthStateChanged=(_auth,cb)=>setTimeout(()=>cb(user),0);window.signInWithPopup=async()=>({user});window.signOut=async()=>{};
window.fetch=async (input,opt={})=>{
 const u=new URL(String(input),'https://mock.local/'),path=u.pathname.substring(1).replace(/\.json$/,''),parts=path.split('/'),b=window.__backend;
 window.__hits.push((opt.method||'GET')+' '+path);window.__queries.push({path,query:u.search,method:opt.method||'GET'});
 const v=location.hash.includes('never')?'V01':'VXX';
 if(/regV\d+Submit/.test(path)){const body=JSON.stringify({result:{signupNo:3,rankLabel:'備選#1'}});window.__payloadBytes+=new TextEncoder().encode(body).length;return new Response(body,{status:200})}
 let data=null;
 if(parts[0].startsWith('eventsV'))data=b.meta;
 else if(parts[0].startsWith('syncV'))data={token:b.token,lastChange:Object.keys(b.changes).sort().at(-1)};
 else if(parts[0].startsWith('changesV')){
  const startAt=u.searchParams.get('startAt');let arr=Object.entries(b.changes).sort((a,b)=>a[0].localeCompare(b[0]));
  if(startAt)arr=arr.filter(([k])=>k>=JSON.parse(startAt));
  if(u.searchParams.has('limitToFirst'))arr=arr.slice(0,Number(u.searchParams.get('limitToFirst')));
  if(u.searchParams.has('limitToLast'))arr=arr.slice(-Number(u.searchParams.get('limitToLast')));
  data=Object.fromEntries(arr);
 }
 else if(parts[0].startsWith('publicRowsV'))data=parts[2]?b.rows[parts[2]]||null:b.rows;
 else if(parts[0].startsWith('privateRowsV'))data=parts[2]?{lineName:'同一LINE'}:{p00000001:{lineName:'同一LINE'},p00000002:{lineName:'同一LINE'}};
 else if(parts[0].startsWith('ownerEventsV'))data={'ABCDE':{title:'測試盃',eventDate:'2026-11-01',capacity:2}};
 else throw new Error('Unexpected request: '+path);
 const body=JSON.stringify(data??null);window.__payloadBytes+=new TextEncoder().encode(body).length;
 return new Response(body,{status:200});
};
})()'''

def html(src,page,event_id=E):
 body=(src/page).read_text()
 if page!='index.html':body=body.replace('new URLSearchParams(location.search)',f"new URLSearchParams('?event={event_id}')")
 else:
  body=re.sub(r'^import .*?;\s*','',body,flags=re.M)
  body=body.replace('<script type="module">','<script>')
 return body

def snap(p):
 return p.evaluate('({hits:[...__hits],bytes:__payloadBytes,streams:__streams.length})')
def clear(p):p.evaluate('__hits.length=0;__payloadBytes=0')
def request_paths(s):return [v.split(' ',1)[1] for v in s['hits']]

def run(browser,src,label):
 event_id='ABCDE' if label==CURRENT_VERSION else 'a'*24
 ctx=browser.new_context(viewport={'width':390,'height':800});ctx.add_init_script(JS_SEED.replace("'ABCDE'","'"+event_id+"'"))
 results={}
 try:
  print(label,'status load',flush=True);p=ctx.new_page();p.set_content(html(src,'status.html',event_id))
  p.wait_for_function("document.querySelector('#rows')?.textContent.includes('第一位')")
  p.wait_for_timeout(650)
  results['status_initial']=snap(p)
  clear(p);p.locator('#search').fill('093');p.wait_for_timeout(100);results['status_search']=snap(p)
  clear(p);p.locator('#refresh').click();p.wait_for_timeout(350);results['status_refresh_unchanged']=snap(p)
  clear(p)
  p.evaluate("__backend.rows.p00000001.status='approved';__backend.rows.p00000001.recordVersion=4;Object.assign(__backend.changes,{'-chg0002':{type:'review',key:'p00000001'},'-chg0003':{type:'review',key:'p00000001'},'-chg0004':{type:'review',key:'p00000001'}});__backend.token='v2';__streams.at(-1).emit('put',{path:'/',data:{token:'v2',lastChange:'-chg0004'}})")
  p.wait_for_function("document.querySelector('#rows')?.textContent.includes('通過')")
  p.wait_for_timeout(400);results['status_three_changes_one_row']=snap(p)
  if label==CURRENT_VERSION:
   assert request_paths(results['status_initial']).count('changesV03/'+E)==0
   assert results['status_search']['hits']==[]
   assert request_paths(results['status_three_changes_one_row']).count('publicRowsV03/'+E+'/p00000001')==1
   assert request_paths(results['status_three_changes_one_row']).count('syncV03/'+E)==0
   # A late transaction can publish a smaller journal push key. Verify safe full refresh.
   p.locator('#search').fill('');clear(p)
   p.evaluate("__backend.rows.p00000002.status='rejected';__backend.token='v3';__backend.changes['-chg0000']={type:'review',key:'p00000002'};__streams.at(-1).emit('put',{path:'/',data:{token:'v3',lastChange:'-chg0000'}})")
   p.wait_for_function("document.querySelector('#rows')?.textContent.includes('不通過')")
   p.wait_for_timeout(350)
   results['status_out_of_order_safe_refresh']=snap(p)
   assert 'publicRowsV03/'+E in request_paths(results['status_out_of_order_safe_refresh']),results
   # A partial SSE token-only event must fetch the marker before applying deltas.
   clear(p)
   p.evaluate("__backend.rows.p00000001.recordVersion=5;__backend.token='v4';__backend.changes['-chg0005']={type:'review',key:'p00000001'};__streams.at(-1).emit('patch',{path:'/token',data:'v4'})")
   p.wait_for_function("typeof syncToken!=='undefined' && syncToken==='v4'")
   p.wait_for_timeout(350)
   results['status_partial_sse_token']=snap(p)
   assert 'syncV03/'+E in request_paths(results['status_partial_sse_token'])
  p.close()
  print(label,'signup load',flush=True);p=ctx.new_page();p.set_content(html(src,'signup.html',event_id))
  p.wait_for_function("!document.querySelector('#entryCard').classList.contains('hide')")
  results['signup_initial']=snap(p)
  clear(p)
  p.evaluate('Promise.all([load(),load(),load()])');p.wait_for_timeout(200)
  results['signup_resume_within_15s']=snap(p)
  p.locator('#playerName').fill('第三位');p.locator('#phone3').fill('093');p.locator('#lineName').fill('同一LINE')
  clear(p);p.locator('#submit').click();print(label,'submit clicked',p.locator('#notice').inner_text(),flush=True);p.wait_for_function("document.querySelector('#rank')?.textContent.includes('備選#1')")
  results['signup_submit']=snap(p)
  assert sum('publicRows' in x for x in results['signup_submit']['hits'])==0
  p.close()
  print(label,'manager load',flush=True);p=ctx.new_page();p.set_content(html(src,'index.html',event_id))
  p.wait_for_function("document.querySelector('#events')?.textContent.includes('測試盃')");print(label,'manager home ready',flush=True)
  results['manager_home']=snap(p)
  clear(p);p.locator('[data-manage]').click()
  p.wait_for_function("document.querySelector('#roster')?.textContent.includes('第一位')");print(label,'manager roster ready',flush=True)
  p.wait_for_timeout(650)
  results['manager_enter_event']=snap(p)
  clear(p);p.locator('#search').fill('第一');p.locator('[data-tab="approved"]').click()
  results['manager_search_filter']=snap(p)
  clear(p);p.locator('#copyLink').click();p.locator('#copyStatus').click();p.wait_for_timeout(80)
  results['manager_copy_links']=snap(p)
  clear(p);p.locator('#refresh').click();p.wait_for_timeout(350)
  results['manager_manual_refresh']=snap(p)
  if label==CURRENT_VERSION:
   p.locator('[data-tab="all"]').click();p.locator('#search').fill('');p.locator('[data-review="p00000001"]').click();clear(p);p.locator('[data-to="pending"]').click();results['manager_noop_review']=snap(p);assert not results['manager_noop_review']['hits']
   p.locator('[data-edit="p00000001"]').click();clear(p);p.locator('#entryForm button[type="submit"]').click();results['manager_noop_entry_edit']=snap(p);assert not results['manager_noop_entry_edit']['hits']
   p.locator('#editEvent').click();clear(p);p.locator('#editForm button[type="submit"]').click();results['manager_noop_event_edit']=snap(p);assert not results['manager_noop_event_edit']['hits']
   assert request_paths(results['manager_enter_event']).count('changesV03/'+E)==0
   assert not any('privateRows' in x for x in results['manager_search_filter']['hits'])
  p.close()
 finally:
  ctx.close()
 return results

if __name__=='__main__':
 with sync_playwright() as pw:
  b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  # Bundled immutable V0.1 frontend for a reproducible audit after old folders are deleted.
  with tempfile.TemporaryDirectory(prefix='bx_audit_baseline_') as temp:
   with zipfile.ZipFile(ROOT/'functions/tests/audit_baseline_previous.zip') as baseline:
    baseline.extractall(temp)
   versions={PREVIOUS_VERSION:run(b,Path(temp)/'reg',PREVIOUS_VERSION),CURRENT_VERSION:run(b,ROOT/'reg',CURRENT_VERSION)}
  b.close()
 summary={label:{case:{'httpCount':len(r['hits']),'estimatedJsonPayloadBytes':r['bytes'],'sseSubscriptionsCreated':r['streams'],'paths':r['hits']} for case,r in scenarios.items()}for label,scenarios in versions.items()}
 target=ROOT/'REQUEST_AUDIT_MEASUREMENTS.json';target.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 for case in sorted(set(summary[PREVIOUS_VERSION])&set(summary[CURRENT_VERSION])):
  a=summary[PREVIOUS_VERSION][case];z=summary[CURRENT_VERSION][case]
  print(f'{case:31}: {PREVIOUS_VERSION}={a["httpCount"]:2d} HTTP; {CURRENT_VERSION}={z["httpCount"]:2d} HTTP; JSON {a["estimatedJsonPayloadBytes"]}/{z["estimatedJsonPayloadBytes"]} B')
 print('PASS browser request audit, offline fixtures only:',target)
