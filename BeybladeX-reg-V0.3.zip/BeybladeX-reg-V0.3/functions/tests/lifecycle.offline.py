#!/usr/bin/env python3
"""V0.3 browser lifecycle regression, OFFLINE fake RTDB/SSE, NO live HTTP.
These tests are not a 100-device real-network benchmark.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import importlib.util
BASE=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('request_audit_browser.py'))
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
E='ABCDE'
VIS="""Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>window.__vis||'visible'});window.__vis='visible';window.__setVisibility=(state)=>{window.__vis=state;document.dispatchEvent(new Event('visibilitychange'))};"""

def make(ctx,filename):
 p=ctx.new_page();p.set_content(audit.html(BASE/'reg',filename));return p

def monitor(p):
 return p.evaluate("({hits:[...__hits],openStreams:__streams.filter(s=>s.readyState!==EventSource.CLOSED).length,allStreams:__streams.length})")

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 ctx=browser.new_context(viewport={'width':390,'height':844});ctx.add_init_script(audit.JS_SEED);ctx.add_init_script(VIS)
 try:
  p=make(ctx,'status.html')
  p.wait_for_function("document.querySelector('#rows')?.textContent.includes('第一位') && liveOnline")
  assert monitor(p)['openStreams']==1
  p.evaluate("__hits.length=0;__setVisibility('hidden')")
  p.wait_for_function('liveStream===null')
  assert monitor(p)['openStreams']==0
  assert p.evaluate('statusWatch===null && reconnect===null')
  p.clock.install();p.clock.fast_forward(600000)
  assert monitor(p)['hits']==[],monitor(p)
  p.evaluate("__backend.rows.p00000001.status='approved'; __backend.changes['-chg0002']={type:'review',key:'p00000001'};__backend.token='v2';__setVisibility('visible')")
  p.wait_for_function("syncToken==='v2' && document.querySelector('#rows')?.textContent.includes('通過')")
  assert monitor(p)['openStreams']==1
  assert monitor(p)['hits'].count('GET syncV03/'+E)==1,monitor(p)
  print('PASS PUBLIC: hidden = 0 SSE/0 periodic GET; resume = one marker GET then row delta; visible stays realtime',flush=True)
  p.close()

  p=make(ctx,'index.html');p.wait_for_function("document.querySelector('#events')?.textContent.includes('測試盃')")
  p.locator('[data-manage]').click();p.wait_for_function("document.querySelector('#roster')?.textContent.includes('第一位') && managerOnline")
  assert monitor(p)['openStreams']==1
  p.evaluate("__hits.length=0;__setVisibility('hidden')")
  p.wait_for_function('managerStream===null')
  assert monitor(p)['openStreams']==0
  assert p.evaluate('managerWatch===null && managerRetry===null')
  p.clock.install();p.clock.fast_forward(600000)
  assert monitor(p)['hits']==[],monitor(p)
  p.evaluate("__backend.rows.p00000001.status='approved'; __backend.changes['-chg0002']={type:'review',key:'p00000001'};__backend.token='v2';__setVisibility('visible')")
  p.wait_for_function("syncToken==='v2' && document.querySelector('#roster')?.textContent.includes('通過')")
  assert monitor(p)['openStreams']==1
  assert monitor(p)['hits'].count('GET syncV03/'+E)==1,monitor(p)
  print('PASS MANAGER: hidden = 0 SSE/0 periodic GET; resume = marker+delta; private data stays authenticated',flush=True)
  p.close()

  p=make(ctx,'status.html');p.wait_for_function("document.querySelector('#rows')?.textContent.includes('第一位') && liveOnline")
  p.evaluate("__hits.length=0;__streams.at(-1).onerror()")
  p.wait_for_function('liveStream===null')
  assert p.evaluate('retryAttempt===1 && reconnect!==null')
  p.evaluate("__setVisibility('hidden')")
  assert p.evaluate('reconnect===null && statusWatch===null')
  p.clock.install();p.clock.fast_forward(600000)
  assert monitor(p)['hits']==[],monitor(p)
  print('PASS SSE: explicit close on any error, bounded exponential/jitter retry; hidden cancels retry',flush=True)
  p.close()

  # Pause/resume during a slow initial roster GET: aborted request must be retried exactly once.
  p=make(ctx,'status.html');p.wait_for_function("document.querySelector('#rows')?.textContent.includes('第一位')")
  p.evaluate('''() => {
   window.__realFetch=window.fetch;window.__abortedReads=0;
   window.fetch=(u,opt={})=>{
    if(String(u).includes('publicRowsV03/')&&!String(u).includes('p000000')){
     return new Promise((res,rej)=>{opt.signal?.addEventListener('abort',()=>{__abortedReads++;rej(new DOMException('Aborted','AbortError'))},{once:true})})
    }
    return __realFetch(u,opt)
   };
   rows=null;initial();
  }''')
  p.wait_for_function('requesting')
  p.evaluate("__setVisibility('hidden')")
  p.wait_for_function('__abortedReads>=1 && !requesting')
  p.evaluate("window.fetch=__realFetch;__setVisibility('visible')")
  p.wait_for_function("rows!==null && !requesting && document.querySelector('#rows')?.textContent.includes('第一位')")
  print('PASS PUBLIC resume-during-load: aborted slow initial read; reruns exactly one usable snapshot',flush=True)
  p.close()

  # Same initial-load race for the organizer; keep its authoritative private roster intact.
  p=make(ctx,'index.html');p.wait_for_function("document.querySelector('#events')?.textContent.includes('測試盃')")
  p.evaluate('''() => {
   window.__realFetch=window.fetch;window.__abortedReads=0;
   window.fetch=(u,opt={})=>{
    if(String(u).includes('publicRowsV03/')&&!String(u).includes('p000000')){
     return new Promise((res,rej)=>{opt.signal?.addEventListener('abort',()=>{__abortedReads++;rej(new DOMException('Aborted','AbortError'))},{once:true})})
    }
    return __realFetch(u,opt)
   };
  }''')
  p.locator('[data-manage]').click();p.wait_for_function('managerLoading')
  p.evaluate("__setVisibility('hidden')")
  p.wait_for_function('__abortedReads>=1 && !managerLoading')
  p.evaluate("window.fetch=__realFetch;__setVisibility('visible')")
  p.wait_for_function("eventMeta!==null && !managerLoading && document.querySelector('#roster')?.textContent.includes('第一位')")
  assert monitor(p)['openStreams']==1
  print('PASS MANAGER resume-during-load: hidden abort and correct roster reload without duplicate GET race',flush=True)
  p.close()

  p=make(ctx,'signup.html');p.wait_for_function("!document.querySelector('#entryCard').classList.contains('hide')")
  p.evaluate("__hits.length=0;__setVisibility('hidden')")
  p.clock.install();p.clock.fast_forward(600000)
  assert monitor(p)['hits']==[],monitor(p)
  p.evaluate("lastMetaChecked=Date.now()-16000;__setVisibility('visible')")
  p.wait_for_function("__hits.some(x=>x.includes('eventsV03/'))")
  p.locator('#playerName').fill('第三位');p.locator('#phone3').fill('093');p.locator('#lineName').fill('同一LINE');p.locator('#submit').click()
  p.wait_for_function("document.querySelector('#rank')?.textContent.includes('備選#1')")
  print('PASS SIGNUP: hidden metadata idle; POST registration still works',flush=True)
  p.close()

  # Exercise separate browser page lifecycles; not a real device/RTDB stress test.
  pages=[make(ctx,'status.html') for _ in range(10)]
  for page in pages:page.wait_for_function('liveOnline')
  assert sum(monitor(page)['openStreams'] for page in pages)==10
  for page in pages:page.evaluate("__hits.length=0;__setVisibility('hidden')")
  assert sum(monitor(page)['openStreams'] for page in pages)==0
  assert all(monitor(page)['hits']==[] for page in pages)
  for page in pages:page.close()
  print('PASS 10-TAB lifecycle fixture: every background tab closes its SSE and stops new reads; 100-device real-load test not yet run',flush=True)
 finally:
  ctx.close();browser.close()
