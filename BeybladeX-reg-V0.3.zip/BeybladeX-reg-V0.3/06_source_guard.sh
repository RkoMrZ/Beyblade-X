#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
node - <<'JS'
const assert=require('node:assert/strict'),fs=require('node:fs');
const cfg=JSON.parse(fs.readFileSync('RELEASE_VERSION.json','utf8'));
const label=cfg.release,api=cfg.apiPrefix,suffix=cfg.dataSuffix;
assert(/^(?:V0\.[1-9]\d*|V[1-9]\d*\.\d+)$/.test(label));
const [major,minor]=label.substring(1).split('.');
assert.equal(suffix,'V'+major+minor);
assert.equal(api,'reg'+suffix);
assert.equal(cfg.firebaseProject,'ljtreg-39954');
const f=fs.readFileSync('functions/index.js','utf8');
const re=/exports\.(reg[A-Za-z0-9]+)\s*=/g;
const exports=[...f.matchAll(re)].map(x=>x[1]);
const expected=['CreateEvent','UpdateEvent','SetOpen','Submit','Review','EditEntry','DeleteEntry','DeleteEvent','MyRank'].map(x=>api+x);
assert.deepEqual(exports.slice().sort(),expected.slice().sort(),'Exactly nine versioned functions required');
const roots=['events','ownerEvents','publicRows','privateRows','alloc','changes','nameClaims','rankActive','receipts','sync','rowLocks'];
const srcfiles=['functions/index.js','database.rules.json','reg/index.html','reg/signup.html','reg/status.html'];
for(const file of srcfiles){
 const body=fs.readFileSync(file,'utf8');
 const versioned=/\b(?:regV\d+|reg8)[A-Z][A-Za-z]+|\b(?:events|ownerEvents|publicRows|privateRows|alloc|changes|nameClaims|rankActive|receipts|sync|rowLocks)V\d+\b/g;
 for(const m of body.matchAll(versioned)){
   if(m[0].startsWith('reg'))assert(m[0].startsWith(api),file+': stale API '+m[0]);
   else assert(m[0].endsWith(suffix),file+': stale database path '+m[0]);
 }
}
for(const root of roots)assert(f.includes(root+suffix),'Backend path not versioned: '+root);
for(const page of ['reg/index.html','reg/signup.html','reg/status.html']){
 const s=fs.readFileSync(page,'utf8');assert(s.includes(label+' 測試版'),page+' missing release label');
 assert(s.includes('ljtreg-39954'),page+' incorrect Firebase project');
}
const rules=JSON.parse(fs.readFileSync('database.rules.json','utf8')).rules;
assert.equal(rules['.read'],false);assert.equal(rules['.write'],false);
for(const root of ['events','ownerEvents','publicRows','privateRows','changes','sync'])assert(rules[root+suffix],root+' missing from rules');
for(const k of Object.keys(rules))if(k!=='.read'&&k!=='.write')assert(k.endsWith(suffix),'Stale Rules path '+k);
assert.equal(JSON.parse(fs.readFileSync('firebase.json','utf8')).functions[0].codebase,'registration');
const hosting=JSON.parse(fs.readFileSync('firebase.json','utf8')).hosting;
assert.equal(hosting.site,'bbxr-tamsui');
assert.equal(hosting.public,'reg');
assert(hosting.rewrites.some(x=>x.source==='/s/**'&&x.destination==='/signup.html'));
assert(hosting.rewrites.some(x=>x.source==='/q/**'&&x.destination==='/status.html'));
assert(f.includes('https://bbxr-tamsui.web.app'),'Hosting CORS domain must be explicitly allowed');
assert(f.includes('const EVENT_ID_RE=/^[A-Z0-9]{5}$/'));
for(const file of ['reg/signup.html','reg/status.html'])assert(fs.readFileSync(file,'utf8').includes('location.pathname.match'),'direct /s/ or /q/ path reading absent');
console.log('PASS version guard:',label,expected.length,'functions, 5-char codes, Hosting routes, CORS, Rules, 3 HTML pages');
JS
