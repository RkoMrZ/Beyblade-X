#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
echo '== VERSION-ISOLATED PREFLIGHT: NO LIVE DATABASE WRITES =='
if command -v nvm >/dev/null 2>&1; then nvm use 22 || nvm install 22; fi
node --version
command -v firebase >/dev/null || { echo 'ERROR: Firebase CLI not found'; exit 1; }
bash 06_source_guard.sh
node --check functions/index.js
node functions/tests/code_space.test.js
node functions/tests/smoke.test.js
node functions/tests/rules.static.test.js
if python3 -c 'import playwright' >/dev/null 2>&1 && command -v chromium >/dev/null 2>&1; then
  python3 functions/tests/frontend.offline.py
  python3 functions/tests/request_audit_browser.py
  python3 functions/tests/lifecycle.offline.py
  python3 functions/tests/short_urls.offline.py
else
  echo 'SKIP browser offline audit: Playwright or chromium not installed in this Cloud Shell (see packaged offline report).';
fi
npm install --prefix functions --no-audit --no-fund
echo '== RTDB Emulator integration (demo project only) =='
timeout -k 10s 360s firebase emulators:exec --only database --project demo-ljtreg 'node functions/tests/emulator.integration.js'
echo 'PASS: source, smoke, Rules and Firebase RTDB Emulator (no live data changed).'
