# BBX-V0.13 — 跨平台按鈕觸控定位整理

基於 V0.12 前端，只部署 Firebase Hosting `bbxs-tamsui`；既有 9 支 Cloud Functions、Realtime Database Rules 與賽事資料原樣保留。

## 本次整理
- 刪除 V0.10/0.11 兩組衝突的 visualViewport、固定高度與 `!important` 覆蓋式彈窗定位補丁。
- 將裁判記分、修改比分、比分選擇、重設確認、刪除確認、獎品抽籤結果及全螢幕對戰表統一以 **document 座標** 定位；避免各系統的視覺與觸控座標分離。
- 移除以前多層 `max-width:520px` 高度、底部留白及強制 `min-height` 覆蓋，使用一份手機排版規則與可捲動面板，主要動作按鈕高度至少 44px。
- 使用同一函式響應視窗縮放、捲動、背景恢復與裝置轉向；所有互動的開啟點立即同步位置。
- CSS 與 JS 使用版本號與內容雜湊重新命名；V0.12 不會被瀏覽器過期快取混用。
- Node.js 回歸測試、靜態檢查與 Chromium 跨裝置矩陣測試，不宣稱取代真正的 iOS Safari/Android 裝置實測。

## 特別保留
`bbxV011*` Functions、`authorityBBXV011` 與 `releaseTag` 是仍使用中的資料庫協定名稱，**不能**當成過時函式任意刪除。兩種抽籤、記分交易及雲端權限也完全保留。

## 安全部署
本套件僅 Hosting；`bash 00_start.sh` 會先做檔案、程式與測試檢查，再更新 `ljt-beyblade-x` 的 `bbxs-tamsui` 網站，不清除或改寫 Firebase 任何賽事資料。
