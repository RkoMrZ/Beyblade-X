#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
[[ "$(basename "$PWD")" == BBX-V0.13 ]] || { echo 'STOP: wrong version folder';exit 2; }
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v013-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight missing';exit 3; }
P=ljt-beyblade-x
SITE=bbxs-tamsui
gcloud auth print-access-token >/dev/null
firebase hosting:sites:get "$SITE" --project "$P" >/dev/null
mkdir -p hosting-public
# Only clear the transient local upload staging; never delete Firebase data.
rm -rf hosting-public/assets
mkdir -p hosting-public/assets
cp -f index.html viewer.html hosting-public/
cp -f assets/index-v013-*.css assets/index-v013-*.js assets/viewer-v013-*.css assets/viewer-v013-*.js hosting-public/assets/
# No reused immutable URLs: each referenced asset filename contains its content SHA-256 prefix.
python3 - <<'PY_CHECK'
from pathlib import Path
import re,hashlib
for source in ('index.html','viewer.html'):
 html=Path(source).read_text()
 paths=re.findall(r'assets/(?:index|viewer)-v013-[0-9a-f]{12}\.(?:js|css)',html)
 assert len(paths)==2,(source,paths)
 for path in paths:
  f=Path(path);m=re.search(r'-([0-9a-f]{12})\.(?:js|css)$',path)
  assert hashlib.sha256(f.read_bytes()).hexdigest().startswith(m.group(1)),path
print('PASS: immutable Hosting asset URLs are content fingerprinted')
PY_CHECK
test -s hosting-public/index.html && test -s hosting-public/viewer.html
firebase deploy --only hosting --config firebase.hosting.json --project "$P" --non-interactive
# Verification compares file content, not just a reused V0.13 basename.
for attempt in 1 2 3 4 5 6; do
 tmp_html="$(mktemp)"
 if curl --fail --location --silent --show-error --max-time 15 -H 'Cache-Control: no-cache' "https://${SITE}.web.app/" -o "$tmp_html" && cmp -s index.html "$tmp_html"; then
  rm -f "$tmp_html"
  break
 fi
 rm -f "$tmp_html"
 if [ "$attempt" -eq 6 ];then echo 'STOP: deployed HTML byte-for-byte verification failed';exit 4;fi
 sleep 3
done
ASSET="$(sed -n 's/.*src="\.\/assets\/\([^"]*index-v013-[a-f0-9]*\.js\)".*/\1/p' index.html | head -1)"
test -n "$ASSET" || { echo 'STOP: hashed JS reference missing'; exit 4; }
TMP_JS="$(mktemp)"
curl --fail --location --silent --show-error --max-time 20 "https://${SITE}.web.app/assets/${ASSET}" -o "$TMP_JS"
cmp -s "assets/${ASSET}" "$TMP_JS" || { rm -f "$TMP_JS"; echo 'STOP: CDN JS hash mismatch'; exit 4; }
rm -f "$TMP_JS"
printf '\nPASS: V0.13 exact HTML and SHA-fingerprinted JS deployed on %s.web.app\n' "$SITE"
