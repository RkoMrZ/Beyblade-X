#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == 'BBX-V0.13' ]] || { echo 'STOP: incorrect V0.13 folder'; exit 2; }
python3 - <<'PY'
from pathlib import Path
import hashlib,json
m=json.loads(Path('MANIFEST.json').read_text())
assert m['project_id']=='BBX-V0.13' and m['firebase_project']=='ljt-beyblade-x'
assert len(m['functions_exports'])==9
for item in m['files']:
 p=Path(item['path']);raw=p.read_bytes()
 assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],str(p)
print('PASS: V0.13 package byte-level integrity')
PY
python3 - <<'PY_BACKEND'
import hashlib,json
from pathlib import Path
expected={'functions/bbx-v011-lifecycle.js': 'b2a47ad3f7253654272a5f728434f6f332d569fa450e7d892830482978a585e9', 'functions/bbx-v011-core.js': 'a773a9e9342bd2ad5aaa6cb714eaa837b82d6bc74490aa2a2a7ab0639f07642c', 'functions/bbx-v011-organizer.js': '0e313221417d0dcd98f9171f69d91a433b43d5a571943fb1f14ed27515045277', 'functions/bbx-v011-cleanup.js': '888397ccf9aa05278b2fbfae001a33b9c2c5ffa8a5b0015ed001d0e1b4569124', 'functions/bbx-v011-publication.js': '4988a12830264f7f395b866dc987b3ac289a5105e587cdf0ca2292afe9e6e0b9', 'functions/index.js': 'd0b22b0a9bb4e30512375484713312657b31694396c2a8765d6568914497a55c', 'functions/package.json': '93a45fb35f3b0adca23f323d827072350265eb217e776fab0c7f301f744a940d', 'database.rules.json': 'ead2bd91a9eb35816140cb4565e428a55c4ad2c1ed20b2502f718527a351ef06'}
for name,digest in expected.items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,'Backend was changed: '+name
print('PASS: existing 9 Cloud Functions and RTDB Rules are byte-identical to V0.11')
PY_BACKEND
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required'; exit 3; }
for f in functions/*.js assets/*.js; do node --check "$f"; done
node --test tests/*.test.js
python3 tests/check_rules_syntax.py
python3 tests/check_static.py
python3 tests/check_cleanup_rules.py
python3 deploy/merge-rules.py docs/previous-v09-rules.json /tmp/bbx-v013-test-merge.json
python3 - <<'PY'
import json
x=json.load(open('/tmp/bbx-v013-test-merge.json'))['rules']
assert x['authorityBBXV09']=={'.read':False,'.write':False}
assert x['authorityBBXV011']=={'.read':False,'.write':False}
assert 'authorityBBXV09' in x['publicEvents']['$eventId']['.read']
assert 'authorityBBXV011' in x['publicEvents']['$eventId']['.read']
print('PASS: old V0.9 and new V0.13 public access rules are safely split')
PY
command -v firebase >/dev/null || { echo 'STOP: Firebase CLI unavailable'; exit 4; }
sha256sum MANIFEST.json | awk '{print $1}' > "$HOME/.bbx-v013-preflight-ok"
printf '\nPASS: BBX-V0.13 frontend and backend-compatibility tests passed (Hosting only).\n'
