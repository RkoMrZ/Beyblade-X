const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v042.js'),'utf8');
const hero=src.slice(src.indexOf('function privateHeroHtml(){'),src.indexOf('function capturePrivateBracket('));
const render=src.slice(src.indexOf('function renderAdmin({bracketOnly=false}={}){'),src.indexOf('function renderFinalPlacings(){'));
const patch=src.slice(src.indexOf('function patchPrivateBracket(){'),src.indexOf('function bracketDefaultScale(){'));
const tab=src.slice(src.indexOf('function showTab(t){'),src.indexOf('function updateRefereePanelHtml('));
test('V0.39 role-specific HTML, not post-render CSS, enforces organizer action visibility',()=>{
 assert.match(hero,/const organizerAccess=hasOrganizerAccess\(\)/);
 assert.match(hero,/organizerAccess\?`<button id=organizerHeroBtn/);
 assert.match(hero,/\$\{heroActions\}/);
 assert.doesNotMatch(hero,/adminActions><button id=organizerHeroBtn/);
});
test('V0.39 SSE patch and bracketOnly rebuild both invoke access pass',()=>{
 assert.match(render,/if\(bracketOnly && patchPrivateBracket\(\)\)\{\s*applyAccessUI\(\);/);
 assert.match(render,/renderDraw\(\);renderRoster\(\);renderShare\(\);\s*}\s*\/\/ This includes bracketOnly fallback full renders[\s\S]*?applyAccessUI\(\)/);
 assert.match(patch,/const hero=privateHeroHtml\(\)/);
});
test('V0.39 access loss cannot leave organizer tab active or clickable',()=>{
 assert.match(render,/!hasOrganizerAccess\(\) && \['organizer','draw','roster'\]\.includes\(currentAdminTab\)/);
 assert.match(render,/panel\.classList\.toggle\('hidden',x!=='bracket'\)/);
 assert.match(tab,/if\(isReferee&&!organizerAccess&&t==='organizer'\)t='bracket'/);
 assert.match(tab,/if\(!organizerAccess && \(t==='draw'\|\|t==='roster'\|\|t==='organizer'\)\)/);
});
const O=require('../functions/bbx-v011-organizer');
test('Cloud organizer reducer requires owner or admin privilege (not referee alone)',()=>{
 const s=fs.readFileSync(path.join(__dirname,'../functions/bbx-v011-organizer.js'),'utf8');
 assert.match(s,/raw\.ownerUid!==uid && !perms\.admin/);
 assert.match(s,/permission-denied/);
});
