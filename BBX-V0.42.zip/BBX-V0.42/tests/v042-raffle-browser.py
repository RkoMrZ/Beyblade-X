#!/usr/bin/env python3
"""Real Chromium: cancel a raffle checkbox while RTDB projection still lags."""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
s=(root/'assets/index-v042.js').read_text()
css=(root/'assets/index-v042.css').read_text()
part=s[s.index('let raffleTimer=null;'):s.index('function shuffleDraw(){')]
# draw markup references browser helpers, and mock only Firebase/network.
pre=r'''
window.ev={id:'TEST-E',roster:['阿賢','阿霆'],testOnly:false,raffleState:{winners:[],checked:{'阿賢':true,'阿霆':true}}};
window.cloudEventsCache={};window.currentAdminTab='draw';
window.$=id=>document.getElementById(id);
window.esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
window.cloneJson=o=>JSON.parse(JSON.stringify(o));
window.hasOrganizerAccess=()=>true;window.isV1Authority=()=>true;
window.mockSeq=27;window.mockAuthorityCalled=false;window.mockAlerts=[];
window.alert=t=>window.mockAlerts.push(t);
window.v1CloudOrganizerCommand=async()=>{
 window.mockAuthorityCalled=true;
 // An old projection arrives while the scoped command succeeds.
 window.ev.raffleState={winners:[],checked:{'阿賢':true,'阿霆':true}};
 return {ok:true,seq:28,published:false};
};
window.rtdbRestGet=async path=>path.endsWith('/publishedSeq')
 ?window.mockSeq:{winners:[],checked:{'阿賢':true,'阿霆':false}};
window.backgroundRefreshCurrentEvent=async()=>{};
'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width in [375,390,768,1366]:
        page=browser.new_page(viewport={'width':width,'height':820})
        page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style><div id="drawTab"></div>')
        page.evaluate(pre+part+'\nrenderDraw();')
        check=page.locator('.raffleCheck').nth(1)
        assert check.is_checked()
        check.uncheck()
        assert not page.locator('.raffleCheck').nth(1).is_checked()
        page.wait_for_timeout(760)
        assert page.evaluate('mockAuthorityCalled')
        # V0.41 rechecked here ~2s after operation; V0.42 stays unchecked.
        assert not page.locator('.raffleCheck').nth(1).is_checked()
        assert page.locator('#raffleStartBtn').is_disabled()
        assert '等待雲端確認' in page.locator('#drawTab').inner_text()
        page.evaluate('mockSeq=28')
        page.wait_for_function('!v1RaffleHasUnconfirmedChanges()',timeout=7000)
        assert not page.locator('.raffleCheck').nth(1).is_checked()
        assert page.locator('#raffleStartBtn').is_enabled()
        assert '勾選已儲存到雲端' in page.locator('#drawTab').inner_text()
        assert page.evaluate('mockAlerts.length')==0
        page.close()
    browser.close()
print('PASS: V0.42 real DOM checkbox does not bounce on stale projection; verified ack restores draw controls in 375/390/768/1366 widths')
