'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v042.js'),'utf8');
const between=(a,b)=>{const x=src.indexOf(a),y=src.indexOf(b,x+1);assert(x>=0&&y>x);return src.slice(x,y)};
const stateFns=between('function defaultRaffleState(){','let v1RafflePending=null,v1RaffleTimer=null,v1RaffleBusy=false;');
function setup({delayed=false,receipt=null,pub=28,projected={winners:[],checked:{阿賢:true,阿霆:false}}}={}){
  let resume,reads=[],alerts=[],renders=0,commands=[];
  const ctx={
    ev:{id:'E',roster:['阿賢','阿霆'],raffleState:{winners:[],checked:{阿賢:true,阿霆:true}}},
    Map,Promise,console,cloneJson:structuredClone,cloudEventsCache:{},currentAdminTab:'draw',
    raffleSpinning:false,clearTimeout(){},
    setTimeout(cb){ if(delayed){setImmediate(cb);return 7;}queueMicrotask(cb);return 8; },
    async v1CloudOrganizerCommand(action,payload,id,options){
      commands.push({action,payload,id,options});
      // Simulate the V0.41 stale projection clobber AFTER authority commit.
      ctx.ev.raffleState={winners:[],checked:{阿賢:true,阿霆:true}};
      return receipt||{ok:true,seq:28,published:false};
    },
    async rtdbRestGet(key){ reads.push(key);return key.endsWith('publishedSeq')?pub:projected; },
    backgroundRefreshCurrentEvent:async()=>{ctx.ev.raffleState=structuredClone(projected)},
    renderDraw(){renders++},alert(s){alerts.push(s)}
  };
  vm.createContext(ctx);vm.runInContext(stateFns,ctx);
  return {ctx,reads,alerts,commands,get renders(){return renders},resume(){if(resume){const cb=resume;resume=null;cb()}}};
}
test('V0.41 exact rebound: stale draw snapshot while publication pending keeps unchecked overlay',async()=>{
  const t=setup({delayed:true,pub:27});
  vm.runInContext('enqueueV1RaffleCheck("阿霆",false)',t.ctx);
  const promise=vm.runInContext('flushV1RaffleChecks()',t.ctx);
  // The pending authoritative update has not yet been projected to events/.
  for(let i=0;i<5;i++)await Promise.resolve();
  assert.equal(vm.runInContext('getRaffleState().checked["阿霆"]',t.ctx),false);
  assert.equal(vm.runInContext('v1RaffleHasUnconfirmedChanges()',t.ctx),true);
  assert.equal(t.commands[0].options.deferEventRefresh,true);
  // A normal publication now appears; one bounded retry confirms via REST.
  t.ctx.rtdbRestGet=async key=>key.endsWith('publishedSeq')?28:{winners:[],checked:{阿賢:true,阿霆:false}};
  t.resume();await promise;
  assert.equal(vm.runInContext('getRaffleState().checked["阿霆"]',t.ctx),false);
  assert.equal(vm.runInContext('v1RaffleHasUnconfirmedChanges()',t.ctx),false);
  assert.equal(t.alerts.length,0);
});
test('confirmed checkbox is protected from an older in-flight full-event response',async()=>{
  const t=setup();vm.runInContext('enqueueV1RaffleCheck("阿霆",false)',t.ctx);
  await vm.runInContext('flushV1RaffleChecks()',t.ctx);
  const older={publishedSeq:27,raffleState:{winners:[],checked:{阿賢:true,阿霆:true}}};
  const original=t.ctx.ev;
  const result=vm.runInContext('preserveVerifiedRaffleOnOldEventSnapshot',t.ctx)(older,original,'E');
  assert.equal(result.raffleState.checked.阿霆,false);
  const later={publishedSeq:29,raffleState:{winners:[],checked:{阿賢:true,阿霆:true}}};
  assert.equal(vm.runInContext('preserveVerifiedRaffleOnOldEventSnapshot',t.ctx)(later,original,'E').raffleState.checked.阿霆,true);
});
test('publishedSeq before acknowledgement never falsely confirms saving a checkbox',async()=>{
  const t=setup({pub:27});vm.runInContext('enqueueV1RaffleCheck("阿霆",false)',t.ctx);
  await vm.runInContext('flushV1RaffleChecks()',t.ctx);
  assert.equal(t.alerts.length,1);assert.match(t.alerts[0],/尚未確認|尚待發布/);
  assert.equal(vm.runInContext('v1RaffleHasUnconfirmedChanges()',t.ctx),false);
  assert.equal(t.commands.length,1); // must not repeat ambiguous write with a fresh opId
});
test('authority says published but wrong checkbox value: report conflict; no silent bounce',async()=>{
  const t=setup({pub:29,projected:{winners:[],checked:{阿賢:true,阿霆:true}}});
  vm.runInContext('enqueueV1RaffleCheck("阿霆",false)',t.ctx);
  await vm.runInContext('flushV1RaffleChecks()',t.ctx);
  assert.equal(t.alerts.length,1);assert.match(t.alerts[0],/不一致/);
});
test('prize draw and reset cannot race an unconfirmed checkbox operation',()=>{
  assert.match(src,/function startPrizeRaffle\(\)[\s\S]{0,230}v1RaffleHasUnconfirmedChanges/);
  assert.match(src,/function resetPrizeRaffleRound\(\)[\s\S]{0,230}v1RaffleHasUnconfirmedChanges/);
  assert.match(src,/raffleSaving\?'':'disabled'/);
});
