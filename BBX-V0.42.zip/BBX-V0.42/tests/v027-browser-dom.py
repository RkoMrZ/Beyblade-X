from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil
import re,json
s=(Path(__file__).resolve().parents[1]/'assets/index-v042.js').read_text()
block=s[s.index('let bracketViewEventId=null;'):s.index('function bracketDefaultScale(){')]
match=s[s.index('function renderBracketMatch(m,ri,mi){'):s.index('function refereeIdentityKey(){')]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium') or shutil.which('chromium-browser'),headless=True,args=['--no-sandbox'])
 for w in (375,390,768,1366):
  page=b.new_page(viewport={'width':w,'height':800})
  page.set_content('''<div id="bracketTab"><div class="adminHero">Init</div><div class="bracketShell"><div class="bracketScroll" style="overflow:auto;height:320px;width:300px"><div class="bracketCanvas"><section class="roundCol" data-round="0"><div class="roundMatches"></div></section></div></div></div></div>''')
  page.evaluate('''() => {window.$=id=>document.getElementById(id);window.esc=x=>String(x??''); window.isReferee=false;window.isAdmin=true;window.hasOrganizerAccess=()=>window.isAdmin;window.usesThreePlayerFinal=()=>false;window.isV1Authority=()=>true;window.getMyReferee=()=>'';window.freeFlowLabel=()=>'';window.drawBracketLinks=()=>window.linkDraws++;window.linkDraws=0;window.renderRR=()=>'';window.renderFinalPlacings=()=>'';window.ev={id:'MATCH',name:'Demo',mode:'free',freeFinal:'champ',roster:['A','B','C','D'],rounds:[{name:'Round1',matches:[{a:'A',b:'B',sa:0,sb:0,winner:null,refereeActive:false},{a:'C',b:'D',sa:0,sb:0,winner:null,refereeActive:false}]}]};}''')
  page.add_script_tag(content=match+'\n'+block)
  page.evaluate('''() => {
    const tab=document.getElementById('bracketTab');tab.querySelector('.adminHero').outerHTML=privateHeroHtml();
    const matches=ev.rounds[0].matches.map((m,i)=>renderBracketMatch(m,0,i)).join('');tab.querySelector('.roundMatches').innerHTML=matches;
    capturePrivateBracket(privateHeroHtml());window.oldCard=tab.querySelector('[data-mi="1"]');
    const sc=tab.querySelector('.bracketScroll');sc.scrollTop=90;window.oldScroll=sc;
    ev.rounds[0].matches[0].sa=4;ev.rounds[0].matches[0].refereeActive=true;ev.rounds[0].matches[0].referee='裁判 1';
  }''')
  assert page.evaluate('patchPrivateBracket()') is True
  assert page.evaluate('document.querySelector(`[data-mi="1"]`)===window.oldCard')
  assert page.evaluate('document.querySelector(".bracketScroll")===window.oldScroll')
  assert page.evaluate('document.querySelector(`[data-mi="0"] .bScore`).textContent')=='4'
  assert page.evaluate('document.querySelector(`[data-mi="0"]`).classList.contains("judging")')
  page.evaluate('ev.rounds[0].matches[1].sb=6;')
  assert page.evaluate('patchPrivateBracket()') is True
  assert page.evaluate('document.querySelector(`[data-mi="0"]`)===window.oldCard') is False
  assert page.evaluate('document.querySelectorAll(`[data-mi="1"] .bScore`)[1].textContent')=='6'
  page.close()
  print('PASS',w,'no unchanged-card replacement, scroll container retained, scores & locks patched')
 b.close()
