#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.42 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: V0.42 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.42 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v042.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v042-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight mismatch';exit 3; }
# V0.42 is Hosting-only. Requires V0.41's setRaffleChecks callable already live.
# Do not redeploy Functions or Database Rules while matches are in progress.
bash deploy/hosting-v042.sh
date -u > .release-completed
printf '\nPASS: V0.42 Hosting deployed; Functions/Rules/data unchanged.\n'
