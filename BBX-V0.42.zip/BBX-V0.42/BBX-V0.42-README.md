# BBX-V0.42 — 抽獎勾選「取消後兩秒重新勾選」修正

基於 BBX-V0.41 完整套件；保留它已部署的 `setRaffleChecks` 雲端權威操作。**此次只修改 Hosting 前端**。

- V0.41 在 Callable 回覆後就取消勾選暫存，再進行 `renderDraw()`；如果 RTDB events 投影尚未追上權威寫入，使用者剛取消的勾選會被舊快照再次打勾。
- V0.42 將成功回執 (`seq`) 與 RTDB `publishedSeq`、`raffleState` 分別核對；只有真正發布了同一個選手的最新勾選，才取消暫存，避免 2 秒反彈。
- 即使在發布前收到舊版賽事 REST 回應，也不會讓它覆蓋已驗證的較新抽獎狀態。
- 不確定的結果不自動重複發送新 `opId`；有明確錯誤提示。只發送異動欄位，不發送舊的完整抽獎名單。
- 抽獎勾選未驗證完成前，暫時阻止「開始抽籤／開始新一輪」；不阻止其他場次比分記分。
- 主辦權限、雲端權威、Functions、Database Rules、比分、晉級、裁判權限、觀眾 SSE 均不更動。
- **依賴**：Firebase 專案已成功部署 V0.41 的 `bbxV011OrganizerAuthority`，包含 `setRaffleChecks`。本版不重新部署 Functions。
- 本地模擬及 Chromium 測試不代表真實雙手機已通過驗收。
