'use strict';
const crypto=require('node:crypto');
const C=require('./bbx-v011-core');
const {CommandError}=C;
const fail=(code,m)=>{throw new CommandError(code,m)};
const deep=x=>JSON.parse(JSON.stringify(x));
const OP=/^[a-f0-9]{48}$/;
const forbidden=new Set(['BYE','待定']);
function name(x){const s=typeof x==='string'?x.trim():'';if(!s||s.length>60||forbidden.has(s)||/[\u0000-\u001f]/.test(s))fail('invalid-argument','選手名稱無效');return s}
function match(a,b){const m={a:a||'BYE',b:b||'BYE',sa:'',sb:'',winner:null,referee:'',refereeActive:false,matchVersion:0};if(m.a==='BYE'&&m.b!=='BYE')m.winner=m.b;else if(m.b==='BYE'&&m.a!=='BYE')m.winner=m.a;return m}
function pending(){return match('待定','待定')}
// Automatic free-format selection is a server-owned structural decision.
// No repechage matches or losing-player draw is permitted in this release.
const FORMAT_TARGETS=Object.freeze([2,3,4,6,8,12,16,24,32,48,64,96,128]);
function deriveFormat(n){
 if(!Number.isInteger(n)||n<2||n>128)fail('invalid-argument','參賽人數須介於 2 至 128 人');
 const target=FORMAT_TARGETS.find(x=>x>=n);
 return {target,byes:target-n,freeFinal:target%3===0?'rr3':'champ'};
}
function initialAutoMatches(roster,target){
 if(target===3)fail('invalid-argument','三人直接使用循環賽');
 const byes=target-roster.length,slots=target/2;
 if(byes<0||byes>slots)fail('invalid-argument','輪空數量不合法');
 const byePositions=new Set();
 for(let i=0;i<byes;i++)byePositions.add(Math.floor((i+.5)*slots/byes));
 let at=0;
 const first=Array.from({length:slots},(_,i)=>byePositions.has(i)?match(roster[at++],'BYE'):match(roster[at++],roster[at++]));
 if(at!==roster.length||first.filter(x=>x.a==='BYE'||x.b==='BYE').length!==byes)
  fail('failed-precondition','輪空編排驗證未通過');
 return first;
}
// Build exactly the bracket produced by the original V1.0 buildFirst()/ensureNext().
// Maintain its BYE promotion, placement-final and last-three-round behavior.
function build(roster,mode,freeFinal,firstOverride=null,policy=null){
 const auto=policy?.formatPolicy==='auto16'&&mode==='free';
 const plan=auto?deriveFormat(roster.length):null;
 if(auto)freeFinal=plan.freeFinal;
 const r=[...roster];
 if(freeFinal==='rr3'&&mode==='free'&&r.length===3){
   return {rounds:[],finalRR:{players:r,matches:[[0,1],[1,2],[0,2]].map(([a,b])=>match(r[a],r[b]))}};
 }
 let first=[];
 if(firstOverride)first=deep(firstOverride);
 else if(auto)first=initialAutoMatches(r,plan.target);
 else if(mode==='single'){
   let power=1;while(power<r.length)power*=2;
   let at=0;for(let i=0;i<power-r.length;i++)first.push(match(r[at++],'BYE'));
   while(at<r.length)first.push(match(r[at++],r[at++]||'BYE'));
 }else for(let i=0;i<r.length;i+=2)first.push(match(r[i],r[i+1]||'BYE'));
 const rounds=[{name:'第 1 輪',matches:first}];
 let finalRR=null;
 const makePending=()=>match('待定','待定');
 const loser=m=>m?.winner?(m.winner===m.a?m.b:m.winner===m.b?m.a:'待定'):'待定';
 const putPlayers=(m,a,b)=>{
   a=a||'待定';b=b||'待定';
   if(m.a!==a||m.b!==b){m.a=a;m.b=b;m.sa='';m.sb='';m.winner=null;m.referee='';m.refereeActive=false;}
   if(m.a==='BYE'&&m.b!=='BYE'&&m.b!=='待定')m.winner=m.b;
   else if(m.b==='BYE'&&m.a!=='BYE'&&m.a!=='待定')m.winner=m.a;
 };
 for(let ri=0;ri<24;ri++){
   const cur=rounds[ri];if(!cur?.matches?.length||cur.placementFinal)break;
   const count=cur.matches.length;
   if(freeFinal==='rr3'&&count<=3){
     const winners=cur.matches.map(m=>m.winner).filter(Boolean);
     if(cur.matches.every(m=>!!m.winner)&&winners.length===3){
       finalRR={players:winners,matches:[[0,1],[1,2],[0,2]].map(([a,b])=>match(winners[a],winners[b]))};
     }
     break;
   }
   if((freeFinal==='champ'||mode==='single')&&count===2){
     const final={name:'最終名次',placementFinal:true,matches:[makePending(),makePending()]};
     const m0=cur.matches[0],m1=cur.matches[1];
     putPlayers(final.matches[0],m0?.winner||'待定',m1?.winner||'待定');
     putPlayers(final.matches[1],loser(m0),loser(m1));
     rounds.push(final);break;
   }
   if(count<=1)break;
   const next={name:`第 ${ri+2} 輪`,matches:Array.from({length:Math.ceil(count/2)},makePending)};
   for(let mi=0;mi<next.matches.length;mi++){
     const a=cur.matches[2*mi],b=cur.matches[2*mi+1];
     putPlayers(next.matches[mi],a?a.winner||'待定':'BYE',b?b.winner||'待定':'BYE');
   }
   rounds.push(next);
 }
 return {rounds,finalRR};
}
function anyStarted(b){return (b.rounds||[]).some(r=>(r.matches||[]).some(m=>m.refereeActive||m.claimUid||Number(m.sa||0)>0||Number(m.sb||0)>0||(m.winner&&m.a!=='BYE'&&m.b!=='BYE')))||!!b.finalRR?.matches?.some(m=>m.refereeActive||m.claimUid||m.winner||Number(m.sa||0)>0||Number(m.sb||0)>0)}
// Referee-list edits require no LIVE match lock, not no historical scores/winners.
// Finished matches can be renamed/reconfigured without changing their match data.
function anyActiveReferee(b){return (b.rounds||[]).some(r=>(r.matches||[]).some(m=>m?.refereeActive===true||(!m?.winner&&!!m?.claimUid)))||!!b.finalRR?.matches?.some(m=>m?.refereeActive===true||(!m?.winner&&!!m?.claimUid))}
function changeName(b,oldName,next){
 b.roster=b.roster.map(s=>s===oldName?next:s);
 for(const r of b.rounds||[])for(const m of r.matches||[]){for(const f of ['a','b','winner'])if(m[f]===oldName)m[f]=next;if(m.reviewPublished)for(const f of ['a','b','winner'])if(m.reviewPublished[f]===oldName)m.reviewPublished[f]=next;}
 if(b.finalRR){b.finalRR.players=b.finalRR.players.map(s=>s===oldName?next:s);for(const m of b.finalRR.matches||[]){for(const f of ['a','b','winner'])if(m[f]===oldName)m[f]=next;if(m.reviewPublished)for(const f of ['a','b','winner'])if(m.reviewPublished[f]===oldName)m.reviewPublished[f]=next;}}
}
function pubRound(r){return {name:r.name,...(r.placementFinal?{placementFinal:true}:{}),matches:(r.matches||[]).map(C.sanitizedMatch)}}
function pubRR(f){return f?{players:f.players,matches:(f.matches||[]).map(C.sanitizedMatch)}:null}
function apply(raw,uid,req,now,perms){
 if(!raw)fail('not-found','雲端賽事不存在');
 if(!OP.test(req?.opId||''))fail('invalid-argument','操作碼格式錯誤');
 const created=parseInt(req.opId.slice(0,12),16);if(created>now+300000||created<now-1800000)fail('failed-precondition','操作已過期');
 const action=req.action;
 if(!['rename','addPlayer','delPlayer','rebuild','randomRebuild','swapPlayers','closePublic','extendPublic','setReferees','appendReferee','setRaffle','setRaffleChecks'].includes(action))fail('invalid-argument','操作未支援');
 const fp=crypto.createHash('sha256').update(JSON.stringify({action,index:req.index,value:req.value,ri:req.ri,i:req.i,j:req.j,expectedSeq:req.expectedSeq,refereeNames:req.refereeNames,raffleState:req.raffleState,checks:req.checks})).digest('hex');
 const past=raw.receipts?.[req.opId];if(past){if(past.uid!==uid||past.hash!==fp)fail('permission-denied','操作碼被其他要求使用');return {replay:true,receipt:past.result}}
 if(raw.ownerUid!==uid && !perms.admin)fail('permission-denied','僅主辦可以修改名單與籤表');
 if(['closePublic','extendPublic'].includes(action)&&raw.ownerUid!==uid)fail('permission-denied','只有賽事建立者能管理公開連結');
 // Scoped raffle checkbox changes apply to the current authoritative board.
 // Match scores increment seq independently and must not reject a safe checkbox
 // patch. Every OTHER organizer action retains the strict expectedSeq guard.
 if(action!=='setRaffleChecks' && (!Number.isInteger(req.expectedSeq)||req.expectedSeq!==(raw.seq||0)))fail('aborted','資料已被其他裝置修改，請重新載入賽程');
 if(Object.keys(raw.outbox||{}).length>=48)fail('resource-exhausted','雲端公開資料正在同步，請稍候');
 const b=deep(raw),before=deep(raw);
 if(!Array.isArray(b.roster)||b.roster.length>128)fail('failed-precondition','名單資料格式不符');
 if(action==='closePublic'){
   b.publicOpen=false; b.publicUntil=now;
 } else if(action==='extendPublic'){
   b.publicOpen=true; b.publicUntil=now+4*60*60*1000;
 } else if(action==='appendReferee'){
   // V0.36: A new, never-claimed slot may be appended DURING a tournament.
   // Indexes of existing refereeClaims and active matches MUST remain stable.
   // The client supplies no replacement names or entire board snapshot.
   if(!Array.isArray(b.refereeNames)||b.refereeNames.length<1||b.refereeNames.length>12||
       b.refereeNames.some(x=>typeof x!=='string'||!x.trim()))
     fail('failed-precondition','裁判名單資料格式不符');
   if(b.refereeNames.length>=12)fail('failed-precondition','裁判最多 12 位');
   // Pick the next unused default name from authoritative server state.
   let number=b.refereeNames.length+1;
   while(b.refereeNames.includes(`裁判 ${number}`))number++;
   b.refereeNames.push(`裁判 ${number}`);
   b.refereeCount=b.refereeNames.length;
 } else if(action==='setReferees'){
   if(!Array.isArray(req.refereeNames)||req.refereeNames.length<1||req.refereeNames.length>12)fail('invalid-argument','裁判人數必須介於1至12人');
   const next=req.refereeNames.map(x=>{const s=typeof x==='string'?x.trim():'';if(!s||s.length>40||/[\u0000-\u001f]/.test(s))fail('invalid-argument','裁判名稱無效');return s});
   if(new Set(next).size!==next.length)fail('invalid-argument','裁判名稱不可重複');
   // Changing identities while a referee is judging would invalidate permissions.
   if(anyActiveReferee(b))fail('failed-precondition','仍有場次正在執裁，請先完成或釋放該場次');
   b.refereeNames=next;b.refereeCount=next.length;
 } else if(action==='setRaffleChecks'){
   const checks=req.checks;
   if(!Array.isArray(checks)||checks.length<1||checks.length>128)fail('invalid-argument','抽獎勾選數量無效');
   if(checks.some(x=>!x||typeof x.name!=='string'||typeof x.checked!=='boolean'||!b.roster.includes(x.name)) ||
      new Set(checks.map(x=>x.name)).size!==checks.length)
     fail('invalid-argument','抽獎勾選名單無效');
   const original=b.raffleState;
   const state=original&&Array.isArray(original.winners)&&original.checked&&typeof original.checked==='object'&&!Array.isArray(original.checked)
     ?deep(original):{winners:[],checked:Object.fromEntries(b.roster.map(name=>[name,true]))};
   if(checks.some(x=>state.winners.includes(x.name)))fail('failed-precondition','已中籤者不可重新勾選');
   for(const x of checks)state.checked[x.name]=x.checked;
   b.raffleState=state;
 } else if(action==='setRaffle'){
   const r=req.raffleState;
   if(!r||typeof r!=='object'||Array.isArray(r)||!Array.isArray(r.winners)||!r.checked||typeof r.checked!=='object'||Array.isArray(r.checked))fail('invalid-argument','抽獎狀態格式錯誤');
   if(r.winners.length>b.roster.length||new Set(r.winners).size!==r.winners.length||r.winners.some(x=>!b.roster.includes(x)))fail('invalid-argument','抽獎中獎名單無效');
   if(Object.keys(r.checked).some(x=>!b.roster.includes(x))||Object.values(r.checked).some(x=>typeof x!=='boolean'))fail('invalid-argument','抽獎勾選狀態無效');
   b.raffleState={winners:deep(r.winners),checked:deep(r.checked)};
 } else if(action==='rename'){
   const idx=req.index;if(!Number.isInteger(idx)||idx<0||idx>=b.roster.length)fail('invalid-argument','選手索引無效');
   const oldName=b.roster[idx],newName=name(req.value);
   if(b.roster.some((x,i)=>i!==idx&&x===newName))fail('already-exists','參賽者名稱不可重複');
   if(oldName===newName)return {unchanged:true,seq:b.seq||0};
   changeName(b,oldName,newName);
   // A renamed match is a new version; stale judge commands must fail.
   for(const r of b.rounds||[])for(const m of r.matches||[])if([m.a,m.b,m.winner].includes(newName))m.matchVersion=(m.matchVersion||0)+1;
   for(const m of b.finalRR?.matches||[])if([m.a,m.b,m.winner].includes(newName))m.matchVersion=(m.matchVersion||0)+1;
 } else {
   if(anyStarted(b))fail('failed-precondition','賽事已開始，不能直接重編籤表');
   if(action==='addPlayer'){
     const val=name(req.value);if(b.roster.length>=128)fail('failed-precondition','參賽人數最多128位');
     if(b.roster.includes(val))fail('already-exists','選手名稱不可重複');b.roster.push(val);
   } else if(action==='delPlayer'){
     const idx=req.index;if(!Number.isInteger(idx)||idx<0||idx>=b.roster.length||b.roster.length<=2)fail('invalid-argument','參賽人數至少2位');b.roster.splice(idx,1);
   } else if(action==='randomRebuild'){
     for(let i=b.roster.length-1;i>0;i--){const j=crypto.randomInt(i+1);[b.roster[i],b.roster[j]]=[b.roster[j],b.roster[i]];} b.pairing='random';
   } else if(action==='swapPlayers'){
     const ri=req.ri,i=req.i,j=req.j;
     if(!Number.isInteger(ri)||ri<0||ri>=(b.rounds||[]).length||ri!==0)fail('failed-precondition','目前只允許第一輪交換選手');
     const list=b.rounds[ri].matches.flatMap(m=>[m.a,m.b]);
     if(!Number.isInteger(i)||!Number.isInteger(j)||i<0||j<0||i>=list.length||j>=list.length||i===j)fail('invalid-argument','交換索引無效');
     [list[i],list[j]]=[list[j],list[i]];
     b.rounds=[];const first=[];for(let k=0;k<list.length;k+=2)first.push(match(list[k],list[k+1]));
     b.rounds=[{name:'第 1 輪',matches:first}];
   }
   if(b.formatPolicy!=='auto16'&&b.freeFinal==='rr3'&&b.mode==='free'){
     let n=b.roster.length;if(n!==3){while(n>3)n=Math.ceil(n/2);if(n!==3)fail('failed-precondition','目前人數無法自然淘汰到三人循環');}
   }
   const built=build(b.roster,b.mode,b.freeFinal,action==='swapPlayers'?b.rounds[0].matches:null,
     b.formatPolicy==='auto16'?{formatPolicy:'auto16'}:null);
   if(b.formatPolicy==='auto16')b.freeFinal=deriveFormat(b.roster.length).freeFinal;
   b.rounds=built.rounds;b.finalRR=built.finalRR;
 }
 const changes=[];
 if(JSON.stringify(before.refereeNames)!==JSON.stringify(b.refereeNames))changes.push({path:'refereeNames',value:b.refereeNames,publicChanged:false});
 if(before.refereeCount!==b.refereeCount)changes.push({path:'refereeCount',value:b.refereeCount,publicChanged:false});
 if(JSON.stringify(before.raffleState)!==JSON.stringify(b.raffleState))changes.push({path:'raffleState',value:b.raffleState,publicChanged:false});
 if(before.publicOpen!==b.publicOpen)changes.push({path:'publicOpen',value:b.publicOpen,publicPath:'meta/publicOpen',publicValue:b.publicOpen});
 if(before.publicUntil!==b.publicUntil)changes.push({path:'publicUntil',value:b.publicUntil,publicPath:'meta/publicUntil',publicValue:b.publicUntil});
 if(JSON.stringify(before.roster)!==JSON.stringify(b.roster))changes.push({path:'roster',value:b.roster,publicPath:'meta/roster',publicValue:b.roster,structure:true});
 if(before.pairing!==b.pairing)changes.push({path:'pairing',value:b.pairing,publicPath:'meta/pairing',publicValue:b.pairing,structure:true});
 if(before.freeFinal!==b.freeFinal)changes.push({path:'freeFinal',value:b.freeFinal,publicPath:'meta/freeFinal',publicValue:b.freeFinal,structure:true});
 if(JSON.stringify(before.rounds)!==JSON.stringify(b.rounds))changes.push({path:'rounds',value:b.rounds,publicValue:b.rounds.map(pubRound),structure:true});
 if(JSON.stringify(before.finalRR)!==JSON.stringify(b.finalRR))changes.push({path:'finalRR',value:b.finalRR,publicValue:pubRR(b.finalRR),structure:true});
 if(!changes.length)return {unchanged:true,seq:b.seq||0};
 // A newly rebuilt bracket may reuse matchVersion=0 and the same positions.
 // A separate structure epoch prevents a stale phone's old claim from being
 // accepted against DIFFERENT players at the same round/match index.
 if(changes.some(ch=>ch.structure===true)){
  b.structureVersion=Number(b.structureVersion||0)+1;
  changes.push({path:'structureVersion',value:b.structureVersion,publicChanged:false});
 }
 b.seq=(b.seq||0)+1;
 const result={ok:true,action,seq:b.seq,...(['closePublic','extendPublic'].includes(action)?{publicOpen:b.publicOpen,publicUntil:b.publicUntil}:{})};
 b.receipts??={};b.outbox??={};
 for(const [k,v] of Object.entries(b.receipts))if(v.at<now-2100000)delete b.receipts[k];
 b.receipts[req.opId]={uid,hash:fp,result,at:now};
 b.outbox[String(b.seq).padStart(12,'0')]={seq:b.seq,changes};
 return {board:b,result,changes};
}
module.exports={apply,build,anyStarted,anyActiveReferee,deriveFormat,initialAutoMatches};
