'use strict';
// Shared infrastructure only; business data is never persisted or cached here.
try{document.documentElement.dataset.theme=localStorage.getItem('reg-v06-theme')==='light'?'light':'dark'}catch{}
// One small startup/foreground check, not a permanent extra SSE connection.
let maintenanceActive=false,servicePending=null;
function showMaintenance(){
 if(!maintenanceActive){maintenanceActive=true;window.dispatchEvent(new Event('bbx-maintenance'))}
 const mount=()=>{
  if(document.getElementById('registrationMaintenance'))return;
  const box=document.createElement('section');box.id='registrationMaintenance';box.setAttribute('role','alert');
  box.innerHTML='<div><h1>系統暫時維修中</h1><p>正在更新服務，請稍後再試。既有報名資料會保留。</p><button type="button">重新確認</button></div>';
  box.querySelector('button').onclick=()=>location.reload();
  for(const n of document.body.children)if(n.tagName!=='SCRIPT')n.inert=true;
  document.body.append(box);
 };
 if(document.body)mount();else document.addEventListener('DOMContentLoaded',mount,{once:true});
}
function checkService(){
 if(servicePending)return servicePending;
 const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),6000);
 servicePending=fetch('https://ljtreg-39954-default-rtdb.asia-southeast1.firebasedatabase.app/registrationServiceState.json',{cache:'no-store',signal:ctl.signal})
 .then(async r=>{if(r.ok&&(await r.json())?.active===true)showMaintenance()})
 // If this optional status probe fails, normal API/Rules checks still fail closed.
 .catch(()=>{}).finally(()=>{clearTimeout(timer);servicePending=null});
 return servicePending;
}
const serviceReady=checkService();
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')checkService()});
window.addEventListener('pageshow',e=>{if(e.persisted)checkService()});
// Static version marker: no business-data polling; pause when hidden.
const CLIENT_VERSION='V0.10';
let versionPending=null,versionTimer=null,versionController=null,versionLast=0,activeWrites=0;
function showVersionUpdate(version){
 const mount=()=>{
  let box=document.getElementById('versionUpdate');
  if(!box){box=document.createElement('aside');box.id='versionUpdate';box.setAttribute('role','status');box.innerHTML='<span></span><button type="button" class="alt">重新整理</button>';document.body.append(box);
   box.querySelector('button').onclick=()=>{if(!activeWrites&&window.confirm('確認已儲存修改後，重新整理取得新版？'))location.reload()};
  }
  box.querySelector('span').textContent='網站已更新至 '+version+'，請重新整理。';
  box.querySelector('button').disabled=activeWrites>0;
 };
 if(document.body)mount();else document.addEventListener('DOMContentLoaded',mount,{once:true});
}
function writeActivity(delta){
 activeWrites=Math.max(0,activeWrites+delta);
 const b=document.getElementById('versionUpdate')?.querySelector('button');if(b)b.disabled=activeWrites>0;
}
function newerVersion(value){
 if(typeof value!=='string'||!/^V\d+\.\d+$/.test(value))return false;
 const a=value.slice(1).split('.').map(Number),b=CLIENT_VERSION.slice(1).split('.').map(Number);
 return a[0]>b[0]||(a[0]===b[0]&&a[1]>b[1]);
}
function checkVersion(){
 if(document.visibilityState!=='visible'||maintenanceActive)return Promise.resolve();
 if(versionPending)return versionPending;
 if(Date.now()-versionLast<60000)return Promise.resolve();
 versionLast=Date.now();versionController=new AbortController();const ctl=versionController,t=setTimeout(()=>ctl.abort(),6000);
 versionPending=fetch('/version.json',{cache:'no-store',signal:ctl.signal}).then(async r=>{if(!r.ok)return;const v=await r.json();if(newerVersion(v?.version))showVersionUpdate(v.version)}).catch(()=>{}).finally(()=>{clearTimeout(t);versionController=null;versionPending=null});
 return versionPending;
}
function versionWake(){
 clearTimeout(versionTimer);versionTimer=null;
 if(document.visibilityState!=='visible'){versionController?.abort();return}
 checkVersion();versionTimer=setTimeout(versionWake,300000);
}
document.addEventListener('visibilitychange',versionWake);
window.addEventListener('pagehide',()=>{clearTimeout(versionTimer);versionTimer=null;versionController?.abort()});
window.addEventListener('pageshow',versionWake);
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',versionWake,{once:true});else versionWake();
function setupOrganizerReturn(){
 const code=location.pathname.match(/^\/[sq]\/([A-Z0-9]{5})\/?$/)?.[1]||new URLSearchParams(location.search).get('e')||new URLSearchParams(location.search).get('event');
 if(new URLSearchParams(location.search).get('from')!=='organizer'||!code||!/^[A-Z0-9]{5}$/.test(code))return;
 const header=document.querySelector('.top');if(!header||document.getElementById('returnOrganizer'))return;
 const link=document.createElement('a');link.id='returnOrganizer';link.className='organizerReturn';link.href='/#manage='+code;link.textContent='返回';
 link.addEventListener('click',e=>{if(activeWrites){e.preventDefault();return}});header.append(link);
 const next=document.getElementById('statusLink');if(next){const u=new URL(next.href,location.href);u.searchParams.set('from','organizer');next.href=u.href}
}
document.addEventListener('DOMContentLoaded',setupOrganizerReturn,{once:true});
window.BBX=Object.freeze({
 version:CLIENT_VERSION,apiVersion:'V0.7',checkVersion,showVersionUpdate,beginWrite:()=>writeActivity(1),endWrite:()=>writeActivity(-1),
 serviceReady,showMaintenance,checkService,get maintenanceActive(){return maintenanceActive},
 createModalViewport(overlay,panel){
  let state=null,frame=0;
  const viewport=window.visualViewport;
  const props=['position','top','left','width','overflow'];
  const position=()=>{
   frame=0;if(!state)return;
   overlay.style.top=Math.max(0,viewport?.offsetTop||0)+'px';
   overlay.style.left=Math.max(0,viewport?.offsetLeft||0)+'px';
   overlay.style.width=(viewport?.width||window.innerWidth)+'px';
   overlay.style.height=(viewport?.height||window.innerHeight)+'px';
  };
  const schedule=()=>{if(state&&!frame)frame=requestAnimationFrame(position)};
  const listen=add=>{
   const method=add?'addEventListener':'removeEventListener';
   viewport?.[method]('resize',schedule);
   viewport?.[method]('scroll',schedule);
   window[method]('resize',schedule);
   window[method]('pageshow',schedule);
  };
  return {
   open(html){
    panel.innerHTML=html;
    if(!state){
     const body=document.body,focus=document.activeElement;
     state={x:window.scrollX,y:window.scrollY,focus,
      styles:props.map(p=>[p,body.style.getPropertyValue(p),body.style.getPropertyPriority(p)]),
      siblings:[...body.children].filter(n=>n!==overlay&&n.tagName!=='SCRIPT').map(n=>[n,n.inert])};
     // Blur a search/edit field before opening to dismiss its keyboard safely.
     if(focus?.matches?.('input,textarea,select'))focus.blur();
     Object.assign(body.style,{position:'fixed',top:-state.y+'px',left:-state.x+'px',width:'100%',overflow:'hidden'});
     state.siblings.forEach(([n])=>{n.inert=true});
     listen(true);
    }
    overlay.classList.remove('hide');position();
    panel.scrollTop=0;panel.tabIndex=-1;panel.focus({preventScroll:true});schedule();
   },
   close(){
    overlay.classList.add('hide');panel.innerHTML='';
    if(!state)return;
    const saved=state;state=null;listen(false);
    if(frame)cancelAnimationFrame(frame);frame=0;
    for(const [p,value,priority] of saved.styles){
     if(value)document.body.style.setProperty(p,value,priority);
     else document.body.style.removeProperty(p);
    }
    saved.siblings.forEach(([n,inert])=>{n.inert=inert});
    for(const p of ['top','left','width','height'])overlay.style.removeProperty(p);
    window.scrollTo({left:saved.x,top:saved.y,behavior:'instant'});
    // Never reopen the keyboard on close; it would move the viewport again.
    if(saved.focus?.isConnected&&!saved.focus.matches?.('input,textarea,select'))saved.focus.focus({preventScroll:true});
   }
  };
 },
 rankClass:label=>typeof label==='string'&&label.startsWith('正選#')?'rank-main':typeof label==='string'&&label.startsWith('備選#')?'rank-wait':'',
 legacyVersions:Object.freeze(/* CLEANUP_VERSIONS */ ["V03", "V04", "V05"]),
 aborted:()=>new DOMException('頁面已休眠或已切換','AbortError'),
 createQueue(){
  let tail=Promise.resolve();const pending=new Map();
  return {run(key,fn){
   if(pending.has(key))return pending.get(key);
   const task=tail.then(fn);
   const result=task.finally(()=>{if(pending.get(key)===result)pending.delete(key)});
   pending.set(key,result);tail=result.catch(()=>{});return result;
  }};
 },
 createReadPool(enabled){
  const pending=new Map();
  return {
   get(url){
    if(!enabled())return Promise.reject(BBX.aborted());
    if(pending.has(url))return pending.get(url).promise;
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),12000);
    const entry={ctl,promise:null};
    entry.promise=(async()=>{
     try{
      await serviceReady;if(maintenanceActive)throw new Error('系統維修中');
      const response=await fetch(url,{cache:'no-store',signal:ctl.signal});
      if(!response.ok){if(response.status===401||response.status===403)await checkService();throw Error('雲端讀取失敗（HTTP '+response.status+'）')};
      const data=await response.json();
      if(ctl.signal.aborted||!enabled())throw BBX.aborted();
      return data;
     }finally{clearTimeout(timer);if(pending.get(url)===entry)pending.delete(url)}
    })();
    pending.set(url,entry);return entry.promise;
   },
   abort(){for(const entry of pending.values())entry.ctl.abort();pending.clear()}
  };
 }
});
