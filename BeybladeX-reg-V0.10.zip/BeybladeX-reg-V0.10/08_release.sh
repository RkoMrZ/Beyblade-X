#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
umask 077
exec 9>.release.lock
flock -n 9 || { echo 'Already running: reconnect reg-v010-release'; exit 3; }
[ ! -f .release-completed ] || { echo RELEASE_ALREADY_COMPLETED; exit 0; }
exec > >(tee -a release.log) 2>&1
sha256sum -c FILE_SHA256.txt >/dev/null
[ -f "$HOME/BeybladeX-reg-V0.7/.release-completed" ] && [ -f "$HOME/BeybladeX-reg-V0.7/.backend-completed" ] || { echo 'STOP: V0.7 completed upgrade evidence not found. Do not reinstall or reset data. Show this message for review.'; exit 2; }
bash 06_source_guard.sh
for f in web/js/*.js; do node --check "$f"; done
# UI-only release: no Functions/Rules deployment and no database writes.
state=$(firebase database:get /registrationServiceState/active --project ljtreg-39954 --instance ljtreg-39954-default-rtdb)
[ "$state" = false ] || { echo 'STOP: maintenance is active or unknown; this release never reopens it automatically.'; exit 2; }
bash 07_deploy_hosting.sh
python3 maintenance/verify_hosting.py
date -u > .release-completed
echo 'RELEASE_COMPLETED V0.10: Hosting only; existing data and backend retained.'
