#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
python3 build.py
node - <<'JS'
const fs=require('fs'),assert=require('assert/strict'),path=require('path');
const c=JSON.parse(fs.readFileSync('RELEASE_VERSION.json')),h=JSON.parse(fs.readFileSync('firebase.json')).hosting;
assert.equal(c.release,'V0.10');assert.equal(c.apiPrefix,'regV06');assert.equal(c.dataSuffix,'V06');assert.equal(c.firebaseProject,'ljtreg-39954');
const f=fs.readFileSync('functions/index.js','utf8');
const names=[...f.matchAll(/exports\.(reg\w+)\s*=/g)].map(m=>m[1]).sort();
assert.deepEqual(names,['CreateEvent','UpdateEvent','SetOpen','Submit','Review','EditEntry','DeleteEntry','DeleteEvent','DeleteLegacyEvent','MyRank'].map(n=>'regV06'+n).sort());
// Legacy data names are allowed ONLY in the audited cleanup endpoint, owner-index UI
// and owner-only Rules. Never allow the old Functions back into exports.
const backend=fs.readFileSync('functions/index.js','utf8');
assert(!/exports\.regV0[1-5]/.test(backend));
const cleaned=require('./functions/cleanup_manifest');
assert.deepEqual(cleaned.LEGACY_VERSIONS,['V03','V04','V05']);
assert.deepEqual(Object.keys(cleaned.roots).sort(),['V03','V04','V05','V06']);
assert(cleaned.roots.V04.includes('managerRows')&&!cleaned.roots.V03.includes('managerRows'));
const frontend=fs.readFileSync('web/js/index.js','utf8');
assert(frontend.includes("call('regV06DeleteLegacyEvent'"));
for(const file of fs.readdirSync('web/js').filter(x=>x!=='index.js'&&x!=='common.js')){
 const x=fs.readFileSync('web/js/'+file,'utf8');assert(!/regV0[1-5]|V0[1-5]|reg-v0[1-5]/.test(x),'legacy read in '+file);
}
for(const file of ['index.html','signup.html','status.html']){const s=fs.readFileSync('reg/'+file,'utf8');assert(s.includes('V0.10 測試版'));assert(!s.includes('{{'));}
assert.equal(JSON.parse(fs.readFileSync('reg/version.json')).version,c.release);
assert(h.headers.some(x=>x.source==='/version.json'&&x.headers.some(y=>y.key==='Cache-Control'&&y.value==='no-store')));
assert.equal(h.site,'bbxr-tamsui');assert.equal(h.public,'reg');
assert(h.rewrites.some(x=>x.source==='/s/**'&&x.destination==='/signup.html'));assert(h.rewrites.some(x=>x.source==='/q/**'&&x.destination==='/status.html'));
const rules=JSON.parse(fs.readFileSync('database.rules.json')).rules;
assert.equal(rules['.read'],false);assert.equal(rules['.write'],false);assert(rules.managerRowsV06);assert(!rules.privateRowsV06);
const manifest=JSON.parse(fs.readFileSync('asset-manifest.json'));
for(const url of Object.values(manifest)){assert(/^\/assets\/[a-z]+\.[a-f0-9]{16}\.(js|css)$/.test(url));assert(fs.existsSync('reg'+url));}
console.log('PASS V0.10 compatibility (V06 storage/API retained), 10 endpoints, owner projection, hashed assets and Hosting routes');
JS
