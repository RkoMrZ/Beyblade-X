"""Mocked Chromium: ordering from unsorted owner index; no production requests."""
import ast,re
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_support import html_assets,browser_options
root=Path(__file__).resolve().parents[2]
tree=ast.parse(Path(__file__).with_name('frontend.offline.py').read_text())
seed=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SEED' for t in n.targets))
seed+='''
const original=window.fetch;
window.__posts=0;
window.fetch=async(u,o={})=>{
 if(o.method==='POST')__posts++;
 if(String(u).includes('/ownerEventsV06/'))return new Response(JSON.stringify({AAAAA:{title:'十一月四日',eventDate:'2026-11-04',capacity:48},CCCCC:{title:'十月二十七日',eventDate:'2026-10-27',capacity:48},BBBBB:{title:'十一月三日',eventDate:'2026-11-03',capacity:48},DDDDD:{title:'缺日期',capacity:48}}),{status:200});
 return original(u,o);
};'''
src=re.sub(r'^import .*?;\s*','',html_assets(root/'reg','index.html'),flags=re.M).replace('<script type="module">','<script>')
with sync_playwright() as p:
 b=p.chromium.launch(**browser_options())
 for width in [390,1280]:
  c=b.new_context(viewport={'width':width,'height':844});c.add_init_script(seed);c.route('**/*',lambda r:r.abort())
  page=c.new_page();page.set_content(src);page.wait_for_selector('[data-manage]')
  ids=page.locator('[data-manage]').evaluate_all('(buttons)=>buttons.map(b=>b.dataset.manage)')
  assert ids==['CCCCC','BBBBB','AAAAA','DDDDD'],ids
  assert page.locator('.versionIndex').inner_text()=='V0.10 測試版'
  assert page.evaluate('BBX.apiVersion')=='V0.7'
  assert page.evaluate('__posts')==0
  assert not any('/eventsV06/' in h or '/publicRowsV06/' in h for h in page.evaluate('__hits'))
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  print(f'PASS {width}px: dates ascending Oct27/Nov3/Nov4; missing date last; V0.10 display/V0.7 protocol; zero writes/roster downloads')
  c.close()
 b.close()
