# BBX-V0.15 — 裁判 QR Code 加入流程修復

## 這次修正

修復裁判尚未取得權限，就先讀取完整私人賽事而遭 Firebase Rules 拒絕的先後順序問題。

裁判以 `?event=五碼&ref=1` 進入時：
1. 只讀取公開的五碼對應賽事 ID。
2. 顯示獨立裁判驗證表單（不下載任何選手或比分）。
3. 確認六位數驗證碼後建立或沿用 Firebase 匿名／既有登入身分，將驗證碼寫入 `refereeUsers/{eventId}/{uid}`，由既有 Rules 核驗。
4. 確認裁判授權後，才讀取 `events/{eventId}` 全量資料並切換到裁判頁。
5. 已領取權限的裁判返回時先查單一 UID 權限，成功即可正常恢復。

這次只修改 Hosting 前端與自動化測試；`functions/`、`database.rules.json`、獎品抽籤、籤表重建、記分交易及跨版本清理後端均未修改。

為 iPhone Cloud Shell 保留原有 `cd ~` 開始的一行式下載 SHA-256 驗證和 `bash 00_start.sh` 入口。

## 測試限制

本地 Node.js 回歸測試僅能驗證前端程式路徑；真實 Firebase Emulator、iPhone Safari、Android Chrome 與 PC 跨設備測試仍須在部署環境與實機完成。正式賽事資料不作任何刪除或回填。
