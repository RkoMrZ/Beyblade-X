#!/usr/bin/env python3
"""BBX V0.11 preflight: externalized assets preserve V0.8 functional markup and styling."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def older(name):return (root/'baseline'/name.replace('.html','.v08.html')).read_text()
def cur(name):return (root/name).read_text()
# No user-facing markup changes except intentional audience Return removal.
def markup(t):
 t=re.sub(r'<style\b[^>]*>[\s\S]*?</style>','',t,flags=re.I)
 t=re.sub(r'<script\b[^>]*>[\s\S]*?</script>','',t,flags=re.I)
 t=re.sub(r'<link rel="stylesheet" href="\./assets/index-v015(?:-[a-f0-9]{12})?\.css">','',t)
 t=re.sub(r'<section id="refereeJoin" class="hidden">[\s\S]*?</section>','',t)
 # The one intentional organizer UI addition is a read-only sync panel.
 t=re.sub(r'<div class="ownerSyncRow">[\s\S]*?(?=<div id="savedEvents")','',t)
 t=t.replace('<span id="savedCount" class="badge">雲端待核對</span>',
             '<span id="savedCount" class="badge">0 場</span>')
 return re.sub(r'>\s+<','><',re.sub(r'\s+',' ',t)).strip()
a,b=markup(older('index.html')),markup(cur('index.html'))
assert a==b,'Tournament HTML changed beyond read-only sync diagnostics'
a=markup(older('viewer.html')).replace('<button type="button" onclick="goBack()">返回</button>','')
b=markup(cur('viewer.html'))
assert a.replace('>  </div>','> </div>')==b,'Viewer markup changed unexpectedly beyond requested back removal'
for name in ('index','viewer'):
 orig='\n\n'.join(re.findall(r'<style\b[^>]*>([\s\S]*?)</style>',older(name+'.html'),re.I))+'\n'
 if name=='viewer':
  assert cur('assets/'+name+'-v015.css').startswith(orig),'viewer original stylesheet changed'
 else:
  updated=cur('assets/index-v015.css')
  assert '.bracketMatch{' in updated and '.quickScoreBtns{' in updated
  assert '--app-vv' not in updated and 'position:fixed !important' not in updated
  assert updated.count('position:absolute;')>=2

 assert '<style' not in cur(name+'.html')
print('PASS original tournament markup preserved; modal CSS consolidated for correct hit targets')
ui=cur('assets/index-v015.js'); viewer=cur('assets/viewer-v015.js'); fn=cur('functions/index.js'); rules=json.loads(cur('database.rules.json'))['rules']
for text in ('startPrizeRaffle','resetPrizeRaffleRound','raffleState','randomRebuild','v1OrganizerAction(\'randomRebuild\')'):
 assert text in ui,text
assert "ev.roster=shuffle(ev.roster)" in ui
assert "this feature" not in ui # no English regression notice
assert "function publicUrl()" in ui and 'bbxs-tamsui.web.app/v/' in ui
assert "params.get('event')||pathCode" in viewer
assert "bbxV011CreateAuthority" in fn and "bbxV011CreateAuthority" in ui
assert 'authorityBBXV011/${eventId}' in fn
assert "ref:'authorityBBXV011/{eventId}/board/seq'" in fn
assert "document.visibilityState==='hidden'" in viewer
assert 'bbxV011PublicationPending' in rules and 'authorityBBXV011' in rules
assert 'authorityBBXV09' in rules['publicEvents']['$eventId']['.read']
assert 'authorityBBXV010' in rules['publicEvents']['$eventId']['.read']
assert 'authorityBBXV011' in rules['publicEvents']['$eventId']['.read']
assert rules['authorityBBXV08']=={'.read':False,'.write':False}
assert rules['authorityBBXV09']=={'.read':False,'.write':False}
assert rules['authorityBBXV010']=={'.read':False,'.write':False}
assert rules['authorityBBXV011']=={'.read':False,'.write':False}
assert 'ljtreg' not in fn+ui
assert ui.count('onValue(`events/${id}/raffleState`')==1
print('PASS prize raffle is distinct from roster redraw; short URL and private authority')
assert 'inFlightRestReads' in ui and 'inFlightPublicReads' in ui
assert 'await db.ref().update(rootWrites)' in fn
assert "db.ref(`events/${eventId}/authorityBBX`).get()" in fn
assert "db.ref(`events/${eventId}`).get()" not in fn[fn.index('async function publish('):fn.index('async function publishSafely(')]
print('PASS concurrent read coalescing and incremental projection scope')
