'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const index=fs.readFileSync(path.join(root,'assets/index-v015.js'),'utf8');
const viewer=fs.readFileSync(path.join(root,'assets/viewer-v015.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const viewerHtml=fs.readFileSync(path.join(root,'viewer.html'),'utf8');
const pick=(src,beg,end)=>{let a=src.indexOf(beg),b=src.indexOf(end,a);assert.ok(a>=0&&b>a,`slice ${beg}`);return src.slice(a,b)};
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};

test('same RTDB GET coalesces only concurrent reads, not future updates',async()=>{
 let count=0;const pending=deferred();
 const slice=pick(index,'const inFlightRestReads=new Map();','async function fetchRestGetOnce(');
 const ctx={Map,fbAuth:{currentUser:{uid:'owner'}}};vm.createContext(ctx);
 vm.runInContext(slice+'function fetchRestGetOnce(){return globalThis.fetcher()}',ctx);
 ctx.fetcher=()=>{count++;return count===1?pending.promise:Promise.resolve({seq:2})};
 const a=vm.runInContext('rtdbRestGet("events/TEST")',ctx);
 const b=vm.runInContext('rtdbRestGet("events/TEST")',ctx);
 assert.equal(a,b);assert.equal(count,1);
 pending.resolve({seq:1});await a;await new Promise(r=>setImmediate(r));
 const c=await vm.runInContext('rtdbRestGet("events/TEST")',ctx);
 assert.equal(count,2);assert.equal(c.seq,2);
});

test('public reader coalesces concurrent GET but never permanently caches',async()=>{
 let count=0;const pending=deferred();
 const slice=pick(index,'const inFlightPublicReads=new Map();','async function fetchPublicCloudOnce(');
 const ctx={Map,fbAuth:{currentUser:null}};vm.createContext(ctx);
 vm.runInContext(slice+'function fetchPublicCloudOnce(){return globalThis.fetcher()}',ctx);
 ctx.fetcher=()=>{count++;return count===1?pending.promise:Promise.resolve(20)};
 const a=vm.runInContext('publicCloudGet("publicEvents/TEST")',ctx);
 const b=vm.runInContext('publicCloudGet("publicEvents/TEST")',ctx);
 assert.equal(a,b);assert.equal(count,1);
 pending.resolve(10);await a;await new Promise(r=>setImmediate(r));
 assert.equal(await vm.runInContext('publicCloudGet("publicEvents/TEST")',ctx),20);
});

test('bracket randomRebuild is a roster structure operation, not a prize raffle',()=>{
 const slice=pick(index,'function randomRebuild(){','function closeRaffleWinnerModal(');
 const ctx={isAdmin:true,ev:{testOnly:true,roster:['A','B','C'],raffleState:{winners:['A'],checked:{A:false,B:true,C:true}}},
  isV1Authority:()=>false,shuffle:a=>a.slice().reverse(),rebuild(){ctx.rebuilt++},rebuilt:0};
 vm.createContext(ctx);vm.runInContext(slice,ctx);vm.runInContext('randomRebuild()',ctx);
 assert.deepEqual([...ctx.ev.roster],['C','B','A']);assert.equal(ctx.ev.pairing,'random');assert.equal(ctx.rebuilt,1);
 assert.deepEqual([...ctx.ev.raffleState.winners],['A']);
});

test('prize raffle changes only raffle state, never roster or bracket',()=>{
 const slice=pick(index,'function setRaffleChecked(name,checked){','function secureRandomIndex(max){');
 const ctx={hasOrganizerAccess:()=>true,raffleSpinning:false,ev:{roster:['A','B'],rounds:[{matches:[{a:'A',b:'B'}]}]},
  getRaffleState:()=>({winners:[],checked:{A:true,B:true}}),saveRaffleState(x){ctx.saved=x},renderDraw(){}};
 vm.createContext(ctx);vm.runInContext(slice,ctx);vm.runInContext('setRaffleChecked("A",false)',ctx);
 assert.equal(ctx.saved.checked.A,false);assert.deepEqual([...ctx.ev.roster],['A','B']);
 assert.equal(ctx.ev.rounds[0].matches[0].a,'A');
});

test('hosting viewer is short-route aware, hides return and loads independent static CSS/JS',()=>{
 assert.match(viewer,/const pathCode=location\.pathname\.match/);
 assert.match(viewer,/params\.get\('event'\)\|\|pathCode/);
 assert.doesNotMatch(viewerHtml,/onclick="goBack\(\)"/);
 assert.match(viewerHtml,/assets\/viewer-v015-[0-9a-f]{12}\.css/);
 assert.match(viewerHtml,/assets\/viewer-v015-[0-9a-f]{12}\.js/);
 assert.match(html,/assets\/index-v015-[0-9a-f]{12}\.css/);
 assert.match(html,/assets\/index-v015-[0-9a-f]{12}\.js/);
 const hosting=JSON.parse(fs.readFileSync(path.join(root,'firebase.hosting.json'),'utf8'));
 assert.equal(hosting.hosting.site,'bbxs-tamsui');
 assert.deepEqual(hosting.hosting.rewrites,[{source:'/v/**',destination:'/viewer.html'}]);
});

test('old V0.8 namespace remains available to cleanup, not used by new V0.11 event',()=>{
 const fn=fs.readFileSync(path.join(root,'functions/index.js'),'utf8');
 assert.match(fn,/const base=eventId=>`authorityBBXV011\/\$\{eventId\}`/);
 assert.match(fn,/function withLegacyV08DeletionLocks\(/);
 assert.match(fn,/withLegacyV08DeletionLocks\(eventId,\(\)=>remove\('authorityBBXV08'\)\)/);
 const rules=JSON.parse(fs.readFileSync(path.join(root,'database.rules.json'),'utf8')).rules;
 assert.equal(rules.authorityBBXV08['.read'],false);
 assert.equal(rules.authorityBBXV011['.read'],false);
});
