#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: deployment already running; inspect release.log'; exit 3; }
if [ -f .release-completed ]; then echo 'PASS: BBX-V0.15 already deployed and verified'; exit 0; fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.15 REFEREE ENTRY START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/BBX-V0.15-檢查.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v015-preflight-ok" 2>/dev/null)" ]] || { echo 'STOP: preflight mismatch'; exit 3; }
gcloud auth print-access-token >/dev/null
# IMPORTANT: frontend-only gate fix; no Cloud Functions, Database Rules, or RTDB data writes.
bash deploy/BBX-V0.15-Hosting.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.15 Hosting deployed and verified; Functions, Rules, live RTDB untouched.\n'
