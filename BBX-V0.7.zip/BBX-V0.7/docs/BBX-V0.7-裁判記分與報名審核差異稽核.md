# V0.7 裁判記分同步稽核（對照使用者提供的 BeybladeX-reg-V0.4）

## 報名系統實際程式做法

- `web/js/index.js` 的 `attempt()` 使用 `loading`，防止同畫面重複提交；成功後直接用 Callable 回傳的 `out.row` 更新指定選手，不必同步拉回整張審核名單。
- `functions/index.js` 的 `regV04Review` 經 `withRecord` 驗證建立者、`rowLock(e,k)`、`recordVersion`，然後一次 RTDB 多路徑 update（選手狀態、排名旗標、change journal、輕量同步標記）。
- 管理頁只讀 `syncV04` 小節點，不變就不抓名單；有變則按 `changesV04` 只取受影響選手；版本落後時才完整同步。
- 這是使用者提供的 V0.4 封包，不等於線上報名站的即時部署狀態。其 `loading` 是防連按，不是允許一位選手的多個審核狀態同時交錯提交。

## 賽程表故障原因與修正

1. 舊的 `quickAddMatchScore` 立即更新本機畫面、120ms 後背景送絕對比分。舊 `queueSingleMatchCloud` 可能在前一次請求未確認時再送下一筆，使用舊 matchVersion，導致版本衝突、5分只顯示於畫面。
2. 舊 `complete` 會直接把前端送來的比分寫到私有權威 board 再計算勝者；新版改為 `score` 才能修改比分，`complete` 僅比對「已寫入比分 / matchVersion / 執裁權」，再計算晉級，避免過期分數覆寫。
3. 同場分數透過 `v05ScoreQueues` 合併並依序送出；快速點擊不需要每一點等待 UI，但「此場完成」會等待該場未確認分數送出。不同場次的狀態佇列互不等待，不新增鎖。
4. 同場比分的版本只在 Callable 已確認後前進。失去回應時先查同一 opId 收據與私有權威比分，不用新 opId 重送、不造成重複計分。
5. 讀取 `events` 子場次監聽及背景快照時，忽略 matchVersion 更舊的投影，不以延遲公布資料覆寫本機已確認數字。衝突時只讀對應的私有權威場次校正，不下載整場。
6. 正常成功時 `complete` 不再額外 GET 權威比分，由伺服器原子驗證；最後一次權威提交即可定案，公開投影仍在背景按 seq 發布。

## 已做與尚未做

- 已通過 Node 本地模擬／回歸與前端語法、原版 UI 保留檢查。未完成 Firebase Emulator、真實 iPhone/多裁判/200 觀眾效能測試。
- 此封包修改 **`index.html`、`functions/index.js`、`functions/bbx-v07-core.js`** 及測試；`viewer.html`、Rules、生命週期刪除功能、五碼功能保持原設計。
- 必須同一版部署 Cloud Functions **完整九支**（尤其 `bbxV07CommandAuthority` 和 `bbxV07GetOperation`）及 GitHub Pages `index.html`；只執行三支生命週期修復腳本不能修復比分。
- 公開發布若持續失敗，後端的 outbox 上限仍可能對新操作造成背壓；這是獨立的可靠性問題，須在線上錯誤紀錄與壓測中驗證。
