# BBX-V0.7
每場賽事 operationLock 與 publishing 分開，租期 75 秒；一般 callable 時限 60 秒。
交易期間保留小節點 listener，finally 移除。不永久監聽，不刪除別人的 token。
私人權威與收據/outbox 原子提交；公開投影非同步。
測試見 TEST_RESULTS.txt。部署保持 GitHub Pages＋Cloud Functions。
