# BBX-V0.7 鎖／互斥／公開發布全流程稽核（修訂版）

## 版本狀態
這是尚未部署的 V0.7 修訂候選包。保留正式 V1.0 HTML 與 CSS。基於前版已發生的公開發布積壓與操作鎖殘留問題重設，並非斷言已取得 V0.4 第一次錯誤的完整例外堆疊。

## 實際鎖定範圍
- `bbxV07CreateLocks/{uid}`：同帳號建立賽事的短租約。只限制該帳號名額分配與原子建立。
- `authorityBBXV07/{eventId}/operationLock`：該賽事權威寫入序號、晉級結果、outbox 與必要細分節點的原子提交。用 token 租約，逾時可接管；此鎖不跨不同 eventId。
- `authorityBBXV07/{eventId}/publishing`：該賽事唯一發布者租約。只允許發布佇列序號按序遞增，不會搶 operationLock。
- 刪除賽事必須先取得同場賽事的操作鎖與發布鎖，避免刪除期間發布舊快照重建公開節點。這是兩者唯一必須同時取得的例外，且固定先操作後發布，避免鎖取得順序相反產生死結。
- 觀眾端不加鎖，只訂閱公開增量與初始快照。

## 已完成的資料提交／公開同步路徑
1. 主辦／裁判提交操作碼、必要輸入與預期版本；Cloud Function 檢查登入身分與權限。
2. 在單場 operationLock 下讀取權威 board，驗證 expectedMatchVersion / expectedSeq，計算晉級，產生 immutable outbox。
3. 透過一次 RTDB multipath update 同時提交局部 board 更動、遞增 board/seq、publicEvents/以外的權威序號，以及 `bbxV07PublicationPending/{eventId}` 修復提示。成功後立即回應主辦；不等待觀眾發布。
4. `bbxV07PublishAuthority` 收到 seq 更新時，僅取得同場 publishing 租約，以 publishedSeq + 1 讀取 outbox；先更新必要的 events/publicEvents 投影節點，再移動 publishedSeq 並移除該筆 outbox。若重啟，在進度前進之前重送相同投影可重入。
5. 若發布失敗、鎖繁忙或背景觸發遺失，**不以無上限 trigger retry 重複請款**；durable pending index 保留。每五分鐘的 `bbxV07RepairQueue` 僅查最多 20 個最久未更新的待處理事件，再以相同的發布租約補送。修復成功只在其最新序號已追上時，透過條件交易刪除相應提示。
6. 若 outbox 缺少已承諾的序號，發出 `BBX_PUBLICATION_GAP` 錯誤、保留提示和 publishedSeq，禁止跳號與假裝成功。需要再查失落紀錄，而不是跳過增量資料。
7. 主辦「關閉觀看」和權威更新在同一次提交立即變更兩個 gate；對 V0.7 賽事，Firebase Rules 更以權威 board 的 publicOpen、publicUntil 作為最終公開讀取判定。較舊待發佈操作不能重新授予觀看權限。

## 已發現且修正的實際缺陷
- **多裁判串行耗時**：原實作取得賽事操作鎖後才讀整份 board／計算晉級；現改為先並行計算再短暫鎖定版本核對與原子提交；不新增裁判鎖，也不讓兩位裁判接手同場。
- **重排後 matchVersion 歸零的誤接手**：新增 `structureVersion`，並於原子提交立即鏡射事件版本；舊畫面送出的結構版本不符一律拒絕。
- **公開開關重播競態**：舊 outbox 在「重新開放」後可能回放較早的關閉，或在關閉後回放較早的開放；現改為開／關皆與權威原子提交，背景發布完全不改 gate。
- 原來只靠獨立發布租約，但 onValueWritten `retry:true` 在持續異常時可能反覆執行：已改成持久佇列＋有界定時修復，並加入有意義的結構化錯誤紀錄。
- 發布 `outbox` 缺序號時原本只是結束循環：現在會明確報錯而不跳號。
- 新版已改為背景 outbox **完全不碰**公開開關與結構版本；權威提交時直接更新真實 gate，Firebase Rules 同時參照權威 board，降低投影競態的風險。
- 定時修復只能刪除等於或低於已發布序號的舊修復提示，不能刪掉另一支函數新增的待處理操作。

## 保守限制與必要雲端驗證
- 同一賽事仍保留一把短時間 `operationLock`，因為 `seq`、晉級依賴及 outbox 需要**單一提交順序**。這不是每個資料節點一把鎖，否則比分更新和晉級會有跨節點競爭；不同賽事完全獨立。
- 每次裁判操作仍至少讀一次權威 board；發生多人版本競爭時可能重新讀取，因此**在高競爭時可能增加後端讀取量**，換取更短的鎖佔用時間。讀與運算可並行、寫入序號仍短暫序列化，不宣稱零等待、零成本，亦不把本地模擬耗時當成雲端性能數據。
- 預檢在 Cloud Shell 必須通過 Firebase Emulator 權限測試；本地 Node 測試不能替代真正的 RTDB 並行／Eventarc 執行、Cloud Scheduler 啟用、iOS 多人連線、費用稽核。
- 新增 1 支 `bbxV07RepairQueue` 定時函數（共 9 支 V0.7 Functions），每五分鐘查一次至多 20 筆待處理索引，不會每五分鐘讀整張賽事。仍有少量固定的雲端排程費用與讀取量。
- 並未在這個候選 ZIP 內自動變動線上 V0.4，亦不會清除線上既有賽事資料。V0.4 的首次發布例外原始堆疊尚未取得，不能宣稱原始錯誤已唯一定位。
