# BBX-V0.7

賽程表修正版，來源 BBX-V0.6(1).zip；不是線上報名系統。
修正：小節點交易監聽生命週期與鎖釋放、比分佇列版本、失敗比分回復、實際錯誤提示、刪除與第一筆操作競態。
保留 V0.1～V0.6 清理路徑、永久清理登記及五碼別名；新增 V0.7 私有命名空間。

## 發布方式
1. 將 BBX-V0.7.zip 上傳 GitHub rkomrz/Beyblade-X main 根目錄。
2. Cloud Shell 下載解壓後執行 bash BBX-V0.7/00_start.sh。Node 22，固定 tmux bbx-v07-release。
3. 自動測試通過後部署 ljt-beyblade-x 的九支 bbxV07* Functions，合併並部署 Rules，精確退役九支 bbxV06*。
4. 後端成功後，把本包 index.html 與 viewer.html 覆蓋 GitHub Pages 根目錄同名檔案。
ZIP 上傳不會自動更新網頁。網站仍是 https://rkomrz.github.io/Beyblade-X/ 。
本包不部署 Firebase Hosting、不更改網域、不清空資料庫、不觸碰報名系統。

## 版本隔離與驗收
版本 BBX-V0.7、API bbxV07*、權威 authorityBBXV07、建立鎖 bbxV07CreateLocks、修復索引 bbxV07PublicationPending。
既有活動不遷移；舊版不能用新版操作記分，請新建 V0.7 測試賽事。合法建立者仍可使用跨版本清理。
核對 TEST_RESULTS.txt；模擬器不能取代真實手機、正式 IAM、Eventarc 與 Scheduler 驗收。
