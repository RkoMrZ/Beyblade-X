#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: deployment already running'; exit 3; }
[ ! -e .release-started ] || { echo 'STOP: deployment previously started. Inspect release.log before retry.'; exit 3; }
exec > >(tee -a release.log) 2>&1
bash deploy/BBX-V0.7-檢查.sh
(set -o noclobber; date -u > .release-started)
bash deploy/BBX-V0.7-Cloud-Functions.sh
date -u > .release-completed
echo 'BACKEND_RELEASE_COMPLETED: Update GitHub Pages index.html and viewer.html from this ZIP. Hosting was NOT deployed.'
