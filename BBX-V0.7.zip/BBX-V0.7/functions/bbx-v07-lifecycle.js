'use strict';
// V0.6 lifecycle foundation: immutable internal eventId is the ONLY deletion key.
// Five-character code is an alias. Never group event data by short code or releaseTag.
const crypto=require('node:crypto');
const D=require('./bbx-v07-cleanup');
const ALPHABET='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const CODE=/^[A-HJ-NP-Z2-9]{5}$/;
const EVENT=/^[A-Za-z0-9_-]{6,100}$/;
const UID=/^[^.#$\[\]/\x00-\x1F\x7F]{1,128}$/;
const STRUCTURE_VERSION=1;
function shortCode(uid,eventId,attempt=0){
 if(!UID.test(uid)||!EVENT.test(eventId)||!Number.isSafeInteger(attempt)||attempt<0)throw Error('invalid public code identity');
 const bytes=crypto.createHash('sha256').update(`BBX-code-v1:${uid}:${eventId}:${attempt}`).digest();
 let n=bytes.readUInt32BE(0);
 let out='';for(let i=0;i<5;i++){out=ALPHABET[n%ALPHABET.length]+out;n=Math.floor(n/ALPHABET.length)}
 return out;
}
const validCode=c=>CODE.test(c||'');
const roots=Object.freeze([...D.EVENT_ROOTS]);
// Historical structural inventory is cumulative. New releases must ADD roots,
// never silently remove a root from this list.
function defaultPaths(eventId){
 if(!EVENT.test(eventId||''))throw Error('invalid eventId');
 return roots.map(root=>root+'/'+eventId);
}
function validatePath(path,eventId,ownerUid,code){
 if(typeof path!=='string'||path.length>250||path.includes('//'))throw Error('unsafe path');
 if(defaultPaths(eventId).includes(path))return path;
 if(UID.test(ownerUid||'')&&/^userEvents\/[^/]+\/[012]$/.test(path)&&path.startsWith(`userEvents/${ownerUid}/`))return path;
 if(validCode(code)&&path===`bbxPublicCodeLookup/${code}`)return path;
 throw Error('non-event cleanup path: '+path);
}
function registry({eventId,ownerUid,originVersion,code=null,slot,createdAt=Date.now(),actualRoots=[],extra=[]}){
 if(!EVENT.test(eventId||'')||!UID.test(ownerUid||'')||typeof originVersion!=='string')throw Error('invalid event registry identity');
 const paths=actualRoots.map(root=>{if(!roots.includes(root))throw Error('unknown historical root');return root+'/'+eventId});
 if(slot!==undefined&&slot!==null){if(!/^[012]$/.test(String(slot)))throw Error('invalid slot');paths.push(`userEvents/${ownerUid}/${slot}`)}
 if(code){if(!validCode(code))throw Error('invalid 5-char code');paths.push(`bbxPublicCodeLookup/${code}`)}
 paths.push(...extra);
 const locations=[...new Set(paths)].sort();
 locations.forEach(path=>validatePath(path,eventId,ownerUid,code));
 return {schema:STRUCTURE_VERSION,eventId,ownerUid,originVersion,releases:[originVersion],publicCode:code||null,
   locations,status:'active',createdAt};
}
function mergeRegistered(old,next){
 if(!old)return next;
 if((old.status!=='active'&&old.status!=='deleting')||old.eventId!==next.eventId||old.ownerUid!==next.ownerUid||old.originVersion!==next.originVersion)throw Error('registry identity or lifecycle mismatch');
 const code=old.publicCode||next.publicCode;
 if(old.publicCode&&next.publicCode&&old.publicCode!==next.publicCode)throw Error('publicCode cannot change');
 const releaseList=x=>Array.isArray(x)?x:Object.entries(x||{}).filter(([,v])=>v===true).map(([k])=>k);
 const versions=[...new Set([...releaseList(old.releases),...releaseList(next.releases),old.originVersion,next.originVersion])].sort();
 if(versions.some(v=>typeof v!=='string'||!/^[A-Za-z0-9_.-]{1,30}$/.test(v)))throw Error('invalid release label');
 const loc=[...new Set([...(old.locations||[]),...(next.locations||[])])].sort();
 loc.forEach(path=>validatePath(path,old.eventId,old.ownerUid,code));
 return {...old,publicCode:code,locations:loc,releases:versions,status:'active'};
}
function deletionPaths(record,eventId,uid,slots){
 if(record&&(record.eventId!==eventId||record.ownerUid!==uid||record.status==='deleted'))throw Error('registry event owner mismatch');
 const code=record?.publicCode||null;
 const locations=[...defaultPaths(eventId),...(record?.locations||[]),...D.buildCleanupPaths(eventId,uid,slots)];
 // User slots may already have been reassigned after interrupted deletion.
 // Never remove a slot belonging to a DIFFERENT tournament.
 const safe=locations.filter(path=>!path.startsWith(`userEvents/${uid}/`)||
    String(slots?.[path.slice(`userEvents/${uid}/`.length)]||'')===eventId);
 return [...new Set(safe.map(path=>validatePath(path,eventId,uid,code)))].sort();
}
module.exports={ALPHABET,shortCode,validCode,defaultPaths,validatePath,registry,mergeRegistered,deletionPaths,STRUCTURE_VERSION};
