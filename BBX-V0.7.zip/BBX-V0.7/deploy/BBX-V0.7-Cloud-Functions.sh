#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ "$(basename "$ROOT")" == BBX-V0.7 ]] || { echo 'STOP: wrong release folder'; exit 2; }
python3 - <<'PYINNER'
import json
m=json.load(open('MANIFEST.json'))
assert m['project_id']=='BBX-V0.7' and m['firebase_project']=='ljt-beyblade-x'
assert len(m['functions_exports'])==9
assert all(name.startswith('bbxV07') for name in m['functions_exports'])
PYINNER
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v07-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: tests and Firebase Emulator not passed for this exact ZIP'; exit 3; }
for c in gcloud firebase node npm python3; do command -v "$c" >/dev/null || { echo "STOP: missing $c"; exit 3; }; done
[[ "$(node -p 'process.versions.node.split(".")[0]')" == 22 ]] || { echo 'STOP: Node 22 required'; exit 3; }
if ! gcloud auth print-access-token >/dev/null 2>&1; then
 mapfile -t A < <(gcloud auth list --format='value(account)' | sed '/^$/d')
 [[ ${#A[@]} == 1 ]] || { echo 'STOP: gcloud auth login required'; exit 3; }
 gcloud config set account "${A[0]}" --quiet
fi
gcloud auth print-access-token >/dev/null
P=ljt-beyblade-x
DB=ljt-beyblade-x-default-rtdb
gcloud config set project "$P" --quiet
[[ "$(python3 -c 'import json;print(json.load(open(".firebaserc"))["projects"]["default"])')" == "$P" ]] || { echo 'STOP: wrong Firebase project'; exit 3; }
echo '=== Deploy BBX-V0.7 new Functions ==='
npm --prefix functions install --no-audit --no-fund
FN='functions:bbxV07CreateAuthority,functions:bbxV07CommandAuthority,functions:bbxV07GetOperation,functions:bbxV07RepairPublication,functions:bbxV07PublishAuthority,functions:bbxV07OrganizerAuthority,functions:bbxV07DeleteAuthority,functions:bbxV07RepairQueue,functions:bbxV07AssignPublicCode'
firebase deploy --only "$FN" --project "$P" --non-interactive --force
gcloud functions list --regions=asia-southeast1 --project "$P" --format=json > /tmp/bbx-v07-functions.json
python3 - <<'PYINNER'
import json
m=json.load(open('MANIFEST.json'))
a=json.load(open('/tmp/bbx-v07-functions.json'))
names={str(f['name']).split('/')[-1] for f in a}
assert set(m['functions_exports']).issubset(names),f'Missing V0.7: {set(m["functions_exports"])-names}'
print('PASS: all 9 V0.7 Functions deployed')
PYINNER
echo '=== Merge existing Rules and deploy V0.7 ==='
TOKEN="$(gcloud auth print-access-token)"
RULES_URL="https://${DB}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
curl -fLsS --retry 3 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v07-before-rules.json
python3 deploy/merge-rules.py /tmp/bbx-v07-before-rules.json database.deploy.rules.json
python3 - <<'CONFIG'
import json
x=json.load(open('firebase.json'));x['database']['rules']='database.deploy.rules.json'
json.dump(x,open('firebase.deploy.json','w'))
CONFIG
firebase deploy --only database --config firebase.deploy.json --project "$P" --non-interactive
TOKEN="$(gcloud auth print-access-token)"
RULES_URL="https://${DB}.asia-southeast1.firebasedatabase.app/.settings/rules.json"
curl -fLsS --retry 3 -H "Authorization: Bearer $TOKEN" "$RULES_URL" -o /tmp/bbx-v07-online-rules.json
python3 - <<'PYINNER'
import json
from pathlib import Path
def read(p):
 x=json.loads(Path(p).read_text());return json.loads(x) if isinstance(x,str) else x
assert read('database.deploy.rules.json')==read('/tmp/bbx-v07-online-rules.json'),'online Rules differ'
print('PASS: online V0.7 Rules verified')
PYINNER
# Retire ONLY known V0.6 functions, after V0.7 and Rules are confirmed working.
python3 - <<'PYINNER'
import json,subprocess
m=json.load(open('MANIFEST.json'))
old=m['previous_function_exports']
assert all(n.startswith('bbxV06') for n in old)
actual=json.loads(subprocess.check_output(['gcloud','functions','list','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=json'],text=True))
found={x['name'].split('/')[-1] for x in actual}
for fn in old:
 if fn in found:
  print('Retiring old function:',fn,flush=True)
  subprocess.run(['gcloud','functions','delete',fn,'--region=asia-southeast1','--project=ljt-beyblade-x','--quiet'],check=True)
actual=json.loads(subprocess.check_output(['gcloud','functions','list','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=json'],text=True))
found={x['name'].split('/')[-1] for x in actual}
want=set(m['functions_exports'])
assert want.issubset(found) and not (set(old)&found),f'Missing new / remaining retired: {sorted((want-found)|(set(old)&found))}'
print('PASS: V0.7 functions present, V0.6 retired; unrelated functions preserved')
PYINNER
printf '
PASS: BBX-V0.7 Functions (9) + Rules deployed and verified. Update GitHub Pages index.html and viewer.html from this SAME ZIP.
'
