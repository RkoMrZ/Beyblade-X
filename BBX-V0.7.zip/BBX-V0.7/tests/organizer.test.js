'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Org=require('../functions/bbx-v07-organizer');
const Core=require('../functions/bbx-v07-core');
const NOW=Date.now();let i=0;
const id=()=>{i++;return NOW.toString(16).padStart(12,'0')+i.toString(16).padStart(36,'0')};
const names=['A','B','C','D','E','F','G','H'];
function initial(){const {rounds,finalRR}=Org.build(names,'single','champ');return {ownerUid:'boss',roster:[...names],mode:'single',freeFinal:'champ',pairing:'ordered',rounds,finalRR,seq:0,receipts:{},outbox:{}}}
function exec(raw,action,props={},user='boss'){return Org.apply(raw,user,{opId:id(),expectedSeq:raw.seq,action,...props},NOW,{admin:user==='mod'})}
test('server generates 8-player original single-elimination structure',()=>{const b=initial();assert.equal(b.rounds.length,3);assert.equal(b.rounds[0].matches.length,4);assert.equal(b.rounds[2].placementFinal,true)});
test('rename only changes specific participant and increments match version',()=>{const before=initial(),out=exec(before,'rename',{index:0,value:'A2'});assert.equal(out.board.roster[0],'A2');assert.equal(out.board.rounds[0].matches[0].a,'A2');assert.equal(out.board.rounds[0].matches[0].matchVersion,1);assert.equal(before.roster[0],'A');assert(out.changes.some(x=>x.path==='rounds'&&x.structure===true));assert(out.changes.some(x=>x.path==='roster'&&x.publicPath==='meta/roster'))});
test('stale organizer seq is rejected',()=>{const a=initial();assert.throws(()=>Org.apply(a,'boss',{opId:id(),expectedSeq:99,action:'rebuild'},NOW,{}),/重新載入/)});
test('different actor cannot edit without co-admin',()=>assert.throws(()=>exec(initial(),'rename',{index:0,value:'Z'},'intruder'),/主辦/));
test('co-admin can edit organizer roster',()=>assert.equal(exec(initial(),'rename',{index:0,value:'Z'},'mod').board.roster[0],'Z'));
test('reject duplicate names and reserved keywords',()=>{assert.throws(()=>exec(initial(),'rename',{index:0,value:'B'}),/重複/);assert.throws(()=>exec(initial(),'rename',{index:0,value:'BYE'}),/無效/)});
test('add and remove player on unstarted bracket regenerates rounds',()=>{const added=exec(initial(),'addPlayer',{value:'I'});assert.equal(added.board.roster.length,9);const deleted=exec(added.board,'delPlayer',{index:8});assert.equal(deleted.board.roster.length,8)});
test('no rebuilding after one match is scored',()=>{const b=initial();b.rounds[0].matches[0].sa=1;assert.throws(()=>exec(b,'rebuild'),/已開始/);assert.throws(()=>exec(b,'addPlayer',{value:'Z'}),/已開始/)});
test('swap first-round players keeps new pairing after whole bracket rebuilt',()=>{const b=initial();const out=exec(b,'swapPlayers',{ri:0,i:0,j:2});assert.equal(out.board.rounds[0].matches[0].a,'C');assert.equal(out.board.rounds[0].matches[1].a,'A');assert.equal(out.board.roster[0],'A')});
test('replay with same opId is idempotent even if original seq no longer current',()=>{const b=initial(),op=id(),req={opId:op,action:'rename',expectedSeq:0,index:0,value:'Z'};const out=Org.apply(b,'boss',req,NOW,{});const second=Org.apply(out.board,'boss',req,NOW,{});assert.deepEqual(second.receipt,out.result)});
test('never accepts browser-supplied board snapshot in organizer requests',()=>{const b=initial();const out=Org.apply(b,'boss',{opId:id(),action:'rename',expectedSeq:0,index:0,value:'Z',rounds:[{matches:[{winner:'EVIL'}]}],roster:['EVIL']},NOW,{});assert.equal(out.board.rounds[0].matches[0].a,'Z');assert.notEqual(out.board.roster[0],'EVIL')});
test('public structural projection strips referee lock/UID fields',()=>{const b=initial();b.rounds[0].matches[0].claimUid='secret';const out=exec(b,'rename',{index:0,value:'Z'});const pub=out.changes.find(x=>x.path==='rounds').publicValue;assert(!JSON.stringify(pub).includes('secret'))});
test('randomization preserves roster membership',()=>{const b=initial(),out=exec(b,'randomRebuild');assert.deepEqual([...out.board.roster].sort(),names.slice().sort())});
test('renaming a previously completed match updates preserved public review snapshot',()=>{const b=initial();const m=b.rounds[0].matches[0];m.sa=4;m.sb=1;m.winner='A';m.reviewPublished={a:'A',b:'B',sa:4,sb:1,winner:'A'};const out=exec(b,'rename',{index:0,value:'Z'});assert.equal(out.board.rounds[0].matches[0].reviewPublished.winner,'Z');const pub=out.changes.find(x=>x.path==='rounds').publicValue;assert.equal(pub[0].matches[0].winner,'Z')});
test('reject roster edits once a referee has claimed a match',()=>{const b=initial();b.rounds[0].matches[0].refereeActive=true;assert.throws(()=>exec(b,'addPlayer',{value:'I'}),/已開始/)});

test('owner closes public link with only public metadata changes',()=>{
 const b=initial(); b.publicOpen=true;b.publicUntil=NOW+3600000;
 const out=exec(b,'closePublic');
 assert.equal(out.board.publicOpen,false);
 assert.equal(out.board.publicUntil,NOW);
 assert.equal(out.result.publicOpen,false);
 assert.deepEqual(out.changes.map(x=>x.path).sort(),['publicOpen','publicUntil']);
 assert.deepEqual(out.changes.map(x=>x.publicPath).sort(),['meta/publicOpen','meta/publicUntil']);
 assert.deepEqual(out.board.rounds,b.rounds);
});
test('closing public link is owner-only even for co-admin',()=>{
 const b=initial();b.publicOpen=true;b.publicUntil=NOW+20000;
 assert.throws(()=>exec(b,'closePublic',{},'mod'),/建立者/);
});
test('owner can extend an expired or closed public link with SERVER clock',()=>{
 const b=initial();b.publicOpen=false;b.publicUntil=NOW-1000;
 const out=exec(b,'extendPublic',{publicUntil:NOW+365*86400000,publicOpen:false});
 assert.equal(out.board.publicOpen,true);
 assert.equal(out.board.publicUntil,NOW+4*60*60*1000);
 assert.equal(out.result.publicUntil,NOW+4*60*60*1000);
 assert.equal(out.changes.length,2);
});
test('public link extension rejects stale seq and non-owner',()=>{
 const b=initial();b.publicOpen=false;b.publicUntil=NOW-1000;
 assert.throws(()=>Org.apply(b,'boss',{opId:id(),action:'extendPublic',expectedSeq:9},NOW,{}),/重新載入/);
 assert.throws(()=>exec(b,'extendPublic',{},'mod'),/建立者/);
});
test('public close operation supports safe idempotent replay',()=>{
 const b=initial();b.publicOpen=true;b.publicUntil=NOW+50000;
 const op=id(),req={opId:op,action:'closePublic',expectedSeq:0};
 const first=Org.apply(b,'boss',req,NOW,{});
 const second=Org.apply(first.board,'boss',req,NOW,{});
 assert.deepEqual(second.receipt,first.result);
 assert.equal(first.board.seq,1);
});
