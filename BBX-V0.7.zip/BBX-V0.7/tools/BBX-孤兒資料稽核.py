#!/usr/bin/env python3
"""BBX Realtime Database historical orphan auditor. Dry-run by default.

No orphan is removed based on a 5-char code, a guessed owner, or an absent
/events record alone. --apply requires root-level authority owner evidence or
an immutable server-side event registry plus explicit confirmation.
"""
import argparse,subprocess,urllib.request,urllib.error,urllib.parse,json,time,hashlib,sys
from pathlib import Path

ROOTS=['admins','authorityBBX','authorityBBXV04','authorityBBXV07',
       'publicEvents','secrets','refereeClaims','refereeUsers','refereeSecrets',
       'bbxV07PublicationPending']
DB='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app'

def reader(args):
    if args.fixture:
        obj=json.loads(Path(args.fixture).read_text())
        def read(path,shallow=False):
            v=obj
            for k in path.strip('/').split('/'):
                if not k: continue
                v=v.get(k) if isinstance(v,dict) else None
            return {key:True for key in v} if shallow and isinstance(v,dict) else v
        return read, None
    token=subprocess.check_output(['gcloud','auth','print-access-token'],text=True,stderr=subprocess.DEVNULL).strip()
    def read(path,shallow=False):
        url=DB+'/'+urllib.parse.quote(path,safe='/')+'.json'
        if shallow:url+='?shallow=true'
        req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token})
        with urllib.request.urlopen(req,timeout=25) as response:return json.load(response)
    return read,token

def write_null(path,token):
    req=urllib.request.Request(DB+'/'+urllib.parse.quote(path,safe='/')+'.json',method='DELETE',headers={'Authorization':'Bearer '+token})
    with urllib.request.urlopen(req,timeout=25) as response:
        result=response.read().decode().strip()
        if result not in ('','null'):raise RuntimeError('Unexpected response to delete')

def main():
    a=argparse.ArgumentParser(description='BBX orphan and expired create-lock audit; no write by default')
    a.add_argument('--fixture',help='offline test JSON, always dry-run')
    a.add_argument('--show-ids',action='store_true',help='show event IDs for manual audit')
    a.add_argument('--event-id',help='specific orphan event id to examine')
    a.add_argument('--owner-uid',help='trusted original creator UID from retained authority or registry')
    a.add_argument('--approve-id',help='exact event ID typed again as explicit confirmation')
    a.add_argument('--origin-version',help='verified historical test release tag, required if no permanent registry')
    a.add_argument('--apply',action='store_true',help='restricted orphan cleanup; requires author evidence')
    args=a.parse_args()
    if args.fixture and args.apply:raise SystemExit('STOP: fixture mode is read-only')
    read,token=reader(args)
    current=set(read('events',True) or {})
    perroot={r:set(read(r,True) or {}) for r in ROOTS}
    event_candidates=set().union(*perroot.values())-current
    ledger=set(read('bbxEventCleanupRegistry',True) or {})
    def masked(e):return e if args.show_ids or e==args.event_id else e[:4]+'…'+hashlib.sha256(e.encode()).hexdigest()[:6]
    print('=== BBX 全庫孤兒資料稽核（預設只讀取）===')
    print('活躍主檔：',len(current),'孤兒候選賽事 ID 數：',len(event_candidates))
    for r in ROOTS:
        print(r,'總紀錄：',len(perroot[r]),'缺主檔候選：',len(perroot[r]-current))
    for e in sorted(event_candidates):
        if args.event_id and e!=args.event_id:continue
        record=read('bbxEventCleanupRegistry/'+e) if e in ledger else None
        evid=[]
        if isinstance(record,dict) and record.get('ownerUid'):evid.append('registry:'+str(record.get('status')))
        found_owner=[]
        for root in ['authorityBBX','authorityBBXV04','authorityBBXV07']:
            if e not in perroot[root]:continue
            uid=read(f'{root}/{e}/ownerUid') or read(f'{root}/{e}/board/ownerUid')
            if uid:found_owner.append(uid);evid.append(root+':owner-present')
        if len(set(found_owner))>1:evid.append('CONFLICT:authority-owners')
        print('候選：',masked(e),'節點：',','.join(r for r in ROOTS if e in perroot[r]),'歸屬線索：',','.join(evid) or 'NONE')
    locks=read('bbxV04CreateLocks') or {}
    now=time.time()*1000
    expired=sum(isinstance(v,dict) and isinstance(v.get('until'),(int,float)) and v['until']+120000<now for v in locks.values())
    print('V0.4 已逾期超過2分鐘的建立鎖：',expired,'（帳號層級，沒有自動刪除）')
    if not args.apply:
        print('PASS：只讀盤點；無變更。歷史孤兒必須個別核對才能清理。')
        return
    e=args.event_id
    if not e or e!=args.approve_id or not args.owner_uid or not e.replace('_','').replace('-','').isalnum() or len(e)<6:
        raise SystemExit('STOP: 必須 --event-id、完全一致的 --approve-id、--owner-uid')
    if e in current:raise SystemExit('STOP: still has a live main event; use normal owner deletion')
    record=read('bbxEventCleanupRegistry/'+e)
    proofs=[]
    if isinstance(record,dict) and record.get('ownerUid')==args.owner_uid and record.get('eventId')==e and record.get('status')!='deleted':proofs.append('registry')
    for root in ['authorityBBX','authorityBBXV04','authorityBBXV07']:
        if e not in perroot[root]:continue
        uid=read(f'{root}/{e}/ownerUid') or read(f'{root}/{e}/board/ownerUid')
        if uid and uid!=args.owner_uid:raise SystemExit('STOP: conflicting private authority owner')
        if uid==args.owner_uid:proofs.append(root)
    if not proofs:raise SystemExit('STOP: no trustworthy creator evidence; leave for admin review')
    permitted=['BBX-V0.1','BBX-V0.2','BBX-V0.3','BBX-V0.4','BBX-V0.7']
    if record:
        if record.get('originVersion') not in permitted:raise SystemExit('STOP: unknown original release')
    else:
        if a.origin_version not in permitted or not e.startswith(('B1_','B2_','B3_','B4_','B7_')):
            raise SystemExit('STOP: no registry; require verified --origin-version BBX-V0.x and legacy test ID prefix')
    if e in (read('events',True) or {}):raise SystemExit('STOP: main event appeared during audit')
    # Old V0.x Functions must already be retired: no source is allowed to
    # write data back while an orphan cleanup is running.
    names=subprocess.check_output(['gcloud','functions','list','--v2','--regions=asia-southeast1','--project=ljt-beyblade-x','--format=value(name)'],text=True)
    if any(x.strip().split('/')[-1].lower().startswith(('bbxv01','bbxv02','bbxv03','bbxv04')) for x in names.splitlines()):
        raise SystemExit('STOP: retired legacy writer still deployed')
    # Does not include account slots, shared locks, or 5code indexes without registry proof.
    # Registry aliases require another explicit review, not a guess.
    if isinstance(record,dict) and record.get('publicCode'):
        raise SystemExit('STOP: code-indexed orphan must be resumed via owner DeleteAuthority or reviewed manually')
    targets=[f'{root}/{e}' for root in ROOTS if e in perroot[root]]
    if not targets:raise SystemExit('STOP: no existing event scoped data to remove')
    print('已核對原建立者，正在移除',len(targets),'個明確的賽事專屬路徑')
    # One atomic multipath root update. This cannot delete any other event ID.
    patch={path:None for path in targets}
    req=urllib.request.Request(DB+'/.json',method='PATCH',data=json.dumps(patch).encode(),
      headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=35) as response:
        if response.status not in (200,204):raise RuntimeError('Unexpected database write response')
    remnants=[path for path in targets if read(path) is not None]
    if remnants:raise SystemExit('WARNING: 殘留尚未清零 '+str(remnants))
    # Keep the smallest lifecycle tombstone, no roster or private secrets.
    tomb={'eventId':e,'ownerUid':args.owner_uid,'originVersion':(record or {}).get('originVersion') or args.origin_version,
          'schema':1,'status':'deleted','verified':True,'orphanRecovered':True,'deletedAt':int(time.time()*1000),
          'locations':targets,'publicCode':None}
    req=urllib.request.Request(DB+'/bbxEventCleanupRegistry/'+urllib.parse.quote(e,safe='')+'.json',method='PUT',
      data=json.dumps(tomb).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=25) as response:
        if response.status not in (200,204):raise RuntimeError('Tombstone write failed')
    print('PASS：明確孤兒路徑已原子清理並逐項讀回確認；未修改其他主辦索引或帳號鎖')

if __name__=='__main__':
    try:main()
    except Exception as ex:
        print('STOP:',type(ex).__name__,str(ex)[:200]);sys.exit(1)
