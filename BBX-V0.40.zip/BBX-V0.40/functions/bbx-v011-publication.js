'use strict';
// Pure, testable builder for a single public projection increment.
// No client can supply arbitrary paths: only outbox entries produced by the server.
const PRIVATE_ROOTS=new Set(['rounds','finalRR','roster','name','mode','pairing','freeFinal','publicOpen','publicUntil','raffleState','refereeNames','refereeCount','structureVersion']);
const VALID_KEY=/^[a-zA-Z0-9_-]+$/;
function validatePath(path,publicProjection=false){
 if(typeof path!=='string'||path.length>220||!path.split('/').every(p=>VALID_KEY.test(p)))throw Error('BBX_INVALID_PROJECTION_PATH');
 if(!PRIVATE_ROOTS.has(path.split('/')[0]) && !(publicProjection&&path.split('/')[0]==='meta'))throw Error('BBX_UNSUPPORTED_PROJECTION_PATH '+path);
 return path;
}
function buildProjectionPatch(eventId,item){
 if(!/^[A-Za-z0-9_-]{6,100}$/.test(eventId))throw Error('BBX_INVALID_EVENT');
 const next=Number(item?.seq);
 if(!Number.isSafeInteger(next)||next<1||!Array.isArray(item.changes))throw Error('BBX_INVALID_OUTBOX');
 const patch={};let structure=false;const matchHints={};
 for(const ch of item.changes){
  const privatePath=validatePath(ch.path);
  // The live access gate is committed atomically alongside authority writes.
  // Older asynchronous outbox entries must NEVER open, close or roll back it.
  if(privatePath==='publicOpen'||privatePath==='publicUntil'||privatePath==='structureVersion')continue;
  patch[`events/${eventId}/${privatePath}`]=ch.value===undefined?null:ch.value;
  // Same atomic patch as the actual projected private match. The reader can
  // repair a single missed match instead of mistaking another match for ack.
  const roundHint=privatePath.match(/^rounds\/(\d+)\/matches\/(\d+)$/);
  const rrHint=privatePath.match(/^finalRR\/matches\/(\d+)$/);
  // RTDB child keys cannot contain '/', so use a compact stable match ID.
  if(Number.isSafeInteger(ch.value?.matchVersion)){
   // Private notification includes the actual visible match state. Two phones
   // may have the same matchVersion but different stale referee UI; the
   // receiver must reconcile that mismatch rather than assuming it is current.
   const m=ch.value;
   const receipt={version:m.matchVersion,refereeActive:m.refereeActive===true,
    referee:String(m.referee||''),winner:m.winner||null,
    sa:m.sa??'',sb:m.sb??''};
   if(roundHint)matchHints[`r${roundHint[1]}_${roundHint[2]}`]=receipt;
   else if(rrHint)matchHints[`f${rrHint[1]}`]=receipt;
  }
  if(ch.publicChanged!==false){
   const publicPath=validatePath(ch.publicPath||ch.path,true);
   if(ch.publicValue===undefined)throw Error('BBX_MISSING_PUBLIC_VALUE '+publicPath);
   patch[`publicEvents/${eventId}/${publicPath}`]=ch.publicValue;
  }
  if(ch.structure===true||privatePath==='finalRR/players')structure=true;
 }
 if(structure){
  const t=Date.now();patch[`events/${eventId}/syncVersion`]=t;
  patch[`publicEvents/${eventId}/meta/syncVersion`]=t;
 }
 // Access rights are not projected here. The organizer's atomic write is
 // already authoritative for both open and close even while outbox is behind.
 patch[`publicEvents/${eventId}/meta/authoritySeq`]=next;
 // This private, server-owned publication watermark is committed atomically
 // with events/{id}/rounds and advancement. Clients must NOT confuse it with
 // the earlier authority command counter.
 patch[`events/${eventId}/publishedSeq`]=next;
 patch[`events/${eventId}/publishedMatchHints`]={seq:next,matches:matchHints};
 return patch;
}
module.exports={buildProjectionPatch,validatePath};
