'use strict';
// Deterministic V1.0 match authority. Never accepts a client-supplied event/round snapshot.
const crypto=require('node:crypto');
class CommandError extends Error {constructor(code,message){super(message);this.code=code;}}
const fail=(code,message)=>{throw new CommandError(code,message)};
const copy=x=>JSON.parse(JSON.stringify(x));
const sha=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const pending='待定', bye='BYE';
const opFormat=/^[a-f0-9]{48}$/;
const scoreValue=x=>x===''||x==null?0:Number(x);
const keyFor=t=>t.kind==='rr'?'finalRR/matches/'+t.mi:`rounds/${t.ri}/matches/${t.mi}`;
function validateTarget(t){
 if(!t||!['round','rr'].includes(t.kind)||!Number.isInteger(t.mi)||t.mi<0||t.mi>127||t.kind==='round'&&(!Number.isInteger(t.ri)||t.ri<0||t.ri>20))fail('invalid-argument','場次索引不正確');
}
function located(b,t){
 validateTarget(t);
 const m=t.kind==='rr'?b.finalRR?.matches?.[t.mi]:b.rounds?.[t.ri]?.matches?.[t.mi];
 if(!m)fail('not-found','該場次不存在');return m;
}
const started=m=>m?.refereeActive||!!m?.winner&&m?.a!==bye&&m?.b!==bye||scoreValue(m?.sa)>0||scoreValue(m?.sb)>0;
function byeWinner(m){if(m.a===bye&&m.b!==pending&&m.b!==bye)return m.b;if(m.b===bye&&m.a!==pending&&m.a!==bye)return m.a;return null;}
function setParticipants(m,a,b){
 a=a||pending;b=b||pending;
 if(m.a===a&&m.b===b)return;
 if(started(m))fail('failed-precondition','下一輪已有比分或裁判接手，禁止從舊晉級結果直接覆蓋');
 m.a=a;m.b=b;m.sa='';m.sb='';m.winner=byeWinner(m);m.referee='';m.refereeActive=false;m.matchVersion=(m.matchVersion||0)+1;
}
function loser(m){return m&&m.winner?(m.winner===m.a?m.b:m.winner===m.b?m.a:pending):pending;}
function propagate(b){
 const rr3=b.freeFinal==='rr3';const rounds=b.rounds||[];
 for(let ri=0;ri<rounds.length;ri++){
   const cur=rounds[ri],next=rounds[ri+1];if(!cur?.matches?.length||cur.placementFinal)break;
   if(rr3&&cur.matches.length<=3){
     const winners=cur.matches.map(m=>m.winner);
     if(winners.every(Boolean)&&winners.length===3){
       if(b.finalRR && JSON.stringify(b.finalRR.players)===JSON.stringify(winners))break;
       if(b.finalRR?.matches?.some(started))fail('failed-precondition','三人循環已開始，禁止覆蓋');
       b.finalRR={players:winners,matches:[[0,1],[1,2],[0,2]].map(([i,j])=>({a:winners[i],b:winners[j],sa:'',sb:'',winner:null,referee:'',refereeActive:false,matchVersion:0}))};
     }else if(b.finalRR){
       if(b.finalRR.matches?.some(started))fail('failed-precondition','三人循環已開始，禁止刪除');
       b.finalRR=null;
     }
     break;
   }
   if(!next){ // Original V1.0 already pre-builds rounds. If absent, let V1 create a structural round explicitly.
     if(cur.matches.length>1)fail('failed-precondition','賽程結構缺少下一輪，請主辦先修復賽程');
     break;
   }
   if(next.placementFinal){
     if(cur.matches.length!==2||next.matches?.length!==2)fail('failed-precondition','最終名次輪結構不符');
     setParticipants(next.matches[0],cur.matches[0].winner||pending,cur.matches[1].winner||pending);
     setParticipants(next.matches[1],loser(cur.matches[0]),loser(cur.matches[1]));
     break;
   }
   for(let mi=0;mi<next.matches.length;mi++){
     const a=cur.matches[mi*2]?.winner||pending;
     const b=cur.matches[mi*2+1]?(cur.matches[mi*2+1].winner||pending):bye;
     setParticipants(next.matches[mi],a,b);
   }
 }
}
function sanitizedMatch(m){return {a:m.a??pending,b:m.b??pending,sa:m.sa??'',sb:m.sb??'',winner:m.winner||null,refereeActive:m.refereeActive===true,referee:m.refereeActive===true?String(m.referee||'').slice(0,40):''};}
function getChanges(before,after){
 const changes=[];
 const max=Math.max(before.rounds?.length||0,after.rounds?.length||0);
 for(let ri=0;ri<max;ri++){
  const a=before.rounds?.[ri]?.matches||[],b=after.rounds?.[ri]?.matches||[];
  for(let mi=0;mi<Math.max(a.length,b.length);mi++) if(JSON.stringify(a[mi]??null)!==JSON.stringify(b[mi]??null)){
   const previous=a[mi]?(a[mi].reviewPublished||sanitizedMatch(a[mi])):null;
   const latest=b[mi]?(b[mi].reviewPublished||sanitizedMatch(b[mi])):null;
   changes.push({path:`rounds/${ri}/matches/${mi}`,value:b[mi]??null,publicValue:latest,publicChanged:JSON.stringify(previous)!==JSON.stringify(latest)});
  }
 }
 const a=before.finalRR,b=after.finalRR;
 if(JSON.stringify(a?.players||null)!==JSON.stringify(b?.players||null))changes.push({path:'finalRR/players',value:b?.players??null,publicValue:b?.players??null});
 for(let mi=0;mi<Math.max(a?.matches?.length||0,b?.matches?.length||0);mi++)if(JSON.stringify(a?.matches?.[mi]??null)!==JSON.stringify(b?.matches?.[mi]??null)){
   const previous=a?.matches?.[mi]?(a.matches[mi].reviewPublished||sanitizedMatch(a.matches[mi])):null;
   const latest=b?.matches?.[mi]?(b.matches[mi].reviewPublished||sanitizedMatch(b.matches[mi])):null;
   changes.push({path:`finalRR/matches/${mi}`,value:b?.matches?.[mi]??null,publicValue:latest,publicChanged:JSON.stringify(previous)!==JSON.stringify(latest)});
 }
 return changes;
}
// This pure reducer runs inside a server-owned event mutex; only changed private leaves are written.
function apply(raw,uid,req,now,permissions={}){
 if(!raw)fail('not-found','賽事尚未加入雲端權威控制');
 if(!opFormat.test(req?.opId||''))fail('invalid-argument','操作代碼格式錯誤');
 const created=parseInt(req.opId.slice(0,12),16);
 if(created>now+300000||created<now-1800000)fail('failed-precondition','操作已過期，請重新讀取最新比分');
 const action=req.action;
 if(!['claim','score','complete','release','reset','clear'].includes(action))fail('invalid-argument','操作不支援');
 const fingerprint=sha({action,target:req.target,expectedMatchVersion:req.expectedMatchVersion,expectedStructureVersion:req.expectedStructureVersion,sa:req.sa,sb:req.sb,referee:req.referee});
 const receipt=raw.receipts?.[req.opId];
 if(receipt){if(receipt.uid!==uid||receipt.hash!==fingerprint)fail('permission-denied','操作代碼已被使用');return {replay:true,receipt:receipt.result};}
 if(raw.ownerUid!==uid&&!permissions.admin&&!permissions.referee)fail('permission-denied','沒有主辦或裁判權限');
 // Public viewer expiry only controls viewer access; it must never freeze the organizer/judges.
 if(raw.deleted===true)fail('failed-precondition','賽事已刪除');
 if(!Number.isInteger(req.expectedStructureVersion)||req.expectedStructureVersion!==Number(raw.structureVersion||0))fail('aborted','籤表已由主辦重新編排，請重新讀取最新場次');
 const outboxCount=Object.keys(raw.outbox||{}).length;
 if(outboxCount>=48)fail('resource-exhausted','增量投影尚未追上，禁止累積比分變更');
 const before=copy(raw),b=copy(raw),m=located(b,req.target);
 if(!Number.isInteger(req.expectedMatchVersion)||req.expectedMatchVersion!==(m.matchVersion||0))fail('aborted','場次已由其他裝置更新，請重新同步');
 if(m.a===pending||m.b===pending||m.a===bye||m.b===bye)fail('failed-precondition','這場尚未準備好或為自動晉級');
 const who=String(req.referee||'').trim();
 if(action==='claim'){
   if(!who||who.length>40)fail('invalid-argument','裁判名稱無效');
   if(raw.ownerUid!==uid && !permissions.admin && permissions.refereeName!==who)fail('permission-denied','裁判只能使用已授權的名稱');
   if(m.refereeActive && m.referee && m.claimUid!==uid)fail('aborted','這場已有其他裁判執裁');
   // One device/uid cannot be actively claiming two matches at once.
   for(const r of b.rounds||[])for(const other of r.matches||[])if(other.claimUid===uid&&other!==m){if(other.reviewPublished){other.sa=other.reviewPublished.sa;other.sb=other.reviewPublished.sb;delete other.reviewPublished;}other.refereeActive=false;other.referee='';other.claimUid=null;other.matchVersion=(other.matchVersion||0)+1;}
   for(const other of b.finalRR?.matches||[])if(other.claimUid===uid&&other!==m){if(other.reviewPublished){other.sa=other.reviewPublished.sa;other.sb=other.reviewPublished.sb;delete other.reviewPublished;}other.refereeActive=false;other.referee='';other.claimUid=null;other.matchVersion=(other.matchVersion||0)+1;}
   m.refereeActive=true;m.referee=who;m.claimUid=uid;
 } else {
   if(!m.refereeActive||m.claimUid!==uid&&raw.ownerUid!==uid&&!permissions.admin)fail('permission-denied','請先取得該場執裁權');
   if(action==='score'||action==='complete'){
     const a=req.sa,bscore=req.sb;
     if(!Number.isInteger(a)||!Number.isInteger(bscore)||a<0||a>6||bscore<0||bscore>6||a>=4&&bscore>=4)fail('invalid-argument','比分必須是0–6，且不可雙方都達4');
     if(action==='score'){
      // Score is the ONLY command allowed to write scores. Completion must
      // never overwrite a confirmed server score with a stale browser value.
      if(m.winner&&!m.reviewPublished)m.reviewPublished=sanitizedMatch(m);
      m.sa=a;m.sb=bscore;
     }
   }
   if(action==='complete'){
      if(Number(req.sa)!==Number(m.sa)||Number(req.sb)!==Number(m.sb))
       fail('aborted','雲端比分已改變，請重新讀取最新比分再完成');
      if(Math.max(m.sa,m.sb)<4||m.sa===m.sb)fail('failed-precondition','未達4分或沒有分出勝負');
      m.winner=m.sa>m.sb?m.a:m.b;m.referee='';m.refereeActive=false;m.claimUid=null;
      delete m.reviewPublished;delete m._previousWinner;
      if(req.target.kind==='round')propagate(b);
   } else if(action==='release'){
      if(m.reviewPublished){m.sa=m.reviewPublished.sa;m.sb=m.reviewPublished.sb;delete m.reviewPublished;}
      m.referee='';m.refereeActive=false;m.claimUid=null;
   } else if(action==='reset'||action==='clear'){
      const hadWinner=!!m.winner||!!m._previousWinner;
      m.sa=0;m.sb=0;m.winner=null;delete m.reviewPublished;delete m._previousWinner;
      if(action==='clear'){m.referee='';m.refereeActive=false;m.claimUid=null;}
      if(req.target.kind==='round'&&hadWinner)propagate(b);
   }
 }
 m.matchVersion=(m.matchVersion||0)+1;
 const changes=getChanges(before,b);
 const result={ok:true,action,matchVersion:m.matchVersion,winner:m.winner||null,seq:(b.seq||0)+1};
 b.seq=result.seq;b.receipts??={};b.outbox??={};
 for(const [k,v] of Object.entries(b.receipts))if(v.at<now-2100000)delete b.receipts[k];
 b.receipts[req.opId]={uid,hash:fingerprint,result,at:now};
 b.outbox[String(b.seq).padStart(12,'0')]={seq:b.seq,changes};
 return {board:b,result,changes};
}
function bootstrap(e){
 if(!e?.id||!e.ownerUid||(!Array.isArray(e.rounds)&&!(e.mode==='free'&&e.freeFinal==='rr3'&&Array.isArray(e.finalRR?.matches))))fail('invalid-argument','原版賽事資料不完整');
 const b={ownerUid:e.ownerUid,publicOpen:e.publicOpen!==false,publicUntil:e.publicUntil,refereeNames:copy(e.refereeNames||['裁判 1']),refereeCount:Number(e.refereeCount)||1,raffleState:copy(e.raffleState||null),mode:e.mode,freeFinal:e.freeFinal,formatPolicy:e.formatPolicy||null,pairing:e.pairing||'ordered',name:e.name||'Beyblade X Tournament',roster:copy(e.roster||[]),rounds:copy(e.rounds||[]),finalRR:copy(e.finalRR||null),seq:0,structureVersion:Number(e.structureVersion)||0,receipts:{},outbox:{}};
 for(const r of b.rounds)for(const m of r.matches||[])m.matchVersion??=0;
 for(const m of b.finalRR?.matches||[])m.matchVersion??=0;
 return b;
}
module.exports={CommandError,apply,bootstrap,getChanges,sanitizedMatch,propagate};
