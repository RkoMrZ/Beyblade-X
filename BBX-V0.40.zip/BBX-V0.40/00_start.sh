#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec bash 01_release.sh
