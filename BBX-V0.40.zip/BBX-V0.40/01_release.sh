#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
exec 9>.release.lock
flock -n 9 || { echo 'STOP: V0.40 deployment already running'; exit 3; }
if [[ -f .release-completed ]];then echo 'PASS: V0.40 already deployed';exit 0;fi
exec > >(tee -a release.log) 2>&1
printf '\n=== BBX-V0.40 START %s ===\n' "$(date -u '+%FT%TZ')"
bash deploy/preflight-v040.sh
[[ "$(sha256sum MANIFEST.json | awk '{print $1}')" == "$(cat "$HOME/.bbx-v040-preflight-ok" 2>/dev/null || true)" ]] || { echo 'STOP: preflight mismatch';exit 3; }
bash deploy/hosting-v040.sh
date -u > .release-completed
printf '\nPASS: BBX-V0.40 Hosting deployed; Functions, Rules and existing events untouched.\n'
