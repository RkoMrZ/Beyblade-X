# Beyblade X BBX-V0.11：Chrome／Safari 雲端清單差異修復候選

2026-10-20；測試候選，**尚未部署／尚未在真實 iPhone 驗收**。

## 程式核對後確認的風險

1. 原 `firebase.hosting.json` 對 `/assets/**` 設定 `max-age=31536000, immutable`，但原 V0.11 多次修改仍重用 `index-v011.js` 等相同網址，可能使 Safari / Chrome 長期執行不同版本 JS，造成登入索引顯示行為不同。這是**有程式證據的快取配置缺陷**；本次差異是否全由它造成，仍需實際 UID 和資料庫核對。
2. 舊版 RTDB `userEvents/{uid}` 監聽 callback 沒有回來或遭拒絕時，首頁會把尚未取得的資料呈現得像 0/3 場，且錯誤只在 Console。當使用者遭遇 iOS 分頁回收、登入還原或讀取超時時，容易錯判賽事被刪。
3. `syncMyCloudEvents` 在主檔讀取失敗時沿用原 RAM 資料，卻不一定標記 `pendingSync`；因此原本已成功載入的舊賽事可能仍有管理按鈕。
4. ID Token 原先只依時間快取，未與 Firebase UID 綁定；跨身分快速切換時，較慢回來的舊 Token Promise 可能污染下一個登入狀態。

## 本次修正

- 所有 Hosting 靜態資源檔在新 HTML 使用內容 SHA-256 前 12 碼命名（例如 `index-v011-xxxx.js`），可安全繼續使用 `immutable`。HTML `no-cache`，資源網址內容變更即換新，避免 Safari 延用舊版。
- `userEvents/{uid}` 仍使用既有 RTDB SDK 單一即時監聽；另外在每次首頁開啟／重新訂閱約 0.9 秒後，執行**一次**帶目前 UID 的 REST 讀取核對。SDK 未回應、`permission_denied` 或空索引時不會直接聲稱真實 0；REST 失敗有最多 4 次指數退避重試（4、8、16、32 秒），背景分頁會停止，避免長期反覆下載。
- SDK/REST 索引不一致，保留 REST 證實的賽事與原有 ID，不自動回填、移除或移轉 Firebase 索引；「我的賽事」會標示異常。
- 主檔暫時 GET 失敗、`null`、索引突然空掉、背景恢復時，保存已知事件卡片但設為 `pendingSync`，防止依快取資料顯示刪除／主辦管理按鈕。登入 UID 變更後，舊 UID 的事件 RAM 清單立即清除，但不刪除任何雲端資料。
- 首頁狀態區分：登入未恢復、核對中、權限拒絕、網路／逾時、SDK/REST 不一致、核對成功 0 場、以及已知主檔待核對。雲端名額未核對時暫停「建立新賽事」（Functions 既有配額權限不變）。
- 新增可展開的「查看同步診斷」，顯示 Firebase Project、UID、Provider、索引路徑、SDK 數、REST 數、核對與錯誤狀態，不儲存比分、Token 或名單；可點「重新核對雲端」與「複製診斷資料」。
- REST token cache 綁定 UID，遲來的舊 UID token 會被拒絕。
- 不變更資料庫節點、刪除流程、裁判指令、權威比分邏輯、兩種抽籤或歷史 Functions/Rules。觀眾 `viewer` 僅更新 URL 指紋，原 SSE JS 行為不變。

## Chrome / Safari 實機對照方法

1. **兩個瀏覽器都重新進入 `https://bbxs-tamsui.web.app/`**，確認頁面已有「查看同步診斷」。舊頁先關閉再開啟，避免舊 JS 繼續執行。
2. 兩端都點「查看同步診斷」和「重新核對雲端」，稍後比較 `Firebase UID` 與 `登入 Provider`。兩者 UID 不一樣時，並不是相同 Firebase 主辦帳號，即使顯示同一暱稱也不能合併清單。
3. 兩者 UID 相同時，比較 `REST 索引數`：若 Chrome =3、Safari =3，但 SDK 一側為 0，先確認快取與 RTDB socket；若兩個 REST 結果不同，保留診斷，不要建立或刪除賽事，查 HTTP Code / 網路；若都 =0 但 Chrome 保有 3 張卡，先核對伺服器真實 `events` 和 `userEvents`，不要把卡片視為存在證據。
4. 若 `REST 索引數=3` 但沒有任何卡片，可能是事件主檔讀取權限或資料不一致，使用 **唯讀** Cloud Shell 工具 `python3 tools/BBX-賽事索引唯讀檢查.py 123` 核對五碼 L7472、EACLN、JH2BV 所指向的長 ID 是否仍有主檔與 owner slot。
5. 再測 Safari 背景停留／返回、Chrome 重新整理、切換視窗、離線／上線、三人直接循環與六人進入 RR3。只有實機都正常才可決定正式 V1.0。

## 邊界

- 本機 Node.js 回歸測試 134/134 通過；CSS/UI 靜態一致性與 Rules 合併安全檢查通過。
- 真正 Firebase Database Emulator、Cloud Shell 遠端部署、兩個瀏覽器的實際 UID / 3 場真實索引資料、以及 iPhone Safari 裁判面板觸控位置，皆需部署環境或實機再驗證。
- 此候選的 Functions 與 Rules 源碼維持 V0.11 上傳版原狀。若線上實際仍為舊版，部署腳本會先跑完整測試，再只更新目標專案的指定 9 支 V0.11 Functions、累積 Rules，最後更新 Hosting。
- 本次**沒有**登入 Firebase 生產資料庫的管理憑證；沒有讀／寫／刪生產資料。
