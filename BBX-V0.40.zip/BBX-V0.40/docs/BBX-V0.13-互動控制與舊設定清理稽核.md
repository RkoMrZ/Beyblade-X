# BBX-V0.13 按鈕／觸控座標／重複設定稽核

## 程式盤點
- `index.html`：31 處 `onclick` 標記（含基本頁面與選擇控制），`assets/index-v013.js`：70 處模板或動態 `onclick`，另有 12 處 click 監聽註冊。
- 經原始碼名稱比對，主辦／裁判端 46 個具名點擊處理函式都存在；觀眾頁 3 個具名處理函式也存在。此檢查僅驗證綁定名稱，不代表每項交易在伺服器端均成功。
- 畫面與點擊框優先關注：裁判比分、快速加分、關閉、重設、刪除確認、比分選擇、抽獎結果與籤表全螢幕。主辦、裁判、觀眾的其他動作以靜態 Handler 存在性檢查和既有 Node 回歸測試涵蓋。

## 刪除或合併
- 移除 2026 年初多次疊加的 `fixed + 100dvh`、`--app-vv-top` 與相互抵銷的 `!important` 彈窗定位設定。
- 移除裁判面板中多份重複的 `max-width:520px` / `max-height:760px` 強制縮小按鈕、底部增加 70／78px、強制最小面板高度規則。
- 刪除 Safari 專用 CSS 分支，改用單一、不區分系統的 `visualViewport.pageTop/pageLeft/width/height` 文件座標；無該 API 的瀏覽器使用 `scrollX/Y`、`innerWidth/Height`。
- 分數編輯、比分選擇、重設、刪除、抽獎、籤表全螢幕的顯示／觸控區共用相同位置來源；面板內可捲動，重要按鈕至少 44px 高。
- 保留與位置無關、仍被其他功能使用的樣式與函式，包括 disabled／hidden 狀態以及 Cloud Functions/Rules 協定名稱。絕不依 `V011` 名稱擅刪後端。

## 已完成測試
- Node.js `node --test tests/*.test.js`：143/143 通過。
- 使用本地 Chromium，在 8 種模擬螢幕規格（手機直橫、Android 手機、平板、筆電、桌面）× 2 種頁面捲動位置，針對 6 種控制區共執行 528 次按鈕中心命中及實際 tap/click 事件測試，皆通過。
- `tests/check_static.py`、`tests/check_rules_syntax.py`、`tests/check_cleanup_rules.py` 通過；Functions 與 Rules 原始檔和 V0.12 逐位元相同。

## 必須保留的實機驗收
Chromium 的 iPhone User-Agent 與觸控模擬**不是 iOS Safari 或真實 WebKit**。本地未提供 iOS WebKit、Android 真機或 Firefox/PC 多瀏覽器矩陣；不能聲稱這些已驗收。部署後須用真機 Safari、iOS Chrome、Android Chrome 及 PC Chrome/Edge/Firefox 驗證每個實際按鈕位置，尤其切背景、網址列收合與頁面捲動時。

## 部署安全
本版只允許 Hosting `bbxs-tamsui`，嚴禁修改 `ljtreg-39954`、重新部署 Functions/Rules 或刪除既有賽事。
