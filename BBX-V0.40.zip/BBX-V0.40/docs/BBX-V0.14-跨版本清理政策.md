# BBX-V0.14 跨版本清理實作規則

## 版本相容性
網站交付版本 ≠ Firebase 賽事 releaseTag：V0.12、V0.13、V0.14 前端沿用 V0.11 Cloud Functions 協定，新建賽事存 `releaseTag: BBX-V0.11`，不因網頁更新改寫舊主檔。當未來真的新增 authority namespace 時，必須先拓展 `EVENT_ROOTS`、結構目錄、Registry 寫入和整合測試，否則不得啟用該資料版本。

## 正確刪除範圍
以不可變 eventId 和可信建立者 UID 判斷；依實際 releaseTag 使用同一賽事對應權威鎖、阻斷新寫入，蒐集歷史全量 namespace + Registry 登記路徑。原子刪除後，逐項重新讀取並確認空值才可宣告成功。任何主辦索引槽已被另一賽事占用不得移除。

## 五碼與防重播
主辦已成功刪除、核對所有實際賽事根節點消失後，移除對應 `bbxPublicCodeLookup` 及 `bbxPublicCodeReservations`。日後五碼允許重用，舊 QR Code 可能開到新賽事（使用者已接受此風險）。若短碼保留已屬別場賽事，絕不覆寫或刪除。

`bbxEventCleanupRegistry/{eventId}` 在刪除途中保留完整資訊供斷線續刪；成功後縮成 `{status:'deleted',verified:true}`。因目前 CREATE `eventId = hash(uid:opId)`，這個極小標記不可隨便刪除，否則舊操作碼可能重新建立已刪賽事。建立者、選手、比分、完整路徑、短碼均不再儲存在已刪除的 Registry 項下。

## 舊墓碑
部署程式**不會**掃描或批次刪除歷史墓碑/孤兒資料。只有已通過逐項核驗，且從 `status:deleted`、`verified:true`、歷史目錄、五碼所有權等取得可信證據的殘留，才能進行獨立的安全清理。完整保留資料給無法可信判定歸屬的舊賽事；禁止僅靠 5 碼或版本號猜測刪除。

## 範圍
只部署 `bbxV011DeleteAuthority`（沿用原名稱，不改其他 Functions 的 RPC 協定）及 `bbxs-tamsui` Hosting。V0.14 不修改 RTDB Rules，不刪 live Firebase 賽事，不處理獨立報名系統。
