#!/usr/bin/env python3
"""Catch unmatched parentheses in shipped RTDB expressions before emulator startup.

This is a structural guard, NOT a replacement for the Firebase emulator compiler.
Historical snapshots are intentionally untouched.
"""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]

def check(path):
    data=json.loads(Path(path).read_text())
    errors=[]
    checked=0
    def walk(item,parts):
        nonlocal checked
        if isinstance(item,dict):
            for key,value in item.items():walk(value,parts+[key])
        elif isinstance(item,str) and parts[-1].startswith('.') and any(x in item for x in ('(',')')):
            checked+=1
            stack=[]
            quote=False
            escaped=False
            for i,c in enumerate(item):
                if c=="'" and not escaped:
                    quote=not quote
                elif not quote:
                    if c=='(':
                        stack.append(i)
                    elif c==')':
                        if stack:stack.pop()
                        else:errors.append((parts,i,'unexpected closing parenthesis'))
                escaped = c=='\\' and not escaped
            if stack:errors.append((parts,stack[-1],'missing closing parenthesis'))
            if quote:errors.append((parts,len(item),'unterminated string'))
    walk(data,[])
    if errors:
        for parts,position,message in errors:
            print('STOP:',path,'/'.join(parts),'pos',position,message)
        raise SystemExit(1)
    print('PASS: balanced RTDB Rules expressions:',checked,Path(path).name)

check(root/'database.rules.json')
