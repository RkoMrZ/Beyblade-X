const assert=require('node:assert/strict'),Module=require('node:module'),crypto=require('node:crypto');
const host=process.env.FIREBASE_DATABASE_EMULATOR_HOST;
if(!/^(127\.0\.0\.1|localhost):[0-9]+$/.test(host||''))throw Error('LOCAL EMULATOR REQUIRED');
process.env.GCLOUD_PROJECT='ljt-beyblade-x';
for(const k of ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','WS_PROXY','WSS_PROXY'])delete process.env[k];
const deps='../functions/node_modules/';
const admin=require(deps+'firebase-admin');
const old=Module._load;
Module._load=function(name,parent){
 if(parent?.filename.endsWith('/BBX-V0.15/functions/index.js')){
  if(name==='firebase-admin')return {database:()=>admin.database(),initializeApp:()=>admin.initializeApp({projectId:'demo-bbx-audit',databaseURL:'https://demo-bbx-audit-default-rtdb.firebaseio.com'})};
  if(name==='firebase-functions/v2/https')return {...old.apply(this,arguments),onCall:(_,fn)=>fn};
  if(name==='firebase-functions/v2/database')return {onValueWritten:(_,fn)=>fn};
  if(name==='firebase-functions/v2/scheduler')return {onSchedule:(_,fn)=>fn};
 }
 return old.apply(this,arguments);
};
const api=require('../functions/index');Module._load=old;
const db=admin.database();
const op=()=>Date.now().toString(16).padStart(12,'0')+crypto.randomBytes(18).toString('hex');
const invoke=(name,data,uid='owner')=>api['bbxV011'+name]({auth:{uid,token:{firebase:{sign_in_provider:'google.com'}}},data:{clientVersion:'bbx-v0.11-authority-1',...data}});
(async()=>{
 const rules=require('../database.rules.json');
 const rulesResponse=await fetch('http://'+host+'/.settings/rules.json?ns=demo-bbx-audit-default-rtdb',{method:'PUT',headers:{Authorization:'Bearer owner','Content-Type':'application/json'},body:JSON.stringify(rules)});
 assert.equal(rulesResponse.status,200);
 await db.ref().set(null);
 const probe=db.ref('auditLease');await probe.set({token:'local-proof'});
 await probe.once('value');let seen;
 const cold=await probe.transaction(cur=>{seen=cur;return cur?.token==='local-proof'?null:undefined},undefined,false);
 console.log('ORIGINAL_CAS_PROBE',JSON.stringify({callbackValue:seen,committed:cold.committed,remaining:(await probe.get()).val()}));
 await probe.remove();
 const c=await invoke('CreateAuthority',{opId:op(),name:'Local audit',roster:['A','B','C','D'],mode:'free',pairing:'ordered',freeFinal:'champ'});
 console.log('CREATE PASS',c.eventId);
 const eventId=c.eventId,target={kind:'round',ri:0,mi:0};let version=0;
 for(const [action,sa,sb] of [['claim',0,0],['score',0,3],['score',0,6],['complete',0,6]]){
  const r=await invoke('CommandAuthority',{eventId,target,opId:op(),action,sa,sb,referee:'裁判 1',expectedMatchVersion:version,expectedStructureVersion:0});version=r.matchVersion;console.log(action,'PASS',r);
  assert.equal((await db.ref('authorityBBXV011/'+eventId+'/operationLock').get()).val(),null,'operation lease must be released');
  await api.bbxV011PublishAuthority({data:{after:{exists:()=>true}},params:{eventId}});
 }
 assert.equal((await db.ref('publicEvents/'+eventId+'/rounds/0/matches/0/sb').get()).val(),6);
 console.log('PUBLICATION PASS');
 const read=await invoke('GetOperation',{eventId,readMatch:true,target});assert.equal(read.match.sb,6);
 const alias=await invoke('AssignPublicCode',{eventId});assert.ok(alias.ok);
 await invoke('OrganizerAuthority',{eventId,opId:op(),action:'closePublic',expectedSeq:4});
 await invoke('RepairPublication',{eventId});
 await api.bbxV011RepairQueue();
 assert.equal((await db.ref('bbxV011PublicationPending/'+eventId).get()).val(),null);
 assert.equal((await db.ref('authorityBBXV011/'+eventId+'/publishing').get()).val(),null);
 console.log('GET / ALIAS / ORGANIZER / REPAIR / SCHEDULE PASS');

 await invoke('DeleteAuthority',{eventId});assert.equal((await db.ref('events/'+eventId).get()).val(),null);
 console.log('DELETE PASS; productionTouched=false');
})().catch(e=>{console.error('AUDIT FAILURE',e);process.exitCode=1}).finally(()=>admin.app().delete());
