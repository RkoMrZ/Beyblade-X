 'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../assets/index-v040.js'),'utf8');
const start=src.indexOf('async function refreshRefereeClaimsNow(){');
const end=src.indexOf('\nfunction findRefereeIndexByName',start);
assert.ok(start>0 && end>start);
const code=src.slice(start,end);
test('referee tab never treats past claimsReady as proof the current claims are fresh',async()=>{
 let reads=0,renders=0;
 const ctx={console,JSON,Date,window:{__bbxSyncMetrics:{eventId:'E0',claimsReady:true}},
 cloudUnsub:()=>{},isAdmin:true,isReferee:false,refereeClaimsStreamRevision:1,currentAdminTab:'referee',
 ev:{id:'E0',refereeClaims:{}},normalizeRefereeClaims:()=>ctx.ev.refereeClaims,
 normalizeRefereeClaimsData:d=>d||{},refereeClaimsConfirmed:()=>true,confirmRefereeClaims:()=>false,rtdbRestGet:async()=>{reads++;return {'1':{uid:'u2'}}},
 $:()=>({}),renderReferee:()=>{renders++}};
 vm.createContext(ctx);vm.runInContext(code,ctx);await ctx.refreshRefereeClaimsNow();
 assert.equal(reads,1);assert.equal(ctx.ev.refereeClaims['1'].uid,'u2');assert.equal(renders,1);
 assert.equal(ctx.refereeClaimsStreamRevision,2);
});
test('an in-flight REST response never overwrites a newer claims live snapshot',async()=>{
 let release;const pending=new Promise(r=>{release=r});
 const ctx={console,JSON,Date,window:{__bbxSyncMetrics:{eventId:'E0'}},isAdmin:true,isReferee:false,
 refereeClaimsStreamRevision:3,currentAdminTab:'referee',ev:{id:'E0',refereeClaims:{'1':{uid:'live'}}},
 normalizeRefereeClaims:()=>ctx.ev.refereeClaims,normalizeRefereeClaimsData:d=>d||{},refereeClaimsConfirmed:()=>true,confirmRefereeClaims:()=>false,
 rtdbRestGet:()=>pending,$:()=>({}),renderReferee:()=>{throw new Error('stale render')}};
 vm.createContext(ctx);vm.runInContext(code,ctx);const inFlight=ctx.refreshRefereeClaimsNow();
 ctx.refereeClaimsStreamRevision=4;release({'1':{uid:'stale'}});await inFlight;
 assert.equal(ctx.ev.refereeClaims['1'].uid,'live');
});
