'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const viewer=fs.readFileSync(path.join(__dirname,'../assets/viewer-v040.js'),'utf8');
test('viewer keeps SSE and only does whole bracket render for structure changes',()=>{
 assert.match(viewer,/new EventSource\(streamUrl\(kind,id\)\)/);
 assert.match(viewer,/const rebuilt=!renderedShape\|\|shape!==renderedShape/);
 assert.match(viewer,/if\(!rebuilt\)\{/);
 assert.match(viewer,/renderedMatches\.get\(key\)===html/);
 assert.match(viewer,/card\.outerHTML=html/);
});
test('score update never resets auto scale and structure rebuild preserves scroll',()=>{
 const render=viewer.slice(viewer.indexOf('function render(){'),viewer.indexOf('// V0.22: align every round'));
 assert.doesNotMatch(render,/autoScale\(/);
 assert.match(viewer,/if\(preserveScale\)setScale\(scale\);else autoScale\(\)/);
 assert.match(viewer,/sc\.scrollLeft=scrollLeft;sc\.scrollTop=scrollTop/);
});
