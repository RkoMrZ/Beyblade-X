'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const O=require('../functions/bbx-v011-organizer');
const now=Date.now();let nonce=0;
const opId=()=>now.toString(16).padStart(12,'0')+(++nonce).toString(16).padStart(36,'0');
const match=(a,b)=>({a,b,sa:0,sb:0,winner:null,referee:'',refereeActive:false,matchVersion:0});
function board(){return {ownerUid:'ORG',seq:20,roster:['A','B','C','D','E','F'],refereeNames:['裁判 1'],refereeCount:1,
 rounds:[{matches:[match('A','B'),match('C','D'),match('E','F')]}],finalRR:null,receipts:{},outbox:{},publicOpen:true}}
function apply(b,action,extra={},who='ORG'){return O.apply(b,who,{opId:opId(),expectedSeq:b.seq,action,...extra},now,{admin:false})}
test('append is allowed after a completed match and preserves scores, winner, active judge and match lock',()=>{
 const b=board(),m=b.rounds[0].matches[0];m.sa=4;m.sb=1;m.winner='A';m.referee='裁判 1';m.refereeActive=false;m.claimUid='UID_A';m.matchVersion=16;
 const before=JSON.stringify(b.rounds),out=apply(b,'appendReferee');
 assert.deepEqual(out.board.refereeNames,['裁判 1','裁判 2']);assert.equal(out.board.refereeCount,2);
 assert.equal(out.board.seq,21);assert.equal(JSON.stringify(out.board.rounds),before);
 assert.deepEqual(out.changes.map(x=>x.path).sort(),['refereeCount','refereeNames']);
 assert.ok(out.changes.every(x=>x.publicChanged===false));
 assert.equal(b.refereeCount,1,'input board is not modified');
});
test('append preserves active judging lock on an in-progress match',()=>{
 const b=board();b.rounds[0].matches[0].refereeActive=true;
 b.rounds[0].matches[0].claimUid='UID_A';b.rounds[0].matches[0].sa=2;
 const out=apply(b,'appendReferee');
 assert.deepEqual(out.board.rounds,b.rounds);
 assert.equal(out.board.rounds[0].matches[0].refereeActive,true);
});
test('append is valid even if a three-person round robin has completed',()=>{
 const b=board();b.rounds=[];b.finalRR={players:['A','B','C'],matches:[{...match('A','B'),sa:4,sb:2,winner:'A',claimUid:'UID_A'}]};
 const out=apply(b,'appendReferee');assert.deepEqual(out.board.finalRR,b.finalRR);
});
test('name collision generates a unique server name without changing occupied slot IDs',()=>{
 const b=board();b.refereeNames=['裁判 2','裁判 3'];b.refereeCount=2;
 const out=apply(b,'appendReferee',{refereeNames:['EVIL'],value:'FAKE'});
 assert.deepEqual(out.board.refereeNames,['裁判 2','裁判 3','裁判 4']);
});
test('12 referee hard limit and malformed existing list fail without mutation',()=>{
 const b=board();b.refereeNames=Array.from({length:12},(_,i)=>'R'+i);b.refereeCount=12;
 assert.throws(()=>apply(b,'appendReferee'),/最多 12/);
 b.refereeNames=[];assert.throws(()=>apply(b,'appendReferee'),/格式不符/);
});
test('append still requires organizer privileges and current seq',()=>{
 const b=board();assert.throws(()=>apply(b,'appendReferee',{},'GUEST'),/僅主辦/);
 assert.throws(()=>O.apply(b,'ORG',{action:'appendReferee',opId:opId(),expectedSeq:b.seq-1},now,{}),/重新載入/);
});
test('append opId replay is idempotent and cannot add duplicate slot',()=>{
 const b=board(),id=opId(),req={action:'appendReferee',opId:id,expectedSeq:b.seq};
 const first=O.apply(b,'ORG',req,now,{}),again=O.apply(first.board,'ORG',req,now,{});
 assert.equal(again.replay,true);assert.deepEqual(again.receipt,first.result);
 assert.equal(first.board.refereeNames.length,2);
});
test('finished historical scores do not block released referee roster updates',()=>{
 const b=board(),m=b.rounds[0].matches[0];m.winner='A';m.sa=4;m.sb=2;m.claimUid=null;m.refereeActive=false;m.referee='';
 const prior=JSON.stringify(b.rounds),out=apply(b,'setReferees',{refereeNames:['新的裁判 1']});
 assert.deepEqual(out.board.refereeNames,['新的裁判 1']);assert.equal(JSON.stringify(out.board.rounds),prior);
});
test('active judge still prevents a referee rename/removal, even if other matches finished',()=>{
 const b=board();b.rounds[0].matches[0].winner='A';b.rounds[0].matches[0].sa=4;
 b.rounds[0].matches[1].refereeActive=true;b.rounds[0].matches[1].claimUid='UID_B';
 assert.throws(()=>apply(b,'setReferees',{refereeNames:['新裁判']}),/正在執裁/);
 b.rounds[0].matches[1].refereeActive=false;
 assert.throws(()=>apply(b,'setReferees',{refereeNames:['新裁判']}),/正在執裁/);
});
test('round-robin finished results retain all scores on referee rename',()=>{
 const b=board();b.rounds=[];b.finalRR={players:['A','B','C'],matches:[{...match('A','B'),sa:4,sb:2,winner:'A'}]};
 const saved=JSON.stringify(b.finalRR),out=apply(b,'setReferees',{refereeNames:['新裁判']});
 assert.equal(JSON.stringify(out.board.finalRR),saved);
});
test('bracket rebuild still rejects historical score even when identity edits allowed',()=>{
 const b=board();b.rounds[0].matches[0].winner='A';b.rounds[0].matches[0].sa=4;
 assert.throws(()=>apply(b,'rebuild'),/賽事已開始/);
});
test('front-end uses only appendReferee for append button, while rename and remove retain setReferees',()=>{
 const front=fs.readFileSync(path.resolve(__dirname,'../assets/index-v040.js'),'utf8');
 const add=front.slice(front.indexOf('async function addReferee(){'),front.indexOf('async function removeReferee(',front.indexOf('async function addReferee(){')));
 assert.match(add,/v1OrganizerAction\('appendReferee'\)/);
 assert.doesNotMatch(add,/v1OrganizerAction\('setReferees'/);
 assert.match(front,/v1OrganizerAction\('setReferees',\{refereeNames:nextNames\}\)/);
});
test('only full replacement runs the global claims gate; append bypasses only that gate',()=>{
 const index=fs.readFileSync(path.resolve(__dirname,'../functions/index.js'),'utf8');
 const fn=index.slice(index.indexOf('exports.bbxV011OrganizerAuthority='),index.indexOf('// Legacy V0.1-V0.3 used authorityBBX'));
 assert.match(fn,/if\(req\.data\?\.action==='setReferees'\)/);
 assert.match(fn,/O\.apply\(cur,uid,req\.data,Date\.now\(\),permission\)/);
 assert.doesNotMatch(fn,/if\(req\.data\?\.action==='appendReferee'\)[^]*?throw new HttpsError/);
});
