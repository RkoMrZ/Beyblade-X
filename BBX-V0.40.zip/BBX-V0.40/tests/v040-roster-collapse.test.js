'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/index-v040.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/index-v040.css'),'utf8');
test('V0.40 roster is initially collapsed using native details; show number in summary',()=>{
 const create=html.slice(html.indexOf('<section id="create"'),html.indexOf('<section id="admin"'));
 const match=create.match(/<details id="draftRosterDisclosure"([^>]*)>/);
 assert.ok(match,'roster details missing');
 assert.doesNotMatch(match[1],/\bopen\b/,'must be collapsed on initial load');
 assert.match(create,/<summary[^>]*>.*?id="countBadge"[^>]*>0 人.*?<\/summary>/s);
 assert.match(create,/<div id="rosterPreview" class="muted">/);
 assert.match(create,/<\/details>\s*<div class="toolbar"[^>]*>\s*<button data-create-tournament="1"/s);
 assert.match(css,/\.draftRosterDisclosure\[open\]/);
});
test('V0.40 preview updates roster and badge without rebuilding the disclosure element',()=>{
 const render=js.slice(js.indexOf('function renderRosterPreviewFromDraft(){'),js.indexOf('function updatePreview(){'));
 assert.match(render,/\$\('countBadge'\)\.textContent=draftRoster\.length\+' 人'/);
 assert.match(render,/\$\('rosterPreview'\)\.innerHTML/);
 assert.doesNotMatch(render,/draftRosterDisclosure|\.open\s*=|innerHTML\s*=.*<details/s);
 const demo=js.slice(js.indexOf('function makeDemo(){'),js.indexOf('function clearDraftRoster(){'));
 assert.match(demo,/renderRosterPreviewFromDraft\(\)/);
});
