"""Exercise authenticated private SSE initialisation, delta reconciliation, failure barrier in Chromium."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil
s=(Path(__file__).resolve().parents[1]/'assets/index-v040.js').read_text()
block=s[s.index('function listenCloudEvent(id){'):s.index('async function waitForAuthRestore(')]
fixture='''
window.$=id=>document.getElementById(id);
window.FIREBASE_CONFIG={databaseURL:'https://example.invalid'};
window.bbxSseSupported=()=>true;
window.bbxRealtimeTransport='SSE + REST';
window.bbxLifecycleEvents=[];window.bbxEnteringPrivateEvent=0;
window.cloudInitPromise=null;window.ownerIndexUnsub=null;window.cloudReady=true;
window.fbAuth={currentUser:{uid:'OWNER',providerData:[{providerId:'google.com'}]}};
window.ev={id:'EV1',authorityBBX:'active',releaseTag:'BBX-V0.11',name:'Testing',mode:'free',freeFinal:'champ',roster:['A','B','C','D'],
 rounds:[{name:'第一輪',matches:[{a:'A',b:'B',sa:0,sb:0,winner:null,refereeActive:false,matchVersion:1},{a:'C',b:'D',sa:0,sb:0,winner:null,refereeActive:false,matchVersion:1}]}],
 refereeClaims:{},publishedSeq:0,syncVersion:1,refereeNames:['裁判 1']};
window.isAdmin=true;window.isReferee=false;window.cloudListenerEpoch=0;window.cloudUnsub=null;window.cloudResyncBlocked=false;
window.cloudEventsCache={};window.liveRetryAttempts=new Map();window.refereeClaimsStreamRevision=0;
window.currentAdminTab='bracket';window.metrics=[];
window.isV1Authority=()=>true;
window.v05ScorePending=()=>false;
window.confirmRefereeClaims=()=>{};
window.normalizeRefereeClaimsData=raw=>raw||{};
window.renderAdmin=(o={})=>{metrics.push(['render',o.bracketOnly||false]);};
window.renderReferee=()=>{};window.listenPublicProjectionEvent=()=>{};
window.getRestIdToken=async()=> 'ey.test-token';
window.restPaths=[];
window.fakeMatch={a:'A',b:'B',sa:1,sb:0,winner:null,refereeActive:true,referee:'裁判 1',claimUid:'OWNER',matchVersion:2};
window.rtdbRestGet=async path=>{restPaths.push(path);
 if(path==='refereeClaims/EV1')return {'0':{uid:'OWNER'}};
 if(path==='events/EV1/rounds/0/matches/0')return {...fakeMatch};
 if(path==='events/EV1/publishedSeq')return 1;
 if(path==='events/EV1/syncVersion')return 1;
 if(path==='events/EV1')return {...ev};
 return null;
};
window.bbxLifecycleNote=()=>{};
window.FakeSSE=class{
 constructor(url){this.url=url;this.callbacks={};this.closed=false;FakeSSE.instances.push(this)}
 addEventListener(type,callback){this.callbacks[type]=callback}
 close(){this.closed=true}
 send(type,obj){if(this.callbacks[type])this.callbacks[type]({data:JSON.stringify(obj)})}
};
FakeSSE.instances=[];window.EventSource=FakeSSE;
'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 for width in [375,390,768,1366]:
  page=browser.new_page(viewport={'width':width,'height':800})
  page_errors=[];page.on('pageerror',lambda e:page_errors.append(str(e)))
  page.set_content('<div id="admin"><div class="adminTabs"></div><div id="bracketTab"></div></div>')
  page.add_script_tag(content=fixture+'\n'+block+'\nlistenCloudEvent("EV1");')
  page.wait_for_function('FakeSSE.instances.length===2')
  assert page.evaluate('FakeSSE.instances.map(s=>s.url.includes("auth=ey.test-token"))')==[True,True]
  page.evaluate('''()=>{for(const stream of FakeSSE.instances)stream.onopen();
    FakeSSE.instances[0].send('put',{path:'/',data:{seq:0,matches:{}}});
    FakeSSE.instances[1].send('put',{path:'/',data:{}});
  }''')
  page.wait_for_function('window.cloudResyncBlocked===false',timeout=6000)
  page.locator('#bbxLiveDiag summary').click()
  page.locator('#bbxLiveDiag button').click()
  diag=page.locator('#bbxLiveDiag pre').inner_text()
  assert 'SSE + REST' in diag and '已驗證' in diag and '串流 2' in diag,(width,diag)
  page.evaluate('FakeSSE.instances[0].send("put",{path:"/",data:{seq:1,matches:{r0_0:{version:2,sa:1,sb:0,refereeActive:true,referee:"裁判 1",winner:""}}}})')
  page.wait_for_function('ev.rounds[0].matches[0].sa===1',timeout=6000)
  assert page.evaluate('metrics.every(m=>m[1]===true)'),(width,'sse delta forced full renderer')
  assert page.evaluate('restPaths.filter(p=>p=== "events/EV1").length')<=1
  page.evaluate('FakeSSE.instances[0].onerror()')
  page.wait_for_function('cloudResyncBlocked===true')
  assert page.evaluate('FakeSSE.instances[0].closed && FakeSSE.instances[1].closed')
  page.evaluate('cloudUnsub()')
  assert not page_errors,(width,page_errors)
  print('PASS',width,'private SSE initial snapshot, REST match delta, local patch, error lock, cleanup')
  page.close()
 browser.close()
