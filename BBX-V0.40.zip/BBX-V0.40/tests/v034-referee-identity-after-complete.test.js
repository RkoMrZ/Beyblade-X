'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../assets/index-v040.js'),'utf8');
function segment(start,end){
  const i=source.indexOf(start),j=source.indexOf(end,i);
  assert.ok(i>=0&&j>i,`missing code: ${start} / ${end}`);
  return source.slice(i,j);
}
const claimsFunctions=segment('function refereeIdentityKey(){','function normalizeRefereeClaims(){');
const refresh=segment('async function backgroundRefreshCurrentEvent(id){','function stopMyCloudEventIndexListener(){');
const preflight=segment('async function refreshEventBeforeCriticalAction(){','async function cloudSet(');
const finish=segment('async function v1FinishCloud(kind,ri,mi){','async function v1CloudOrganizerCommand(');
function makeContext({admin=false,uid='UID-JUDGE',snapshot=true}={}){
  const old={id:'EVENT',ownerUid:admin?uid:'UID-OWNER',authorityBBX:'active',releaseTag:'BBX-V0.11',
    rounds:[{matches:[{sa:4,sb:0,matchVersion:4,winner:null,referee:'裁判 2',refereeActive:true}]}],
    refereeNames:['裁判 1','裁判 2'],refereeClaims:{'1':{uid:'UID-JUDGE',name:'裁判 2'}}};
  const server={...old,rounds:[{matches:[{...old.rounds[0].matches[0],winner:'A',referee:'',refereeActive:false,matchVersion:5}]}]};
  delete server.refereeClaims; // This field is intentionally outside events/<id>.
  const display=[];let fetchCount=0;
  const ctx={console,Date,JSON,Number,String,Promise,Error,isAdmin:admin,isReferee:!admin,ev:old,
    fbAuth:{currentUser:{uid}},cloudReady:true,cloudEventsCache:{},currentAdminTab:'bracket',
    cloudResyncBlocked:false,refereeClaimsStreamRevision:1,
    localStorage:{getItem:()=>'',removeItem:()=>{}},
    rtdbRestGet:async()=>{fetchCount++;return structuredClone(server)},
    isV1Authority:()=>true,v05ScorePending:()=>false,
    refreshAdminState:async()=>false,refreshRefereeState:async()=>true,
    renderAdmin:()=>display.push(ctx.getMyReferee()),showTab:()=>display.push(ctx.getMyReferee()),
    localEventSave:()=>{},alert(msg){throw new Error(`unexpected alert ${msg}`)},
    v05FlushScores:async()=>{},v1Match:()=>ctx.ev.rounds[0].matches[0],canCompleteMatch:()=>true,
    v1CloudMatchCommand:async()=>{ctx.ev.rounds[0].matches[0].winner='A'},
    backToBracketFromMatch:()=>{},
    backgroundSyncAlert:()=>{},
  };
  vm.createContext(ctx);
  vm.runInContext(claimsFunctions,ctx);
  vm.runInContext('confirmedRefereeClaimsContext="EVENT:UID-JUDGE"',ctx);
  vm.runInContext('function currentRefereeUid(){return fbAuth.currentUser.uid;}',ctx);
  vm.runInContext(refresh,ctx);
  vm.runInContext(preflight,ctx);
  vm.runInContext(finish,ctx);
  return {ctx,old,server,display,fetchCount:()=>fetchCount};
}
test('complete -> cloud event refresh -> next match retains actual confirmed referee claim without referee-tab visit',async()=>{
  const {ctx,display}=makeContext();
  assert.equal(ctx.getMyReferee(),'裁判 2');
  let background;
  const original=ctx.backgroundRefreshCurrentEvent;
  ctx.backgroundRefreshCurrentEvent=(id)=>background=original(id);
  await ctx.v1FinishCloud('round',0,0);
  assert.ok(background,'completion must start its background event refresh');
  await background;
  assert.equal(ctx.ev.rounds[0].matches[0].winner,'A');
  assert.equal(ctx.getMyReferee(),'裁判 2');
  assert.equal(ctx.ev.refereeClaims['1'].uid,'UID-JUDGE');
  assert.ok(display.every(name=>name==='裁判 2'),'bracket should never show missing identity during refresh');
});
test('owner acting as a claimed referee also retains claim after match completion refresh',async()=>{
  const {ctx}=makeContext({admin:true});
  // Owner and judge match the same UID for this test.
  ctx.ev.refereeClaims['1'].uid='UID-JUDGE';
  await ctx.backgroundRefreshCurrentEvent('EVENT');
  assert.equal(ctx.getMyReferee(),'裁判 2');
});
test('precritical REST refresh does not silently erase separate refereeClaims branch',async()=>{
  const {ctx}=makeContext();
  await ctx.refreshEventBeforeCriticalAction();
  assert.equal(ctx.getMyReferee(),'裁判 2');
  assert.equal(ctx.ev.refereeClaims['1'].uid,'UID-JUDGE');
});
test('event snapshots from a different event cannot import the previous event referee identity',()=>{
  const {ctx}=makeContext();
  const result=ctx.preserveLiveRefereeClaimsOnEventSnapshot({id:'DIFFERENT',rounds:[]});
  assert.equal(result.refereeClaims,undefined);
});
test('claim absent in authoritative live state stays absent, never resurrected by a stale local preference',async()=>{
  const {ctx}=makeContext();
  ctx.ev.refereeClaims={};
  await ctx.backgroundRefreshCurrentEvent('EVENT');
  assert.equal(ctx.getMyReferee(),'');
});
