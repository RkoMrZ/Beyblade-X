'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const Org=require('../functions/bbx-v011-organizer');
const Core=require('../functions/bbx-v011-core');
const roster=n=>Array.from({length:n},(_,i)=>`選手${i+1}`);
const targets=[2,3,4,6,8,12,16,24,32,48,64,96,128];
for(let n=2;n<=128;n++){
  test(`auto16 exactly ${n} entrants: correct target/BYEs, no phantom players or repechage`,()=>{
    const r=roster(n), plan=Org.deriveFormat(n);
    const target=targets.find(t=>t>=n);
    assert.equal(plan.target,target);
    assert.equal(plan.byes,target-n);
    assert.equal(plan.freeFinal,target%3===0?'rr3':'champ');
    const built=Org.build(r,'free','rr3',null,{formatPolicy:'auto16'});
    assert.ok(!JSON.stringify(built).includes('敗部復活'));
    if(n===3){assert.equal(built.rounds.length,0);assert.equal(built.finalRR.matches.length,3);return;}
    const first=built.rounds[0].matches;
    assert.equal(first.length,target/2);
    assert.equal(first.filter(m=>m.a==='BYE'||m.b==='BYE').length,target-n);
    assert.equal(first.filter(m=>m.winner!==null).length,target-n);
    assert.equal(first.filter(m=>m.a==='BYE'&&m.b==='BYE').length,0);
    const actual=first.flatMap(m=>[m.a,m.b]).filter(x=>x!=='BYE');
    assert.deepEqual(actual.sort(),r.sort());
    const b=Core.bootstrap({id:'X',ownerUid:'owner',mode:'free',formatPolicy:'auto16',freeFinal:plan.freeFinal,rounds:built.rounds,finalRR:built.finalRR,roster:r});
    assert.equal(b.formatPolicy,'auto16');
  });
}
test('40 entrants advance eight BYEs directly, then the remaining 16 winners form 24 strong',()=>{
  const r=roster(40), built=Org.build(r,'free','champ',null,{formatPolicy:'auto16'});
  assert.deepEqual(built.rounds.map(x=>x.matches.length),[24,12,6,3]);
  assert.equal(built.finalRR,null);
  assert.equal(built.rounds[0].matches.filter(m=>m.winner).length,8);
  assert.equal(built.rounds[0].matches.filter(m=>!m.winner).length,16);
  const b=Core.bootstrap({id:'X',ownerUid:'owner',mode:'free',freeFinal:'rr3',formatPolicy:'auto16',roster:r,rounds:built.rounds,finalRR:built.finalRR});
  for(const m of b.rounds[0].matches)if(!m.winner){m.sa=4;m.sb=2;m.winner=m.a;}
  Core.propagate(b);
  assert.equal(b.rounds[1].matches.filter(m=>m.a==='待定'||m.b==='待定').length,0);
  assert.equal(new Set(b.rounds[1].matches.flatMap(m=>[m.a,m.b])).size,24);
  assert.equal(b.finalRR,null);
  for(let ri=1;ri<3;ri++){
    for(const m of b.rounds[ri].matches){m.sa=4;m.sb=1;m.winner=m.a;}
    Core.propagate(b);
  }
  for(const m of b.rounds[3].matches){m.sa=4;m.sb=1;m.winner=m.a;}
  Core.propagate(b);
  assert.equal(b.finalRR.players.length,3);
  assert.equal(b.finalRR.matches.length,3);
});
test('legacy free 40 and existing single 40 remain untouched by auto16 policy',()=>{
  const old=Org.build(roster(40),'free','champ');
  const single=Org.build(roster(40),'single','champ');
  assert.equal(old.rounds[0].matches.length,20);
  assert.equal(single.rounds[0].matches.length,32);
  assert.equal(old.rounds[0].matches.some(m=>m.b==='BYE'),false);
});
test('rebuild auto16 maintains policy whereas old event keeps old behavior',()=>{
  const r=roster(40), built=Org.build(r,'free','rr3',null,{formatPolicy:'auto16'});
  const b=Core.bootstrap({id:'X',ownerUid:'owner',mode:'free',freeFinal:'rr3',formatPolicy:'auto16',roster:r,rounds:built.rounds,finalRR:built.finalRR});
  const now=Date.now(),opId=now.toString(16).padStart(12,'0')+'d'.repeat(36);
  const out=Org.apply(b,'owner',{opId,action:'randomRebuild',expectedSeq:0},now,{});
  assert.equal(out.board.formatPolicy,'auto16');
  assert.equal(out.board.rounds[0].matches.length,24);
  assert.equal(out.board.rounds[0].matches.filter(m=>m.winner).length,8);
});
test('format policy rejects out-of-range sizes (not saved to Firebase)',()=>{
 for(const n of [0,1,129,300]) assert.throws(()=>Org.deriveFormat(n),/人數/);
});
