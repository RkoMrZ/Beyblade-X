# BBX-V0.40 — 建賽預覽名單預設收合

以已驗證之 BBX-V0.39 為基準，僅修改建立賽事頁面「選手名單」預覽呈現，預設收合，摘要顯示人數，點擊標題展開編輯，建立對戰表按鈕維持常駐。重新產生名單、貼上名單及修改單一名稱不會改變使用者手動選擇的展開狀態。

- Hosting-only：不更新 Functions、Database Rules、裁判權限、比分交易或觀眾 SSE。
- 保留 Firebase Auth、主辦 SSE/REST、完整歷史刪除與跨版本資料相容。
- Cloud Shell：確認 ZIP SHA-256，再執行 bash 00_start.sh；啟動腳本執行 Node.js、Emulator 和 Hosting 自動驗證。
- 尚須以 Safari/Chrome 實機確認展開、收合及建立賽事操作。
