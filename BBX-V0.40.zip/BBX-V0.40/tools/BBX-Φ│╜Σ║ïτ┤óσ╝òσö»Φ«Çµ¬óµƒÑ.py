#!/usr/bin/env python3
"""Read-only Firebase RTDB audit: identify events orphaned from their owner's userEvents slots.
Uses existing gcloud credentials; never modifies data or prints owner UID / token.
Usage: python3 tools/BBX-賽事索引唯讀檢查.py [event_name]
"""
import json,subprocess,urllib.request,urllib.parse,sys
BASE='https://ljt-beyblade-x-default-rtdb.asia-southeast1.firebasedatabase.app'
needle=sys.argv[1] if len(sys.argv)>1 else '123'
try:
 token=subprocess.check_output(['gcloud','auth','print-access-token'],stderr=subprocess.DEVNULL,text=True).strip()
 if not token: raise ValueError('empty token')
except Exception:
 raise SystemExit('STOP: Cloud Shell Google 帳號未授權；本工具未修改任何資料')

def read(path,shallow=False):
 url=BASE+'/'+urllib.parse.quote(path,safe='/')+'.json'+('?shallow=true' if shallow else '')
 req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token},method='GET')
 with urllib.request.urlopen(req,timeout=20) as r:return json.load(r)

print('=== 唯讀檢查：賽事名稱',repr(needle),'===')
try:
 ids=read('events',True) or {}
 if not isinstance(ids,dict):raise ValueError('unexpected events index')
 print('資料庫賽事主檔數量:',len(ids))
 if len(ids)>100:
  print('STOP: 超過 100 場，請使用精確事件 ID 查核以避免額外流量')
  sys.exit(1)
 found=0
 for eid in ids:
  name=read('events/'+eid+'/name')
  if name!=needle:continue
  found+=1
  uid=read('events/'+eid+'/ownerUid')
  code=read('events/'+eid+'/publicCode')
  if not uid or not isinstance(uid,str):
   print('名稱符合，但缺少 ownerUid；需人工稽核；賽事代碼:',code or '未知');continue
  slots=read('userEvents/'+uid) or {}
  linked=isinstance(slots,dict) and eid in slots.values()
  print('活動五碼:',code or '未知','| 主檔: 存在 | 主辦索引:', '存在' if linked else '缺失（需安全復原）')
 print('符合名稱的賽事數量:',found)
 if not found:print('未找到指定名稱的主檔；無法僅從首頁 0/3 推斷已刪除')
 print('=== 全程只有 GET，沒有寫入或刪除 ===')
except Exception as exc:
 print('CHECK FAILED:',type(exc).__name__,str(exc)[:240])
 sys.exit(1)
