# BBX-V0.10

賽程表完整升級套件。Firebase：`ljt-beyblade-x`（asia-southeast1）。Hosting：`bbxs-tamsui`。

## 兩種抽籤不可混淆

- **🎁 參賽者獎品抽籤**（抽籤分頁）：使用 `raffleState` 記錄勾選與中獎者，不得改動參賽者對戰分組。
- **🎲 參賽者名單抽籤重建**（參賽名單分頁）：使用主辦 `randomRebuild` 指令重建賽程，受結構版本和既有比賽結果限制，不可改動 `raffleState` 中獎名單。

## 大型電商可用的十項資料處理原則

1. **合併同資料並行 GET**：`inFlightRestReads`、`inFlightPublicReads` 僅合併執行中的讀取；完成後移除，不永久快取。
2. **最小必要欄位**：裁判按場次 / round child 監聽；發布只讀必要權威 gate 和逐筆 outbox，不重讀整場。
3. **短時間更新合併**：同場計分操作保留先後順序和原操作代碼，更新畫面合併但不能漏掉分數。
4. **靜態與動態分開**：CSS / JS 改 `assets/`，檔名含 v010 可長時間快取；HTML 不快取；賽事資料只走 Firebase。
5. **雲端唯一權威**：主辦、裁判提交操作代碼，Firebase Functions 做版本與權限檢查；觀眾資料為只讀投影。
6. **原子與版本安全**：有需要的寫入保留同場賽事操作鎖、RTDB 原子多節點更新和發布租約；沒有增加新鎖。
7. **過時回應防護**：監聽世代、matchVersion、SSE 回應序號、防止舊 GET 覆蓋較新資料。
8. **首次快照、後續增量**：各輪 match collection 監聽變更，公開頁 EventSource 以 SSE put/patch 接收增量。
9. **不連續時必要完整同步**：同步記錄缺號時觸發修復，不盲目跳號；公開頁重連與版本失序時允許單場完整快照。
10. **不引入 Redis/Kafka/自建 WebSocket/微服務**：持續使用 Firebase Hosting、Realtime Database 與 Cloud Functions。

## 短網址

- 主辦網站：`https://bbxs-tamsui.web.app/`
- 觀眾：`https://bbxs-tamsui.web.app/v/ABCDE`（ABCDE 為活動五碼）。
- 公開觀眾頁沒有「返回主辦首頁」按鈕。UI 改動不取代 Rules 和 Functions 權限控管。

## V0.10 三人循環與 Safari 恢復修正

- 自由編排選擇「最後三人循環」，名單填入 **3 人**，可直接建立 3 場循環賽（A–B、B–C、A–C），**淘汰輪數為 0**；6 人仍先打 3 場預賽再進三循環。
- 三人循環每次比分回音只重畫賽程區，不重建其他隱藏分頁，也不重啟主辦／裁判驗證碼輪詢。
- Safari 背景恢復讀取超時，不再直接清掉畫面、賽事 ID 或原 Google 身分；保留雲端資料，暫停寫入直到重新同步。
- 主辦頁即使在 Firebase 登入完成前重新整理，只要網址帶 event 就等待恢復；不把主辦頁誤降為公開觀眾頁。
- V0.9 舊賽事使用 V0.9 的計分 Functions，新建 V0.10 用 V0.10；前端相容舊賽事，舊函數暫時保留，直到沒有仍在使用的 V0.9 賽事才移除。
- 此版針對三人循環的修正是基於原始碼缺陷和本地測試；尚未取得真實 iPhone 的異常堆疊，也未線上復現該次故障。

## 手機 Cloud Shell 工作流

把 **`BBX-V0.10.zip`** 放在 GitHub 儲存庫 `rkomrz/Beyblade-X` 的 `main` 根目錄。
下載 ZIP 並核對 ZIP SHA-256 後解壓，進入 `~/BBX-V0.10` 執行 `bash 00_start.sh`。該腳本執行本地測試、Firebase Emulator、部署 9 支 V0.10 Functions、Rules，最後只部署 `bbxs-tamsui` Hosting（包含 `index.html`、`viewer.html` 和 `assets/`）。**不要再清空 Firebase，也不要部署到獨立報名專案。**

啟動成功後，`release.log` 會記錄過程，`.release-completed` 僅在三項部署後標記。若手機螢幕關閉斷線，重連後先看 `tail -n 30 ~/BBX-V0.10/release.log`，勿同時發起另一份部署。

### 驗證狀態

- 本機 JavaScript 整合與回歸測試、檔案與 Rules 離線測試由本套件建立後執行。
- **Firebase Emulator 和真實多人手機實機測試未在生成環境執行**；Cloud Shell `00_start.sh` 的前置測試通過後才會部署，正式驗收仍要做。
