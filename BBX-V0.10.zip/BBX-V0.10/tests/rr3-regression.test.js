'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const O=require('../functions/bbx-v010-organizer'),C=require('../functions/bbx-v010-core');
const uid='owner', now=1792000000000;let seq=0;
const op=()=>now.toString(16).padStart(12,'0')+(++seq).toString(16).padStart(36,'0');
function apply(b,action,mi,sa,sb){
 const req={opId:op(),action,target:{kind:'rr',ri:0,mi},expectedMatchVersion:b.finalRR.matches[mi].matchVersion,expectedStructureVersion:b.structureVersion,referee:'裁判 1',...(sa===undefined?{}:{sa,sb})};
 return C.apply(b,uid,req,now,{owner:true});
}
test('exactly 3 players start with three RR matches, without phantom knockout rounds',()=>{
 const built=O.build(['A','B','C'],'free','rr3');
 assert.equal(built.rounds.length,0);
 assert.deepEqual(built.finalRR.players,['A','B','C']);
 assert.deepEqual(built.finalRR.matches.map(m=>[m.a,m.b]),[['A','B'],['B','C'],['A','C']]);
});
test('3-player cloud first completed result leaves next matches, identities and versions intact',()=>{
 const built=O.build(['A','B','C'],'free','rr3');
 let b=C.bootstrap({id:'EVT3',ownerUid:uid,mode:'free',freeFinal:'rr3',roster:['A','B','C'],...built});
 b=apply(b,'claim',0).board;
 b=apply(b,'score',0,0,4).board;
 const result=apply(b,'complete',0,0,4);b=result.board;
 assert.equal(b.rounds.length,0);
 assert.equal(b.finalRR.matches[0].winner,'B');
 assert.equal(b.finalRR.matches[1].matchVersion,0);
 assert.equal(b.finalRR.matches[2].matchVersion,0);
 assert.equal(b.finalRR.matches[1].winner,null);
 assert.equal(b.finalRR.matches[2].winner,null);
 assert.equal(result.changes.length,1);
 assert.equal(result.changes[0].path,'finalRR/matches/0');
});
test('6-player qualifier creates RR and first RR score does not rewrite qualifiers',()=>{
 const built=O.build(['A','B','C','D','E','F'],'free','rr3');
 let b=C.bootstrap({id:'EVT6',ownerUid:uid,mode:'free',freeFinal:'rr3',roster:['A','B','C','D','E','F'],...built});
 for(let i=0;i<3;i++){
  const t={kind:'round',ri:0,mi:i};
  const put=(action,sa,sb)=>C.apply(b,uid,{opId:op(),action,target:t,expectedMatchVersion:b.rounds[0].matches[i].matchVersion,expectedStructureVersion:b.structureVersion,referee:'裁判 1',...(sa===undefined?{}:{sa,sb})},now,{owner:true});
  b=put('claim').board;b=put('score',4,1).board;b=put('complete',4,1).board;
 }
 const prev=JSON.stringify(b.rounds);
 assert.equal(b.finalRR.matches.length,3);
 b=apply(b,'claim',0).board;b=apply(b,'score',0,3,4).board;b=apply(b,'complete',0,3,4).board;
 assert.equal(JSON.stringify(b.rounds),prev);
 assert.equal(b.finalRR.matches[0].winner,b.finalRR.matches[0].b);
 assert.equal(b.finalRR.matches[1].winner,null);
});
test('private cloud refresh does not silently drop owner to viewer or wipe last visible event on temporary GET failure',()=>{
 const src=fs.readFileSync(path.join(__dirname,'../assets/index-v010.js'),'utf8');
 assert.match(src,/authenticated private read temporarily unavailable/);
 assert.doesNotMatch(src,/authenticated retry failed, fallback public read/);
 assert.match(src,/cloudResyncBlocked=true/);
 assert.match(src,/function renderAdmin\(\{bracketOnly=false\}/);
 assert.match(src,/if\(!editing\)renderAdmin\(\{bracketOnly:true\}\)/);
});
