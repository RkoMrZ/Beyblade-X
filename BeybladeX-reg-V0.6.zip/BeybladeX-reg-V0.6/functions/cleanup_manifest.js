'use strict';
// Audited historical schema registry. Adding any event-scoped collection requires
// updating this inventory and cleanup tests BEFORE deploying a new version.
// V03 is verified against the V0.3 source package; V04 against deployed V0.4.
const registry=require('./cleanup_registry.json');
const roots=Object.freeze(Object.fromEntries(Object.entries(registry.schemas).map(([v,s])=>[v,Object.freeze(s.eventRoots)])));
const LEGACY_VERSIONS=Object.freeze(Object.keys(roots).filter(v=>v!==registry.currentVersion));
function cleanupPaths(version,eid,uid,{retainEventTombstone=false,retainAllocatorTombstone=false}={}){
 if(!Object.hasOwn(roots,version)||!/^[A-Z0-9]{5}$/.test(eid)||!uid||/[.#$\[\]/]/.test(uid))throw Error('invalid cleanup target');
 const paths={};
 for(const name of roots[version]){
  if(name==='events'&&retainEventTombstone)continue;
  if(name==='alloc'&&retainAllocatorTombstone)continue;
  paths[`${name}${version}/${eid}`]=null;
 }
 paths[`${registry.schemas[version].ownerIndex}${version}/${uid}/${eid}`]=null;
 return paths;
}
// Historical deletion includes every version's operational receipts/ledger.
// The same five-letter code in a different source version is never selected.
function completeCleanupPaths(version,eid,uid){
 const paths=cleanupPaths(version,eid,uid);
 for(const root of [...registry.lifecycleRoots,...registry.cleanupReceiptRoots])paths[`${root}/${version}/${eid}`]=null;
 return paths;
}
module.exports={roots,LEGACY_VERSIONS,cleanupPaths,completeCleanupPaths,registry};
