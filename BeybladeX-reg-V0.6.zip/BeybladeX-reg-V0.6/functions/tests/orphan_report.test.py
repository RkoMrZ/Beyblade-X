from pathlib import Path
import importlib.util,json
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('orphan',root/'maintenance/orphan_report.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
registry=json.loads((root/'functions/cleanup_registry.json').read_text())
data={'privateRowsV06':{'ABCDE':{'sample':True},'ZZZZZ':{'sample':True}},
      'eventLifecycleV06':{'V06':{'ABCDE':{'ownerUid':'owner','sourceVersion':'V06','eventId':'ABCDE','state':'registered'}}},
      'unregisteredLegacy':{}}
result=module.audit(data,registry)
items={v['id']:v for v in result['candidates']}
assert items['ABCDE']['status']=='OWNER_RECOVERY_CANDIDATE'
assert items['ZZZZZ']['status']=='REVIEW_NO_PROOF'
assert result['unknownRoots']==['unregisteredLegacy']
data['eventsV06']={'ABCDE':{'ownerUid':'other'}}
assert next(v for v in module.audit(data,registry)['candidates'] if v['id']=='ABCDE')['status']=='REVIEW_CONFLICT'
assert data['privateRowsV06']['ABCDE']=={'sample':True}, 'Audit must not modify data'
print('PASS offline orphan report: ledger proof, missing proof, conflict, unknown roots, no writes')
