from browser_support import html_assets,browser_options
"""Offline Chromium test: uses in-page fake Firebase HTTPS/SSE, NEVER touches live project."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import re
E='ABCDE'
SRC=Path(__file__).resolve().parents[2]/'reg'
SEED = r'''(() => {
window.__hits=[];window.__queries=[];window.__streams=[];Object.defineProperty(window.crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(32).fill(7).buffer}});
window.__backend={meta:{title:'測試盃',eventDate:'2026-11-01',checkinTime:'09:00',startTime:'10:00',venue:'測試場地',fee:0,capacity:2,open:true,version:1},
rows:{p00000001:{signupNo:1,playerName:'第一位',phone3:'093',status:'pending',recordVersion:1},p00000002:{signupNo:2,playerName:'第二位',phone3:'123',status:'approved',recordVersion:1}},
changes:{'-chg0001':{type:'row',key:'p00000001'}},token:'v1'};
class FakeES {static CLOSED=2;constructor(url){this.url=url;this.readyState=1;this.listeners={};window.__streams.push(this);setTimeout(()=>this.onopen?.(),1)}addEventListener(type,cb){(this.listeners[type]??=[]).push(cb)}close(){this.readyState=FakeES.CLOSED}emit(type,data){(this.listeners[type]||[]).forEach(cb=>cb({data:JSON.stringify(data)}))}}window.EventSource=FakeES;
const user={uid:'tester',getIdToken:async()=> 'testtoken'};
window.initializeApp=()=>({});window.getAuth=()=>({});window.GoogleAuthProvider=class{};window.onAuthStateChanged=(auth,cb)=>setTimeout(()=>cb(user),0);window.signInWithPopup=async()=>({user});window.signOut=async()=>{};
window.fetch=async (input,opt={})=>{
 const u=new URL(String(input),'https://mock.local/'),path=u.pathname.substring(1).replace(/\.json$/,''),parts=path.split('/'),b=window.__backend;
 window.__hits.push(path);window.__queries.push({path,query:u.search});
 if(path==='regV06Submit')return new Response(JSON.stringify({result:{signupNo:3,rankLabel:'備選#1'}}),{status:200});
 let data=null;
 if(parts[0]==='eventsV06')data=b.meta;
 else if(parts[0]==='syncV06')data={token:b.token,lastChange:Object.keys(b.changes).at(-1)};
 else if(parts[0]==='changesV06')data=b.changes;
 else if(parts[0]==='publicRowsV06')data=parts[2]?b.rows[parts[2]]||null:b.rows;
 else if(parts[0]==='managerRowsV06')data=parts[2]?{lineName:'同一LINE'}:{p00000001:{lineName:'同一LINE'},p00000002:{lineName:'同一LINE'}};
 else if(parts[0]==='ownerEventsV06')data={'ABCDE':{title:'測試盃',eventDate:'2026-11-01',capacity:2}};
 else throw new Error('Unexpected path: '+path);
 return new Response(JSON.stringify(data??null),{status:200});
};
})()'''

def html(page):
 src=html_assets(SRC,page)
 if page !='index.html':src=src.replace('new URLSearchParams(location.search)',f"new URLSearchParams('?event={E}')")
 else:
  src=re.sub(r'^import .*?;\s*','',src,flags=re.M)
  src=src.replace('<script type="module">','<script>')
 return src

with sync_playwright() as pw:
 browser=pw.chromium.launch(**browser_options())
 for width in [320,390]:
  ctx=browser.new_context(viewport={'width':width,'height':800});ctx.add_init_script(SEED)
  page=ctx.new_page();page.set_content(html('status.html'))
  page.wait_for_function("document.querySelector('#rows')?.textContent.includes('第一位')")
  page.wait_for_timeout(600);page.evaluate('window.__hits.length=0')
  page.evaluate("Object.assign(__backend.rows.p00000001,{status:'approved',recordVersion:4});Object.assign(__backend.changes,{'-chg0002':{type:'review',key:'p00000001'},'-chg0003':{type:'review',key:'p00000001'},'-chg0004':{type:'review',key:'p00000001'}});__backend.token='v2';__streams.at(-1).emit('put',{path:'/',data:{token:'v2',lastChange:'-chg0004'}})")
  page.wait_for_function("document.querySelector('#rows')?.textContent.includes('已報到') && document.querySelector('#rows')?.textContent.includes('第一位')")
  page.wait_for_timeout(500)
  hits=page.evaluate('window.__hits')
  assert hits.count('publicRowsV06/'+E+'/p00000001')==1,(width,hits)
  assert hits.count('syncV06/'+E)==0,(width,hits)
  assert any(q['path']=='changesV06/'+E and 'startAt' in q['query'] for q in page.evaluate('window.__queries')),(width,page.evaluate('window.__queries'))
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
  print(f'PASS STATUS {width}px: one incremental GET for 3 same-row changes, no redundant sync GET, no overflow')
  ctx.close()
 ctx=browser.new_context(viewport={'width':390,'height':800});ctx.add_init_script(SEED);page=ctx.new_page();page.set_content(html('signup.html'))
 page.wait_for_function("!document.getElementById('entryCard').classList.contains('hide')")
 page.evaluate('window.__hits.length=0')
 page.evaluate('Promise.all([load(),load(),load()])')
 assert page.evaluate('window.__hits').count('eventsV06/'+E+'/meta')==0,'metadata resume cache should avoid repeat GET'
 page.locator('#playerName').fill('第三位');page.locator('#phone3').fill('093');page.locator('#lineName').fill('同一LINE');page.locator('#submit').click()
 page.wait_for_function("document.querySelector('#rank')?.textContent.includes('備選#1')")
 hits=page.evaluate('window.__hits')
 assert 'regV06Submit' in hits and not any('publicRowsV06' in x for x in hits),hits
 print('PASS SIGNUP: 1 callable, rank shown without public roster GET');ctx.close()
 ctx=browser.new_context(viewport={'width':390,'height':800});ctx.add_init_script(SEED);page=ctx.new_page()
 page.set_content(html('index.html'));page.wait_for_function("document.querySelector('#events')?.textContent.includes('測試盃')")
 hits=page.evaluate('window.__hits');assert not any(x.startswith('ownerEvents/') for x in hits),hits
 page.evaluate('window.__hits.length=0');page.locator('[data-manage]').click()
 page.wait_for_function("document.querySelector('#roster')?.textContent.includes('第一位')")
 page.wait_for_timeout(650)
 hits=page.evaluate('window.__hits')
 assert hits.count('publicRowsV06/'+E)==1,hits
 assert hits.count('managerRowsV06/'+E)==1,hits
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'manager overflow'
 page.locator('#search').fill('第一')
 page.evaluate("__hits.length=0;__backend.rows.p00000001.status='approved';__backend.rows.p00000001.recordVersion=2;__backend.changes['-chg0002']={type:'review',key:'p00000001'};__backend.token='v2';__streams.at(-1).emit('patch',{path:'/',data:{token:'v2',lastChange:'-chg0002'}})")
 page.wait_for_function("document.querySelector('#roster')?.textContent.includes('已報到')")
 page.wait_for_timeout(400)
 hits=page.evaluate('window.__hits')
 assert hits.count('publicRowsV06/'+E+'/p00000001')==1,hits
 assert hits.count('syncV06/'+E)==0,hits
 assert page.evaluate("document.activeElement?.id==='search' && document.getElementById('search').value==='第一'"),'search focus should be retained after delta'
 print('PASS MANAGER: no duplicate initial roster download, SSE changed row only, no previous-version request')
 ctx.close();browser.close()
