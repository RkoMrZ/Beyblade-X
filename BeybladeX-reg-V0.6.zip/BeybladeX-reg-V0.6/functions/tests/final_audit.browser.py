"""Adversarial offline browser checks; all external traffic blocked."""
from pathlib import Path
import importlib.util,json
from playwright.sync_api import sync_playwright
from browser_support import browser_options
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('fixture',Path(__file__).with_name('request_audit_browser.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
vis="Object.defineProperty(document,'visibilityState',{get:()=>window.__vis||'visible'});window.__setVisibility=s=>{window.__vis=s;document.dispatchEvent(new Event('visibilitychange'))}"
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(**browser_options());ctx=browser.new_context()
 ctx.add_init_script(fixture.JS_SEED);ctx.add_init_script(vis);ctx.route('**/*',lambda r:r.abort())
 def page():
  p=ctx.new_page();p.set_content(fixture.html(root/'reg','status.html'));p.wait_for_function('liveOnline');return p
 p=page()
 p.evaluate('''() => {const original=fetch;window.fetch=(url,opt)=>String(url).includes('/syncV06/')?new Promise((resolve,reject)=>{window.__release=()=>reject(new DOMException('aborted','AbortError'))}):original(url,opt);checkUpdate()}''')
 p.wait_for_function("typeof __release==='function'")
 p.evaluate("__setVisibility('hidden');__setVisibility('visible');__release()")
 p.wait_for_timeout(600)
 results.append({'case':'resume during an aborted delta restores SSE and watchdog','pass':p.evaluate('liveOnline && liveStream!==null && statusWatch!==null')});p.close()
 p=page()
 p.evaluate('''async () => {
  Object.assign(__backend.changes,{'-chg0002':{type:'review',key:'p00000001'},'-chg0003':{type:'review',key:'p00000002'}});__backend.token='v2';
  __backend.rows.p00000001.status='rejected';
  const original=fetch;window.fetch=async(url,opt)=>{if(String(url).includes('/p00000002.json')){await new Promise(r=>setTimeout(r,40));throw Error('injected row failure')}return original(url,opt)};
  await checkUpdate();
 }''')
 results.append({'case':'failed multi-row delta leaves prior snapshot intact','pass':p.evaluate("rows.p00000001.status==='pending' && syncToken==='v1'")});p.close()
 p=page()
 p.evaluate("window.__oldStream=liveStream;__setVisibility('hidden');__setVisibility('visible')")
 p.wait_for_function('liveOnline');p.evaluate("__oldStream.emit('cancel',null)")
 results.append({'case':'late old-stream cancellation cannot close new stream','pass':p.evaluate('liveOnline && liveStream!==null && !liveDenied')});p.close()
 # A journal tip advertised by sync must be present, otherwise resnapshot.
 p=page()
 p.evaluate("pendingHint={token:'v2',lastChange:'-missing'};__backend.rows.p00000001.status='approved';__hits.length=0")
 p.evaluate('checkUpdate()')
 results.append({'case':'missing journal tip forces a single-event snapshot','pass':p.evaluate("__hits.includes('GET publicRowsV06/ABCDE') && rows.p00000001.status==='approved'")});p.close()
 p=ctx.new_page();p.set_content(fixture.html(root/'reg','index.html'));p.wait_for_selector('[data-manage]');p.locator('[data-manage]').click();p.wait_for_function('managerOnline')
 p.evaluate("window.__oldStream=managerStream;__setVisibility('hidden');__setVisibility('visible')")
 p.wait_for_function('managerOnline');p.evaluate("__oldStream.emit('cancel',null)")
 results.append({'case':'manager old-stream cancellation cannot close new stream','pass':p.evaluate('managerOnline && managerStream!==null && !managerDenied')});p.close()
 p=ctx.new_page();p.set_content(fixture.html(root/'reg','index.html'));p.wait_for_selector('#newEvent');p.locator('#newEvent').click();p.wait_for_selector('#createForm')
 p.evaluate("""() => {const original=fetch;window.fetch=(url,opt)=>String(url).includes('regV06CreateEvent')?new Promise(resolve=>{window.__finishCreate=()=>resolve(new Response(JSON.stringify({result:{eid:'ABCDE'}})))}):original(url,opt);submitCreate({preventDefault(){},target:document.querySelector('#createForm')})}""")
 p.wait_for_function("typeof __finishCreate==='function'");p.evaluate("go('home')");p.wait_for_selector('#newEvent');p.evaluate('__finishCreate()');p.wait_for_timeout(100)
 results.append({'case':'late create result does not navigate away from a newer screen','pass':p.evaluate("mode==='home' && location.hash==='#home'")});p.close()
 ctx.close();browser.close()
print(json.dumps(results,ensure_ascii=False,indent=2))
assert all(r['pass'] for r in results), 'Final audit regression failed'
(root/'FINAL_AUDIT_TEST_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
