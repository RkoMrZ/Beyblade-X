"""Offline release gate: preserve the previous release's cleanup knowledge."""
from pathlib import Path
import json, zipfile
root=Path(__file__).resolve().parents[2]
registry=json.loads((root/'functions/cleanup_registry.json').read_text())
with zipfile.ZipFile(root/'functions/tests/audit_baseline_previous.zip') as baseline:
    names=[n for n in baseline.namelist() if n.endswith('/functions/cleanup_registry.json')]
    if names:
        assert len(names)==1
        previous=json.loads(baseline.read(names[0]))
        for version,schema in previous['schemas'].items():
            assert registry['schemas'].get(version)==schema, 'Historical schema removed/changed: '+version
        assert set(previous.get('lifecycleRoots',[])) <= set(registry.get('lifecycleRoots',[])), 'Lost lifecycle evidence roots'
        assert set(previous['cleanupReceiptRoots']) <= set(registry['cleanupReceiptRoots']), 'Lost historical retry receipt roots'
    else:
        assert registry['currentVersion']=='V06', 'Post-V06 baseline must include the permanent registry'
print('PASS permanent cleanup release gate: previous schema and retry evidence retained')
