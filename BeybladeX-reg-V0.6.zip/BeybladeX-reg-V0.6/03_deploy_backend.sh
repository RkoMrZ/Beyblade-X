#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PROJECT=ljtreg-39954
if command -v nvm >/dev/null 2>&1; then nvm use 22 || nvm install 22; fi
bash 06_source_guard.sh
node --check functions/index.js
node functions/tests/rules.static.test.js
VERSION="$(node -p "JSON.parse(require('fs').readFileSync('RELEASE_VERSION.json','utf8')).release")"
API="$(node -p "JSON.parse(require('fs').readFileSync('RELEASE_VERSION.json','utf8')).apiPrefix")"
echo "Target project: $PROJECT / release: $VERSION / functions: $API*"
echo 'DEV MODE: only the organizer is using V0.x; no maintenance page needed. Do not use any older registration version during upgrade.'
echo 'V0.6 fresh-schema release; backup is OPTIONAL by owner decision; no RTDB reset occurs in this script.'
echo 'Codebase deployment retires old registration functions if asked; confirm ONLY old registration functions.'
read -r -p "To deploy release $VERSION, type DEPLOY-$VERSION-ljtreg-39954: " answer
[ "$answer" = "DEPLOY-$VERSION-ljtreg-39954" ] || { echo CANCELLED; exit 2; }
firebase deploy --only functions:registration --project "$PROJECT"
echo 'Verifying ten new functions and NO old function names...'
FUNCTIONS="$(firebase functions:list --project "$PROJECT")" || exit 4
printf '%s\n' "$FUNCTIONS"
# Check ten expected and detect known historical endpoints; avoid printing secrets.
for suffix in CreateEvent UpdateEvent SetOpen Submit Review EditEntry DeleteEntry DeleteEvent DeleteLegacyEvent MyRank; do
  printf '%s\n' "$FUNCTIONS" | grep -Fq "${API}${suffix}" || { echo "ERROR: ${API}${suffix} is missing"; exit 4; }
done
if printf '%s\n' "$FUNCTIONS" | grep -E 'reg(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|DeleteLegacyEvent|MyRank)([[:space:]│|]|$)|reg8(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|DeleteLegacyEvent|MyRank)([[:space:]│|]|$)' >/dev/null; then
 echo 'ERROR: legacy reg8 endpoint remains; do not reset'; exit 4
fi
# Detect prior versioned functions, excluding the target API.
if printf '%s\n' "$FUNCTIONS" | grep -Eo 'regV[0-9]+(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|DeleteLegacyEvent|MyRank)' | grep -v "^${API}"; then
 echo 'ERROR: previous version functions remain; do not reset'; exit 4
fi
echo 'Now deploying version-exclusive Realtime Database Rules.'
firebase deploy --only database --project "$PROJECT"
# Permit historical cleanup only after retirement and an in-flight request drain.
READY_FILE=$(mktemp)
node -e 'console.log(Date.now()+120000)' > "$READY_FILE"
firebase database:set /registrationMaintenanceV06/legacyCleanupReadyAt "$READY_FILE" --force --project "$PROJECT" --instance ljtreg-39954-default-rtdb
rm -f "$READY_FILE"
echo 'BACKEND_READY: deploy Hosting bbxr-tamsui next. V03, V04 and V05 data remain until separately authorized per-event cleanup; V06 starts in isolated namespaces.'
