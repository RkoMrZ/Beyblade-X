#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
node -v
bash 06_source_guard.sh
PROJECT=ljtreg-39954
INSTANCE=ljtreg-39954-default-rtdb
echo '== DEPLOYED FUNCTION LIST =='
FUNCTIONS="$(firebase functions:list --project "$PROJECT")"
printf '%s\n' "$FUNCTIONS"
for suffix in CreateEvent UpdateEvent SetOpen Submit Review EditEntry DeleteEntry DeleteEvent DeleteLegacyEvent MyRank; do
 printf '%s\n' "$FUNCTIONS" | grep -Fq "regV06${suffix}" || { echo "MISSING regV06${suffix}"; exit 4; }
done
if printf '%s\n' "$FUNCTIONS" | grep -Eo 'regV[0-9]+(CreateEvent|UpdateEvent|SetOpen|Submit|Review|EditEntry|DeleteEntry|DeleteEvent|DeleteLegacyEvent|MyRank)' | grep -v '^regV06'; then echo 'Old Functions remain'; exit 4; fi
echo '== DATABASE ROOT KEY NAMES ONLY (NO PRIVATE DATA) =='
firebase database:get / --shallow --project "$PROJECT" --instance "$INSTANCE" | node -e 'let s="";process.stdin.on("data",x=>s+=x);process.stdin.on("end",()=>{const v=JSON.parse(s);console.log("ROOT NODES:",v===null?"EMPTY":Object.keys(v).join(", "))})'

python3 maintenance/verify_hosting.py
echo DEPLOY_VERIFY_PASSED
