
'use strict';
const DB='https://ljtreg-39954-default-rtdb.asia-southeast1.firebasedatabase.app',FN='https://asia-southeast1-ljtreg-39954.cloudfunctions.net/regV06Submit';
const eid=(new URLSearchParams(location.search).get('e')||new URLSearchParams(location.search).get('event')||location.pathname.match(/^\/s\/([A-Z0-9]{5})\/?$/)?.[1]||'');
const $=s=>document.getElementById(s),safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let meta=null,busy=false,loadingMeta=false,lastMetaChecked=0;
// The signup page has no persistent listener. Only abort metadata GETs on background;
// never abort a user's POST, because a server-side registration might already commit.
const signupReadPool=BBX.createReadPool(()=>!signupSleeping&&document.visibilityState==='visible');
let resumeMetaAfterAbort=false,signupSleeping=document.visibilityState!=='visible';
// A *local-browser* soft cap: different browsers, private sessions or cleared storage can bypass it.
// Keep request IDs so replays of the same successful submission never consume two slots.
const LOCAL_LIMIT=2;
function localSignups(){try{const x=JSON.parse(localStorage.getItem('reg-v06-local-signups-'+eid)||'[]');return Array.isArray(x)?x.filter(v=>/^[0-9a-f]{48}$/.test(v)).slice(0,LOCAL_LIMIT):[]}catch{return []}}
function saveLocalSignup(id){try{const a=localSignups();if(!a.includes(id)){a.push(id);localStorage.setItem('reg-v06-local-signups-'+eid,JSON.stringify(a))}}catch{}}
function localSlotsLeft(){return Math.max(0,LOCAL_LIMIT-localSignups().length)}
function updateLocalHint(){const el=$('localHint');if(el)el.textContent='本瀏覽器每場最多成功報名 '+LOCAL_LIMIT+' 次；目前剩餘 '+localSlotsLeft()+' 次。'}

function msg(t,bad=false){$('notice').className='status '+(bad?'err':'ok');$('notice').textContent=t}
async function load(){
 if(signupSleeping||document.visibilityState!=='visible')return;
 if(!/^[A-Z0-9]{5}$/.test(eid)){msg('報名連結不正確',true);return}
 // iOS can emit several resume events rapidly: one metadata request per 15s is enough.
 if(loadingMeta){resumeMetaAfterAbort=true;return}
 if(meta&&Date.now()-lastMetaChecked<15000)return;
 loadingMeta=true;
 try{
  const m=await signupReadPool.get(DB+'/eventsV06/'+eid+'/meta.json');if(!m||m.deleted)throw Error('找不到比賽或活動已刪除');
  if(signupSleeping||document.visibilityState!=='visible')return;
  meta=m;lastMetaChecked=Date.now();$('title').textContent=m.title;document.title=m.title+'｜選手報名';
  $('entryCard').classList.toggle('hide',!m.open);msg(m.open?'報名開放中':'主辦尚未開放報名',!m.open);
 }catch(e){if(!signupSleeping){$('entryCard').classList.add('hide');msg(e.name==='AbortError'?'網路逾時，請重新開啟頁面':(e.message||'無法確認比賽資料'),true)}}
 finally{loadingMeta=false;if(resumeMetaAfterAbort&&!signupSleeping){resumeMetaAfterAbort=false;setTimeout(load,0)}}
}
function rid(){return Array.from(crypto.getRandomValues(new Uint8Array(24)),x=>x.toString(16).padStart(2,'0')).join('')}
async function idempotency(data){const raw=new TextEncoder().encode(JSON.stringify(data)),digest=await crypto.subtle.digest('SHA-256',raw),key=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');try{const v=JSON.parse(sessionStorage.getItem('reg-v06-request-'+eid)||'null');if(v?.hash===key&&/^[0-9a-f]{48}$/.test(v.rid))return v.rid}catch{}const r=rid();try{sessionStorage.setItem('reg-v06-request-'+eid,JSON.stringify({hash:key,rid:r}))}catch{}return r}
// The callable regV06Submit returns the current rank; the browser never downloads the roster.
$('signup').addEventListener('submit',async ev=>{
 ev.preventDefault();if(busy)return;const data={eid,playerName:$('playerName').value.trim(),phone3:$('phone3').value.trim(),lineName:$('lineName').value.trim()};
 if(!data.playerName||!/^\d{3}$/.test(data.phone3)||!data.lineName){msg('請完整填寫三個欄位',true);return}
 if(localSlotsLeft()<=0){msg('本瀏覽器這場比賽已成功報名 2 次，無法再送出。若需更改資料請聯絡主辦。',true);return}
 busy=true;$('submit').disabled=true;$('submit').textContent='等待雲端確認…';
 try{const requestId=await idempotency(data),ctl=new AbortController(),tm=setTimeout(()=>ctl.abort(),20000);let r;try{r=await fetch(FN,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data:{...data,rid:requestId}}),signal:ctl.signal})}finally{clearTimeout(tm)}const body=await r.json();if(!r.ok||body.error||!body.result?.signupNo)throw Error(body.error?.message||'報名未完成');saveLocalSignup(requestId);updateLocalHint();
 // Display server-confirmed success immediately. Final rank can change following review.
 const no=body.result.signupNo;
 $('rank').className='big rank '+BBX.rankClass(body.result.rankLabel);$('rank').textContent=body.result.rankLabel||('原始順位 #'+no+' · 順位稍後確認');$('details').innerHTML=`<div>📅 日期：${safe(meta.eventDate)}</div><div>🕘 報到：${safe(meta.checkinTime)}</div><div>🚀 開賽：${safe(meta.startTime)}</div><div>📍 地點：${safe(meta.venue)}</div><div>💰 報名費：${safe(meta.fee)} 元</div>`;$('modal').classList.remove('hide');$('signup').reset();try{sessionStorage.removeItem('reg-v06-request-'+eid)}catch{}msg('雲端已確認報名成功');
 }catch(e){msg((e.message||'目前無法確認報名')+'。如網路中斷，請保留原資料後再按一次，系統會使用相同提交憑證。',true)}finally{busy=false;$('submit').disabled=false;$('submit').textContent='確認報名'}
});
$('close').onclick=()=>$('modal').classList.add('hide');updateLocalHint();$('statusLink').href='https://bbxr-tamsui.web.app/q/'+encodeURIComponent(eid);function sleepSignup(){signupSleeping=true;signupReadPool.abort()}
function wakeSignup(){if(document.visibilityState!=='visible')return;signupSleeping=false;if(!busy)load()}
window.addEventListener('pageshow',e=>{if(e.persisted)wakeSignup()});
window.addEventListener('pagehide',sleepSignup);
document.addEventListener('visibilitychange',()=>document.visibilityState==='visible'?wakeSignup():sleepSignup());load();
