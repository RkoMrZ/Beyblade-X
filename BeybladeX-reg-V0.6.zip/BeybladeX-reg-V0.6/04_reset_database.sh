#!/usr/bin/env bash
# Global V03 reset DISABLED intentionally in V0.6.
# Per-event, owner-authorized legacy cleanup replaces deletion of entire old roots.
set -Eeuo pipefail
cd "$(dirname "$0")"
echo 'GLOBAL_LEGACY_RESET_DISABLED: do not delete V03/V04 roots.'
echo 'Use the organizer homepage > 檢查舊版活動資料 > 刪除舊資料; per-event owner verification is required.'
echo 'Unowned orphan records require a separately reviewed maintenance plan and explicit authorization.'
exit 2
